import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"];import { Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { CustomerLayout, Guard, StaffLayout, homeOf } from "/src/layouts.tsx";
import { useApp } from "/src/store.tsx";
import Login from "/src/pages/Login.tsx";
import Home from "/src/pages/Home.tsx";
import Booking from "/src/pages/Booking.tsx";
import Payment from "/src/pages/Payment.tsx";
import MyBookings from "/src/pages/MyBookings.tsx";
import StaffBooking from "/src/pages/StaffBooking.tsx";
import StaffOrders from "/src/pages/StaffOrders.tsx";
import StaffStats from "/src/pages/StaffStats.tsx";
import OwnerStaff from "/src/pages/OwnerStaff.tsx";
import OwnerCourts from "/src/pages/OwnerCourts.tsx";
import OwnerReports from "/src/pages/OwnerReports.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/App.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
export default function App() {
	_s();
	const { user } = useApp();
	return /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: user ? /* @__PURE__ */ _jsxDEV(Navigate, {
				to: homeOf(user.role),
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 44
			}, this) : /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 90
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			element: /* @__PURE__ */ _jsxDEV(Guard, { min: "customer" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 23
			}, this),
			children: /* @__PURE__ */ _jsxDEV(Route, {
				element: /* @__PURE__ */ _jsxDEV(CustomerLayout, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 25
				}, this),
				children: [
					/* @__PURE__ */ _jsxDEV(Route, {
						index: true,
						element: /* @__PURE__ */ _jsxDEV(Home, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 33
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "booking",
						element: /* @__PURE__ */ _jsxDEV(Booking, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 42
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "payment/:id",
						element: /* @__PURE__ */ _jsxDEV(Payment, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 46
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "my-bookings",
						element: /* @__PURE__ */ _jsxDEV(MyBookings, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 46
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			element: /* @__PURE__ */ _jsxDEV(Guard, { min: "staff" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 23
			}, this),
			children: /* @__PURE__ */ _jsxDEV(Route, {
				element: /* @__PURE__ */ _jsxDEV(StaffLayout, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 25
				}, this),
				children: [
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "staff/booking",
						element: /* @__PURE__ */ _jsxDEV(StaffBooking, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 48
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "staff/orders",
						element: /* @__PURE__ */ _jsxDEV(StaffOrders, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 47
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "staff/stats",
						element: /* @__PURE__ */ _jsxDEV(StaffStats, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 46
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						element: /* @__PURE__ */ _jsxDEV(Guard, { min: "owner" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 27
						}, this),
						children: [
							/* @__PURE__ */ _jsxDEV(Route, {
								path: "owner/staff",
								element: /* @__PURE__ */ _jsxDEV(OwnerStaff, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 38,
									columnNumber: 48
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 38,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Route, {
								path: "owner/courts",
								element: /* @__PURE__ */ _jsxDEV(OwnerCourts, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 39,
									columnNumber: 49
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 39,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Route, {
								path: "owner/reports",
								element: /* @__PURE__ */ _jsxDEV(OwnerReports, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 40,
									columnNumber: 50
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "*",
			element: /* @__PURE__ */ _jsxDEV(Navigate, {
				to: "/",
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 32
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
}
_s(App, "wcu15LqFo7VN7B41gOUPFXuvdlA=", false, function() {
	return [useApp];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLE9BQU8sY0FBYztBQUN4QyxTQUFTLGdCQUFnQixPQUFPLGFBQWEsY0FBYztBQUMzRCxTQUFTLGNBQWM7QUFDdkIsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sVUFBVTtBQUNqQixPQUFPLGFBQWE7QUFDcEIsT0FBTyxhQUFhO0FBQ3BCLE9BQU8sZ0JBQWdCO0FBQ3ZCLE9BQU8sa0JBQWtCO0FBQ3pCLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sZ0JBQWdCO0FBQ3ZCLE9BQU8sZ0JBQWdCO0FBQ3ZCLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sa0JBQWtCOzs7O0FBRXpCLGVBQWUsU0FBUyxNQUFNOztDQUM1QixNQUFNLEVBQUUsU0FBUyxPQUFPO0NBQ3hCLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQVMsU0FBUyxPQUFPLHdCQUFDLFVBQUQ7SUFBVSxJQUFJLE9BQU8sS0FBSyxJQUFJO0lBQUc7R0FBUzs7OztjQUFJLHdCQUFDLE9BQUQsQ0FBUTs7Ozs7RUFBSTs7Ozs7RUFFL0Ysd0JBQUMsT0FBRDtHQUFPLFNBQVMsd0JBQUMsT0FBRCxFQUFPLEtBQUksV0FBWTs7Ozs7YUFDckMsd0JBQUMsT0FBRDtJQUFPLFNBQVMsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O2NBQWpDO0tBQ0Usd0JBQUMsT0FBRDtNQUFPO01BQU0sU0FBUyx3QkFBQyxNQUFELENBQU87Ozs7O0tBQUk7Ozs7O0tBQ2pDLHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQVUsU0FBUyx3QkFBQyxTQUFELENBQVU7Ozs7O0tBQUk7Ozs7O0tBQzdDLHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQWMsU0FBUyx3QkFBQyxTQUFELENBQVU7Ozs7O0tBQUk7Ozs7O0tBQ2pELHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQWMsU0FBUyx3QkFBQyxZQUFELENBQWE7Ozs7O0tBQUk7Ozs7O0lBQy9DOzs7Ozs7RUFDRjs7Ozs7RUFFUCx3QkFBQyxPQUFEO0dBQU8sU0FBUyx3QkFBQyxPQUFELEVBQU8sS0FBSSxRQUFTOzs7OzthQUNsQyx3QkFBQyxPQUFEO0lBQU8sU0FBUyx3QkFBQyxhQUFELENBQWM7Ozs7O2NBQTlCO0tBQ0Usd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBZ0IsU0FBUyx3QkFBQyxjQUFELENBQWU7Ozs7O0tBQUk7Ozs7O0tBQ3hELHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQWUsU0FBUyx3QkFBQyxhQUFELENBQWM7Ozs7O0tBQUk7Ozs7O0tBQ3RELHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQWMsU0FBUyx3QkFBQyxZQUFELENBQWE7Ozs7O0tBQUk7Ozs7O0tBRXBELHdCQUFDLE9BQUQ7TUFBTyxTQUFTLHdCQUFDLE9BQUQsRUFBTyxLQUFJLFFBQVM7Ozs7O2dCQUFwQztPQUNFLHdCQUFDLE9BQUQ7UUFBTyxNQUFLO1FBQWMsU0FBUyx3QkFBQyxZQUFELENBQWE7Ozs7O09BQUk7Ozs7O09BQ3BELHdCQUFDLE9BQUQ7UUFBTyxNQUFLO1FBQWUsU0FBUyx3QkFBQyxhQUFELENBQWM7Ozs7O09BQUk7Ozs7O09BQ3RELHdCQUFDLE9BQUQ7UUFBTyxNQUFLO1FBQWdCLFNBQVMsd0JBQUMsY0FBRCxDQUFlOzs7OztPQUFJOzs7OztNQUNuRDs7Ozs7O0lBQ0Y7Ozs7OztFQUNGOzs7OztFQUNQLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQUksU0FBUyx3QkFBQyxVQUFEO0lBQVUsSUFBRztJQUFJO0dBQVM7Ozs7O0VBQUk7Ozs7O0NBQ2pEOzs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF2aWdhdGUsIFJvdXRlLCBSb3V0ZXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgQ3VzdG9tZXJMYXlvdXQsIEd1YXJkLCBTdGFmZkxheW91dCwgaG9tZU9mIH0gZnJvbSAnLi9sYXlvdXRzJ1xuaW1wb3J0IHsgdXNlQXBwIH0gZnJvbSAnLi9zdG9yZSdcbmltcG9ydCBMb2dpbiBmcm9tICcuL3BhZ2VzL0xvZ2luJ1xuaW1wb3J0IEhvbWUgZnJvbSAnLi9wYWdlcy9Ib21lJ1xuaW1wb3J0IEJvb2tpbmcgZnJvbSAnLi9wYWdlcy9Cb29raW5nJ1xuaW1wb3J0IFBheW1lbnQgZnJvbSAnLi9wYWdlcy9QYXltZW50J1xuaW1wb3J0IE15Qm9va2luZ3MgZnJvbSAnLi9wYWdlcy9NeUJvb2tpbmdzJ1xuaW1wb3J0IFN0YWZmQm9va2luZyBmcm9tICcuL3BhZ2VzL1N0YWZmQm9va2luZydcbmltcG9ydCBTdGFmZk9yZGVycyBmcm9tICcuL3BhZ2VzL1N0YWZmT3JkZXJzJ1xuaW1wb3J0IFN0YWZmU3RhdHMgZnJvbSAnLi9wYWdlcy9TdGFmZlN0YXRzJ1xuaW1wb3J0IE93bmVyU3RhZmYgZnJvbSAnLi9wYWdlcy9Pd25lclN0YWZmJ1xuaW1wb3J0IE93bmVyQ291cnRzIGZyb20gJy4vcGFnZXMvT3duZXJDb3VydHMnXG5pbXBvcnQgT3duZXJSZXBvcnRzIGZyb20gJy4vcGFnZXMvT3duZXJSZXBvcnRzJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXBwKClcbiAgcmV0dXJuIChcbiAgICA8Um91dGVzPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvbG9naW5cIiBlbGVtZW50PXt1c2VyID8gPE5hdmlnYXRlIHRvPXtob21lT2YodXNlci5yb2xlKX0gcmVwbGFjZSAvPiA6IDxMb2dpbiAvPn0gLz5cbiAgICAgIHsvKiBLaMOhY2ggaMOgbmcgKG5ow6JuIHZpw6puICYgY2jhu6cgc8OibiBr4bq/IHRo4burYSkgKi99XG4gICAgICA8Um91dGUgZWxlbWVudD17PEd1YXJkIG1pbj1cImN1c3RvbWVyXCIgLz59PlxuICAgICAgICA8Um91dGUgZWxlbWVudD17PEN1c3RvbWVyTGF5b3V0IC8+fT5cbiAgICAgICAgICA8Um91dGUgaW5kZXggZWxlbWVudD17PEhvbWUgLz59IC8+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCJib29raW5nXCIgZWxlbWVudD17PEJvb2tpbmcgLz59IC8+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCJwYXltZW50LzppZFwiIGVsZW1lbnQ9ezxQYXltZW50IC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwibXktYm9va2luZ3NcIiBlbGVtZW50PXs8TXlCb29raW5ncyAvPn0gLz5cbiAgICAgICAgPC9Sb3V0ZT5cbiAgICAgIDwvUm91dGU+XG4gICAgICB7LyogTmjDom4gdmnDqm4gKGNo4bunIHPDom4ga+G6vyB0aOG7q2EpICovfVxuICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxHdWFyZCBtaW49XCJzdGFmZlwiIC8+fT5cbiAgICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxTdGFmZkxheW91dCAvPn0+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCJzdGFmZi9ib29raW5nXCIgZWxlbWVudD17PFN0YWZmQm9va2luZyAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cInN0YWZmL29yZGVyc1wiIGVsZW1lbnQ9ezxTdGFmZk9yZGVycyAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cInN0YWZmL3N0YXRzXCIgZWxlbWVudD17PFN0YWZmU3RhdHMgLz59IC8+XG4gICAgICAgICAgey8qIENo4bunIHPDom4gKi99XG4gICAgICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxHdWFyZCBtaW49XCJvd25lclwiIC8+fT5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwib3duZXIvc3RhZmZcIiBlbGVtZW50PXs8T3duZXJTdGFmZiAvPn0gLz5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwib3duZXIvY291cnRzXCIgZWxlbWVudD17PE93bmVyQ291cnRzIC8+fSAvPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJvd25lci9yZXBvcnRzXCIgZWxlbWVudD17PE93bmVyUmVwb3J0cyAvPn0gLz5cbiAgICAgICAgICA8L1JvdXRlPlxuICAgICAgICA8L1JvdXRlPlxuICAgICAgPC9Sb3V0ZT5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiKlwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9cIiByZXBsYWNlIC8+fSAvPlxuICAgIDwvUm91dGVzPlxuICApXG59XG4iXX0=