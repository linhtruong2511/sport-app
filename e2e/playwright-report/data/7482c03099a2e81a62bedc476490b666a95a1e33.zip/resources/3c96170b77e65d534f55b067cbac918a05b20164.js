import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/StaffStats.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { TODAY, fmt, money, remaining, vnd } from "/src/data.ts";
import { useApp } from "/src/store.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/StaffStats.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
export default function StaffStats() {
	_s();
	const { user, bookings, courts, branches, locks, patchBooking, toast } = useApp();
	const nav = useNavigate();
	const branchId = user?.branchId ?? branches[0].id;
	const branch = branches.find((b) => b.id === branchId);
	const bCourts = courts.filter((c) => c.branchId === branchId);
	const todays = bookings.filter((b) => b.date === TODAY && bCourts.some((c) => c.id === b.courtId));
	const live = todays.filter((b) => b.status !== "cancelled");
	const online = live.filter((b) => b.source === "online").length;
	const playingIds = new Set(todays.filter((b) => b.status === "playing").map((b) => b.courtId));
	const lockToday = (id) => locks.find((l) => l.courtId === id && l.from.slice(0, 10) <= TODAY && l.to.slice(0, 10) >= TODAY);
	const maint = bCourts.filter((c) => lockToday(c.id)).length;
	const waitingPay = todays.filter((b) => b.status === "pending").length;
	const waitingPick = todays.filter((b) => b.status === "confirmed" || b.status === "overdue").length;
	const paidSum = (arr) => arr.reduce((s, b) => s + b.paid, 0);
	const revenue = paidSum(live) + todays.filter((b) => b.status === "cancelled").reduce((s, b) => s + (b.keptDeposit ?? 0), 0);
	const qrSum = paidSum(live.filter((b) => b.method === "qr")), cashSum = paidSum(live.filter((b) => b.method === "cash"));
	const full = live.filter((b) => b.paid >= b.total);
	const part = live.filter((b) => b.paid > 0 && b.paid < b.total);
	const kept = todays.filter((b) => b.status === "cancelled").reduce((s, b) => s + (b.keptDeposit ?? 0), 0);
	const soon = todays.filter((b) => b.status === "confirmed" && b.start >= "17:00").sort((a, b) => a.start.localeCompare(b.start)).slice(0, 2);
	const upcoming = [...soon, ...todays.filter((b) => b.status === "overdue")];
	const cName = (id) => courts.find((c) => c.id === id)?.name ?? "";
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
		className: "row g16",
		style: { alignItems: "stretch" },
		children: [
			/* @__PURE__ */ _jsxDEV(Stat, {
				label: "Tổng lượt đặt hôm nay",
				icon: "📅",
				bg: "var(--brand-100)",
				color: "var(--s900)",
				value: `${live.length} lượt đặt`,
				sub: `${online} đơn đặt online • ${live.length - online} đơn đặt tại quầy`
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Stat, {
				label: "Số sân đang có khách chơi",
				icon: "🟢",
				bg: "var(--brand-100)",
				color: "var(--brand-800)",
				value: `${playingIds.size} / ${bCourts.length} sân`,
				sub: `${bCourts.length - playingIds.size - maint} sân đang trống • ${maint} sân đang bảo trì`
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Stat, {
				label: "Đơn chờ nhận sân / tất toán",
				icon: "⏳",
				bg: "var(--amber-100)",
				color: "var(--amber-800)",
				value: `${waitingPay + waitingPick} đơn`,
				sub: `${waitingPay} đơn chờ chuyển khoản • ${waitingPick} đơn chờ nhận sân`
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "hero col g8 f1",
				style: {
					padding: 20,
					borderRadius: 16
				},
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "row between",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "t12 w700",
							style: { color: "var(--brand-100)" },
							children: "Doanh thu thực thu hôm nay"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 40
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "center t16 w800",
							style: {
								width: 36,
								height: 36,
								borderRadius: 12,
								background: "var(--brand-600)"
							},
							children: "₫"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 138
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "t24 w800",
						children: vnd(revenue)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "t12",
						style: { color: "var(--brand-100)" },
						children: [
							"Chuyển khoản: ",
							money(qrSum),
							" • Tiền mặt: ",
							money(cashSum)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "grid12",
		children: [/* @__PURE__ */ _jsxDEV("section", {
			className: "span7 card col g16",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "row between",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "t16 w800 c-ink",
						style: { lineHeight: "24px" },
						children: ["Tình trạng hoạt động các sân tại ", branch.name]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: "/staff/booking",
						className: "link-btn",
						children: "+ Đặt sân mới tại quầy →"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					style: {
						display: "grid",
						gridTemplateColumns: "1fr 1fr",
						gap: 12
					},
					children: bCourts.map((c) => {
						const lk = lockToday(c.id);
						const bk = todays.find((b) => b.courtId === c.id && b.status === "playing");
						const next = todays.filter((b) => b.courtId === c.id && (b.status === "confirmed" || b.status === "overdue")).sort((a, b) => a.start.localeCompare(b.start))[0];
						const base = {
							borderRadius: 12,
							padding: 14,
							minHeight: 80,
							display: "flex",
							alignItems: "center",
							justifyContent: "space-between",
							gap: 8
						};
						if (lk) return /* @__PURE__ */ _jsxDEV("div", {
							style: {
								...base,
								background: "var(--s200)",
								border: "1px solid var(--s300)"
							},
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "col",
								children: [
									/* @__PURE__ */ _jsxDEV("b", {
										className: "t12 c-s800 w800",
										children: c.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 57,
										columnNumber: 40
									}, this),
									/* @__PURE__ */ _jsxDEV("b", {
										className: "t12 c-s700",
										children: "🔒 Đang bảo trì mặt sân"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 57,
										columnNumber: 83
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "t11 c-s600",
										children: [
											lk.from.slice(8, 10),
											"/",
											lk.from.slice(5, 7),
											" ",
											lk.from.slice(11),
											" – ",
											lk.to.slice(8, 10),
											"/",
											lk.to.slice(5, 7),
											" ",
											lk.to.slice(11)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 57,
										columnNumber: 136
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "badge sq c-white",
								style: {
									background: "var(--s500)",
									fontSize: 10
								},
								children: "Tạm khóa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 58,
								columnNumber: 19
							}, this)]
						}, c.id, true, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 17
						}, this);
						if (bk) return /* @__PURE__ */ _jsxDEV("div", {
							style: {
								...base,
								background: "rgba(236,253,245,.7)",
								border: "2px solid var(--brand-500)"
							},
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "col",
								children: [
									/* @__PURE__ */ _jsxDEV("b", {
										className: "t12 c-ink w800",
										children: c.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 62,
										columnNumber: 40
									}, this),
									/* @__PURE__ */ _jsxDEV("b", {
										className: "t12 c-brand9",
										children: ["Đang sử dụng • #", bk.id]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 62,
										columnNumber: 82
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "t11 c-s600",
										children: [
											"Khách: ",
											bk.customer,
											" • Hết giờ: ",
											bk.end
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 62,
										columnNumber: 137
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "badge sq c-white",
								style: {
									background: remaining(bk) === 0 ? "var(--brand-700)" : "var(--amber-800)",
									fontSize: 10
								},
								children: remaining(bk) === 0 ? "Đã thu đủ" : "Còn thiếu"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 19
							}, this)]
						}, c.id, true, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 17
						}, this);
						return /* @__PURE__ */ _jsxDEV("div", {
							style: {
								...base,
								background: "#fff",
								border: "1px solid var(--s300)"
							},
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "col",
								children: [
									/* @__PURE__ */ _jsxDEV("b", {
										className: "t12 c-ink w800",
										children: c.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 67,
										columnNumber: 40
									}, this),
									/* @__PURE__ */ _jsxDEV("b", {
										className: "t12 c-brand",
										children: "Đang trống khung hiện tại"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 67,
										columnNumber: 82
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "t11 c-s600",
										children: next ? `Có lịch khách đặt lúc ${next.start} (#BK${next.id.slice(-4)})` : "Chưa có lịch tiếp theo hôm nay"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 68,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 67,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-primary btn-sm",
								style: { fontSize: 11 },
								onClick: () => nav("/staff/booking"),
								children: "Lập đơn"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 19
							}, this)]
						}, c.id, true, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "hint col g8",
					style: { padding: 16 },
					children: [/* @__PURE__ */ _jsxDEV("b", {
						className: "c-ink",
						children: [
							"Chi tiết tiền thực thu trong ca hôm nay (",
							vnd(revenue),
							"):"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "row g12",
						style: { paddingTop: 4 },
						children: [
							[
								"Đơn đã thu đủ 100%:",
								paidSum(full),
								"c-ink"
							],
							[
								"Tiền cọc mới thu hôm nay:",
								paidSum(part),
								"c-brand"
							],
							[
								"Tiền cọc đơn hủy giữ lại:",
								kept,
								"c-amber"
							]
						].map(([k, v, c]) => /* @__PURE__ */ _jsxDEV("div", {
							className: "f1 col",
							style: {
								background: "#fff",
								border: "1px solid var(--s300)",
								borderRadius: 8,
								padding: 12
							},
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s500",
								children: k
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 143
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: `t14 w800 ${c}`,
								children: [fmt(v), " VNĐ"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 178
							}, this)]
						}, k, true, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("section", {
			className: "span5 card col g16",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "row between head-rule",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "col",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "t16 w800 c-ink",
						style: { lineHeight: "24px" },
						children: "Lịch khách sắp đến nhận sân"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 34
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "t12 c-s600",
						children: "Các đơn bắt đầu trong vòng 60 phút tới"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 128
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: "/staff/orders",
					className: "link-btn",
					children: "Xem toàn bộ →"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 84,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "col g12",
				children: [upcoming.length === 0 && /* @__PURE__ */ _jsxDEV("div", {
					className: "hint",
					style: {
						textAlign: "center",
						padding: 24
					},
					children: "Hiện không có đơn nào sắp đến giờ nhận sân."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 39
				}, this), upcoming.slice(0, 4).map((b) => {
					const rem = remaining(b), late = b.status === "overdue";
					const tone = late ? {
						bg: "var(--rose-50)",
						bd: "2px solid var(--rose-300)",
						chip: "var(--rose-200)",
						cc: "var(--rose-950)",
						t: "Khách trễ 30 phút"
					} : rem > 0 ? {
						bg: "var(--amber-50)",
						bd: "2px solid var(--amber-400)",
						chip: "var(--amber-200)",
						cc: "var(--amber-950)",
						t: `Cần thu thêm ${money(rem)}`
					} : {
						bg: "var(--s50)",
						bd: "1px solid var(--s300)",
						chip: "var(--brand-100)",
						cc: "var(--brand-900)",
						t: `Đã thanh toán đủ ${money(b.total)}`
					};
					return /* @__PURE__ */ _jsxDEV("div", {
						className: "col g8",
						style: {
							background: tone.bg,
							border: tone.bd,
							borderRadius: 12,
							padding: 16
						},
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "row between g8",
								children: [/* @__PURE__ */ _jsxDEV("b", {
									className: "t12 c-ink w800",
									children: [
										"#",
										b.id,
										" • ",
										cName(b.courtId)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 97,
									columnNumber: 51
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "badge sq",
									style: {
										background: tone.chip,
										color: tone.cc,
										padding: "2px 10px"
									},
									children: tone.t
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 97,
									columnNumber: 113
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "t12 c-s700",
								children: [
									"Khách: ",
									/* @__PURE__ */ _jsxDEV("b", { children: [
										b.customer,
										" (",
										b.phone,
										")"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 52
									}, this),
									late ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
										" • Đã đặt cọc ",
										money(b.paid),
										" nhưng chưa đến nhận sân."
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 91
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [" • Giờ chơi: ", /* @__PURE__ */ _jsxDEV("b", { children: [
										b.start,
										" - ",
										b.end
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 168
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 153
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "row",
								style: { justifyContent: "flex-end" },
								children: late ? /* @__PURE__ */ _jsxDEV("button", {
									className: "btn btn-danger btn-sm",
									style: { padding: "6px 14px" },
									onClick: () => nav("/staff/orders"),
									children: "Hủy lịch & Mở sân"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 100,
									columnNumber: 29
								}, this) : rem > 0 ? /* @__PURE__ */ _jsxDEV("button", {
									className: "btn btn-primary btn-sm",
									style: { padding: "6px 14px" },
									onClick: () => nav("/staff/orders"),
									children: "Thu tiền & Giao sân"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 101,
									columnNumber: 35
								}, this) : /* @__PURE__ */ _jsxDEV("button", {
									className: "btn btn-primary btn-sm",
									style: { padding: "6px 14px" },
									onClick: () => {
										patchBooking(b.id, { status: "playing" });
										toast(`Đã giao ${cName(b.courtId)} cho khách.`, "ok");
									},
									children: "Giao sân ngay"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 102,
									columnNumber: 27
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 19
							}, this)
						]
					}, b.id, true, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 17
					}, this);
				})]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 83,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
}
_s(StaffStats, "vmGe7Bq2ZierRIdsrnF3zk95nvg=", false, function() {
	return [useApp, useNavigate];
});
_c = StaffStats;
function Stat({ label, icon, bg, color, value, sub }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "card col g8 f1",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "row between",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "t12 w700 c-s600",
					children: label
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 36
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "center t16 w700",
					style: {
						width: 36,
						height: 36,
						borderRadius: 12,
						background: bg,
						color
					},
					children: icon
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 84
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "t24 w800",
				style: { color },
				children: value
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "t12 c-s600",
				children: sub
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 116,
		columnNumber: 5
	}, this);
}
_c2 = Stat;
var _c, _c2;
$RefreshReg$(_c, "StaffStats");
$RefreshReg$(_c2, "Stat");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/StaffStats.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/StaffStats.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/StaffStats.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/StaffStats.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLE9BQU8sS0FBSyxPQUFPLFdBQVcsV0FBVztBQUVsRCxTQUFTLGNBQWM7Ozs7QUFFdkIsZUFBZSxTQUFTLGFBQWE7O0NBQ25DLE1BQU0sRUFBRSxNQUFNLFVBQVUsUUFBUSxVQUFVLE9BQU8sY0FBYyxVQUFVLE9BQU87Q0FDaEYsTUFBTSxNQUFNLFlBQVk7Q0FDeEIsTUFBTSxXQUFXLE1BQU0sWUFBWSxTQUFTLEVBQUUsQ0FBQztDQUMvQyxNQUFNLFNBQVMsU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLFFBQVE7Q0FDckQsTUFBTSxVQUFVLE9BQU8sUUFBUSxNQUFNLEVBQUUsYUFBYSxRQUFRO0NBQzVELE1BQU0sU0FBUyxTQUFTLFFBQVEsTUFBTSxFQUFFLFNBQVMsU0FBUyxRQUFRLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUM7Q0FDakcsTUFBTSxPQUFPLE9BQU8sUUFBUSxNQUFNLEVBQUUsV0FBVyxXQUFXO0NBQzFELE1BQU0sU0FBUyxLQUFLLFFBQVEsTUFBTSxFQUFFLFdBQVcsUUFBUSxDQUFDLENBQUM7Q0FDekQsTUFBTSxhQUFhLElBQUksSUFBSSxPQUFPLFFBQVEsTUFBTSxFQUFFLFdBQVcsU0FBUyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUUsT0FBTyxDQUFDO0NBQzdGLE1BQU0sYUFBYSxPQUFlLE1BQU0sTUFBTSxNQUFNLEVBQUUsWUFBWSxNQUFNLEVBQUUsS0FBSyxNQUFNLEdBQUcsRUFBRSxLQUFLLFNBQVMsRUFBRSxHQUFHLE1BQU0sR0FBRyxFQUFFLEtBQUssS0FBSztDQUNsSSxNQUFNLFFBQVEsUUFBUSxRQUFRLE1BQU0sVUFBVSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7Q0FDckQsTUFBTSxhQUFhLE9BQU8sUUFBUSxNQUFNLEVBQUUsV0FBVyxTQUFTLENBQUMsQ0FBQztDQUNoRSxNQUFNLGNBQWMsT0FBTyxRQUFRLE1BQU0sRUFBRSxXQUFXLGVBQWUsRUFBRSxXQUFXLFNBQVMsQ0FBQyxDQUFDO0NBQzdGLE1BQU0sV0FBVyxRQUFtQixJQUFJLFFBQVEsR0FBRyxNQUFNLElBQUksRUFBRSxNQUFNLENBQUM7Q0FDdEUsTUFBTSxVQUFVLFFBQVEsSUFBSSxJQUFJLE9BQU8sUUFBUSxNQUFNLEVBQUUsV0FBVyxXQUFXLENBQUMsQ0FBQyxRQUFRLEdBQUcsTUFBTSxLQUFLLEVBQUUsZUFBZSxJQUFJLENBQUM7Q0FDM0gsTUFBTSxRQUFRLFFBQVEsS0FBSyxRQUFRLE1BQU0sRUFBRSxXQUFXLElBQUksQ0FBQyxHQUFHLFVBQVUsUUFBUSxLQUFLLFFBQVEsTUFBTSxFQUFFLFdBQVcsTUFBTSxDQUFDO0NBQ3ZILE1BQU0sT0FBTyxLQUFLLFFBQVEsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFLO0NBQ2pELE1BQU0sT0FBTyxLQUFLLFFBQVEsTUFBTSxFQUFFLE9BQU8sS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLO0NBQzlELE1BQU0sT0FBTyxPQUFPLFFBQVEsTUFBTSxFQUFFLFdBQVcsV0FBVyxDQUFDLENBQUMsUUFBUSxHQUFHLE1BQU0sS0FBSyxFQUFFLGVBQWUsSUFBSSxDQUFDO0NBQ3hHLE1BQU0sT0FBTyxPQUFPLFFBQVEsTUFBTSxFQUFFLFdBQVcsZUFBZSxFQUFFLFNBQVMsT0FBTyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sRUFBRSxNQUFNLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDO0NBQzNJLE1BQU0sV0FBVyxDQUFDLEdBQUcsTUFBTSxHQUFHLE9BQU8sUUFBUSxNQUFNLEVBQUUsV0FBVyxTQUFTLENBQUM7Q0FDMUUsTUFBTSxTQUFTLE9BQWUsT0FBTyxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFFBQVE7Q0FFdkUsT0FDRSxnREFDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFVLE9BQU8sRUFBRSxZQUFZLFVBQVU7WUFBeEQ7R0FDRSx3QkFBQyxNQUFEO0lBQU0sT0FBTTtJQUF3QixNQUFLO0lBQUssSUFBRztJQUFtQixPQUFNO0lBQWMsT0FBTyxHQUFHLEtBQUssT0FBTztJQUFZLEtBQUssR0FBRyxPQUFPLG9CQUFvQixLQUFLLFNBQVMsT0FBTztHQUFxQjs7Ozs7R0FDdk0sd0JBQUMsTUFBRDtJQUFNLE9BQU07SUFBNEIsTUFBSztJQUFLLElBQUc7SUFBbUIsT0FBTTtJQUFtQixPQUFPLEdBQUcsV0FBVyxLQUFLLEtBQUssUUFBUSxPQUFPO0lBQU8sS0FBSyxHQUFHLFFBQVEsU0FBUyxXQUFXLE9BQU8sTUFBTSxvQkFBb0IsTUFBTTtHQUFxQjs7Ozs7R0FDdFAsd0JBQUMsTUFBRDtJQUFNLE9BQU07SUFBOEIsTUFBSztJQUFJLElBQUc7SUFBbUIsT0FBTTtJQUFtQixPQUFPLEdBQUcsYUFBYSxZQUFZO0lBQU8sS0FBSyxHQUFHLFdBQVcsMEJBQTBCLFlBQVk7R0FBcUI7Ozs7O0dBQzFOLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQWlCLE9BQU87S0FBRSxTQUFTO0tBQUksY0FBYztJQUFHO2NBQXZFO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBNkIsd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBVyxPQUFPLEVBQUUsT0FBTyxtQkFBbUI7aUJBQUc7TUFBZ0M7Ozs7Z0JBQUMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBa0IsT0FBTztRQUFFLE9BQU87UUFBSSxRQUFRO1FBQUksY0FBYztRQUFJLFlBQVk7T0FBbUI7aUJBQUc7TUFBTzs7OztjQUFNOzs7Ozs7S0FDbFEsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQVksSUFBSSxPQUFPO0tBQU87Ozs7O0tBQzdDLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO01BQU0sT0FBTyxFQUFFLE9BQU8sbUJBQW1CO2dCQUF0RDtPQUF5RDtPQUFlLE1BQU0sS0FBSztPQUFFO09BQWMsTUFBTSxPQUFPO01BQUs7Ozs7OztJQUNsSDs7Ozs7O0VBQ0Y7Ozs7O1dBRUwsd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO01BQWlCLE9BQU8sRUFBRSxZQUFZLE9BQU87Z0JBQTNELENBQThELHFDQUFrQyxPQUFPLElBQVM7Ozs7O2VBQ2hILHdCQUFDLE1BQUQ7TUFBTSxJQUFHO01BQWlCLFdBQVU7Z0JBQVc7S0FBOEI7Ozs7YUFDMUU7Ozs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxPQUFPO01BQUUsU0FBUztNQUFRLHFCQUFxQjtNQUFXLEtBQUs7S0FBRztlQUNwRSxRQUFRLEtBQUssTUFBTTtNQUNsQixNQUFNLEtBQUssVUFBVSxFQUFFLEVBQUU7TUFDekIsTUFBTSxLQUFLLE9BQU8sTUFBTSxNQUFNLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxXQUFXLFNBQVM7TUFDMUUsTUFBTSxPQUFPLE9BQU8sUUFBUSxNQUFNLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxXQUFXLGVBQWUsRUFBRSxXQUFXLFVBQVUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsTUFBTSxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztNQUM3SixNQUFNLE9BQU87T0FBRSxjQUFjO09BQUksU0FBUztPQUFJLFdBQVc7T0FBSSxTQUFTO09BQVEsWUFBWTtPQUFVLGdCQUFnQjtPQUFpQixLQUFLO01BQUU7TUFDNUksSUFBSSxJQUFJLE9BQ04sd0JBQUMsT0FBRDtPQUFnQixPQUFPO1FBQUUsR0FBRztRQUFNLFlBQVk7UUFBZSxRQUFRO09BQXdCO2lCQUE3RixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQXFCLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFtQixFQUFFO1NBQVE7Ozs7O1NBQUMsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWE7U0FBMEI7Ozs7O1NBQUMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQThCLEdBQUcsS0FBSyxNQUFNLEdBQUcsRUFBRTtXQUFFO1dBQUUsR0FBRyxLQUFLLE1BQU0sR0FBRyxDQUFDO1dBQUU7V0FBRSxHQUFHLEtBQUssTUFBTSxFQUFFO1dBQUU7V0FBSSxHQUFHLEdBQUcsTUFBTSxHQUFHLEVBQUU7V0FBRTtXQUFFLEdBQUcsR0FBRyxNQUFNLEdBQUcsQ0FBQztXQUFFO1dBQUUsR0FBRyxHQUFHLE1BQU0sRUFBRTtVQUFROzs7Ozs7UUFBTTs7Ozs7aUJBQzNSLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO1FBQW1CLE9BQU87U0FBRSxZQUFZO1NBQWUsVUFBVTtRQUFHO2tCQUFHO09BQWM7Ozs7ZUFDbEc7U0FISyxFQUFFOzs7O2FBR1A7TUFDUCxJQUFJLElBQUksT0FDTix3QkFBQyxPQUFEO09BQWdCLE9BQU87UUFBRSxHQUFHO1FBQU0sWUFBWTtRQUF3QixRQUFRO09BQTZCO2lCQUEzRyxDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQXFCLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFrQixFQUFFO1NBQVE7Ozs7O1NBQUMsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWIsQ0FBNEIsb0JBQWlCLEdBQUcsRUFBTTs7Ozs7O1NBQUMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQTZCO1dBQVEsR0FBRztXQUFTO1dBQWEsR0FBRztVQUFVOzs7Ozs7UUFBTTs7Ozs7aUJBQ3ZNLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO1FBQW1CLE9BQU87U0FBRSxZQUFZLFVBQVUsRUFBRSxNQUFNLElBQUkscUJBQXFCO1NBQW9CLFVBQVU7UUFBRztrQkFBSSxVQUFVLEVBQUUsTUFBTSxJQUFJLGNBQWM7T0FBa0I7Ozs7ZUFDM0w7U0FISyxFQUFFOzs7O2FBR1A7TUFDUCxPQUNFLHdCQUFDLE9BQUQ7T0FBZ0IsT0FBTztRQUFFLEdBQUc7UUFBTSxZQUFZO1FBQVEsUUFBUTtPQUF3QjtpQkFBdEYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUFxQix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBa0IsRUFBRTtTQUFROzs7OztTQUFDLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFjO1NBQTRCOzs7OztTQUNwSCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBYyxPQUFPLHlCQUF5QixLQUFLLE1BQU0sT0FBTyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsRUFBRSxLQUFLO1NBQXVDOzs7OztRQUFNOzs7OztpQkFDdEosd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBeUIsT0FBTyxFQUFFLFVBQVUsR0FBRztRQUFHLGVBQWUsSUFBSSxnQkFBZ0I7a0JBQUc7T0FBZTs7OztlQUN0SDtTQUpLLEVBQUU7Ozs7YUFJUDtLQUNULENBQUM7SUFDRTs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFjLE9BQU8sRUFBRSxTQUFTLEdBQUc7ZUFBbEQsQ0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUFxQjtPQUEwQyxJQUFJLE9BQU87T0FBRTtNQUFLOzs7OztlQUNqRix3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFVLE9BQU8sRUFBRSxZQUFZLEVBQUU7Z0JBQzVDO09BQUM7UUFBQztRQUF1QixRQUFRLElBQUk7UUFBRztPQUFPO09BQUc7UUFBQztRQUE2QixRQUFRLElBQUk7UUFBRztPQUFTO09BQUc7UUFBQztRQUE2QjtRQUFNO09BQVM7TUFBQyxDQUFDLENBQVcsS0FBSyxDQUFDLEdBQUcsR0FBRyxPQUNqTCx3QkFBQyxPQUFEO09BQWEsV0FBVTtPQUFTLE9BQU87UUFBRSxZQUFZO1FBQVEsUUFBUTtRQUF5QixjQUFjO1FBQUcsU0FBUztPQUFHO2lCQUEzSCxDQUE4SCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBVTtPQUFROzs7O2lCQUFDLHdCQUFDLEtBQUQ7UUFBRyxXQUFXLFlBQVk7a0JBQTFCLENBQWdDLElBQUksQ0FBQyxHQUFFLE1BQU87Ozs7O2VBQU07U0FBM007Ozs7YUFBMk0sQ0FDdE47S0FDRTs7OzthQUNGOzs7Ozs7R0FDRTs7Ozs7WUFFVCx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQXFCLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO01BQWlCLE9BQU8sRUFBRSxZQUFZLE9BQU87Z0JBQUc7S0FBK0I7Ozs7ZUFBQyx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYTtLQUF5Qzs7OzthQUFNOzs7OztjQUM1TCx3QkFBQyxNQUFEO0tBQU0sSUFBRztLQUFnQixXQUFVO2VBQVc7SUFBbUI7Ozs7WUFDOUQ7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNHLFNBQVMsV0FBVyxLQUFLLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQU8sT0FBTztNQUFFLFdBQVc7TUFBVSxTQUFTO0tBQUc7ZUFBRztJQUFnRDs7OztjQUM1SSxTQUFTLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU07S0FDL0IsTUFBTSxNQUFNLFVBQVUsQ0FBQyxHQUFHLE9BQU8sRUFBRSxXQUFXO0tBQzlDLE1BQU0sT0FBTyxPQUFPO01BQUUsSUFBSTtNQUFrQixJQUFJO01BQTZCLE1BQU07TUFBbUIsSUFBSTtNQUFtQixHQUFHO0tBQW9CLElBQ2hKLE1BQU0sSUFBSTtNQUFFLElBQUk7TUFBbUIsSUFBSTtNQUE4QixNQUFNO01BQW9CLElBQUk7TUFBb0IsR0FBRyxnQkFBZ0IsTUFBTSxHQUFHO0tBQUksSUFDcko7TUFBRSxJQUFJO01BQWMsSUFBSTtNQUF5QixNQUFNO01BQW9CLElBQUk7TUFBb0IsR0FBRyxvQkFBb0IsTUFBTSxFQUFFLEtBQUs7S0FBSTtLQUNqSixPQUNFLHdCQUFDLE9BQUQ7TUFBZ0IsV0FBVTtNQUFTLE9BQU87T0FBRSxZQUFZLEtBQUs7T0FBSSxRQUFRLEtBQUs7T0FBSSxjQUFjO09BQUksU0FBUztNQUFHO2dCQUFoSDtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQWdDLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQThCO1VBQUUsRUFBRTtVQUFHO1VBQUksTUFBTSxFQUFFLE9BQU87U0FBSzs7Ozs7a0JBQUMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7U0FBVyxPQUFPO1VBQUUsWUFBWSxLQUFLO1VBQU0sT0FBTyxLQUFLO1VBQUksU0FBUztTQUFXO21CQUFJLEtBQUs7UUFBUTs7OztnQkFBTTs7Ozs7O09BQ3BOLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQTBCO1NBQU8sd0JBQUMsS0FBRDtVQUFJLEVBQUU7VUFBUztVQUFHLEVBQUU7VUFBTTtTQUFJOzs7OztTQUFFLE9BQU87VUFBRTtVQUFlLE1BQU0sRUFBRSxJQUFJO1VBQUU7U0FBMkI7Ozs7b0JBQUksZ0RBQUUsaUJBQWEsd0JBQUMsS0FBRDtVQUFJLEVBQUU7VUFBTTtVQUFJLEVBQUU7U0FBTzs7OztpQkFBRzs7Ozs7UUFBSzs7Ozs7O09BQ3RMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQU0sT0FBTyxFQUFFLGdCQUFnQixXQUFXO2tCQUN0RCxPQUFPLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO1NBQXdCLE9BQU8sRUFBRSxTQUFTLFdBQVc7U0FBRyxlQUFlLElBQUksZUFBZTttQkFBRztRQUF5Qjs7OzttQkFDNUksTUFBTSxJQUFJLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO1NBQXlCLE9BQU8sRUFBRSxTQUFTLFdBQVc7U0FBRyxlQUFlLElBQUksZUFBZTttQkFBRztRQUEyQjs7OzttQkFDbkosd0JBQUMsVUFBRDtTQUFRLFdBQVU7U0FBeUIsT0FBTyxFQUFFLFNBQVMsV0FBVztTQUFHLGVBQWU7VUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFFBQVEsVUFBVSxDQUFDO1VBQUcsTUFBTSxXQUFXLE1BQU0sRUFBRSxPQUFPLEVBQUUsY0FBYyxJQUFJO1NBQUU7bUJBQUc7UUFBcUI7Ozs7O09BQ3hOOzs7OztNQUNGO1FBUkssRUFBRTs7OztZQVFQO0lBRVQsQ0FBQyxDQUNFOzs7OztXQUNFOzs7OztVQUNOOzs7OztTQUNMOzs7OztBQUVOOzs7OztBQUVBLFNBQVMsS0FBSyxFQUFFLE9BQU8sTUFBTSxJQUFJLE9BQU8sT0FBTyxPQUErRjtDQUM1SSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQTZCLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQW1CO0lBQVk7Ozs7Y0FBQyx3QkFBQyxRQUFEO0tBQU0sV0FBVTtLQUFrQixPQUFPO01BQUUsT0FBTztNQUFJLFFBQVE7TUFBSSxjQUFjO01BQUksWUFBWTtNQUFJO0tBQU07ZUFBSTtJQUFXOzs7O1lBQU07Ozs7OztHQUM1TSx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFXLE9BQU8sRUFBRSxNQUFNO2NBQUk7R0FBVzs7Ozs7R0FDeEQsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYztHQUFPOzs7OztFQUMvQjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3RhZmZTdGF0cy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgVE9EQVksIGZtdCwgbW9uZXksIHJlbWFpbmluZywgdm5kIH0gZnJvbSAnLi4vZGF0YSdcbmltcG9ydCB0eXBlIHsgQm9va2luZyB9IGZyb20gJy4uL2RhdGEnXG5pbXBvcnQgeyB1c2VBcHAgfSBmcm9tICcuLi9zdG9yZSdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU3RhZmZTdGF0cygpIHtcbiAgY29uc3QgeyB1c2VyLCBib29raW5ncywgY291cnRzLCBicmFuY2hlcywgbG9ja3MsIHBhdGNoQm9va2luZywgdG9hc3QgfSA9IHVzZUFwcCgpXG4gIGNvbnN0IG5hdiA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgYnJhbmNoSWQgPSB1c2VyPy5icmFuY2hJZCA/PyBicmFuY2hlc1swXS5pZFxuICBjb25zdCBicmFuY2ggPSBicmFuY2hlcy5maW5kKChiKSA9PiBiLmlkID09PSBicmFuY2hJZCkhXG4gIGNvbnN0IGJDb3VydHMgPSBjb3VydHMuZmlsdGVyKChjKSA9PiBjLmJyYW5jaElkID09PSBicmFuY2hJZClcbiAgY29uc3QgdG9kYXlzID0gYm9va2luZ3MuZmlsdGVyKChiKSA9PiBiLmRhdGUgPT09IFRPREFZICYmIGJDb3VydHMuc29tZSgoYykgPT4gYy5pZCA9PT0gYi5jb3VydElkKSlcbiAgY29uc3QgbGl2ZSA9IHRvZGF5cy5maWx0ZXIoKGIpID0+IGIuc3RhdHVzICE9PSAnY2FuY2VsbGVkJylcbiAgY29uc3Qgb25saW5lID0gbGl2ZS5maWx0ZXIoKGIpID0+IGIuc291cmNlID09PSAnb25saW5lJykubGVuZ3RoXG4gIGNvbnN0IHBsYXlpbmdJZHMgPSBuZXcgU2V0KHRvZGF5cy5maWx0ZXIoKGIpID0+IGIuc3RhdHVzID09PSAncGxheWluZycpLm1hcCgoYikgPT4gYi5jb3VydElkKSlcbiAgY29uc3QgbG9ja1RvZGF5ID0gKGlkOiBzdHJpbmcpID0+IGxvY2tzLmZpbmQoKGwpID0+IGwuY291cnRJZCA9PT0gaWQgJiYgbC5mcm9tLnNsaWNlKDAsIDEwKSA8PSBUT0RBWSAmJiBsLnRvLnNsaWNlKDAsIDEwKSA+PSBUT0RBWSlcbiAgY29uc3QgbWFpbnQgPSBiQ291cnRzLmZpbHRlcigoYykgPT4gbG9ja1RvZGF5KGMuaWQpKS5sZW5ndGhcbiAgY29uc3Qgd2FpdGluZ1BheSA9IHRvZGF5cy5maWx0ZXIoKGIpID0+IGIuc3RhdHVzID09PSAncGVuZGluZycpLmxlbmd0aFxuICBjb25zdCB3YWl0aW5nUGljayA9IHRvZGF5cy5maWx0ZXIoKGIpID0+IGIuc3RhdHVzID09PSAnY29uZmlybWVkJyB8fCBiLnN0YXR1cyA9PT0gJ292ZXJkdWUnKS5sZW5ndGhcbiAgY29uc3QgcGFpZFN1bSA9IChhcnI6IEJvb2tpbmdbXSkgPT4gYXJyLnJlZHVjZSgocywgYikgPT4gcyArIGIucGFpZCwgMClcbiAgY29uc3QgcmV2ZW51ZSA9IHBhaWRTdW0obGl2ZSkgKyB0b2RheXMuZmlsdGVyKChiKSA9PiBiLnN0YXR1cyA9PT0gJ2NhbmNlbGxlZCcpLnJlZHVjZSgocywgYikgPT4gcyArIChiLmtlcHREZXBvc2l0ID8/IDApLCAwKVxuICBjb25zdCBxclN1bSA9IHBhaWRTdW0obGl2ZS5maWx0ZXIoKGIpID0+IGIubWV0aG9kID09PSAncXInKSksIGNhc2hTdW0gPSBwYWlkU3VtKGxpdmUuZmlsdGVyKChiKSA9PiBiLm1ldGhvZCA9PT0gJ2Nhc2gnKSlcbiAgY29uc3QgZnVsbCA9IGxpdmUuZmlsdGVyKChiKSA9PiBiLnBhaWQgPj0gYi50b3RhbClcbiAgY29uc3QgcGFydCA9IGxpdmUuZmlsdGVyKChiKSA9PiBiLnBhaWQgPiAwICYmIGIucGFpZCA8IGIudG90YWwpXG4gIGNvbnN0IGtlcHQgPSB0b2RheXMuZmlsdGVyKChiKSA9PiBiLnN0YXR1cyA9PT0gJ2NhbmNlbGxlZCcpLnJlZHVjZSgocywgYikgPT4gcyArIChiLmtlcHREZXBvc2l0ID8/IDApLCAwKVxuICBjb25zdCBzb29uID0gdG9kYXlzLmZpbHRlcigoYikgPT4gYi5zdGF0dXMgPT09ICdjb25maXJtZWQnICYmIGIuc3RhcnQgPj0gJzE3OjAwJykuc29ydCgoYSwgYikgPT4gYS5zdGFydC5sb2NhbGVDb21wYXJlKGIuc3RhcnQpKS5zbGljZSgwLCAyKVxuICBjb25zdCB1cGNvbWluZyA9IFsuLi5zb29uLCAuLi50b2RheXMuZmlsdGVyKChiKSA9PiBiLnN0YXR1cyA9PT0gJ292ZXJkdWUnKV1cbiAgY29uc3QgY05hbWUgPSAoaWQ6IHN0cmluZykgPT4gY291cnRzLmZpbmQoKGMpID0+IGMuaWQgPT09IGlkKT8ubmFtZSA/PyAnJ1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGcxNlwiIHN0eWxlPXt7IGFsaWduSXRlbXM6ICdzdHJldGNoJyB9fT5cbiAgICAgICAgPFN0YXQgbGFiZWw9XCJU4buVbmcgbMaw4bujdCDEkeG6t3QgaMO0bSBuYXlcIiBpY29uPVwi8J+ThVwiIGJnPVwidmFyKC0tYnJhbmQtMTAwKVwiIGNvbG9yPVwidmFyKC0tczkwMClcIiB2YWx1ZT17YCR7bGl2ZS5sZW5ndGh9IGzGsOG7o3QgxJHhurd0YH0gc3ViPXtgJHtvbmxpbmV9IMSRxqFuIMSR4bq3dCBvbmxpbmUg4oCiICR7bGl2ZS5sZW5ndGggLSBvbmxpbmV9IMSRxqFuIMSR4bq3dCB04bqhaSBxdeG6p3lgfSAvPlxuICAgICAgICA8U3RhdCBsYWJlbD1cIlPhu5Egc8OibiDEkWFuZyBjw7Mga2jDoWNoIGNoxqFpXCIgaWNvbj1cIvCfn6JcIiBiZz1cInZhcigtLWJyYW5kLTEwMClcIiBjb2xvcj1cInZhcigtLWJyYW5kLTgwMClcIiB2YWx1ZT17YCR7cGxheWluZ0lkcy5zaXplfSAvICR7YkNvdXJ0cy5sZW5ndGh9IHPDom5gfSBzdWI9e2Ake2JDb3VydHMubGVuZ3RoIC0gcGxheWluZ0lkcy5zaXplIC0gbWFpbnR9IHPDom4gxJFhbmcgdHLhu5FuZyDigKIgJHttYWludH0gc8OibiDEkWFuZyBi4bqjbyB0csOsYH0gLz5cbiAgICAgICAgPFN0YXQgbGFiZWw9XCLEkMahbiBjaOG7nSBuaOG6rW4gc8OibiAvIHThuqV0IHRvw6FuXCIgaWNvbj1cIuKPs1wiIGJnPVwidmFyKC0tYW1iZXItMTAwKVwiIGNvbG9yPVwidmFyKC0tYW1iZXItODAwKVwiIHZhbHVlPXtgJHt3YWl0aW5nUGF5ICsgd2FpdGluZ1BpY2t9IMSRxqFuYH0gc3ViPXtgJHt3YWl0aW5nUGF5fSDEkcahbiBjaOG7nSBjaHV54buDbiBraG/huqNuIOKAoiAke3dhaXRpbmdQaWNrfSDEkcahbiBjaOG7nSBuaOG6rW4gc8OibmB9IC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVybyBjb2wgZzggZjFcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCwgYm9yZGVyUmFkaXVzOiAxNiB9fT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuXCI+PHNwYW4gY2xhc3NOYW1lPVwidDEyIHc3MDBcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWJyYW5kLTEwMCknIH19PkRvYW5oIHRodSB0aOG7sWMgdGh1IGjDtG0gbmF5PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImNlbnRlciB0MTYgdzgwMFwiIHN0eWxlPXt7IHdpZHRoOiAzNiwgaGVpZ2h0OiAzNiwgYm9yZGVyUmFkaXVzOiAxMiwgYmFja2dyb3VuZDogJ3ZhcigtLWJyYW5kLTYwMCknIH19PuKCqzwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInQyNCB3ODAwXCI+e3ZuZChyZXZlbnVlKX08L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0MTJcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWJyYW5kLTEwMCknIH19PkNodXnhu4NuIGtob+G6o246IHttb25leShxclN1bSl9IOKAoiBUaeG7gW4gbeG6t3Q6IHttb25leShjYXNoU3VtKX08L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZDEyXCI+XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYW43IGNhcmQgY29sIGcxNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0MTYgdzgwMCBjLWlua1wiIHN0eWxlPXt7IGxpbmVIZWlnaHQ6ICcyNHB4JyB9fT5Uw6xuaCB0cuG6oW5nIGhv4bqhdCDEkeG7mW5nIGPDoWMgc8OibiB04bqhaSB7YnJhbmNoLm5hbWV9PC9oMj5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL3N0YWZmL2Jvb2tpbmdcIiBjbGFzc05hbWU9XCJsaW5rLWJ0blwiPisgxJDhurd0IHPDom4gbeG7m2kgdOG6oWkgcXXhuqd5IOKGkjwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdncmlkJywgZ3JpZFRlbXBsYXRlQ29sdW1uczogJzFmciAxZnInLCBnYXA6IDEyIH19PlxuICAgICAgICAgICAge2JDb3VydHMubWFwKChjKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGxrID0gbG9ja1RvZGF5KGMuaWQpXG4gICAgICAgICAgICAgIGNvbnN0IGJrID0gdG9kYXlzLmZpbmQoKGIpID0+IGIuY291cnRJZCA9PT0gYy5pZCAmJiBiLnN0YXR1cyA9PT0gJ3BsYXlpbmcnKVxuICAgICAgICAgICAgICBjb25zdCBuZXh0ID0gdG9kYXlzLmZpbHRlcigoYikgPT4gYi5jb3VydElkID09PSBjLmlkICYmIChiLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCcgfHwgYi5zdGF0dXMgPT09ICdvdmVyZHVlJykpLnNvcnQoKGEsIGIpID0+IGEuc3RhcnQubG9jYWxlQ29tcGFyZShiLnN0YXJ0KSlbMF1cbiAgICAgICAgICAgICAgY29uc3QgYmFzZSA9IHsgYm9yZGVyUmFkaXVzOiAxMiwgcGFkZGluZzogMTQsIG1pbkhlaWdodDogODAsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGdhcDogOCB9IGFzIGNvbnN0XG4gICAgICAgICAgICAgIGlmIChsaykgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17Yy5pZH0gc3R5bGU9e3sgLi4uYmFzZSwgYmFja2dyb3VuZDogJ3ZhcigtLXMyMDApJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLXMzMDApJyB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sXCI+PGIgY2xhc3NOYW1lPVwidDEyIGMtczgwMCB3ODAwXCI+e2MubmFtZX08L2I+PGIgY2xhc3NOYW1lPVwidDEyIGMtczcwMFwiPvCflJIgxJBhbmcgYuG6o28gdHLDrCBt4bq3dCBzw6JuPC9iPjxzcGFuIGNsYXNzTmFtZT1cInQxMSBjLXM2MDBcIj57bGsuZnJvbS5zbGljZSg4LCAxMCl9L3tsay5mcm9tLnNsaWNlKDUsIDcpfSB7bGsuZnJvbS5zbGljZSgxMSl9IOKAkyB7bGsudG8uc2xpY2UoOCwgMTApfS97bGsudG8uc2xpY2UoNSwgNyl9IHtsay50by5zbGljZSgxMSl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2Ugc3EgYy13aGl0ZVwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1zNTAwKScsIGZvbnRTaXplOiAxMCB9fT5U4bqhbSBraMOzYTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj4pXG4gICAgICAgICAgICAgIGlmIChiaykgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17Yy5pZH0gc3R5bGU9e3sgLi4uYmFzZSwgYmFja2dyb3VuZDogJ3JnYmEoMjM2LDI1MywyNDUsLjcpJywgYm9yZGVyOiAnMnB4IHNvbGlkIHZhcigtLWJyYW5kLTUwMCknIH19PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2xcIj48YiBjbGFzc05hbWU9XCJ0MTIgYy1pbmsgdzgwMFwiPntjLm5hbWV9PC9iPjxiIGNsYXNzTmFtZT1cInQxMiBjLWJyYW5kOVwiPsSQYW5nIHPhu60gZOG7pW5nIOKAoiAje2JrLmlkfTwvYj48c3BhbiBjbGFzc05hbWU9XCJ0MTEgYy1zNjAwXCI+S2jDoWNoOiB7YmsuY3VzdG9tZXJ9IOKAoiBI4bq/dCBnaeG7nToge2JrLmVuZH08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBzcSBjLXdoaXRlXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogcmVtYWluaW5nKGJrKSA9PT0gMCA/ICd2YXIoLS1icmFuZC03MDApJyA6ICd2YXIoLS1hbWJlci04MDApJywgZm9udFNpemU6IDEwIH19PntyZW1haW5pbmcoYmspID09PSAwID8gJ8SQw6MgdGh1IMSR4bunJyA6ICdDw7JuIHRoaeG6v3UnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj4pXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2MuaWR9IHN0eWxlPXt7IC4uLmJhc2UsIGJhY2tncm91bmQ6ICcjZmZmJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLXMzMDApJyB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sXCI+PGIgY2xhc3NOYW1lPVwidDEyIGMtaW5rIHc4MDBcIj57Yy5uYW1lfTwvYj48YiBjbGFzc05hbWU9XCJ0MTIgYy1icmFuZFwiPsSQYW5nIHRy4buRbmcga2h1bmcgaGnhu4duIHThuqFpPC9iPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0MTEgYy1zNjAwXCI+e25leHQgPyBgQ8OzIGzhu4tjaCBraMOhY2ggxJHhurd0IGzDumMgJHtuZXh0LnN0YXJ0fSAoI0JLJHtuZXh0LmlkLnNsaWNlKC00KX0pYCA6ICdDaMawYSBjw7MgbOG7i2NoIHRp4bq/cCB0aGVvIGjDtG0gbmF5J308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tc21cIiBzdHlsZT17eyBmb250U2l6ZTogMTEgfX0gb25DbGljaz17KCkgPT4gbmF2KCcvc3RhZmYvYm9va2luZycpfT5M4bqtcCDEkcahbjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PilcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGludCBjb2wgZzhcIiBzdHlsZT17eyBwYWRkaW5nOiAxNiB9fT5cbiAgICAgICAgICAgIDxiIGNsYXNzTmFtZT1cImMtaW5rXCI+Q2hpIHRp4bq/dCB0aeG7gW4gdGjhu7FjIHRodSB0cm9uZyBjYSBow7RtIG5heSAoe3ZuZChyZXZlbnVlKX0pOjwvYj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGcxMlwiIHN0eWxlPXt7IHBhZGRpbmdUb3A6IDQgfX0+XG4gICAgICAgICAgICAgIHsoW1snxJDGoW4gxJHDoyB0aHUgxJHhu6cgMTAwJTonLCBwYWlkU3VtKGZ1bGwpLCAnYy1pbmsnXSwgWydUaeG7gW4gY+G7jWMgbeG7m2kgdGh1IGjDtG0gbmF5OicsIHBhaWRTdW0ocGFydCksICdjLWJyYW5kJ10sIFsnVGnhu4FuIGPhu41jIMSRxqFuIGjhu6d5IGdp4buvIGzhuqFpOicsIGtlcHQsICdjLWFtYmVyJ11dIGFzIGNvbnN0KS5tYXAoKFtrLCB2LCBjXSkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtrfSBjbGFzc05hbWU9XCJmMSBjb2xcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnI2ZmZicsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1zMzAwKScsIGJvcmRlclJhZGl1czogOCwgcGFkZGluZzogMTIgfX0+PHNwYW4gY2xhc3NOYW1lPVwiYy1zNTAwXCI+e2t9PC9zcGFuPjxiIGNsYXNzTmFtZT17YHQxNCB3ODAwICR7Y31gfT57Zm10KHYpfSBWTsSQPC9iPjwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhbjUgY2FyZCBjb2wgZzE2XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiBoZWFkLXJ1bGVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sXCI+PGgyIGNsYXNzTmFtZT1cInQxNiB3ODAwIGMtaW5rXCIgc3R5bGU9e3sgbGluZUhlaWdodDogJzI0cHgnIH19Pkzhu4tjaCBraMOhY2ggc+G6r3AgxJHhur9uIG5o4bqtbiBzw6JuPC9oMj48cCBjbGFzc05hbWU9XCJ0MTIgYy1zNjAwXCI+Q8OhYyDEkcahbiBi4bqvdCDEkeG6p3UgdHJvbmcgdsOybmcgNjAgcGjDunQgdOG7m2k8L3A+PC9kaXY+XG4gICAgICAgICAgICA8TGluayB0bz1cIi9zdGFmZi9vcmRlcnNcIiBjbGFzc05hbWU9XCJsaW5rLWJ0blwiPlhlbSB0b8OgbiBi4buZIOKGkjwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnMTJcIj5cbiAgICAgICAgICAgIHt1cGNvbWluZy5sZW5ndGggPT09IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJoaW50XCIgc3R5bGU9e3sgdGV4dEFsaWduOiAnY2VudGVyJywgcGFkZGluZzogMjQgfX0+SGnhu4duIGtow7RuZyBjw7MgxJHGoW4gbsOgbyBz4bqvcCDEkeG6v24gZ2nhu50gbmjhuq1uIHPDom4uPC9kaXY+fVxuICAgICAgICAgICAge3VwY29taW5nLnNsaWNlKDAsIDQpLm1hcCgoYikgPT4ge1xuICAgICAgICAgICAgICBjb25zdCByZW0gPSByZW1haW5pbmcoYiksIGxhdGUgPSBiLnN0YXR1cyA9PT0gJ292ZXJkdWUnXG4gICAgICAgICAgICAgIGNvbnN0IHRvbmUgPSBsYXRlID8geyBiZzogJ3ZhcigtLXJvc2UtNTApJywgYmQ6ICcycHggc29saWQgdmFyKC0tcm9zZS0zMDApJywgY2hpcDogJ3ZhcigtLXJvc2UtMjAwKScsIGNjOiAndmFyKC0tcm9zZS05NTApJywgdDogJ0tow6FjaCB0cuG7hSAzMCBwaMO6dCcgfVxuICAgICAgICAgICAgICAgIDogcmVtID4gMCA/IHsgYmc6ICd2YXIoLS1hbWJlci01MCknLCBiZDogJzJweCBzb2xpZCB2YXIoLS1hbWJlci00MDApJywgY2hpcDogJ3ZhcigtLWFtYmVyLTIwMCknLCBjYzogJ3ZhcigtLWFtYmVyLTk1MCknLCB0OiBgQ+G6p24gdGh1IHRow6ptICR7bW9uZXkocmVtKX1gIH1cbiAgICAgICAgICAgICAgICAgIDogeyBiZzogJ3ZhcigtLXM1MCknLCBiZDogJzFweCBzb2xpZCB2YXIoLS1zMzAwKScsIGNoaXA6ICd2YXIoLS1icmFuZC0xMDApJywgY2M6ICd2YXIoLS1icmFuZC05MDApJywgdDogYMSQw6MgdGhhbmggdG/DoW4gxJHhu6cgJHttb25leShiLnRvdGFsKX1gIH1cbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17Yi5pZH0gY2xhc3NOYW1lPVwiY29sIGc4XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogdG9uZS5iZywgYm9yZGVyOiB0b25lLmJkLCBib3JkZXJSYWRpdXM6IDEyLCBwYWRkaW5nOiAxNiB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gZzhcIj48YiBjbGFzc05hbWU9XCJ0MTIgYy1pbmsgdzgwMFwiPiN7Yi5pZH0g4oCiIHtjTmFtZShiLmNvdXJ0SWQpfTwvYj48c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBzcVwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IHRvbmUuY2hpcCwgY29sb3I6IHRvbmUuY2MsIHBhZGRpbmc6ICcycHggMTBweCcgfX0+e3RvbmUudH08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0MTIgYy1zNzAwXCI+S2jDoWNoOiA8Yj57Yi5jdXN0b21lcn0gKHtiLnBob25lfSk8L2I+e2xhdGUgPyA8PiDigKIgxJDDoyDEkeG6t3QgY+G7jWMge21vbmV5KGIucGFpZCl9IG5oxrBuZyBjaMawYSDEkeG6v24gbmjhuq1uIHPDom4uPC8+IDogPD4g4oCiIEdp4budIGNoxqFpOiA8Yj57Yi5zdGFydH0gLSB7Yi5lbmR9PC9iPjwvPn08L3A+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiIHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiAnZmxleC1lbmQnIH19PlxuICAgICAgICAgICAgICAgICAgICB7bGF0ZSA/IDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1kYW5nZXIgYnRuLXNtXCIgc3R5bGU9e3sgcGFkZGluZzogJzZweCAxNHB4JyB9fSBvbkNsaWNrPXsoKSA9PiBuYXYoJy9zdGFmZi9vcmRlcnMnKX0+SOG7p3kgbOG7i2NoICYgTeG7nyBzw6JuPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgOiByZW0gPiAwID8gPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLXNtXCIgc3R5bGU9e3sgcGFkZGluZzogJzZweCAxNHB4JyB9fSBvbkNsaWNrPXsoKSA9PiBuYXYoJy9zdGFmZi9vcmRlcnMnKX0+VGh1IHRp4buBbiAmIEdpYW8gc8OibjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgOiA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tc21cIiBzdHlsZT17eyBwYWRkaW5nOiAnNnB4IDE0cHgnIH19IG9uQ2xpY2s9eygpID0+IHsgcGF0Y2hCb29raW5nKGIuaWQsIHsgc3RhdHVzOiAncGxheWluZycgfSk7IHRvYXN0KGDEkMOjIGdpYW8gJHtjTmFtZShiLmNvdXJ0SWQpfSBjaG8ga2jDoWNoLmAsICdvaycpIH19PkdpYW8gc8OibiBuZ2F5PC9idXR0b24+fVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKVxufVxuXG5mdW5jdGlvbiBTdGF0KHsgbGFiZWwsIGljb24sIGJnLCBjb2xvciwgdmFsdWUsIHN1YiB9OiB7IGxhYmVsOiBzdHJpbmc7IGljb246IHN0cmluZzsgYmc6IHN0cmluZzsgY29sb3I6IHN0cmluZzsgdmFsdWU6IHN0cmluZzsgc3ViOiBzdHJpbmcgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBjb2wgZzggZjFcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj48c3BhbiBjbGFzc05hbWU9XCJ0MTIgdzcwMCBjLXM2MDBcIj57bGFiZWx9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImNlbnRlciB0MTYgdzcwMFwiIHN0eWxlPXt7IHdpZHRoOiAzNiwgaGVpZ2h0OiAzNiwgYm9yZGVyUmFkaXVzOiAxMiwgYmFja2dyb3VuZDogYmcsIGNvbG9yIH19PntpY29ufTwvc3Bhbj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidDI0IHc4MDBcIiBzdHlsZT17eyBjb2xvciB9fT57dmFsdWV9PC9kaXY+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0MTIgYy1zNjAwXCI+e3N1Yn08L3A+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==