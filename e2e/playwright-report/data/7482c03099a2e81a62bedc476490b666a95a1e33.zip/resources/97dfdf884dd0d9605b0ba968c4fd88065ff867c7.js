import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/StaffOrders.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { TODAY, kfmt, remaining, toVN, vnd, money } from "/src/data.ts";
import { useApp } from "/src/store.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/StaffOrders.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
const REASONS = [
	"Khách quá giờ nhận sân không đến",
	"Khách yêu cầu hủy lịch",
	"Sân gặp sự cố / bảo trì đột xuất",
	"Đặt nhầm khung giờ",
	"Lý do khác"
];
export default function StaffOrders() {
	_s();
	const { user, bookings, courts, branches, patchBooking, cancelBooking, toast } = useApp();
	const branchId = user?.branchId ?? branches[0].id;
	const [f, setF] = useState("all");
	const [q, setQ] = useState("");
	const [query, setQuery] = useState("");
	const todays = bookings.filter((b) => b.date === TODAY && courts.find((c) => c.id === b.courtId)?.branchId === branchId);
	const [settleId, setSettleId] = useState(() => todays.find((b) => b.status === "confirmed" && remaining(b) > 0)?.id ?? null);
	const [cancelId, setCancelId] = useState(() => todays.find((b) => b.status === "overdue")?.id ?? null);
	const [method, setMethod] = useState("qr");
	const [reason, setReason] = useState(REASONS[0]);
	const [note, setNote] = useState("");
	const cnt = {
		all: todays.length,
		waiting: todays.filter((b) => b.status === "confirmed").length,
		playing: todays.filter((b) => b.status === "playing").length,
		overdue: todays.filter((b) => b.status === "overdue").length
	};
	const kw = query.trim().replace("#", "").toLowerCase();
	const rows = todays.filter((b) => (f === "all" || (f === "waiting" ? b.status === "confirmed" : b.status === f)) && (!kw || b.id.toLowerCase().includes(kw) || b.customer.toLowerCase().includes(kw) || b.phone.includes(kw))).sort((a, b) => [
		"overdue",
		"confirmed",
		"pending",
		"playing",
		"completed",
		"cancelled"
	].indexOf(a.status) - [
		"overdue",
		"confirmed",
		"pending",
		"playing",
		"completed",
		"cancelled"
	].indexOf(b.status) || a.start.localeCompare(b.start));
	const cName = (b) => courts.find((c) => c.id === b.courtId)?.name ?? "";
	const settle = bookings.find((b) => b.id === settleId && b.status === "confirmed");
	const cancel = bookings.find((b) => b.id === cancelId && [
		"confirmed",
		"overdue",
		"pending"
	].includes(b.status));
	const tabs = [
		["all", `Tất cả đơn hôm nay (${cnt.all})`],
		["waiting", `Chờ khách nhận sân (${cnt.waiting})`],
		["playing", `Đang chơi trên sân (${cnt.playing})`],
		["overdue", `Quá giờ nhận sân (${cnt.overdue})`]
	];
	const statusBadge = (b) => {
		const m = {
			confirmed: ["b-sky", "Đã xác nhận"],
			playing: ["b-mint", "Đang sử dụng"],
			overdue: ["b-amber", "Quá giờ nhận sân"],
			pending: ["b-amber", "Chờ thanh toán"],
			completed: ["b-gray", "Hoàn thành"],
			cancelled: ["b-rose", "Đã hủy"]
		};
		return /* @__PURE__ */ _jsxDEV("span", {
			className: `badge ${m[b.status][0]}`,
			children: m[b.status][1]
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 12
		}, this);
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
		className: "card row between wrap g16",
		style: { padding: 16 },
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "row g8 wrap",
			children: tabs.map(([k, l]) => /* @__PURE__ */ _jsxDEV("button", {
				className: `btn btn-md ${f === k ? "btn-primary" : "btn-ghost"}`,
				style: {
					padding: "8px 14px",
					background: f === k ? undefined : "var(--s100)",
					fontWeight: f === k ? 700 : 600
				},
				onClick: () => setF(k),
				children: l
			}, k, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 33
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "row g8",
			children: [/* @__PURE__ */ _jsxDEV("input", {
				className: "input sm",
				style: {
					width: 240,
					background: "var(--s50)",
					padding: "8px 14px",
					borderRadius: 12
				},
				placeholder: "Mã đơn, tên hoặc SĐT khách",
				value: q,
				onChange: (e) => setQ(e.target.value),
				onKeyDown: (e) => e.key === "Enter" && setQuery(q)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "btn btn-dark",
				onClick: () => setQuery(q),
				children: "Tìm đơn"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "grid12",
		children: [/* @__PURE__ */ _jsxDEV("section", {
			className: "span8 card col g16",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "row between",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "t14 w800 c-ink",
					children: ["Danh sách lịch đặt sân ngày ", toVN(TODAY)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "t12 w500 c-s600",
					children: "Lưu ý: Thu đủ 100% tiền sân trước khi bấm Nhận sân"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "tbl-wrap",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "tbl",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", { children: "Mã đơn / Khách hàng" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 26
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Sân & Giờ chơi" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 54
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Thanh toán" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 77
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Trạng thái" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 96
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "r",
							children: "Xử lý"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 115
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 22
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [rows.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
						colSpan: 5,
						style: {
							textAlign: "center",
							padding: 32,
							color: "var(--s600)"
						},
						children: "Không có đơn nào phù hợp."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 43
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 39
					}, this), rows.map((b) => {
						const rem = remaining(b);
						const late = b.status === "overdue";
						return /* @__PURE__ */ _jsxDEV("tr", {
							className: settleId === b.id && b.status === "confirmed" ? "hl" : "",
							children: [
								/* @__PURE__ */ _jsxDEV("td", { children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "code mono",
										children: ["#", b.id]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 65,
										columnNumber: 27
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w700 c-s800",
										children: b.customer
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 65,
										columnNumber: 67
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "t11 c-s600",
										children: [b.phone, !b.member ? " (Khách vãng lai)" : ""]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 65,
										columnNumber: 114
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 65,
									columnNumber: 23
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w800 c-ink",
									children: cName(b)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 27
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: `w700 ${late ? "c-rose" : b.status === "playing" ? "c-brand8" : "c-brand8"}`,
									style: late ? undefined : b.status === "confirmed" && rem > 0 ? undefined : {
										color: b.status === "confirmed" ? "var(--s700)" : undefined,
										fontWeight: 600
									},
									children: [
										b.start,
										" - ",
										b.end,
										late ? " (Trễ 30p)" : ""
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 71
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 23
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [
										"Tổng: ",
										/* @__PURE__ */ _jsxDEV("b", { children: money(b.total) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 68,
											columnNumber: 36
										}, this),
										b.paid > 0 && rem > 0 ? ` (Đã cọc: ${kfmt(b.paid)})` : ""
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 68,
										columnNumber: 25
									}, this),
									b.status === "cancelled" ? /* @__PURE__ */ _jsxDEV("div", {
										className: "c-s600",
										children: "Đã hủy"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 69,
										columnNumber: 53
									}, this) : rem > 0 ? /* @__PURE__ */ _jsxDEV("div", {
										className: "w800",
										style: { color: late ? "var(--amber-800)" : "var(--rose-700)" },
										children: late ? `Đã cọc: ${vnd(b.paid)}` : `Còn thiếu: ${vnd(rem)}`
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 70,
										columnNumber: 29
									}, this) : /* @__PURE__ */ _jsxDEV("div", {
										className: "w700 c-brand8",
										children: "Còn thiếu: 0 VNĐ"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 71,
										columnNumber: 29
									}, this),
									b.status !== "cancelled" && !late && /* @__PURE__ */ _jsxDEV("span", {
										className: `badge sq ${rem === 0 ? "b-green" : "b-amber"}`,
										style: {
											fontSize: 10,
											padding: "2px 8px",
											marginTop: 4
										},
										children: rem === 0 ? "Đã trả đủ 100%" : b.paid > 0 ? "Đã đặt cọc" : "Chưa thanh toán"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 72,
										columnNumber: 63
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 23
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: statusBadge(b) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 23
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "r",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "col g6",
										style: { alignItems: "flex-end" },
										children: [
											b.status === "confirmed" && rem > 0 && /* @__PURE__ */ _jsxDEV("button", {
												className: "btn btn-primary btn-sm",
												onClick: () => setSettleId(b.id),
												children: [
													"Thu nốt ",
													kfmt(rem),
													" & Nhận sân"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 67
											}, this),
											b.status === "confirmed" && rem === 0 && /* @__PURE__ */ _jsxDEV("button", {
												className: "btn btn-primary btn-sm",
												onClick: () => {
													patchBooking(b.id, { status: "playing" });
													toast(`Đã bàn giao ${cName(b)} cho khách.`, "ok");
												},
												children: "Nhận sân ngay"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 78,
												columnNumber: 69
											}, this),
											b.status === "confirmed" && /* @__PURE__ */ _jsxDEV("button", {
												className: "btn btn-danger-o btn-xs",
												style: { fontWeight: 600 },
												onClick: () => setCancelId(b.id),
												children: "Hủy lịch"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 79,
												columnNumber: 56
											}, this),
											b.status === "playing" && /* @__PURE__ */ _jsxDEV("button", {
												className: "btn btn-dark btn-sm",
												onClick: () => {
													patchBooking(b.id, { status: "completed" });
													toast(`Đơn #${b.id} đã hoàn thành.`, "ok");
												},
												children: "✓ Kết thúc & Hoàn thành"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 80,
												columnNumber: 54
											}, this),
											late && /* @__PURE__ */ _jsxDEV("button", {
												className: "btn btn-danger btn-sm",
												onClick: () => setCancelId(b.id),
												children: "Hủy đơn & Mở sân"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 81,
												columnNumber: 36
											}, this),
											b.status === "pending" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "t11 c-amber w700",
												children: "Chờ khách chuyển khoản"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 82,
												columnNumber: 56
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												className: "btn btn-danger-o btn-xs",
												onClick: () => setCancelId(b.id),
												children: "Hủy lịch"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 82,
												columnNumber: 120
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 82,
												columnNumber: 54
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 76,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 23
								}, this)
							]
						}, b.id, true, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 21
						}, this);
					})] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 55,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("aside", {
			className: "span4 col g20",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "card col g16",
				style: {
					border: "2px solid var(--brand-700)",
					boxShadow: "var(--shadow-md)"
				},
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "row between head-rule",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "col g2",
						style: { paddingTop: 5 },
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "eyebrow",
							children: "Khách đến nhận sân"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 65
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "t16 w800 c-ink",
							style: { lineHeight: "24px" },
							children: "Thu tất toán & Bàn giao sân"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 116
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 15
					}, this), settle && /* @__PURE__ */ _jsxDEV("span", {
						className: "badge sq b-gray mono",
						style: {
							fontSize: 11.5,
							fontWeight: 800
						},
						children: ["#", settle.id]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 26
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 13
				}, this), !settle ? /* @__PURE__ */ _jsxDEV("div", {
					className: "hint",
					style: {
						textAlign: "center",
						padding: 24
					},
					children: [
						"Chọn nút ",
						/* @__PURE__ */ _jsxDEV("b", { children: "\"Thu nốt … & Nhận sân\"" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 100
						}, this),
						" ở một đơn trong bảng để thu tiền còn thiếu."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 24
				}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "hint col g6",
						children: [
							/* @__PURE__ */ _jsxDEV(Line, {
								k: "Khách hàng:",
								v: `${settle.customer} (${settle.phone})`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV(Line, {
								k: "Sân & Khung giờ:",
								v: `${cName(settle)} (${settle.start} - ${settle.end})`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV(Line, {
								k: "Tổng tiền đơn:",
								v: vnd(settle.total)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV(Line, {
								k: "Đã đặt cọc trước:",
								v: vnd(settle.paid),
								green: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "row between top-rule",
								style: {
									paddingTop: 6,
									borderColor: "var(--s300)"
								},
								children: [/* @__PURE__ */ _jsxDEV("b", {
									className: "t14 c-rose",
									style: { fontWeight: 800 },
									children: "Cần thu thêm tại quầy:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 111
								}, this), /* @__PURE__ */ _jsxDEV("b", {
									className: "t14 c-rose",
									style: { fontWeight: 800 },
									children: vnd(remaining(settle))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 191
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 17
					}, this),
					remaining(settle) > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "col g8",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							style: { margin: 0 },
							children: "Hình thức thu phần còn lại"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "row g8",
							children: [["qr", "📱 Quét QR"], ["cash", "💵 Tiền mặt"]].map(([k, l]) => /* @__PURE__ */ _jsxDEV("label", {
								className: `radio-card f1${method === k ? " on" : ""}`,
								style: { fontWeight: 700 },
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "radio",
									name: "m",
									checked: method === k,
									onChange: () => setMethod(k)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 198
								}, this), l]
							}, k, true, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 99
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "btn btn-primary btn-lg btn-block",
						onClick: () => {
							patchBooking(settle.id, {
								paid: settle.total,
								status: "playing",
								method
							});
							toast(`Đã thu đủ ${vnd(remaining(settle))} & cho khách vào sân.`, "ok");
							setSettleId(null);
						},
						children: remaining(settle) > 0 ? `✓ Đã thu đủ ${money(remaining(settle))} & Cho khách vào sân` : "✓ Cho khách vào sân"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 17
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "card col g16",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "row between head-rule",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "col g2",
						style: { paddingTop: 5 },
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "eyebrow",
							style: { color: "var(--rose-700)" },
							children: "Xử lý hủy lịch"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 65
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "t16 w800 c-ink",
							style: { lineHeight: "24px" },
							children: "Hủy đơn & Giải phóng sân"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 149
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 15
					}, this), cancel && /* @__PURE__ */ _jsxDEV("span", {
						className: "badge sq b-rose-soft mono",
						style: {
							background: "var(--rose-100)",
							fontSize: 11.4,
							fontWeight: 800
						},
						children: ["#", cancel.id]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 26
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 13
				}, this), !cancel ? /* @__PURE__ */ _jsxDEV("div", {
					className: "hint",
					style: {
						textAlign: "center",
						padding: 24
					},
					children: [
						"Chọn ",
						/* @__PURE__ */ _jsxDEV("b", { children: "\"Hủy lịch\"" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 96
						}, this),
						" hoặc ",
						/* @__PURE__ */ _jsxDEV("b", { children: "\"Hủy đơn & Mở sân\"" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 119
						}, this),
						" ở một đơn để xử lý."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 24
				}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "hint",
						style: {
							background: "var(--rose-100)",
							borderColor: "var(--rose-300)",
							color: "var(--rose-950)",
							padding: 12
						},
						children: cancel.paid > 0 ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							"Khách đã đặt cọc ",
							/* @__PURE__ */ _jsxDEV("b", { children: vnd(cancel.paid) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 42
							}, this),
							cancel.status === "overdue" ? " nhưng quá giờ 30 phút không đến nhận sân." : ".",
							" Khi hủy, tiền cọc được giữ lại và sân được mở trống để nhận khách mới."
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 23
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: "Đơn chưa phát sinh khoản thanh toán. Khi hủy, khung giờ sẽ được mở trống để nhận khách mới." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 23
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "col g8",
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "label",
								style: { margin: 0 },
								children: "Lý do hủy đơn"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("select", {
								className: "select sm",
								value: reason,
								onChange: (e) => setReason(e.target.value),
								children: REASONS.map((r) => /* @__PURE__ */ _jsxDEV("option", { children: r }, r, false, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 128
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								className: "input sm",
								style: { fontWeight: 500 },
								placeholder: "Ghi chú thêm (không bắt buộc)",
								value: note,
								onChange: (e) => setNote(e.target.value)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "btn btn-danger btn-md btn-block",
						onClick: () => {
							cancelBooking(cancel.id, note.trim() ? `${reason} – ${note.trim()}` : reason, cancel.paid > 0);
							toast(`Đã hủy đơn #${cancel.id} & mở trống sân.`);
							setCancelId(null);
							setNote("");
						},
						children: "Xác nhận hủy đơn & Mở trống lại sân"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 141,
						columnNumber: 17
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 93,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_s(StaffOrders, "8JiaaCn79o5q3bIveQ3uaQrDXBY=", false, function() {
	return [useApp];
});
_c = StaffOrders;
function Line({ k, v, green }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "row between g12 t12",
		children: [/* @__PURE__ */ _jsxDEV("span", {
			className: green ? "c-brand8" : "c-s600",
			children: k
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 155,
			columnNumber: 47
		}, this), /* @__PURE__ */ _jsxDEV("b", {
			className: green ? "c-brand8" : "c-ink",
			style: { textAlign: "right" },
			children: v
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 155,
			columnNumber: 105
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 155,
		columnNumber: 10
	}, this);
}
_c2 = Line;
var _c, _c2;
$RefreshReg$(_c, "StaffOrders");
$RefreshReg$(_c2, "Line");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/StaffOrders.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/StaffOrders.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/StaffOrders.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/StaffOrders.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxPQUFPLE1BQU0sV0FBVyxNQUFNLEtBQUssYUFBYTtBQUV6RCxTQUFTLGNBQWM7Ozs7QUFHdkIsTUFBTSxVQUFVO0NBQUM7Q0FBb0M7Q0FBMEI7Q0FBb0M7Q0FBc0I7QUFBWTtBQUVySixlQUFlLFNBQVMsY0FBYzs7Q0FDcEMsTUFBTSxFQUFFLE1BQU0sVUFBVSxRQUFRLFVBQVUsY0FBYyxlQUFlLFVBQVUsT0FBTztDQUN4RixNQUFNLFdBQVcsTUFBTSxZQUFZLFNBQVMsRUFBRSxDQUFDO0NBQy9DLE1BQU0sQ0FBQyxHQUFHLFFBQVEsU0FBWSxLQUFLO0NBQ25DLE1BQU0sQ0FBQyxHQUFHLFFBQVEsU0FBUyxFQUFFO0NBQzdCLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sU0FBUyxTQUFTLFFBQVEsTUFBTSxFQUFFLFNBQVMsU0FBUyxPQUFPLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsRUFBRSxhQUFhLFFBQVE7Q0FDdkgsTUFBTSxDQUFDLFVBQVUsZUFBZSxlQUE4QixPQUFPLE1BQU0sTUFBTSxFQUFFLFdBQVcsZUFBZSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxNQUFNLElBQUk7Q0FDMUksTUFBTSxDQUFDLFVBQVUsZUFBZSxlQUE4QixPQUFPLE1BQU0sTUFBTSxFQUFFLFdBQVcsU0FBUyxDQUFDLEVBQUUsTUFBTSxJQUFJO0NBQ3BILE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBd0IsSUFBSTtDQUN4RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsUUFBUSxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxFQUFFO0NBRW5DLE1BQU0sTUFBTTtFQUFFLEtBQUssT0FBTztFQUFRLFNBQVMsT0FBTyxRQUFRLE1BQU0sRUFBRSxXQUFXLFdBQVcsQ0FBQyxDQUFDO0VBQVEsU0FBUyxPQUFPLFFBQVEsTUFBTSxFQUFFLFdBQVcsU0FBUyxDQUFDLENBQUM7RUFBUSxTQUFTLE9BQU8sUUFBUSxNQUFNLEVBQUUsV0FBVyxTQUFTLENBQUMsQ0FBQztDQUFPO0NBQzdOLE1BQU0sS0FBSyxNQUFNLEtBQUssQ0FBQyxDQUFDLFFBQVEsS0FBSyxFQUFFLENBQUMsQ0FBQyxZQUFZO0NBQ3JELE1BQU0sT0FBTyxPQUFPLFFBQVEsT0FBTyxNQUFNLFVBQVUsTUFBTSxZQUFZLEVBQUUsV0FBVyxjQUFjLEVBQUUsV0FBVyxRQUN2RyxDQUFDLE1BQU0sRUFBRSxHQUFHLFlBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxZQUFZLENBQUMsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUM1RyxNQUFNLEdBQUcsTUFBTTtFQUFDO0VBQVc7RUFBYTtFQUFXO0VBQVc7RUFBYTtDQUFXLENBQUMsQ0FBQyxRQUFRLEVBQUUsTUFBTSxJQUFJO0VBQUM7RUFBVztFQUFhO0VBQVc7RUFBVztFQUFhO0NBQVcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxNQUFNLEtBQUssRUFBRSxNQUFNLGNBQWMsRUFBRSxLQUFLLENBQUM7Q0FDM08sTUFBTSxTQUFTLE1BQWUsT0FBTyxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLEVBQUUsUUFBUTtDQUM5RSxNQUFNLFNBQVMsU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLFlBQWEsRUFBRSxXQUFXLFdBQVk7Q0FDbkYsTUFBTSxTQUFTLFNBQVMsTUFBTSxNQUFNLEVBQUUsT0FBTyxZQUFZO0VBQUM7RUFBYTtFQUFXO0NBQVMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUM7Q0FFL0csTUFBTSxPQUFzQjtFQUFDLENBQUMsT0FBTyx1QkFBdUIsSUFBSSxJQUFJLEVBQUU7RUFBRyxDQUFDLFdBQVcsdUJBQXVCLElBQUksUUFBUSxFQUFFO0VBQUcsQ0FBQyxXQUFXLHVCQUF1QixJQUFJLFFBQVEsRUFBRTtFQUFHLENBQUMsV0FBVyxxQkFBcUIsSUFBSSxRQUFRLEVBQUU7Q0FBQztDQUNqTyxNQUFNLGVBQWUsTUFBZTtFQUNsQyxNQUFNLElBQXNDO0dBQUUsV0FBVyxDQUFDLFNBQVMsYUFBYTtHQUFHLFNBQVMsQ0FBQyxVQUFVLGNBQWM7R0FBRyxTQUFTLENBQUMsV0FBVyxrQkFBa0I7R0FBRyxTQUFTLENBQUMsV0FBVyxnQkFBZ0I7R0FBRyxXQUFXLENBQUMsVUFBVSxZQUFZO0dBQUcsV0FBVyxDQUFDLFVBQVUsUUFBUTtFQUFFO0VBQy9RLE9BQU8sd0JBQUMsUUFBRDtHQUFNLFdBQVcsU0FBUyxFQUFFLEVBQUUsT0FBTyxDQUFDO2FBQU8sRUFBRSxFQUFFLE9BQU8sQ0FBQztFQUFTOzs7OztDQUMzRTtDQUVBLE9BQ0UsZ0RBQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7RUFBNEIsT0FBTyxFQUFFLFNBQVMsR0FBRztZQUFwRSxDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osS0FBSyxLQUFLLENBQUMsR0FBRyxPQUFPLHdCQUFDLFVBQUQ7SUFBZ0IsV0FBVyxjQUFjLE1BQU0sSUFBSSxnQkFBZ0I7SUFBZSxPQUFPO0tBQUUsU0FBUztLQUFZLFlBQVksTUFBTSxJQUFJLFlBQVk7S0FBZSxZQUFZLE1BQU0sSUFBSSxNQUFNO0lBQUk7SUFBRyxlQUFlLEtBQUssQ0FBQztjQUFJO0dBQVUsR0FBMU47Ozs7VUFBME4sQ0FBQztFQUMzUDs7OztZQUNMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxTQUFEO0lBQU8sV0FBVTtJQUFXLE9BQU87S0FBRSxPQUFPO0tBQUssWUFBWTtLQUFjLFNBQVM7S0FBWSxjQUFjO0lBQUc7SUFBRyxhQUFZO0lBQTZCLE9BQU87SUFBRyxXQUFXLE1BQU0sS0FBSyxFQUFFLE9BQU8sS0FBSztJQUFHLFlBQVksTUFBTSxFQUFFLFFBQVEsV0FBVyxTQUFTLENBQUM7R0FBSTs7OzthQUNuUSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUFlLGVBQWUsU0FBUyxDQUFDO2NBQUc7R0FBZTs7OztXQUN6RTs7Ozs7VUFDRTs7Ozs7V0FFVCx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkIsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUErQixnQ0FBNkIsS0FBSyxLQUFLLENBQU07Ozs7O2NBQzVFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWtCO0lBQXdEOzs7O1lBQ3ZGOzs7OzthQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQU8sd0JBQUMsTUFBRDtNQUFJLHdCQUFDLE1BQUQsWUFBSSxzQkFBdUI7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7Ozs7TUFBQyx3QkFBQyxNQUFELFlBQUksYUFBYzs7Ozs7TUFBQyx3QkFBQyxNQUFELFlBQUksYUFBYzs7Ozs7TUFBQyx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBSTtNQUFTOzs7OztLQUFLOzs7O2NBQVE7Ozs7ZUFDNUksd0JBQUMsU0FBRCxhQUNHLEtBQUssV0FBVyxLQUFLLHdCQUFDLE1BQUQsWUFBSSx3QkFBQyxNQUFEO01BQUksU0FBUztNQUFHLE9BQU87T0FBRSxXQUFXO09BQVUsU0FBUztPQUFJLE9BQU87TUFBYztnQkFBRztLQUE2Qjs7OztjQUFLOzs7O2VBQzlJLEtBQUssS0FBSyxNQUFNO01BQ2YsTUFBTSxNQUFNLFVBQVUsQ0FBQztNQUN2QixNQUFNLE9BQU8sRUFBRSxXQUFXO01BQzFCLE9BQ0Usd0JBQUMsTUFBRDtPQUFlLFdBQVcsYUFBYSxFQUFFLE1BQU0sRUFBRSxXQUFXLGNBQWMsT0FBTztpQkFBakY7UUFDRSx3QkFBQyxNQUFEO1NBQUksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FBMkIsS0FBRSxFQUFFLEVBQVE7Ozs7OztTQUFDLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFlLEVBQUU7U0FBYzs7Ozs7U0FBQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUE2QixFQUFFLE9BQU8sQ0FBQyxFQUFFLFNBQVMsc0JBQXNCLEVBQVE7Ozs7OztRQUFLOzs7OztRQUNoTCx3QkFBQyxNQUFELGFBQUksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWMsTUFBTSxDQUFDO1FBQU87Ozs7a0JBQUMsd0JBQUMsT0FBRDtTQUFLLFdBQVcsUUFBUSxPQUFPLFdBQVcsRUFBRSxXQUFXLFlBQVksYUFBYTtTQUFjLE9BQU8sT0FBTyxZQUFZLEVBQUUsV0FBVyxlQUFlLE1BQU0sSUFBSSxZQUFZO1VBQUUsT0FBTyxFQUFFLFdBQVcsY0FBYyxnQkFBZ0I7VUFBVyxZQUFZO1NBQUk7bUJBQXpQO1VBQTZQLEVBQUU7VUFBTTtVQUFJLEVBQUU7VUFBSyxPQUFPLGVBQWU7U0FBUTs7Ozs7Z0JBQUs7Ozs7O1FBQ25XLHdCQUFDLE1BQUQ7U0FDRSx3QkFBQyxPQUFEO1VBQUs7VUFBTSx3QkFBQyxLQUFELFlBQUksTUFBTSxFQUFFLEtBQUssRUFBSzs7Ozs7VUFBRSxFQUFFLE9BQU8sS0FBSyxNQUFNLElBQUksYUFBYSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUs7U0FBUTs7Ozs7U0FDakcsRUFBRSxXQUFXLGNBQWMsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQVM7U0FBVzs7OztvQkFBSSxNQUFNLElBQ3JFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQU8sT0FBTyxFQUFFLE9BQU8sT0FBTyxxQkFBcUIsa0JBQWtCO29CQUFJLE9BQU8sV0FBVyxJQUFJLEVBQUUsSUFBSSxNQUFNLGNBQWMsSUFBSSxHQUFHO1NBQVM7Ozs7b0JBQ3hKLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFnQjtTQUFxQjs7Ozs7U0FDdkQsRUFBRSxXQUFXLGVBQWUsQ0FBQyxRQUFRLHdCQUFDLFFBQUQ7VUFBTSxXQUFXLFlBQVksUUFBUSxJQUFJLFlBQVk7VUFBYSxPQUFPO1dBQUUsVUFBVTtXQUFJLFNBQVM7V0FBVyxXQUFXO1VBQUU7b0JBQUksUUFBUSxJQUFJLG1CQUFtQixFQUFFLE9BQU8sSUFBSSxlQUFlO1NBQXdCOzs7OztRQUNyUDs7Ozs7UUFDSix3QkFBQyxNQUFELFlBQUssWUFBWSxDQUFDLEVBQU07Ozs7O1FBQ3hCLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQVMsT0FBTyxFQUFFLFlBQVksV0FBVztvQkFBeEQ7V0FDRyxFQUFFLFdBQVcsZUFBZSxNQUFNLEtBQUssd0JBQUMsVUFBRDtZQUFRLFdBQVU7WUFBeUIsZUFBZSxZQUFZLEVBQUUsRUFBRTtzQkFBMUU7YUFBNkU7YUFBUyxLQUFLLEdBQUc7YUFBRTtZQUFtQjs7Ozs7O1dBQzFKLEVBQUUsV0FBVyxlQUFlLFFBQVEsS0FBSyx3QkFBQyxVQUFEO1lBQVEsV0FBVTtZQUF5QixlQUFlO2FBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxRQUFRLFVBQVUsQ0FBQzthQUFHLE1BQU0sZUFBZSxNQUFNLENBQUMsRUFBRSxjQUFjLElBQUk7WUFBRTtzQkFBRztXQUFxQjs7Ozs7V0FDMU4sRUFBRSxXQUFXLGVBQWUsd0JBQUMsVUFBRDtZQUFRLFdBQVU7WUFBMEIsT0FBTyxFQUFFLFlBQVksSUFBSTtZQUFHLGVBQWUsWUFBWSxFQUFFLEVBQUU7c0JBQUc7V0FBZ0I7Ozs7O1dBQ3RKLEVBQUUsV0FBVyxhQUFhLHdCQUFDLFVBQUQ7WUFBUSxXQUFVO1lBQXNCLGVBQWU7YUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLFFBQVEsWUFBWSxDQUFDO2FBQUcsTUFBTSxRQUFRLEVBQUUsR0FBRyxrQkFBa0IsSUFBSTtZQUFFO3NCQUFHO1dBQStCOzs7OztXQUM3TSxRQUFRLHdCQUFDLFVBQUQ7WUFBUSxXQUFVO1lBQXdCLGVBQWUsWUFBWSxFQUFFLEVBQUU7c0JBQUc7V0FBd0I7Ozs7O1dBQzVHLEVBQUUsV0FBVyxhQUFhLGdEQUFFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFtQjtXQUE0Qjs7OztxQkFBQyx3QkFBQyxVQUFEO1lBQVEsV0FBVTtZQUEwQixlQUFlLFlBQVksRUFBRSxFQUFFO3NCQUFHO1dBQWdCOzs7O21CQUFHOzs7OztVQUMzTDs7Ozs7O1FBQ0g7Ozs7O09BQ0Y7U0FyQkssRUFBRTs7OzthQXFCUDtLQUVSLENBQUMsQ0FDSTs7OzthQUNGOzs7Ozs7R0FDSjs7OztXQUNFOzs7OztZQUVULHdCQUFDLFNBQUQ7R0FBTyxXQUFVO2FBQWpCLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBZSxPQUFPO0tBQUUsUUFBUTtLQUE4QixXQUFXO0lBQW1CO2NBQTNHLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQVMsT0FBTyxFQUFFLFlBQVksRUFBRTtnQkFBL0MsQ0FBa0Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVU7TUFBd0I7Ozs7Z0JBQUMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7T0FBaUIsT0FBTyxFQUFFLFlBQVksT0FBTztpQkFBRztNQUErQjs7OztjQUFNOzs7OztlQUN2TSxVQUFVLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQXVCLE9BQU87T0FBRSxVQUFVO09BQU0sWUFBWTtNQUFJO2dCQUFoRixDQUFtRixLQUFFLE9BQU8sRUFBUzs7Ozs7YUFDN0c7Ozs7O2NBQ0osQ0FBQyxTQUFTLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQU8sT0FBTztNQUFFLFdBQVc7TUFBVSxTQUFTO0tBQUc7ZUFBaEU7TUFBbUU7TUFBUyx3QkFBQyxLQUFELFlBQUcsMkJBQXlCOzs7OztNQUFDO0tBQWlEOzs7OztlQUNuSztLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUFNLEdBQUU7UUFBYyxHQUFHLEdBQUcsT0FBTyxTQUFTLElBQUksT0FBTyxNQUFNO09BQUs7Ozs7O09BQ2xFLHdCQUFDLE1BQUQ7UUFBTSxHQUFFO1FBQW1CLEdBQUcsR0FBRyxNQUFNLE1BQU0sRUFBRSxJQUFJLE9BQU8sTUFBTSxLQUFLLE9BQU8sSUFBSTtPQUFLOzs7OztPQUNyRix3QkFBQyxNQUFEO1FBQU0sR0FBRTtRQUFpQixHQUFHLElBQUksT0FBTyxLQUFLO09BQUk7Ozs7O09BQ2hELHdCQUFDLE1BQUQ7UUFBTSxHQUFFO1FBQW9CLEdBQUcsSUFBSSxPQUFPLElBQUk7UUFBRztPQUFPOzs7OztPQUN4RCx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUF1QixPQUFPO1NBQUUsWUFBWTtTQUFHLGFBQWE7UUFBYztrQkFBekYsQ0FBNEYsd0JBQUMsS0FBRDtTQUFHLFdBQVU7U0FBYSxPQUFPLEVBQUUsWUFBWSxJQUFJO21CQUFHO1FBQXlCOzs7O2tCQUFDLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO1NBQWEsT0FBTyxFQUFFLFlBQVksSUFBSTttQkFBSSxJQUFJLFVBQVUsTUFBTSxDQUFDO1FBQUs7Ozs7Z0JBQU07Ozs7OztNQUNoUTs7Ozs7O0tBQ0osVUFBVSxNQUFNLElBQUksS0FDbkIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFRLE9BQU8sRUFBRSxRQUFRLEVBQUU7aUJBQUc7TUFBaUM7Ozs7Z0JBQ2hGLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNYLENBQUMsQ0FBQyxNQUFNLFlBQVksR0FBRyxDQUFDLFFBQVEsYUFBYSxDQUFDLENBQUMsQ0FBVyxLQUFLLENBQUMsR0FBRyxPQUFPLHdCQUFDLFNBQUQ7UUFBZSxXQUFXLGdCQUFnQixXQUFXLElBQUksUUFBUTtRQUFNLE9BQU8sRUFBRSxZQUFZLElBQUk7a0JBQWhHLENBQW1HLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQVEsTUFBSztTQUFJLFNBQVMsV0FBVztTQUFHLGdCQUFnQixVQUFVLENBQUM7UUFBSTs7OztrQkFBRSxDQUFTO1VBQXJMOzs7O2NBQXFMLENBQUM7TUFDM1E7Ozs7Y0FDRjs7Ozs7O0tBRVAsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBbUMsZUFBZTtPQUNsRSxhQUFhLE9BQU8sSUFBSTtRQUFFLE1BQU0sT0FBTztRQUFPLFFBQVE7UUFBVztPQUFPLENBQUM7T0FDekUsTUFBTSxhQUFhLElBQUksVUFBVSxNQUFNLENBQUMsRUFBRSx3QkFBd0IsSUFBSTtPQUFHLFlBQVksSUFBSTtNQUMzRjtnQkFBSSxVQUFVLE1BQU0sSUFBSSxJQUFJLGVBQWUsTUFBTSxVQUFVLE1BQU0sQ0FBQyxFQUFFLHdCQUF3QjtLQUE4Qjs7Ozs7SUFDMUg7Ozs7WUFFRDs7Ozs7YUFFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQVMsT0FBTyxFQUFFLFlBQVksRUFBRTtnQkFBL0MsQ0FBa0Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBVSxPQUFPLEVBQUUsT0FBTyxrQkFBa0I7aUJBQUc7TUFBb0I7Ozs7Z0JBQUMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7T0FBaUIsT0FBTyxFQUFFLFlBQVksT0FBTztpQkFBRztNQUE0Qjs7OztjQUFNOzs7OztlQUNyTyxVQUFVLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQTRCLE9BQU87T0FBRSxZQUFZO09BQW1CLFVBQVU7T0FBTSxZQUFZO01BQUk7Z0JBQXBILENBQXVILEtBQUUsT0FBTyxFQUFTOzs7OzthQUNqSjs7Ozs7Y0FDSixDQUFDLFNBQVMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBTyxPQUFPO01BQUUsV0FBVztNQUFVLFNBQVM7S0FBRztlQUFoRTtNQUFtRTtNQUFLLHdCQUFDLEtBQUQsWUFBRyxlQUFhOzs7OztNQUFDO01BQU0sd0JBQUMsS0FBRCxZQUFHLHVCQUFxQjs7Ozs7TUFBQztLQUF5Qjs7Ozs7ZUFDMUo7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFPLE9BQU87T0FBRSxZQUFZO09BQW1CLGFBQWE7T0FBbUIsT0FBTztPQUFtQixTQUFTO01BQUc7Z0JBQ2pJLE9BQU8sT0FBTyxJQUNYO09BQUU7T0FBaUIsd0JBQUMsS0FBRCxZQUFJLElBQUksT0FBTyxJQUFJLEVBQUs7Ozs7O09BQUUsT0FBTyxXQUFXLFlBQVksK0NBQStDO09BQUk7TUFBeUU7Ozs7aUJBQ3ZNLCtDQUFFLDhGQUE2Rjs7Ozs7S0FDaEc7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtRQUFRLE9BQU8sRUFBRSxRQUFRLEVBQUU7a0JBQUc7T0FBb0I7Ozs7O09BQ25FLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQVksT0FBTztRQUFRLFdBQVcsTUFBTSxVQUFVLEVBQUUsT0FBTyxLQUFLO2tCQUFJLFFBQVEsS0FBSyxNQUFNLHdCQUFDLFVBQUQsWUFBaUIsRUFBVSxHQUFkOzs7O2VBQWMsQ0FBQztPQUFVOzs7OztPQUNuSix3QkFBQyxTQUFEO1FBQU8sV0FBVTtRQUFXLE9BQU8sRUFBRSxZQUFZLElBQUk7UUFBRyxhQUFZO1FBQWdDLE9BQU87UUFBTSxXQUFXLE1BQU0sUUFBUSxFQUFFLE9BQU8sS0FBSztPQUFJOzs7OztNQUN6Sjs7Ozs7O0tBQ0wsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBa0MsZUFBZTtPQUNqRSxjQUFjLE9BQU8sSUFBSSxLQUFLLEtBQUssSUFBSSxHQUFHLE9BQU8sS0FBSyxLQUFLLEtBQUssTUFBTSxRQUFRLE9BQU8sT0FBTyxDQUFDO09BQzdGLE1BQU0sZUFBZSxPQUFPLEdBQUcsaUJBQWlCO09BQUcsWUFBWSxJQUFJO09BQUcsUUFBUSxFQUFFO01BQ2xGO2dCQUFHO0tBQTJDOzs7OztJQUM5Qzs7OztZQUVEOzs7OztXQUNBOzs7OztVQUNKOzs7OztTQUNMOzs7OztBQUVOOzs7OztBQUVBLFNBQVMsS0FBSyxFQUFFLEdBQUcsR0FBRyxTQUFvRDtDQUN4RSxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FBcUMsd0JBQUMsUUFBRDtHQUFNLFdBQVcsUUFBUSxhQUFhO2FBQVc7RUFBUTs7OztZQUFDLHdCQUFDLEtBQUQ7R0FBRyxXQUFXLFFBQVEsYUFBYTtHQUFTLE9BQU8sRUFBRSxXQUFXLFFBQVE7YUFBSTtFQUFLOzs7O1VBQU07Ozs7OztBQUMvTCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTdGFmZk9yZGVycy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IFRPREFZLCBrZm10LCByZW1haW5pbmcsIHRvVk4sIHZuZCwgbW9uZXkgfSBmcm9tICcuLi9kYXRhJ1xuaW1wb3J0IHR5cGUgeyBCb29raW5nIH0gZnJvbSAnLi4vZGF0YSdcbmltcG9ydCB7IHVzZUFwcCB9IGZyb20gJy4uL3N0b3JlJ1xuXG50eXBlIEYgPSAnYWxsJyB8ICd3YWl0aW5nJyB8ICdwbGF5aW5nJyB8ICdvdmVyZHVlJ1xuY29uc3QgUkVBU09OUyA9IFsnS2jDoWNoIHF1w6EgZ2nhu50gbmjhuq1uIHPDom4ga2jDtG5nIMSR4bq/bicsICdLaMOhY2ggecOqdSBj4bqndSBo4buneSBs4buLY2gnLCAnU8OibiBn4bq3cCBz4buxIGPhu5EgLyBi4bqjbyB0csOsIMSR4buZdCB4deG6pXQnLCAnxJDhurd0IG5o4bqnbSBraHVuZyBnaeG7nScsICdMw70gZG8ga2jDoWMnXVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdGFmZk9yZGVycygpIHtcbiAgY29uc3QgeyB1c2VyLCBib29raW5ncywgY291cnRzLCBicmFuY2hlcywgcGF0Y2hCb29raW5nLCBjYW5jZWxCb29raW5nLCB0b2FzdCB9ID0gdXNlQXBwKClcbiAgY29uc3QgYnJhbmNoSWQgPSB1c2VyPy5icmFuY2hJZCA/PyBicmFuY2hlc1swXS5pZFxuICBjb25zdCBbZiwgc2V0Rl0gPSB1c2VTdGF0ZTxGPignYWxsJylcbiAgY29uc3QgW3EsIHNldFFdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtxdWVyeSwgc2V0UXVlcnldID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IHRvZGF5cyA9IGJvb2tpbmdzLmZpbHRlcigoYikgPT4gYi5kYXRlID09PSBUT0RBWSAmJiBjb3VydHMuZmluZCgoYykgPT4gYy5pZCA9PT0gYi5jb3VydElkKT8uYnJhbmNoSWQgPT09IGJyYW5jaElkKVxuICBjb25zdCBbc2V0dGxlSWQsIHNldFNldHRsZUlkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KCgpID0+IHRvZGF5cy5maW5kKChiKSA9PiBiLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCcgJiYgcmVtYWluaW5nKGIpID4gMCk/LmlkID8/IG51bGwpXG4gIGNvbnN0IFtjYW5jZWxJZCwgc2V0Q2FuY2VsSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4oKCkgPT4gdG9kYXlzLmZpbmQoKGIpID0+IGIuc3RhdHVzID09PSAnb3ZlcmR1ZScpPy5pZCA/PyBudWxsKVxuICBjb25zdCBbbWV0aG9kLCBzZXRNZXRob2RdID0gdXNlU3RhdGU8J3FyJyB8ICdjYXNoJz4oJ3FyJylcbiAgY29uc3QgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKFJFQVNPTlNbMF0pXG4gIGNvbnN0IFtub3RlLCBzZXROb3RlXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGNvbnN0IGNudCA9IHsgYWxsOiB0b2RheXMubGVuZ3RoLCB3YWl0aW5nOiB0b2RheXMuZmlsdGVyKChiKSA9PiBiLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCcpLmxlbmd0aCwgcGxheWluZzogdG9kYXlzLmZpbHRlcigoYikgPT4gYi5zdGF0dXMgPT09ICdwbGF5aW5nJykubGVuZ3RoLCBvdmVyZHVlOiB0b2RheXMuZmlsdGVyKChiKSA9PiBiLnN0YXR1cyA9PT0gJ292ZXJkdWUnKS5sZW5ndGggfVxuICBjb25zdCBrdyA9IHF1ZXJ5LnRyaW0oKS5yZXBsYWNlKCcjJywgJycpLnRvTG93ZXJDYXNlKClcbiAgY29uc3Qgcm93cyA9IHRvZGF5cy5maWx0ZXIoKGIpID0+IChmID09PSAnYWxsJyB8fCAoZiA9PT0gJ3dhaXRpbmcnID8gYi5zdGF0dXMgPT09ICdjb25maXJtZWQnIDogYi5zdGF0dXMgPT09IGYpKVxuICAgICYmICgha3cgfHwgYi5pZC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGt3KSB8fCBiLmN1c3RvbWVyLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoa3cpIHx8IGIucGhvbmUuaW5jbHVkZXMoa3cpKSlcbiAgICAuc29ydCgoYSwgYikgPT4gWydvdmVyZHVlJywgJ2NvbmZpcm1lZCcsICdwZW5kaW5nJywgJ3BsYXlpbmcnLCAnY29tcGxldGVkJywgJ2NhbmNlbGxlZCddLmluZGV4T2YoYS5zdGF0dXMpIC0gWydvdmVyZHVlJywgJ2NvbmZpcm1lZCcsICdwZW5kaW5nJywgJ3BsYXlpbmcnLCAnY29tcGxldGVkJywgJ2NhbmNlbGxlZCddLmluZGV4T2YoYi5zdGF0dXMpIHx8IGEuc3RhcnQubG9jYWxlQ29tcGFyZShiLnN0YXJ0KSlcbiAgY29uc3QgY05hbWUgPSAoYjogQm9va2luZykgPT4gY291cnRzLmZpbmQoKGMpID0+IGMuaWQgPT09IGIuY291cnRJZCk/Lm5hbWUgPz8gJydcbiAgY29uc3Qgc2V0dGxlID0gYm9va2luZ3MuZmluZCgoYikgPT4gYi5pZCA9PT0gc2V0dGxlSWQgJiYgKGIuc3RhdHVzID09PSAnY29uZmlybWVkJykpXG4gIGNvbnN0IGNhbmNlbCA9IGJvb2tpbmdzLmZpbmQoKGIpID0+IGIuaWQgPT09IGNhbmNlbElkICYmIFsnY29uZmlybWVkJywgJ292ZXJkdWUnLCAncGVuZGluZyddLmluY2x1ZGVzKGIuc3RhdHVzKSlcblxuICBjb25zdCB0YWJzOiBbRiwgc3RyaW5nXVtdID0gW1snYWxsJywgYFThuqV0IGPhuqMgxJHGoW4gaMO0bSBuYXkgKCR7Y250LmFsbH0pYF0sIFsnd2FpdGluZycsIGBDaOG7nSBraMOhY2ggbmjhuq1uIHPDom4gKCR7Y250LndhaXRpbmd9KWBdLCBbJ3BsYXlpbmcnLCBgxJBhbmcgY2jGoWkgdHLDqm4gc8OibiAoJHtjbnQucGxheWluZ30pYF0sIFsnb3ZlcmR1ZScsIGBRdcOhIGdp4budIG5o4bqtbiBzw6JuICgke2NudC5vdmVyZHVlfSlgXV1cbiAgY29uc3Qgc3RhdHVzQmFkZ2UgPSAoYjogQm9va2luZykgPT4ge1xuICAgIGNvbnN0IG06IFJlY29yZDxzdHJpbmcsIFtzdHJpbmcsIHN0cmluZ10+ID0geyBjb25maXJtZWQ6IFsnYi1za3knLCAnxJDDoyB4w6FjIG5o4bqtbiddLCBwbGF5aW5nOiBbJ2ItbWludCcsICfEkGFuZyBz4butIGThu6VuZyddLCBvdmVyZHVlOiBbJ2ItYW1iZXInLCAnUXXDoSBnaeG7nSBuaOG6rW4gc8OibiddLCBwZW5kaW5nOiBbJ2ItYW1iZXInLCAnQ2jhu50gdGhhbmggdG/DoW4nXSwgY29tcGxldGVkOiBbJ2ItZ3JheScsICdIb8OgbiB0aMOgbmgnXSwgY2FuY2VsbGVkOiBbJ2Itcm9zZScsICfEkMOjIGjhu6d5J10gfVxuICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9e2BiYWRnZSAke21bYi5zdGF0dXNdWzBdfWB9PnttW2Iuc3RhdHVzXVsxXX08L3NwYW4+XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjYXJkIHJvdyBiZXR3ZWVuIHdyYXAgZzE2XCIgc3R5bGU9e3sgcGFkZGluZzogMTYgfX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGc4IHdyYXBcIj5cbiAgICAgICAgICB7dGFicy5tYXAoKFtrLCBsXSkgPT4gPGJ1dHRvbiBrZXk9e2t9IGNsYXNzTmFtZT17YGJ0biBidG4tbWQgJHtmID09PSBrID8gJ2J0bi1wcmltYXJ5JyA6ICdidG4tZ2hvc3QnfWB9IHN0eWxlPXt7IHBhZGRpbmc6ICc4cHggMTRweCcsIGJhY2tncm91bmQ6IGYgPT09IGsgPyB1bmRlZmluZWQgOiAndmFyKC0tczEwMCknLCBmb250V2VpZ2h0OiBmID09PSBrID8gNzAwIDogNjAwIH19IG9uQ2xpY2s9eygpID0+IHNldEYoayl9PntsfTwvYnV0dG9uPil9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnOFwiPlxuICAgICAgICAgIDxpbnB1dCBjbGFzc05hbWU9XCJpbnB1dCBzbVwiIHN0eWxlPXt7IHdpZHRoOiAyNDAsIGJhY2tncm91bmQ6ICd2YXIoLS1zNTApJywgcGFkZGluZzogJzhweCAxNHB4JywgYm9yZGVyUmFkaXVzOiAxMiB9fSBwbGFjZWhvbGRlcj1cIk3DoyDEkcahbiwgdMOqbiBob+G6t2MgU8SQVCBraMOhY2hcIiB2YWx1ZT17cX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRRKGUudGFyZ2V0LnZhbHVlKX0gb25LZXlEb3duPXsoZSkgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgc2V0UXVlcnkocSl9IC8+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLWRhcmtcIiBvbkNsaWNrPXsoKSA9PiBzZXRRdWVyeShxKX0+VMOsbSDEkcahbjwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkMTJcIj5cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhbjggY2FyZCBjb2wgZzE2XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlblwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInQxNCB3ODAwIGMtaW5rXCI+RGFuaCBzw6FjaCBs4buLY2ggxJHhurd0IHPDom4gbmfDoHkge3RvVk4oVE9EQVkpfTwvaDI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0MTIgdzUwMCBjLXM2MDBcIj5MxrB1IMO9OiBUaHUgxJHhu6cgMTAwJSB0aeG7gW4gc8OibiB0csaw4bubYyBraGkgYuG6pW0gTmjhuq1uIHPDom48L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0Ymwtd3JhcFwiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInRibFwiPlxuICAgICAgICAgICAgICA8dGhlYWQ+PHRyPjx0aD5Nw6MgxJHGoW4gLyBLaMOhY2ggaMOgbmc8L3RoPjx0aD5Tw6JuICYgR2nhu50gY2jGoWk8L3RoPjx0aD5UaGFuaCB0b8OhbjwvdGg+PHRoPlRy4bqhbmcgdGjDoWk8L3RoPjx0aCBjbGFzc05hbWU9XCJyXCI+WOG7rSBsw708L3RoPjwvdHI+PC90aGVhZD5cbiAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgIHtyb3dzLmxlbmd0aCA9PT0gMCAmJiA8dHI+PHRkIGNvbFNwYW49ezV9IHN0eWxlPXt7IHRleHRBbGlnbjogJ2NlbnRlcicsIHBhZGRpbmc6IDMyLCBjb2xvcjogJ3ZhcigtLXM2MDApJyB9fT5LaMO0bmcgY8OzIMSRxqFuIG7DoG8gcGjDuSBo4bujcC48L3RkPjwvdHI+fVxuICAgICAgICAgICAgICAgIHtyb3dzLm1hcCgoYikgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgcmVtID0gcmVtYWluaW5nKGIpXG4gICAgICAgICAgICAgICAgICBjb25zdCBsYXRlID0gYi5zdGF0dXMgPT09ICdvdmVyZHVlJ1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17Yi5pZH0gY2xhc3NOYW1lPXtzZXR0bGVJZCA9PT0gYi5pZCAmJiBiLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCcgPyAnaGwnIDogJyd9PlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD48ZGl2IGNsYXNzTmFtZT1cImNvZGUgbW9ub1wiPiN7Yi5pZH08L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInc3MDAgYy1zODAwXCI+e2IuY3VzdG9tZXJ9PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJ0MTEgYy1zNjAwXCI+e2IucGhvbmV9eyFiLm1lbWJlciA/ICcgKEtow6FjaCB2w6NuZyBsYWkpJyA6ICcnfTwvZGl2PjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkPjxkaXYgY2xhc3NOYW1lPVwidzgwMCBjLWlua1wiPntjTmFtZShiKX08L2Rpdj48ZGl2IGNsYXNzTmFtZT17YHc3MDAgJHtsYXRlID8gJ2Mtcm9zZScgOiBiLnN0YXR1cyA9PT0gJ3BsYXlpbmcnID8gJ2MtYnJhbmQ4JyA6ICdjLWJyYW5kOCd9YH0gc3R5bGU9e2xhdGUgPyB1bmRlZmluZWQgOiBiLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCcgJiYgcmVtID4gMCA/IHVuZGVmaW5lZCA6IHsgY29sb3I6IGIuc3RhdHVzID09PSAnY29uZmlybWVkJyA/ICd2YXIoLS1zNzAwKScgOiB1bmRlZmluZWQsIGZvbnRXZWlnaHQ6IDYwMCB9fT57Yi5zdGFydH0gLSB7Yi5lbmR9e2xhdGUgPyAnIChUcuG7hSAzMHApJyA6ICcnfTwvZGl2PjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5U4buVbmc6IDxiPnttb25leShiLnRvdGFsKX08L2I+e2IucGFpZCA+IDAgJiYgcmVtID4gMCA/IGAgKMSQw6MgY+G7jWM6ICR7a2ZtdChiLnBhaWQpfSlgIDogJyd9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Yi5zdGF0dXMgPT09ICdjYW5jZWxsZWQnID8gPGRpdiBjbGFzc05hbWU9XCJjLXM2MDBcIj7EkMOjIGjhu6d5PC9kaXY+IDogcmVtID4gMFxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IDxkaXYgY2xhc3NOYW1lPVwidzgwMFwiIHN0eWxlPXt7IGNvbG9yOiBsYXRlID8gJ3ZhcigtLWFtYmVyLTgwMCknIDogJ3ZhcigtLXJvc2UtNzAwKScgfX0+e2xhdGUgPyBgxJDDoyBj4buNYzogJHt2bmQoYi5wYWlkKX1gIDogYEPDsm4gdGhp4bq/dTogJHt2bmQocmVtKX1gfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IDxkaXYgY2xhc3NOYW1lPVwidzcwMCBjLWJyYW5kOFwiPkPDsm4gdGhp4bq/dTogMCBWTsSQPC9kaXY+fVxuICAgICAgICAgICAgICAgICAgICAgICAge2Iuc3RhdHVzICE9PSAnY2FuY2VsbGVkJyAmJiAhbGF0ZSAmJiA8c3BhbiBjbGFzc05hbWU9e2BiYWRnZSBzcSAke3JlbSA9PT0gMCA/ICdiLWdyZWVuJyA6ICdiLWFtYmVyJ31gfSBzdHlsZT17eyBmb250U2l6ZTogMTAsIHBhZGRpbmc6ICcycHggOHB4JywgbWFyZ2luVG9wOiA0IH19PntyZW0gPT09IDAgPyAnxJDDoyB0cuG6oyDEkeG7pyAxMDAlJyA6IGIucGFpZCA+IDAgPyAnxJDDoyDEkeG6t3QgY+G7jWMnIDogJ0NoxrBhIHRoYW5oIHRvw6FuJ308L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkPntzdGF0dXNCYWRnZShiKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnNlwiIHN0eWxlPXt7IGFsaWduSXRlbXM6ICdmbGV4LWVuZCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtiLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCcgJiYgcmVtID4gMCAmJiA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tc21cIiBvbkNsaWNrPXsoKSA9PiBzZXRTZXR0bGVJZChiLmlkKX0+VGh1IG7hu5F0IHtrZm10KHJlbSl9ICYgTmjhuq1uIHPDom48L2J1dHRvbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtiLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCcgJiYgcmVtID09PSAwICYmIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbVwiIG9uQ2xpY2s9eygpID0+IHsgcGF0Y2hCb29raW5nKGIuaWQsIHsgc3RhdHVzOiAncGxheWluZycgfSk7IHRvYXN0KGDEkMOjIGLDoG4gZ2lhbyAke2NOYW1lKGIpfSBjaG8ga2jDoWNoLmAsICdvaycpIH19Pk5o4bqtbiBzw6JuIG5nYXk8L2J1dHRvbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtiLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCcgJiYgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLWRhbmdlci1vIGJ0bi14c1wiIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCB9fSBvbkNsaWNrPXsoKSA9PiBzZXRDYW5jZWxJZChiLmlkKX0+SOG7p3kgbOG7i2NoPC9idXR0b24+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Yi5zdGF0dXMgPT09ICdwbGF5aW5nJyAmJiA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tZGFyayBidG4tc21cIiBvbkNsaWNrPXsoKSA9PiB7IHBhdGNoQm9va2luZyhiLmlkLCB7IHN0YXR1czogJ2NvbXBsZXRlZCcgfSk7IHRvYXN0KGDEkMahbiAjJHtiLmlkfSDEkcOjIGhvw6BuIHRow6BuaC5gLCAnb2snKSB9fT7inJMgS+G6v3QgdGjDumMgJiBIb8OgbiB0aMOgbmg8L2J1dHRvbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtsYXRlICYmIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1kYW5nZXIgYnRuLXNtXCIgb25DbGljaz17KCkgPT4gc2V0Q2FuY2VsSWQoYi5pZCl9Pkjhu6d5IMSRxqFuICYgTeG7nyBzw6JuPC9idXR0b24+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Yi5zdGF0dXMgPT09ICdwZW5kaW5nJyAmJiA8PjxzcGFuIGNsYXNzTmFtZT1cInQxMSBjLWFtYmVyIHc3MDBcIj5DaOG7nSBraMOhY2ggY2h1eeG7g24ga2hv4bqjbjwvc3Bhbj48YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tZGFuZ2VyLW8gYnRuLXhzXCIgb25DbGljaz17KCkgPT4gc2V0Q2FuY2VsSWQoYi5pZCl9Pkjhu6d5IGzhu4tjaDwvYnV0dG9uPjwvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInNwYW40IGNvbCBnMjBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgY29sIGcxNlwiIHN0eWxlPXt7IGJvcmRlcjogJzJweCBzb2xpZCB2YXIoLS1icmFuZC03MDApJywgYm94U2hhZG93OiAndmFyKC0tc2hhZG93LW1kKScgfX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuIGhlYWQtcnVsZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnMlwiIHN0eWxlPXt7IHBhZGRpbmdUb3A6IDUgfX0+PHNwYW4gY2xhc3NOYW1lPVwiZXllYnJvd1wiPktow6FjaCDEkeG6v24gbmjhuq1uIHPDom48L3NwYW4+PGgzIGNsYXNzTmFtZT1cInQxNiB3ODAwIGMtaW5rXCIgc3R5bGU9e3sgbGluZUhlaWdodDogJzI0cHgnIH19PlRodSB04bqldCB0b8OhbiAmIELDoG4gZ2lhbyBzw6JuPC9oMz48L2Rpdj5cbiAgICAgICAgICAgICAge3NldHRsZSAmJiA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBzcSBiLWdyYXkgbW9ub1wiIHN0eWxlPXt7IGZvbnRTaXplOiAxMS41LCBmb250V2VpZ2h0OiA4MDAgfX0+I3tzZXR0bGUuaWR9PC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgeyFzZXR0bGUgPyA8ZGl2IGNsYXNzTmFtZT1cImhpbnRcIiBzdHlsZT17eyB0ZXh0QWxpZ246ICdjZW50ZXInLCBwYWRkaW5nOiAyNCB9fT5DaOG7jW4gbsO6dCA8Yj5cIlRodSBu4buRdCDigKYgJiBOaOG6rW4gc8OiblwiPC9iPiDhu58gbeG7mXQgxJHGoW4gdHJvbmcgYuG6o25nIMSR4buDIHRodSB0aeG7gW4gY8OybiB0aGnhur91LjwvZGl2PiA6IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpbnQgY29sIGc2XCI+XG4gICAgICAgICAgICAgICAgICA8TGluZSBrPVwiS2jDoWNoIGjDoG5nOlwiIHY9e2Ake3NldHRsZS5jdXN0b21lcn0gKCR7c2V0dGxlLnBob25lfSlgfSAvPlxuICAgICAgICAgICAgICAgICAgPExpbmUgaz1cIlPDom4gJiBLaHVuZyBnaeG7nTpcIiB2PXtgJHtjTmFtZShzZXR0bGUpfSAoJHtzZXR0bGUuc3RhcnR9IC0gJHtzZXR0bGUuZW5kfSlgfSAvPlxuICAgICAgICAgICAgICAgICAgPExpbmUgaz1cIlThu5VuZyB0aeG7gW4gxJHGoW46XCIgdj17dm5kKHNldHRsZS50b3RhbCl9IC8+XG4gICAgICAgICAgICAgICAgICA8TGluZSBrPVwixJDDoyDEkeG6t3QgY+G7jWMgdHLGsOG7m2M6XCIgdj17dm5kKHNldHRsZS5wYWlkKX0gZ3JlZW4gLz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gdG9wLXJ1bGVcIiBzdHlsZT17eyBwYWRkaW5nVG9wOiA2LCBib3JkZXJDb2xvcjogJ3ZhcigtLXMzMDApJyB9fT48YiBjbGFzc05hbWU9XCJ0MTQgYy1yb3NlXCIgc3R5bGU9e3sgZm9udFdlaWdodDogODAwIH19PkPhuqduIHRodSB0aMOqbSB04bqhaSBxdeG6p3k6PC9iPjxiIGNsYXNzTmFtZT1cInQxNCBjLXJvc2VcIiBzdHlsZT17eyBmb250V2VpZ2h0OiA4MDAgfX0+e3ZuZChyZW1haW5pbmcoc2V0dGxlKSl9PC9iPjwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHtyZW1haW5pbmcoc2V0dGxlKSA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzhcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCIgc3R5bGU9e3sgbWFyZ2luOiAwIH19PkjDrG5oIHRo4bupYyB0aHUgcGjhuqduIGPDsm4gbOG6oWk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnOFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHsoW1sncXInLCAn8J+TsSBRdcOpdCBRUiddLCBbJ2Nhc2gnLCAn8J+StSBUaeG7gW4gbeG6t3QnXV0gYXMgY29uc3QpLm1hcCgoW2ssIGxdKSA9PiA8bGFiZWwga2V5PXtrfSBjbGFzc05hbWU9e2ByYWRpby1jYXJkIGYxJHttZXRob2QgPT09IGsgPyAnIG9uJyA6ICcnfWB9IHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDcwMCB9fT48aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT1cIm1cIiBjaGVja2VkPXttZXRob2QgPT09IGt9IG9uQ2hhbmdlPXsoKSA9PiBzZXRNZXRob2Qoayl9IC8+e2x9PC9sYWJlbD4pfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLWxnIGJ0bi1ibG9ja1wiIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHBhdGNoQm9va2luZyhzZXR0bGUuaWQsIHsgcGFpZDogc2V0dGxlLnRvdGFsLCBzdGF0dXM6ICdwbGF5aW5nJywgbWV0aG9kIH0pXG4gICAgICAgICAgICAgICAgICB0b2FzdChgxJDDoyB0aHUgxJHhu6cgJHt2bmQocmVtYWluaW5nKHNldHRsZSkpfSAmIGNobyBraMOhY2ggdsOgbyBzw6JuLmAsICdvaycpOyBzZXRTZXR0bGVJZChudWxsKVxuICAgICAgICAgICAgICAgIH19PntyZW1haW5pbmcoc2V0dGxlKSA+IDAgPyBg4pyTIMSQw6MgdGh1IMSR4bunICR7bW9uZXkocmVtYWluaW5nKHNldHRsZSkpfSAmIENobyBraMOhY2ggdsOgbyBzw6JuYCA6ICfinJMgQ2hvIGtow6FjaCB2w6BvIHPDom4nfTwvYnV0dG9uPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgY29sIGcxNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiBoZWFkLXJ1bGVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzJcIiBzdHlsZT17eyBwYWRkaW5nVG9wOiA1IH19PjxzcGFuIGNsYXNzTmFtZT1cImV5ZWJyb3dcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXJvc2UtNzAwKScgfX0+WOG7rSBsw70gaOG7p3kgbOG7i2NoPC9zcGFuPjxoMyBjbGFzc05hbWU9XCJ0MTYgdzgwMCBjLWlua1wiIHN0eWxlPXt7IGxpbmVIZWlnaHQ6ICcyNHB4JyB9fT5I4buneSDEkcahbiAmIEdp4bqjaSBwaMOzbmcgc8OibjwvaDM+PC9kaXY+XG4gICAgICAgICAgICAgIHtjYW5jZWwgJiYgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2Ugc3EgYi1yb3NlLXNvZnQgbW9ub1wiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1yb3NlLTEwMCknLCBmb250U2l6ZTogMTEuNCwgZm9udFdlaWdodDogODAwIH19PiN7Y2FuY2VsLmlkfTwvc3Bhbj59XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHshY2FuY2VsID8gPGRpdiBjbGFzc05hbWU9XCJoaW50XCIgc3R5bGU9e3sgdGV4dEFsaWduOiAnY2VudGVyJywgcGFkZGluZzogMjQgfX0+Q2jhu41uIDxiPlwiSOG7p3kgbOG7i2NoXCI8L2I+IGhv4bq3YyA8Yj5cIkjhu6d5IMSRxqFuICYgTeG7nyBzw6JuXCI8L2I+IOG7nyBt4buZdCDEkcahbiDEkeG7gyB44butIGzDvS48L2Rpdj4gOiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaW50XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLXJvc2UtMTAwKScsIGJvcmRlckNvbG9yOiAndmFyKC0tcm9zZS0zMDApJywgY29sb3I6ICd2YXIoLS1yb3NlLTk1MCknLCBwYWRkaW5nOiAxMiB9fT5cbiAgICAgICAgICAgICAgICAgIHtjYW5jZWwucGFpZCA+IDBcbiAgICAgICAgICAgICAgICAgICAgPyA8Pktow6FjaCDEkcOjIMSR4bq3dCBj4buNYyA8Yj57dm5kKGNhbmNlbC5wYWlkKX08L2I+e2NhbmNlbC5zdGF0dXMgPT09ICdvdmVyZHVlJyA/ICcgbmjGsG5nIHF1w6EgZ2nhu50gMzAgcGjDunQga2jDtG5nIMSR4bq/biBuaOG6rW4gc8Oibi4nIDogJy4nfSBLaGkgaOG7p3ksIHRp4buBbiBj4buNYyDEkcaw4bujYyBnaeG7ryBs4bqhaSB2w6Agc8OibiDEkcaw4bujYyBt4bufIHRy4buRbmcgxJHhu4Mgbmjhuq1uIGtow6FjaCBt4bubaS48Lz5cbiAgICAgICAgICAgICAgICAgICAgOiA8PsSQxqFuIGNoxrBhIHBow6F0IHNpbmgga2hv4bqjbiB0aGFuaCB0b8Ohbi4gS2hpIGjhu6d5LCBraHVuZyBnaeG7nSBz4bq9IMSRxrDhu6NjIG3hu58gdHLhu5FuZyDEkeG7gyBuaOG6rW4ga2jDoWNoIG3hu5tpLjwvPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnOFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCIgc3R5bGU9e3sgbWFyZ2luOiAwIH19PkzDvSBkbyBo4buneSDEkcahbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cInNlbGVjdCBzbVwiIHZhbHVlPXtyZWFzb259IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVhc29uKGUudGFyZ2V0LnZhbHVlKX0+e1JFQVNPTlMubWFwKChyKSA9PiA8b3B0aW9uIGtleT17cn0+e3J9PC9vcHRpb24+KX08L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBjbGFzc05hbWU9XCJpbnB1dCBzbVwiIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDUwMCB9fSBwbGFjZWhvbGRlcj1cIkdoaSBjaMO6IHRow6ptIChraMO0bmcgYuG6r3QgYnXhu5ljKVwiIHZhbHVlPXtub3RlfSBvbkNoYW5nZT17KGUpID0+IHNldE5vdGUoZS50YXJnZXQudmFsdWUpfSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1kYW5nZXIgYnRuLW1kIGJ0bi1ibG9ja1wiIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNhbmNlbEJvb2tpbmcoY2FuY2VsLmlkLCBub3RlLnRyaW0oKSA/IGAke3JlYXNvbn0g4oCTICR7bm90ZS50cmltKCl9YCA6IHJlYXNvbiwgY2FuY2VsLnBhaWQgPiAwKVxuICAgICAgICAgICAgICAgICAgdG9hc3QoYMSQw6MgaOG7p3kgxJHGoW4gIyR7Y2FuY2VsLmlkfSAmIG3hu58gdHLhu5FuZyBzw6JuLmApOyBzZXRDYW5jZWxJZChudWxsKTsgc2V0Tm90ZSgnJylcbiAgICAgICAgICAgICAgICB9fT5Yw6FjIG5o4bqtbiBo4buneSDEkcahbiAmIE3hu58gdHLhu5FuZyBs4bqhaSBzw6JuPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9hc2lkZT5cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApXG59XG5cbmZ1bmN0aW9uIExpbmUoeyBrLCB2LCBncmVlbiB9OiB7IGs6IHN0cmluZzsgdjogc3RyaW5nOyBncmVlbj86IGJvb2xlYW4gfSkge1xuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiBnMTIgdDEyXCI+PHNwYW4gY2xhc3NOYW1lPXtncmVlbiA/ICdjLWJyYW5kOCcgOiAnYy1zNjAwJ30+e2t9PC9zcGFuPjxiIGNsYXNzTmFtZT17Z3JlZW4gPyAnYy1icmFuZDgnIDogJ2MtaW5rJ30gc3R5bGU9e3sgdGV4dEFsaWduOiAncmlnaHQnIH19Pnt2fTwvYj48L2Rpdj5cbn1cbiJdfQ==