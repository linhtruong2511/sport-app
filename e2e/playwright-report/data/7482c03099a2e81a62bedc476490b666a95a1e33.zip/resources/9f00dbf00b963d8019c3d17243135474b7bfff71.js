import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/MyBookings.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { TODAY, branchOf, remaining, toVN, vnd } from "/src/data.ts";
import { useApp, useNow } from "/src/store.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/MyBookings.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
const ORDER = {
	confirmed: 0,
	playing: 0,
	overdue: 0,
	pending: 1,
	completed: 2,
	cancelled: 3
};
export default function MyBookings() {
	_s();
	const { bookings, courts, user, cancelBooking, toast } = useApp();
	const nav = useNavigate();
	const now = useNow(1e3);
	const [tab, setTab] = useState("all");
	const [from, setFrom] = useState("2026-11-01");
	const [to, setTo] = useState("2026-11-30");
	const [target, setTarget] = useState(null);
	const [reason, setReason] = useState("Thay đổi kế hoạch cá nhân");
	const owner = user?.role === "customer" ? user.phone : "0987654321";
	const mine = bookings.filter((b) => b.phone === owner && b.date >= from && b.date <= to).sort((a, b) => ORDER[a.status] - ORDER[b.status] || a.date.localeCompare(b.date));
	const grp = (b) => [
		"confirmed",
		"playing",
		"overdue"
	].includes(b.status) ? "confirmed" : b.status;
	const count = (t) => t === "all" ? mine.length : mine.filter((b) => grp(b) === t).length;
	const list = tab === "all" ? mine : mine.filter((b) => grp(b) === tab);
	const info = (b) => {
		const c = courts.find((x) => x.id === b.courtId);
		return {
			c,
			br: branchOf(c.branchId)
		};
	};
	const upcoming = mine.find((b) => b.status === "confirmed" && b.date === TODAY);
	const tabs = [
		["all", "Tất cả"],
		["pending", "Chờ thanh toán"],
		["confirmed", "Đã xác nhận"],
		["completed", "Hoàn thành"],
		["cancelled", "Đã hủy"]
	];
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("section", {
			className: "card row between wrap g16",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "col g2",
				children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "t20 w800 c-ink",
					children: "Lịch đặt sân của tôi & Thông báo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "t12 c-s600",
					children: "Theo dõi các lịch sắp diễn ra, kiểm tra số tiền còn thiếu khi nhận sân và xem tin nhắn ưu đãi từ sân."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "row g8 wrap",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "t12 w600 c-s600",
						children: "Thời gian đặt:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "date",
						className: "input sm",
						style: { width: "auto" },
						value: from,
						onChange: (e) => setFrom(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "t12 w600 c-ink",
						children: "đến"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "date",
						className: "input sm",
						style: { width: "auto" },
						value: to,
						onChange: (e) => setTo(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "grid12",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "span8 col g16",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "row g8",
						style: {
							overflow: "auto",
							paddingBottom: 4
						},
						children: tabs.map(([k, l]) => /* @__PURE__ */ _jsxDEV("button", {
							className: `btn ${tab === k ? "btn-primary" : "btn-outline"}`,
							style: { fontWeight: tab === k ? 700 : 600 },
							onClick: () => setTab(k),
							children: [
								l,
								" (",
								count(k),
								")"
							]
						}, k, true, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 11
					}, this),
					list.length === 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "card center t12 c-s600",
						style: { padding: 40 },
						children: "Chưa có lịch đặt nào trong mục này."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 33
					}, this),
					list.map((b) => {
						const { c, br } = info(b);
						const left = remaining(b);
						const head = /* @__PURE__ */ _jsxDEV("div", {
							className: "row between wrap g12 head-rule",
							style: { rowGap: 8 },
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "row g10",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "mono t11 w800 c-ink",
									style: {
										background: "var(--s200)",
										borderRadius: 8,
										padding: "4px 10px",
										fontSize: 11.5
									},
									children: ["#", b.id]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 59,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "t14 w800 c-ink",
									children: [
										br.name,
										" • ",
										c.name
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 60,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 58,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "row g8",
								children: badges(b)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 15
						}, this);
						if (b.status === "completed") return /* @__PURE__ */ _jsxDEV("div", {
							className: "card col g12",
							children: [head, /* @__PURE__ */ _jsxDEV("div", {
								className: "row between wrap g12",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "t12 c-s700",
									children: [
										"Ngày chơi: ",
										/* @__PURE__ */ _jsxDEV("b", { children: [
											toVN(b.date),
											" • ",
											b.start,
											" - ",
											b.end
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 67,
											columnNumber: 95
										}, this),
										" • Tổng thanh toán: ",
										/* @__PURE__ */ _jsxDEV("b", { children: vnd(b.paid) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 67,
											columnNumber: 158
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 55
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									className: "link-btn",
									onClick: () => nav(`/booking?branch=${c.branchId}&sport=${c.sport}`),
									children: "Đặt lại sân này →"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 67,
								columnNumber: 17
							}, this)]
						}, b.id, true, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 15
						}, this);
						if (b.status === "cancelled") return /* @__PURE__ */ _jsxDEV("div", {
							className: "card col g12",
							style: { opacity: .9 },
							children: [head, /* @__PURE__ */ _jsxDEV("p", {
								className: "t12 c-s600",
								children: [
									b.cancelledAt ? `Đã hủy lúc ${b.cancelledAt}` : `Đơn đã bị hủy`,
									" • Lý do: ",
									/* @__PURE__ */ _jsxDEV("i", { children: [
										"\"",
										b.cancelReason ?? "Không nêu lý do",
										"\""
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 72,
										columnNumber: 118
									}, this),
									"."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 17
							}, this)]
						}, b.id, true, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 15
						}, this);
						const isPending = b.status === "pending";
						const sec = Math.max(0, Math.floor(((b.holdUntil ?? now) - now) / 1e3));
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "card col g16",
							children: [
								head,
								/* @__PURE__ */ _jsxDEV("div", {
									className: "row g12",
									style: { alignItems: "flex-start" },
									children: [
										/* @__PURE__ */ _jsxDEV(Info, {
											k: "Thời gian chơi:",
											v: `${toVN(b.date)} • ${b.start} - ${b.end}`
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 78,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV(Info, {
											k: "Tổng tiền đơn:",
											v: vnd(b.total)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 79,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV(Info, {
											k: isPending ? "Đã thanh toán:" : "Đã đặt cọc:",
											v: vnd(b.paid),
											cls: isPending ? "c-s700" : "c-brand8 w800"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 80,
											columnNumber: 19
										}, this),
										isPending ? /* @__PURE__ */ _jsxDEV(Info, {
											k: "Cần chuyển khoản:",
											v: `${vnd(b.payMode === "full" ? b.total : Math.round(b.total * .3))} (${b.payMode === "full" ? "100" : "30"}%)`,
											cls: "c-brand w800"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 81,
											columnNumber: 32
										}, this) : /* @__PURE__ */ _jsxDEV(Info, {
											k: "Cần trả thêm tại sân:",
											v: vnd(left),
											cls: "c-amber w800"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 82,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "row between wrap g12 top-rule",
									style: { rowGap: 12 },
									children: [isPending ? /* @__PURE__ */ _jsxDEV("span", {
										className: "t12 w700 c-amber",
										children: [
											"⏳ Hệ thống đang giữ chỗ tạm thời cho bạn (còn ",
											String(Math.floor(sec / 60)).padStart(2, "0"),
											" phút ",
											String(sec % 60).padStart(2, "0"),
											" giây)."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 86,
										columnNumber: 23
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "t12 w500 c-s700",
										children: [
											"🔔 Lịch chơi diễn ra lúc ",
											b.start,
											" ",
											b.date === TODAY ? "hôm nay" : `ngày ${toVN(b.date)}`,
											". Vui lòng đến quầy lễ tân trước 10 phút để nhận sân."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 87,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "row g8",
										children: [isPending && /* @__PURE__ */ _jsxDEV(Link, {
											className: "btn btn-primary btn-sm",
											style: { padding: "6px 16px" },
											to: `/payment/${b.id}`,
											children: "Thanh toán QR ngay"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 89,
											columnNumber: 35
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											className: `btn btn-sm ${isPending ? "btn-outline" : "btn-danger-o"}`,
											style: {
												padding: "6px 14px",
												fontWeight: isPending ? 600 : 700
											},
											onClick: () => {
												setTarget(b);
												setReason("Thay đổi kế hoạch cá nhân");
											},
											children: isPending ? "Hủy đơn" : "Hủy lịch đặt"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 90,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 88,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 17
								}, this)
							]
						}, b.id, true, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 15
						}, this);
					})
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				className: "span4 card col g16",
				style: { boxShadow: "var(--shadow-sm)" },
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "row between head-rule",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "row g8",
							children: [/* @__PURE__ */ _jsxDEV("i", { style: {
								width: 10,
								height: 10,
								borderRadius: 9999,
								background: "var(--brand-700)"
							} }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 37
							}, this), /* @__PURE__ */ _jsxDEV("h2", {
								className: "t16 w800 c-ink",
								style: { lineHeight: "24px" },
								children: "Thông báo nhắc lịch & Ưu đãi"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 128
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "badge c-white",
							style: {
								background: "var(--brand-700)",
								padding: "2px 10px"
							},
							children: "3 mới"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this),
					upcoming && /* @__PURE__ */ _jsxDEV("div", {
						className: "col g6",
						style: {
							background: "var(--brand-50)",
							border: "2px solid var(--brand-600)",
							borderRadius: 12,
							padding: 16
						},
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "row between",
								children: [/* @__PURE__ */ _jsxDEV("b", {
									className: "t12 c-ink",
									children: "⏰ Nhắc lịch chơi sắp bắt đầu"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 44
								}, this), /* @__PURE__ */ _jsxDEV("b", {
									className: "t10 c-brand8",
									children: "17:00 Hôm nay"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 101
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "t12 c-s800",
								style: { lineHeight: "19.5px" },
								children: [
									"Chỉ còn 1 tiếng nữa là tới giờ chơi của bạn (",
									/* @__PURE__ */ _jsxDEV("b", { children: [
										upcoming.start,
										" - ",
										upcoming.end,
										" hôm nay"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 119
									}, this),
									") tại ",
									/* @__PURE__ */ _jsxDEV("b", { children: [
										info(upcoming).c.name,
										" - ",
										info(upcoming).br.name.replace(" - ", " ")
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 173
									}, this),
									"."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "hint",
								style: {
									background: "#fff",
									borderColor: "var(--gray-200)",
									padding: 10
								},
								children: [
									/* @__PURE__ */ _jsxDEV("b", {
										className: "c-ink",
										children: "Số tiền còn lại cần thanh toán tại quầy: "
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 107,
										columnNumber: 113
									}, this),
									/* @__PURE__ */ _jsxDEV("b", {
										style: {
											color: "var(--rose-700)",
											fontWeight: 900
										},
										children: vnd(remaining(upcoming))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 107,
										columnNumber: 179
									}, this),
									"."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Notice, {
						title: "🎁 Giảm 20% khung giờ vàng buổi sáng",
						when: "Hôm qua",
						children: [
							"Nhập mã ",
							/* @__PURE__ */ _jsxDEV("b", { children: "SANGVUI20" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 87
							}, this),
							" để được giảm ngay ",
							/* @__PURE__ */ _jsxDEV("b", { children: "20% (tối đa 100.000đ)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 122
							}, this),
							" khi đặt sân từ 06:00 – 11:00 tại mọi chi nhánh."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Notice, {
						title: "🎉 Ưu đãi tri ân hội viên tháng 11",
						when: "01/11/2026",
						children: [
							"Cảm ơn bạn đã đồng hành cùng SportHub! Dùng mã ",
							/* @__PURE__ */ _jsxDEV("b", { children: "TRIAN10" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 127
							}, this),
							" để giảm 10% cho mọi khung giờ đặt trực tuyến."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 7
		}, this),
		target && /* @__PURE__ */ _jsxDEV("div", {
			className: "modal-bg",
			onClick: () => setTarget(null),
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "modal",
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "t18 w800 c-ink",
						children: [
							"Xác nhận hủy ",
							target.status === "pending" ? "đơn" : "lịch đặt",
							" #",
							target.id,
							"?"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 13
					}, this),
					target.paid > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "hint",
						style: {
							background: "var(--rose-50)",
							borderColor: "var(--rose-300)",
							color: "var(--rose-950)"
						},
						children: [
							"Theo quy định, khoản tiền đã đặt cọc ",
							/* @__PURE__ */ _jsxDEV("b", { children: vnd(target.paid) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 191
							}, this),
							" sẽ ",
							/* @__PURE__ */ _jsxDEV("b", { children: "không được hoàn lại" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 220
							}, this),
							" khi hủy lịch."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 33
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "label",
						children: "Lý do hủy"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 18
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						className: "select",
						value: reason,
						onChange: (e) => setReason(e.target.value),
						children: [
							"Thay đổi kế hoạch cá nhân",
							"Bận công việc đột xuất không thể tham gia",
							"Đặt nhầm khung giờ",
							"Lý do khác"
						].map((r) => /* @__PURE__ */ _jsxDEV("option", { children: r }, r, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 140
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "row g8",
						style: { justifyContent: "flex-end" },
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "btn btn-outline btn-md",
							onClick: () => setTarget(null),
							children: "Giữ lịch"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: "btn btn-danger btn-md",
							onClick: () => {
								cancelBooking(target.id, reason, target.paid > 0);
								toast(`Đã hủy ${target.id}.`);
								setTarget(null);
							},
							children: "Xác nhận hủy"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 116,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
	function badges(b) {
		if (b.status === "pending") return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "badge b-amber",
			children: "Chờ thanh toán"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 42
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "badge b-gray-o",
			children: "Chưa thanh toán"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 95
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 40
		}, this);
		if (b.status === "completed") return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "badge b-gray",
			children: "Hoàn thành"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 136,
			columnNumber: 44
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "badge b-green-flat",
			children: "Đã thanh toán đủ"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 136,
			columnNumber: 92
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 136,
			columnNumber: 42
		}, this);
		if (b.status === "cancelled") return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "badge b-rose",
			style: { background: "var(--rose-100)" },
			children: "Đã hủy"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 137,
			columnNumber: 44
		}, this), b.keptDeposit ? /* @__PURE__ */ _jsxDEV("span", {
			className: "badge b-rose-soft",
			children: [
				"Không hoàn tiền cọc (",
				fmtK(b.keptDeposit),
				")"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 137,
			columnNumber: 147
		}, this) : null] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 137,
			columnNumber: 42
		}, this);
		return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "badge b-green",
			children: b.status === "playing" ? "Đang sử dụng" : b.status === "overdue" ? "Quá giờ nhận sân" : "Đã xác nhận"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 138,
			columnNumber: 14
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: `badge ${b.paid >= b.total ? "b-green-flat" : "b-teal"}`,
			children: b.paid >= b.total ? "Đã thanh toán đủ" : `Đã đặt cọc (${Math.round(b.paid / b.total * 100)}%)`
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 139,
			columnNumber: 7
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 138,
			columnNumber: 12
		}, this);
	}
}
_s(MyBookings, "6SEL4P8RB70/jNeiBUCceiiCzE0=", false, function() {
	return [
		useApp,
		useNavigate,
		useNow
	];
});
_c = MyBookings;
const fmtK = (n) => `${String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ".")}đ`;
function Info({ k, v, cls }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "col f1",
		children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "t12 c-s500",
			children: k
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 145,
			columnNumber: 34
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: `t12 w700 ${cls ?? "c-ink"}`,
			children: v
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 145,
			columnNumber: 73
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 145,
		columnNumber: 10
	}, this);
}
_c2 = Info;
function Notice({ title, when, children }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "col g6",
		style: {
			background: "var(--s100)",
			border: "1px solid var(--s300)",
			borderRadius: 12,
			padding: 16
		},
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "row between",
			children: [/* @__PURE__ */ _jsxDEV("b", {
				className: "t12 c-ink",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 36
			}, this), /* @__PURE__ */ _jsxDEV("b", {
				className: "t10 c-s500",
				style: { fontWeight: 600 },
				children: when
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 72
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 150,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			className: "t12 c-s700",
			style: { lineHeight: "19.5px" },
			children
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 151,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 149,
		columnNumber: 5
	}, this);
}
_c3 = Notice;
var _c, _c2, _c3;
$RefreshReg$(_c, "MyBookings");
$RefreshReg$(_c2, "Info");
$RefreshReg$(_c3, "Notice");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/MyBookings.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/MyBookings.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/MyBookings.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/MyBookings.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLE9BQU8sVUFBVSxXQUFXLE1BQU0sV0FBVztBQUV0RCxTQUFTLFFBQVEsY0FBYzs7OztBQUcvQixNQUFNLFFBQWdDO0NBQUUsV0FBVztDQUFHLFNBQVM7Q0FBRyxTQUFTO0NBQUcsU0FBUztDQUFHLFdBQVc7Q0FBRyxXQUFXO0FBQUU7QUFFckgsZUFBZSxTQUFTLGFBQWE7O0NBQ25DLE1BQU0sRUFBRSxVQUFVLFFBQVEsTUFBTSxlQUFlLFVBQVUsT0FBTztDQUNoRSxNQUFNLE1BQU0sWUFBWTtDQUN4QixNQUFNLE1BQU0sT0FBTyxHQUFJO0NBQ3ZCLE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBYyxLQUFLO0NBQ3pDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxZQUFZO0NBQzdDLE1BQU0sQ0FBQyxJQUFJLFNBQVMsU0FBUyxZQUFZO0NBQ3pDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBeUIsSUFBSTtDQUN6RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsMkJBQTJCO0NBRWhFLE1BQU0sUUFBUSxNQUFNLFNBQVMsYUFBYSxLQUFLLFFBQVE7Q0FDdkQsTUFBTSxPQUFPLFNBQVMsUUFBUSxNQUFNLEVBQUUsVUFBVSxTQUFTLEVBQUUsUUFBUSxRQUFRLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FDckYsTUFBTSxHQUFHLE1BQU0sTUFBTSxFQUFFLFVBQVUsTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLLGNBQWMsRUFBRSxJQUFJLENBQUM7Q0FDbkYsTUFBTSxPQUFPLE1BQXFCO0VBQUM7RUFBYTtFQUFXO0NBQVMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxNQUFNLElBQUksY0FBZSxFQUFFO0NBQzVHLE1BQU0sU0FBUyxNQUFZLE1BQU0sUUFBUSxLQUFLLFNBQVMsS0FBSyxRQUFRLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Q0FDeEYsTUFBTSxPQUFPLFFBQVEsUUFBUSxPQUFPLEtBQUssUUFBUSxNQUFNLElBQUksQ0FBQyxNQUFNLEdBQUc7Q0FDckUsTUFBTSxRQUFRLE1BQWU7RUFBRSxNQUFNLElBQUksT0FBTyxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTztFQUFJLE9BQU87R0FBRTtHQUFHLElBQUksU0FBUyxFQUFFLFFBQVE7RUFBRTtDQUFFO0NBQ3pILE1BQU0sV0FBVyxLQUFLLE1BQU0sTUFBTSxFQUFFLFdBQVcsZUFBZSxFQUFFLFNBQVMsS0FBSztDQUM5RSxNQUFNLE9BQXdCO0VBQUMsQ0FBQyxPQUFPLFFBQVE7RUFBRyxDQUFDLFdBQVcsZ0JBQWdCO0VBQUcsQ0FBQyxhQUFhLGFBQWE7RUFBRyxDQUFDLGFBQWEsWUFBWTtFQUFHLENBQUMsYUFBYSxRQUFRO0NBQUM7Q0FFbkssT0FDRTtFQUNFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWlCO0lBQW9DOzs7O2NBQ25FLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWE7SUFBd0c7Ozs7WUFDL0g7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFrQjtLQUFvQjs7Ozs7S0FDdEQsd0JBQUMsU0FBRDtNQUFPLE1BQUs7TUFBTyxXQUFVO01BQVcsT0FBTyxFQUFFLE9BQU8sT0FBTztNQUFHLE9BQU87TUFBTSxXQUFXLE1BQU0sUUFBUSxFQUFFLE9BQU8sS0FBSztLQUFJOzs7OztLQUMxSCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaUI7S0FBUzs7Ozs7S0FDMUMsd0JBQUMsU0FBRDtNQUFPLE1BQUs7TUFBTyxXQUFVO01BQVcsT0FBTyxFQUFFLE9BQU8sT0FBTztNQUFHLE9BQU87TUFBSSxXQUFXLE1BQU0sTUFBTSxFQUFFLE9BQU8sS0FBSztLQUFJOzs7OztJQUNuSDs7Ozs7V0FDRTs7Ozs7O0VBRVQsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFTLE9BQU87T0FBRSxVQUFVO09BQVEsZUFBZTtNQUFFO2dCQUNqRSxLQUFLLEtBQUssQ0FBQyxHQUFHLE9BQ2Isd0JBQUMsVUFBRDtPQUFnQixXQUFXLE9BQU8sUUFBUSxJQUFJLGdCQUFnQjtPQUFpQixPQUFPLEVBQUUsWUFBWSxRQUFRLElBQUksTUFBTSxJQUFJO09BQUcsZUFBZSxPQUFPLENBQUM7aUJBQXBKO1FBQXdKO1FBQUU7UUFBRyxNQUFNLENBQUM7UUFBRTtPQUFTO1NBQWxLOzs7O2FBQWtLLENBQ2hMO0tBQ0U7Ozs7O0tBQ0osS0FBSyxXQUFXLEtBQUssd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBeUIsT0FBTyxFQUFFLFNBQVMsR0FBRztnQkFBRztLQUF3Qzs7Ozs7S0FDN0gsS0FBSyxLQUFLLE1BQU07TUFDZixNQUFNLEVBQUUsR0FBRyxPQUFPLEtBQUssQ0FBQztNQUN4QixNQUFNLE9BQU8sVUFBVSxDQUFDO01BQ3hCLE1BQU0sT0FDSix3QkFBQyxPQUFEO09BQUssV0FBVTtPQUFpQyxPQUFPLEVBQUUsUUFBUSxFQUFFO2lCQUFuRSxDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7U0FBc0IsT0FBTztVQUFFLFlBQVk7VUFBZSxjQUFjO1VBQUcsU0FBUztVQUFZLFVBQVU7U0FBSzttQkFBL0gsQ0FBa0ksS0FBRSxFQUFFLEVBQVM7Ozs7O2tCQUMvSSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEI7VUFBa0MsR0FBRztVQUFLO1VBQUksRUFBRTtTQUFXOzs7OztnQkFDeEQ7Ozs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFVLE9BQU8sQ0FBQztPQUFPOzs7O2VBQ3JDOzs7Ozs7TUFFUCxJQUFJLEVBQUUsV0FBVyxhQUFhLE9BQzVCLHdCQUFDLE9BQUQ7T0FBZ0IsV0FBVTtpQkFBMUIsQ0FBMEMsTUFDeEMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBc0Msd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCO1VBQTZCO1VBQVcsd0JBQUMsS0FBRDtXQUFJLEtBQUssRUFBRSxJQUFJO1dBQUU7V0FBSSxFQUFFO1dBQU07V0FBSSxFQUFFO1VBQU87Ozs7O1VBQUM7VUFBb0Isd0JBQUMsS0FBRCxZQUFJLElBQUksRUFBRSxJQUFJLEVBQUs7Ozs7O1NBQU87Ozs7O2tCQUNySyx3QkFBQyxVQUFEO1NBQVEsV0FBVTtTQUFXLGVBQWUsSUFBSSxtQkFBbUIsRUFBRSxTQUFTLFNBQVMsRUFBRSxPQUFPO21CQUFHO1FBQXlCOzs7O2dCQUFNOzs7OztlQUNqSTtTQUhLLEVBQUU7Ozs7YUFHUDtNQUNQLElBQUksRUFBRSxXQUFXLGFBQWEsT0FDNUIsd0JBQUMsT0FBRDtPQUFnQixXQUFVO09BQWUsT0FBTyxFQUFFLFNBQVMsR0FBSTtpQkFBL0QsQ0FBbUUsTUFDakUsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FBMkIsRUFBRSxjQUFjLGNBQWMsRUFBRSxnQkFBZ0I7U0FBZ0I7U0FBVSx3QkFBQyxLQUFEO1VBQUc7VUFBRSxFQUFFLGdCQUFnQjtVQUFrQjtTQUFJOzs7OztTQUFDO1FBQUk7Ozs7O2VBQU07U0FEckosRUFBRTs7OzthQUNtSjtNQUNqSyxNQUFNLFlBQVksRUFBRSxXQUFXO01BQy9CLE1BQU0sTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLFFBQVEsRUFBRSxhQUFhLE9BQU8sT0FBTyxHQUFJLENBQUM7TUFDdkUsT0FDRSx3QkFBQyxPQUFEO09BQWdCLFdBQVU7aUJBQTFCO1FBQTBDO1FBQ3hDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQVUsT0FBTyxFQUFFLFlBQVksYUFBYTttQkFBM0Q7VUFDRSx3QkFBQyxNQUFEO1dBQU0sR0FBRTtXQUFrQixHQUFHLEdBQUcsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsTUFBTSxLQUFLLEVBQUU7VUFBUTs7Ozs7VUFDekUsd0JBQUMsTUFBRDtXQUFNLEdBQUU7V0FBaUIsR0FBRyxJQUFJLEVBQUUsS0FBSztVQUFJOzs7OztVQUMzQyx3QkFBQyxNQUFEO1dBQU0sR0FBRyxZQUFZLG1CQUFtQjtXQUFlLEdBQUcsSUFBSSxFQUFFLElBQUk7V0FBRyxLQUFLLFlBQVksV0FBVztVQUFrQjs7Ozs7VUFDcEgsWUFBWSx3QkFBQyxNQUFEO1dBQU0sR0FBRTtXQUFvQixHQUFHLEdBQUcsSUFBSSxFQUFFLFlBQVksU0FBUyxFQUFFLFFBQVEsS0FBSyxNQUFNLEVBQUUsUUFBUSxFQUFHLENBQUMsRUFBRSxJQUFJLEVBQUUsWUFBWSxTQUFTLFFBQVEsS0FBSztXQUFLLEtBQUk7VUFBZ0I7Ozs7cUJBQzVLLHdCQUFDLE1BQUQ7V0FBTSxHQUFFO1dBQXdCLEdBQUcsSUFBSSxJQUFJO1dBQUcsS0FBSTtVQUFnQjs7Ozs7U0FDbkU7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQWdDLE9BQU8sRUFBRSxRQUFRLEdBQUc7bUJBQW5FLENBQ0csWUFDRyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEI7V0FBbUM7V0FBK0MsT0FBTyxLQUFLLE1BQU0sTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO1dBQUU7V0FBTyxPQUFPLE1BQU0sRUFBRSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7V0FBRTtVQUFhOzs7OztvQkFDdEwsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQWtDO1dBQTBCLEVBQUU7V0FBTTtXQUFFLEVBQUUsU0FBUyxRQUFRLFlBQVksUUFBUSxLQUFLLEVBQUUsSUFBSTtXQUFJO1VBQTJEOzs7OzttQkFDM0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRyxhQUFhLHdCQUFDLE1BQUQ7V0FBTSxXQUFVO1dBQXlCLE9BQU8sRUFBRSxTQUFTLFdBQVc7V0FBRyxJQUFJLFlBQVksRUFBRTtxQkFBTTtVQUF3Qjs7OztvQkFDdkksd0JBQUMsVUFBRDtXQUFRLFdBQVcsY0FBYyxZQUFZLGdCQUFnQjtXQUFrQixPQUFPO1lBQUUsU0FBUztZQUFZLFlBQVksWUFBWSxNQUFNO1dBQUk7V0FBRyxlQUFlO1lBQUUsVUFBVSxDQUFDO1lBQUcsVUFBVSwyQkFBMkI7V0FBRTtxQkFBSSxZQUFZLFlBQVk7VUFBdUI7Ozs7a0JBQ3hROzs7OztpQkFDRjs7Ozs7O09BQ0Y7U0FqQkssRUFBRTs7OzthQWlCUDtLQUVULENBQUM7SUFDRTs7Ozs7YUFFTCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtJQUFxQixPQUFPLEVBQUUsV0FBVyxtQkFBbUI7Y0FBN0U7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQXdCLHdCQUFDLEtBQUQsRUFBRyxPQUFPO1FBQUUsT0FBTztRQUFJLFFBQVE7UUFBSSxjQUFjO1FBQU0sWUFBWTtPQUFtQixFQUFJOzs7O2lCQUFDLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO1FBQWlCLE9BQU8sRUFBRSxZQUFZLE9BQU87a0JBQUc7T0FBZ0M7Ozs7ZUFBTTs7Ozs7Z0JBQ3ZOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO09BQWdCLE9BQU87UUFBRSxZQUFZO1FBQW9CLFNBQVM7T0FBVztpQkFBRztNQUFXOzs7O2NBQ3hHOzs7Ozs7S0FDSixZQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQVMsT0FBTztPQUFFLFlBQVk7T0FBbUIsUUFBUTtPQUE4QixjQUFjO09BQUksU0FBUztNQUFHO2dCQUFwSTtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQTZCLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFZO1FBQStCOzs7O2tCQUFDLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFlO1FBQWdCOzs7O2dCQUFNOzs7Ozs7T0FDeEksd0JBQUMsS0FBRDtRQUFHLFdBQVU7UUFBYSxPQUFPLEVBQUUsWUFBWSxTQUFTO2tCQUF4RDtTQUEyRDtTQUE2Qyx3QkFBQyxLQUFEO1VBQUksU0FBUztVQUFNO1VBQUksU0FBUztVQUFJO1NBQVc7Ozs7O1NBQUM7U0FBTSx3QkFBQyxLQUFEO1VBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxFQUFFO1VBQUs7VUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLEdBQUcsS0FBSyxRQUFRLE9BQU8sR0FBRztTQUFLOzs7OztTQUFDO1FBQUk7Ozs7OztPQUMvTyx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFPLE9BQU87U0FBRSxZQUFZO1NBQVEsYUFBYTtTQUFtQixTQUFTO1FBQUc7a0JBQS9GO1NBQWtHLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFRO1NBQTRDOzs7OztTQUFDLHdCQUFDLEtBQUQ7VUFBRyxPQUFPO1dBQUUsT0FBTztXQUFtQixZQUFZO1VBQUk7b0JBQUksSUFBSSxVQUFVLFFBQVEsQ0FBQztTQUFLOzs7OztTQUFDO1FBQU07Ozs7OztNQUM5UDs7Ozs7O0tBRVAsd0JBQUMsUUFBRDtNQUFRLE9BQU07TUFBdUMsTUFBSztnQkFBMUQ7T0FBb0U7T0FBUSx3QkFBQyxLQUFELFlBQUcsWUFBWTs7Ozs7T0FBQztPQUFtQix3QkFBQyxLQUFELFlBQUcsd0JBQXdCOzs7OztPQUFDO01BQXdEOzs7Ozs7S0FDbk0sd0JBQUMsUUFBRDtNQUFRLE9BQU07TUFBcUMsTUFBSztnQkFBeEQ7T0FBcUU7T0FBK0Msd0JBQUMsS0FBRCxZQUFHLFVBQVU7Ozs7O09BQUM7TUFBc0Q7Ozs7OztJQUNuTDs7Ozs7V0FDSjs7Ozs7O0VBRUosVUFDQyx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFXLGVBQWUsVUFBVSxJQUFJO2FBQ3JELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQVEsVUFBVSxNQUFNLEVBQUUsZ0JBQWdCO2NBQXpEO0tBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FBK0I7T0FBYyxPQUFPLFdBQVcsWUFBWSxRQUFRO09BQVc7T0FBRyxPQUFPO09BQUc7TUFBSzs7Ozs7O0tBQy9HLE9BQU8sT0FBTyxLQUFLLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQU8sT0FBTztPQUFFLFlBQVk7T0FBa0IsYUFBYTtPQUFtQixPQUFPO01BQWtCO2dCQUF0SDtPQUF5SDtPQUFxQyx3QkFBQyxLQUFELFlBQUksSUFBSSxPQUFPLElBQUksRUFBSzs7Ozs7T0FBQztPQUFJLHdCQUFDLEtBQUQsWUFBRyxzQkFBc0I7Ozs7O09BQUM7TUFBbUI7Ozs7OztLQUM1UCx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQVE7S0FBZ0I7Ozs7ZUFDNUMsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBUyxPQUFPO01BQVEsV0FBVyxNQUFNLFVBQVUsRUFBRSxPQUFPLEtBQUs7Z0JBQ2hGO09BQUM7T0FBNkI7T0FBNkM7T0FBc0I7TUFBWSxDQUFDLENBQUMsS0FBSyxNQUFNLHdCQUFDLFVBQUQsWUFBaUIsRUFBVSxHQUFkOzs7O2FBQWMsQ0FBQztLQUNqSjs7OzthQUFNOzs7OztLQUNoQix3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFTLE9BQU8sRUFBRSxnQkFBZ0IsV0FBVztnQkFBNUQsQ0FDRSx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUF5QixlQUFlLFVBQVUsSUFBSTtpQkFBRztNQUFnQjs7OztnQkFDM0Ysd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBd0IsZUFBZTtRQUFFLGNBQWMsT0FBTyxJQUFJLFFBQVEsT0FBTyxPQUFPLENBQUM7UUFBRyxNQUFNLFVBQVUsT0FBTyxHQUFHLEVBQUU7UUFBRyxVQUFVLElBQUk7T0FBRTtpQkFBRztNQUFvQjs7OztjQUNqTDs7Ozs7O0lBQ0Y7Ozs7OztFQUNGOzs7OztDQUVQOzs7OztDQUdKLFNBQVMsT0FBTyxHQUFZO0VBQzFCLElBQUksRUFBRSxXQUFXLFdBQVcsT0FBTyxnREFBRSx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFnQjtFQUFvQjs7OztZQUFDLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWlCO0VBQXFCOzs7O1VBQUc7Ozs7O0VBQ25KLElBQUksRUFBRSxXQUFXLGFBQWEsT0FBTyxnREFBRSx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFlO0VBQWdCOzs7O1lBQUMsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBcUI7RUFBc0I7Ozs7VUFBRzs7Ozs7RUFDckosSUFBSSxFQUFFLFdBQVcsYUFBYSxPQUFPLGdEQUFFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO0dBQWUsT0FBTyxFQUFFLFlBQVksa0JBQWtCO2FBQUc7RUFBWTs7OztZQUFFLEVBQUUsY0FBYyx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFoQjtJQUFvQztJQUFzQixLQUFLLEVBQUUsV0FBVztJQUFFO0dBQU87Ozs7O2FBQUksSUFBTzs7Ozs7RUFDOU8sT0FBTyxnREFBRSx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFpQixFQUFFLFdBQVcsWUFBWSxpQkFBaUIsRUFBRSxXQUFXLFlBQVkscUJBQXFCO0VBQW9COzs7O1lBQ3BKLHdCQUFDLFFBQUQ7R0FBTSxXQUFXLFNBQVMsRUFBRSxRQUFRLEVBQUUsUUFBUSxpQkFBaUI7YUFBYSxFQUFFLFFBQVEsRUFBRSxRQUFRLHFCQUFxQixlQUFlLEtBQUssTUFBTyxFQUFFLE9BQU8sRUFBRSxRQUFTLEdBQUcsRUFBRTtFQUFVOzs7O1VBQUc7Ozs7O0NBQzFMO0FBQ0Y7Ozs7Ozs7OztBQUNBLE1BQU0sUUFBUSxNQUFjLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLHlCQUF5QixHQUFHLEVBQUU7QUFFL0UsU0FBUyxLQUFLLEVBQUUsR0FBRyxHQUFHLE9BQStDO0NBQ25FLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUF3Qix3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFjO0VBQVE7Ozs7WUFBQyx3QkFBQyxRQUFEO0dBQU0sV0FBVyxZQUFZLE9BQU87YUFBWTtFQUFROzs7O1VBQU07Ozs7OztBQUN0STs7QUFDQSxTQUFTLE9BQU8sRUFBRSxPQUFPLE1BQU0sWUFBd0U7Q0FDckcsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFTLE9BQU87R0FBRSxZQUFZO0dBQWUsUUFBUTtHQUF5QixjQUFjO0dBQUksU0FBUztFQUFHO1lBQTNILENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUE2Qix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFhO0dBQVM7Ozs7YUFBQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtJQUFhLE9BQU8sRUFBRSxZQUFZLElBQUk7Y0FBSTtHQUFROzs7O1dBQU07Ozs7O1lBQ3RJLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO0dBQWEsT0FBTyxFQUFFLFlBQVksU0FBUztHQUFJO0VBQVk7Ozs7VUFDckU7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk15Qm9va2luZ3MudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBUT0RBWSwgYnJhbmNoT2YsIHJlbWFpbmluZywgdG9WTiwgdm5kIH0gZnJvbSAnLi4vZGF0YSdcbmltcG9ydCB0eXBlIHsgQm9va2luZyB9IGZyb20gJy4uL2RhdGEnXG5pbXBvcnQgeyB1c2VBcHAsIHVzZU5vdyB9IGZyb20gJy4uL3N0b3JlJ1xuXG50eXBlIFRhYiA9ICdhbGwnIHwgJ3BlbmRpbmcnIHwgJ2NvbmZpcm1lZCcgfCAnY29tcGxldGVkJyB8ICdjYW5jZWxsZWQnXG5jb25zdCBPUkRFUjogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHsgY29uZmlybWVkOiAwLCBwbGF5aW5nOiAwLCBvdmVyZHVlOiAwLCBwZW5kaW5nOiAxLCBjb21wbGV0ZWQ6IDIsIGNhbmNlbGxlZDogMyB9XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE15Qm9va2luZ3MoKSB7XG4gIGNvbnN0IHsgYm9va2luZ3MsIGNvdXJ0cywgdXNlciwgY2FuY2VsQm9va2luZywgdG9hc3QgfSA9IHVzZUFwcCgpXG4gIGNvbnN0IG5hdiA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3Qgbm93ID0gdXNlTm93KDEwMDApXG4gIGNvbnN0IFt0YWIsIHNldFRhYl0gPSB1c2VTdGF0ZTxUYWI+KCdhbGwnKVxuICBjb25zdCBbZnJvbSwgc2V0RnJvbV0gPSB1c2VTdGF0ZSgnMjAyNi0xMS0wMScpXG4gIGNvbnN0IFt0bywgc2V0VG9dID0gdXNlU3RhdGUoJzIwMjYtMTEtMzAnKVxuICBjb25zdCBbdGFyZ2V0LCBzZXRUYXJnZXRdID0gdXNlU3RhdGU8Qm9va2luZyB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFtyZWFzb24sIHNldFJlYXNvbl0gPSB1c2VTdGF0ZSgnVGhheSDEkeG7lWkga+G6vyBob+G6oWNoIGPDoSBuaMOibicpXG5cbiAgY29uc3Qgb3duZXIgPSB1c2VyPy5yb2xlID09PSAnY3VzdG9tZXInID8gdXNlci5waG9uZSA6ICcwOTg3NjU0MzIxJ1xuICBjb25zdCBtaW5lID0gYm9va2luZ3MuZmlsdGVyKChiKSA9PiBiLnBob25lID09PSBvd25lciAmJiBiLmRhdGUgPj0gZnJvbSAmJiBiLmRhdGUgPD0gdG8pXG4gICAgLnNvcnQoKGEsIGIpID0+IE9SREVSW2Euc3RhdHVzXSAtIE9SREVSW2Iuc3RhdHVzXSB8fCBhLmRhdGUubG9jYWxlQ29tcGFyZShiLmRhdGUpKVxuICBjb25zdCBncnAgPSAoYjogQm9va2luZyk6IFRhYiA9PiAoWydjb25maXJtZWQnLCAncGxheWluZycsICdvdmVyZHVlJ10uaW5jbHVkZXMoYi5zdGF0dXMpID8gJ2NvbmZpcm1lZCcgOiAoYi5zdGF0dXMgYXMgVGFiKSlcbiAgY29uc3QgY291bnQgPSAodDogVGFiKSA9PiAodCA9PT0gJ2FsbCcgPyBtaW5lLmxlbmd0aCA6IG1pbmUuZmlsdGVyKChiKSA9PiBncnAoYikgPT09IHQpLmxlbmd0aClcbiAgY29uc3QgbGlzdCA9IHRhYiA9PT0gJ2FsbCcgPyBtaW5lIDogbWluZS5maWx0ZXIoKGIpID0+IGdycChiKSA9PT0gdGFiKVxuICBjb25zdCBpbmZvID0gKGI6IEJvb2tpbmcpID0+IHsgY29uc3QgYyA9IGNvdXJ0cy5maW5kKCh4KSA9PiB4LmlkID09PSBiLmNvdXJ0SWQpITsgcmV0dXJuIHsgYywgYnI6IGJyYW5jaE9mKGMuYnJhbmNoSWQpIH0gfVxuICBjb25zdCB1cGNvbWluZyA9IG1pbmUuZmluZCgoYikgPT4gYi5zdGF0dXMgPT09ICdjb25maXJtZWQnICYmIGIuZGF0ZSA9PT0gVE9EQVkpXG4gIGNvbnN0IHRhYnM6IFtUYWIsIHN0cmluZ11bXSA9IFtbJ2FsbCcsICdU4bqldCBj4bqjJ10sIFsncGVuZGluZycsICdDaOG7nSB0aGFuaCB0b8OhbiddLCBbJ2NvbmZpcm1lZCcsICfEkMOjIHjDoWMgbmjhuq1uJ10sIFsnY29tcGxldGVkJywgJ0hvw6BuIHRow6BuaCddLCBbJ2NhbmNlbGxlZCcsICfEkMOjIGjhu6d5J11dXG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY2FyZCByb3cgYmV0d2VlbiB3cmFwIGcxNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnMlwiPlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0MjAgdzgwMCBjLWlua1wiPkzhu4tjaCDEkeG6t3Qgc8OibiBj4bunYSB0w7RpICYgVGjDtG5nIGLDoW88L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj5UaGVvIGTDtWkgY8OhYyBs4buLY2ggc+G6r3AgZGnhu4VuIHJhLCBraeG7g20gdHJhIHPhu5EgdGnhu4FuIGPDsm4gdGhp4bq/dSBraGkgbmjhuq1uIHPDom4gdsOgIHhlbSB0aW4gbmjhuq9uIMawdSDEkcOjaSB04burIHPDom4uPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzggd3JhcFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NjAwIGMtczYwMFwiPlRo4budaSBnaWFuIMSR4bq3dDo8L3NwYW4+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJkYXRlXCIgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiBzdHlsZT17eyB3aWR0aDogJ2F1dG8nIH19IHZhbHVlPXtmcm9tfSBvbkNoYW5nZT17KGUpID0+IHNldEZyb20oZS50YXJnZXQudmFsdWUpfSAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NjAwIGMtaW5rXCI+xJHhur9uPC9zcGFuPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZGF0ZVwiIGNsYXNzTmFtZT1cImlucHV0IHNtXCIgc3R5bGU9e3sgd2lkdGg6ICdhdXRvJyB9fSB2YWx1ZT17dG99IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VG8oZS50YXJnZXQudmFsdWUpfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkMTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFuOCBjb2wgZzE2XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzhcIiBzdHlsZT17eyBvdmVyZmxvdzogJ2F1dG8nLCBwYWRkaW5nQm90dG9tOiA0IH19PlxuICAgICAgICAgICAge3RhYnMubWFwKChbaywgbF0pID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2t9IGNsYXNzTmFtZT17YGJ0biAke3RhYiA9PT0gayA/ICdidG4tcHJpbWFyeScgOiAnYnRuLW91dGxpbmUnfWB9IHN0eWxlPXt7IGZvbnRXZWlnaHQ6IHRhYiA9PT0gayA/IDcwMCA6IDYwMCB9fSBvbkNsaWNrPXsoKSA9PiBzZXRUYWIoayl9PntsfSAoe2NvdW50KGspfSk8L2J1dHRvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtsaXN0Lmxlbmd0aCA9PT0gMCAmJiA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgY2VudGVyIHQxMiBjLXM2MDBcIiBzdHlsZT17eyBwYWRkaW5nOiA0MCB9fT5DaMawYSBjw7MgbOG7i2NoIMSR4bq3dCBuw6BvIHRyb25nIG3hu6VjIG7DoHkuPC9kaXY+fVxuICAgICAgICAgIHtsaXN0Lm1hcCgoYikgPT4ge1xuICAgICAgICAgICAgY29uc3QgeyBjLCBiciB9ID0gaW5mbyhiKVxuICAgICAgICAgICAgY29uc3QgbGVmdCA9IHJlbWFpbmluZyhiKVxuICAgICAgICAgICAgY29uc3QgaGVhZCA9IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiB3cmFwIGcxMiBoZWFkLXJ1bGVcIiBzdHlsZT17eyByb3dHYXA6IDggfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzEwXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vIHQxMSB3ODAwIGMtaW5rXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLXMyMDApJywgYm9yZGVyUmFkaXVzOiA4LCBwYWRkaW5nOiAnNHB4IDEwcHgnLCBmb250U2l6ZTogMTEuNSB9fT4je2IuaWR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDE0IHc4MDAgYy1pbmtcIj57YnIubmFtZX0g4oCiIHtjLm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGc4XCI+e2JhZGdlcyhiKX08L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApXG4gICAgICAgICAgICBpZiAoYi5zdGF0dXMgPT09ICdjb21wbGV0ZWQnKSByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17Yi5pZH0gY2xhc3NOYW1lPVwiY2FyZCBjb2wgZzEyXCI+e2hlYWR9XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiB3cmFwIGcxMlwiPjxzcGFuIGNsYXNzTmFtZT1cInQxMiBjLXM3MDBcIj5OZ8OgeSBjaMahaTogPGI+e3RvVk4oYi5kYXRlKX0g4oCiIHtiLnN0YXJ0fSAtIHtiLmVuZH08L2I+IOKAoiBU4buVbmcgdGhhbmggdG/DoW46IDxiPnt2bmQoYi5wYWlkKX08L2I+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJsaW5rLWJ0blwiIG9uQ2xpY2s9eygpID0+IG5hdihgL2Jvb2tpbmc/YnJhbmNoPSR7Yy5icmFuY2hJZH0mc3BvcnQ9JHtjLnNwb3J0fWApfT7EkOG6t3QgbOG6oWkgc8OibiBuw6B5IOKGkjwvYnV0dG9uPjwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj4pXG4gICAgICAgICAgICBpZiAoYi5zdGF0dXMgPT09ICdjYW5jZWxsZWQnKSByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17Yi5pZH0gY2xhc3NOYW1lPVwiY2FyZCBjb2wgZzEyXCIgc3R5bGU9e3sgb3BhY2l0eTogMC45IH19PntoZWFkfVxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj57Yi5jYW5jZWxsZWRBdCA/IGDEkMOjIGjhu6d5IGzDumMgJHtiLmNhbmNlbGxlZEF0fWAgOiBgxJDGoW4gxJHDoyBi4buLIGjhu6d5YH0g4oCiIEzDvSBkbzogPGk+XCJ7Yi5jYW5jZWxSZWFzb24gPz8gJ0tow7RuZyBuw6p1IGzDvSBkbyd9XCI8L2k+LjwvcD48L2Rpdj4pXG4gICAgICAgICAgICBjb25zdCBpc1BlbmRpbmcgPSBiLnN0YXR1cyA9PT0gJ3BlbmRpbmcnXG4gICAgICAgICAgICBjb25zdCBzZWMgPSBNYXRoLm1heCgwLCBNYXRoLmZsb29yKCgoYi5ob2xkVW50aWwgPz8gbm93KSAtIG5vdykgLyAxMDAwKSlcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtiLmlkfSBjbGFzc05hbWU9XCJjYXJkIGNvbCBnMTZcIj57aGVhZH1cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTJcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiAnZmxleC1zdGFydCcgfX0+XG4gICAgICAgICAgICAgICAgICA8SW5mbyBrPVwiVGjhu51pIGdpYW4gY2jGoWk6XCIgdj17YCR7dG9WTihiLmRhdGUpfSDigKIgJHtiLnN0YXJ0fSAtICR7Yi5lbmR9YH0gLz5cbiAgICAgICAgICAgICAgICAgIDxJbmZvIGs9XCJU4buVbmcgdGnhu4FuIMSRxqFuOlwiIHY9e3ZuZChiLnRvdGFsKX0gLz5cbiAgICAgICAgICAgICAgICAgIDxJbmZvIGs9e2lzUGVuZGluZyA/ICfEkMOjIHRoYW5oIHRvw6FuOicgOiAnxJDDoyDEkeG6t3QgY+G7jWM6J30gdj17dm5kKGIucGFpZCl9IGNscz17aXNQZW5kaW5nID8gJ2MtczcwMCcgOiAnYy1icmFuZDggdzgwMCd9IC8+XG4gICAgICAgICAgICAgICAgICB7aXNQZW5kaW5nID8gPEluZm8gaz1cIkPhuqduIGNodXnhu4NuIGtob+G6o246XCIgdj17YCR7dm5kKGIucGF5TW9kZSA9PT0gJ2Z1bGwnID8gYi50b3RhbCA6IE1hdGgucm91bmQoYi50b3RhbCAqIDAuMykpfSAoJHtiLnBheU1vZGUgPT09ICdmdWxsJyA/ICcxMDAnIDogJzMwJ30lKWB9IGNscz1cImMtYnJhbmQgdzgwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDogPEluZm8gaz1cIkPhuqduIHRy4bqjIHRow6ptIHThuqFpIHPDom46XCIgdj17dm5kKGxlZnQpfSBjbHM9XCJjLWFtYmVyIHc4MDBcIiAvPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuIHdyYXAgZzEyIHRvcC1ydWxlXCIgc3R5bGU9e3sgcm93R2FwOiAxMiB9fT5cbiAgICAgICAgICAgICAgICAgIHtpc1BlbmRpbmdcbiAgICAgICAgICAgICAgICAgICAgPyA8c3BhbiBjbGFzc05hbWU9XCJ0MTIgdzcwMCBjLWFtYmVyXCI+4o+zIEjhu4cgdGjhu5FuZyDEkWFuZyBnaeG7ryBjaOG7lyB04bqhbSB0aOG7nWkgY2hvIGLhuqFuIChjw7JuIHtTdHJpbmcoTWF0aC5mbG9vcihzZWMgLyA2MCkpLnBhZFN0YXJ0KDIsICcwJyl9IHBow7p0IHtTdHJpbmcoc2VjICUgNjApLnBhZFN0YXJ0KDIsICcwJyl9IGdpw6J5KS48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDogPHNwYW4gY2xhc3NOYW1lPVwidDEyIHc1MDAgYy1zNzAwXCI+8J+UlCBM4buLY2ggY2jGoWkgZGnhu4VuIHJhIGzDumMge2Iuc3RhcnR9IHtiLmRhdGUgPT09IFRPREFZID8gJ2jDtG0gbmF5JyA6IGBuZ8OgeSAke3RvVk4oYi5kYXRlKX1gfS4gVnVpIGzDsm5nIMSR4bq/biBxdeG6p3kgbOG7hSB0w6JuIHRyxrDhu5tjIDEwIHBow7p0IMSR4buDIG5o4bqtbiBzw6JuLjwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnOFwiPlxuICAgICAgICAgICAgICAgICAgICB7aXNQZW5kaW5nICYmIDxMaW5rIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tc21cIiBzdHlsZT17eyBwYWRkaW5nOiAnNnB4IDE2cHgnIH19IHRvPXtgL3BheW1lbnQvJHtiLmlkfWB9PlRoYW5oIHRvw6FuIFFSIG5nYXk8L0xpbms+fVxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17YGJ0biBidG4tc20gJHtpc1BlbmRpbmcgPyAnYnRuLW91dGxpbmUnIDogJ2J0bi1kYW5nZXItbyd9YH0gc3R5bGU9e3sgcGFkZGluZzogJzZweCAxNHB4JywgZm9udFdlaWdodDogaXNQZW5kaW5nID8gNjAwIDogNzAwIH19IG9uQ2xpY2s9eygpID0+IHsgc2V0VGFyZ2V0KGIpOyBzZXRSZWFzb24oJ1RoYXkgxJHhu5VpIGvhur8gaG/huqFjaCBjw6EgbmjDom4nKSB9fT57aXNQZW5kaW5nID8gJ0jhu6d5IMSRxqFuJyA6ICdI4buneSBs4buLY2ggxJHhurd0J308L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIClcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInNwYW40IGNhcmQgY29sIGcxNlwiIHN0eWxlPXt7IGJveFNoYWRvdzogJ3ZhcigtLXNoYWRvdy1zbSknIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gaGVhZC1ydWxlXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnOFwiPjxpIHN0eWxlPXt7IHdpZHRoOiAxMCwgaGVpZ2h0OiAxMCwgYm9yZGVyUmFkaXVzOiA5OTk5LCBiYWNrZ3JvdW5kOiAndmFyKC0tYnJhbmQtNzAwKScgfX0gLz48aDIgY2xhc3NOYW1lPVwidDE2IHc4MDAgYy1pbmtcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMjRweCcgfX0+VGjDtG5nIGLDoW8gbmjhuq9jIGzhu4tjaCAmIMavdSDEkcOjaTwvaDI+PC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBjLXdoaXRlXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLWJyYW5kLTcwMCknLCBwYWRkaW5nOiAnMnB4IDEwcHgnIH19PjMgbeG7m2k8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge3VwY29taW5nICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGc2XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLWJyYW5kLTUwKScsIGJvcmRlcjogJzJweCBzb2xpZCB2YXIoLS1icmFuZC02MDApJywgYm9yZGVyUmFkaXVzOiAxMiwgcGFkZGluZzogMTYgfX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj48YiBjbGFzc05hbWU9XCJ0MTIgYy1pbmtcIj7ij7AgTmjhuq9jIGzhu4tjaCBjaMahaSBz4bqvcCBi4bqvdCDEkeG6p3U8L2I+PGIgY2xhc3NOYW1lPVwidDEwIGMtYnJhbmQ4XCI+MTc6MDAgSMO0bSBuYXk8L2I+PC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM4MDBcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMTkuNXB4JyB9fT5DaOG7iSBjw7JuIDEgdGnhur9uZyBu4buvYSBsw6AgdOG7m2kgZ2nhu50gY2jGoWkgY+G7p2EgYuG6oW4gKDxiPnt1cGNvbWluZy5zdGFydH0gLSB7dXBjb21pbmcuZW5kfSBow7RtIG5heTwvYj4pIHThuqFpIDxiPntpbmZvKHVwY29taW5nKS5jLm5hbWV9IC0ge2luZm8odXBjb21pbmcpLmJyLm5hbWUucmVwbGFjZSgnIC0gJywgJyAnKX08L2I+LjwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaW50XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNmZmYnLCBib3JkZXJDb2xvcjogJ3ZhcigtLWdyYXktMjAwKScsIHBhZGRpbmc6IDEwIH19PjxiIGNsYXNzTmFtZT1cImMtaW5rXCI+U+G7kSB0aeG7gW4gY8OybiBs4bqhaSBj4bqnbiB0aGFuaCB0b8OhbiB04bqhaSBxdeG6p3k6IDwvYj48YiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXJvc2UtNzAwKScsIGZvbnRXZWlnaHQ6IDkwMCB9fT57dm5kKHJlbWFpbmluZyh1cGNvbWluZykpfTwvYj4uPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxOb3RpY2UgdGl0bGU9XCLwn46BIEdp4bqjbSAyMCUga2h1bmcgZ2nhu50gdsOgbmcgYnXhu5VpIHPDoW5nXCIgd2hlbj1cIkjDtG0gcXVhXCI+Tmjhuq1wIG3DoyA8Yj5TQU5HVlVJMjA8L2I+IMSR4buDIMSRxrDhu6NjIGdp4bqjbSBuZ2F5IDxiPjIwJSAodOG7kWkgxJFhIDEwMC4wMDDEkSk8L2I+IGtoaSDEkeG6t3Qgc8OibiB04burIDA2OjAwIOKAkyAxMTowMCB04bqhaSBt4buNaSBjaGkgbmjDoW5oLjwvTm90aWNlPlxuICAgICAgICAgIDxOb3RpY2UgdGl0bGU9XCLwn46JIMavdSDEkcOjaSB0cmkgw6JuIGjhu5lpIHZpw6puIHRow6FuZyAxMVwiIHdoZW49XCIwMS8xMS8yMDI2XCI+Q+G6o20gxqFuIGLhuqFuIMSRw6MgxJHhu5NuZyBow6BuaCBjw7luZyBTcG9ydEh1YiEgRMO5bmcgbcOjIDxiPlRSSUFOMTA8L2I+IMSR4buDIGdp4bqjbSAxMCUgY2hvIG3hu41pIGtodW5nIGdp4budIMSR4bq3dCB0cuG7sWMgdHV54bq/bi48L05vdGljZT5cbiAgICAgICAgPC9hc2lkZT5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7dGFyZ2V0ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1iZ1wiIG9uQ2xpY2s9eygpID0+IHNldFRhcmdldChudWxsKX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbFwiIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfT5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0MTggdzgwMCBjLWlua1wiPljDoWMgbmjhuq1uIGjhu6d5IHt0YXJnZXQuc3RhdHVzID09PSAncGVuZGluZycgPyAnxJHGoW4nIDogJ2zhu4tjaCDEkeG6t3QnfSAje3RhcmdldC5pZH0/PC9oMz5cbiAgICAgICAgICAgIHt0YXJnZXQucGFpZCA+IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJoaW50XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLXJvc2UtNTApJywgYm9yZGVyQ29sb3I6ICd2YXIoLS1yb3NlLTMwMCknLCBjb2xvcjogJ3ZhcigtLXJvc2UtOTUwKScgfX0+VGhlbyBxdXkgxJHhu4tuaCwga2hv4bqjbiB0aeG7gW4gxJHDoyDEkeG6t3QgY+G7jWMgPGI+e3ZuZCh0YXJnZXQucGFpZCl9PC9iPiBz4bq9IDxiPmtow7RuZyDEkcaw4bujYyBob8OgbiBs4bqhaTwvYj4ga2hpIGjhu6d5IGzhu4tjaC48L2Rpdj59XG4gICAgICAgICAgICA8ZGl2PjxsYWJlbCBjbGFzc05hbWU9XCJsYWJlbFwiPkzDvSBkbyBo4buneTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwic2VsZWN0XCIgdmFsdWU9e3JlYXNvbn0gb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWFzb24oZS50YXJnZXQudmFsdWUpfT5cbiAgICAgICAgICAgICAgICB7WydUaGF5IMSR4buVaSBr4bq/IGhv4bqhY2ggY8OhIG5ow6JuJywgJ0Lhuq1uIGPDtG5nIHZp4buHYyDEkeG7mXQgeHXhuqV0IGtow7RuZyB0aOG7gyB0aGFtIGdpYScsICfEkOG6t3QgbmjhuqdtIGtodW5nIGdp4budJywgJ0zDvSBkbyBraMOhYyddLm1hcCgocikgPT4gPG9wdGlvbiBrZXk9e3J9PntyfTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgIDwvc2VsZWN0PjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzhcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogJ2ZsZXgtZW5kJyB9fT5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUgYnRuLW1kXCIgb25DbGljaz17KCkgPT4gc2V0VGFyZ2V0KG51bGwpfT5HaeG7ryBs4buLY2g8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLWRhbmdlciBidG4tbWRcIiBvbkNsaWNrPXsoKSA9PiB7IGNhbmNlbEJvb2tpbmcodGFyZ2V0LmlkLCByZWFzb24sIHRhcmdldC5wYWlkID4gMCk7IHRvYXN0KGDEkMOjIGjhu6d5ICR7dGFyZ2V0LmlkfS5gKTsgc2V0VGFyZ2V0KG51bGwpIH19PljDoWMgbmjhuq1uIGjhu6d5PC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvPlxuICApXG5cbiAgZnVuY3Rpb24gYmFkZ2VzKGI6IEJvb2tpbmcpIHtcbiAgICBpZiAoYi5zdGF0dXMgPT09ICdwZW5kaW5nJykgcmV0dXJuIDw+PHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYi1hbWJlclwiPkNo4budIHRoYW5oIHRvw6FuPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGItZ3JheS1vXCI+Q2jGsGEgdGhhbmggdG/DoW48L3NwYW4+PC8+XG4gICAgaWYgKGIuc3RhdHVzID09PSAnY29tcGxldGVkJykgcmV0dXJuIDw+PHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYi1ncmF5XCI+SG/DoG4gdGjDoG5oPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGItZ3JlZW4tZmxhdFwiPsSQw6MgdGhhbmggdG/DoW4gxJHhu6c8L3NwYW4+PC8+XG4gICAgaWYgKGIuc3RhdHVzID09PSAnY2FuY2VsbGVkJykgcmV0dXJuIDw+PHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYi1yb3NlXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLXJvc2UtMTAwKScgfX0+xJDDoyBo4buneTwvc3Bhbj57Yi5rZXB0RGVwb3NpdCA/IDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGItcm9zZS1zb2Z0XCI+S2jDtG5nIGhvw6BuIHRp4buBbiBj4buNYyAoe2ZtdEsoYi5rZXB0RGVwb3NpdCl9KTwvc3Bhbj4gOiBudWxsfTwvPlxuICAgIHJldHVybiA8PjxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGItZ3JlZW5cIj57Yi5zdGF0dXMgPT09ICdwbGF5aW5nJyA/ICfEkGFuZyBz4butIGThu6VuZycgOiBiLnN0YXR1cyA9PT0gJ292ZXJkdWUnID8gJ1F1w6EgZ2nhu50gbmjhuq1uIHPDom4nIDogJ8SQw6MgeMOhYyBuaOG6rW4nfTwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGJhZGdlICR7Yi5wYWlkID49IGIudG90YWwgPyAnYi1ncmVlbi1mbGF0JyA6ICdiLXRlYWwnfWB9PntiLnBhaWQgPj0gYi50b3RhbCA/ICfEkMOjIHRoYW5oIHRvw6FuIMSR4bunJyA6IGDEkMOjIMSR4bq3dCBj4buNYyAoJHtNYXRoLnJvdW5kKChiLnBhaWQgLyBiLnRvdGFsKSAqIDEwMCl9JSlgfTwvc3Bhbj48Lz5cbiAgfVxufVxuY29uc3QgZm10SyA9IChuOiBudW1iZXIpID0+IGAke1N0cmluZyhuKS5yZXBsYWNlKC9cXEIoPz0oXFxkezN9KSsoPyFcXGQpKS9nLCAnLicpfcSRYFxuXG5mdW5jdGlvbiBJbmZvKHsgaywgdiwgY2xzIH06IHsgazogc3RyaW5nOyB2OiBzdHJpbmc7IGNscz86IHN0cmluZyB9KSB7XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNvbCBmMVwiPjxzcGFuIGNsYXNzTmFtZT1cInQxMiBjLXM1MDBcIj57a308L3NwYW4+PHNwYW4gY2xhc3NOYW1lPXtgdDEyIHc3MDAgJHtjbHMgPz8gJ2MtaW5rJ31gfT57dn08L3NwYW4+PC9kaXY+XG59XG5mdW5jdGlvbiBOb3RpY2UoeyB0aXRsZSwgd2hlbiwgY2hpbGRyZW4gfTogeyB0aXRsZTogc3RyaW5nOyB3aGVuOiBzdHJpbmc7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGc2XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLXMxMDApJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLXMzMDApJywgYm9yZGVyUmFkaXVzOiAxMiwgcGFkZGluZzogMTYgfX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuXCI+PGIgY2xhc3NOYW1lPVwidDEyIGMtaW5rXCI+e3RpdGxlfTwvYj48YiBjbGFzc05hbWU9XCJ0MTAgYy1zNTAwXCIgc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19Pnt3aGVufTwvYj48L2Rpdj5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM3MDBcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMTkuNXB4JyB9fT57Y2hpbGRyZW59PC9wPlxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=