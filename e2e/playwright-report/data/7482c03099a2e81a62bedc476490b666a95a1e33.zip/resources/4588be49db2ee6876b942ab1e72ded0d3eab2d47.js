import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/StaffBooking.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { COUNTER_SLOTS, MEMBERS, SPORTS, TODAY, evalPromo, kfmt, money, slotHours, slotPrice, vnd } from "/src/data.ts";
import { useApp } from "/src/store.tsx";
import qr from "/src/assets/icons/qr.svg?import";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/StaffBooking.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
export default function StaffBooking() {
	_s();
	const { user, courts, branches, promos, setPromos, blocker, lockAt, holidays, addBooking, receipt, setReceipt, toast } = useApp();
	const branchId = user?.branchId ?? branches[0].id;
	const branch = branches.find((b) => b.id === branchId);
	const [date, setDate] = useState(TODAY);
	const [sport, setSport] = useState("all");
	const [sel, setSel] = useState(null);
	const [kind, setKind] = useState("walkin");
	const [phone, setPhone] = useState("");
	const [name, setName] = useState("");
	const [lookupMsg, setLookupMsg] = useState("");
	const [isMember, setIsMember] = useState(false);
	const [promoCode, setPromoCode] = useState("QUAYCG15");
	const [level, setLevel] = useState("full");
	const [method, setMethod] = useState("cash");
	const bCourts = courts.filter((c) => c.branchId === branchId && c.active);
	const rows = sport === "all" ? bCourts : bCourts.filter((c) => c.sport === sport);
	const holiday = holidays.find((h) => h.date === date);
	const court = sel ? courts.find((c) => c.id === sel.courtId) : undefined;
	const slot = sel ? COUNTER_SLOTS[sel.idx] : undefined;
	const free = !!(court && slot && !blocker(court.id, date, slot.start, slot.end) && !lockAt(court.id, date, slot.start, slot.end));
	const active = free && court && slot ? {
		court,
		slot
	} : null;
	const base = active ? slotPrice(active.court, active.slot) : 0;
	const promoRes = active && promoCode ? evalPromo(promos.find((p) => p.code === promoCode), active.court, date, active.slot, base, true) : null;
	const off = promoRes?.ok ? promoRes.off : 0;
	const total = base - off;
	const pay = level === "full" ? total : Math.round(total * (active?.court.deposit ?? 30) / 100);
	const lookup = () => {
		const m = MEMBERS.find((x) => x.phone === phone.trim());
		if (m) {
			setName(m.name);
			setIsMember(true);
			setKind("member");
			setLookupMsg(`✓ Tìm thấy hội viên: ${m.name}.`);
		} else {
			setIsMember(false);
			setLookupMsg("Không tìm thấy hội viên — ghi nhận là khách vãng lai.");
		}
	};
	const reset = () => {
		setSel(null);
		setPhone("");
		setName("");
		setLookupMsg("");
		setIsMember(false);
		setKind("walkin");
		setLevel("full");
		setMethod("cash");
	};
	const submit = () => {
		if (!active) return toast("Vui lòng chọn một ô trống trên bảng lịch.", "err");
		if (!/^0\d{9}$/.test(phone.trim())) return toast("Số điện thoại khách không hợp lệ (10 chữ số).", "err");
		if (!name.trim()) return toast("Vui lòng nhập họ và tên khách.", "err");
		const nb = addBooking({
			customer: name.trim(),
			phone: phone.trim(),
			member: isMember || kind === "member",
			courtId: active.court.id,
			date,
			start: active.slot.start,
			end: active.slot.end,
			subtotal: base,
			discount: off,
			total,
			paid: pay,
			payMode: level,
			method,
			source: "counter",
			status: "confirmed",
			promo: promoRes?.ok ? promoCode : undefined
		});
		if (promoRes?.ok) setPromos((ps) => ps.map((p) => p.code === promoCode ? {
			...p,
			used: p.used + 1
		} : p));
		setReceipt({
			code: `PT${nb.id.slice(2, 8)}${String(Math.floor(Math.random() * 90) + 10)}`,
			order: `#${nb.id}`,
			amount: pay,
			method: method === "cash" ? "Tiền mặt" : "VietQR",
			cashier: user?.name ?? ""
		});
		toast(`Đã thu ${vnd(pay)} & tạo đơn #${nb.id}.`, "ok");
		reset();
	};
	const cellFor = (c, i) => {
		const s = COUNTER_SLOTS[i];
		if (holiday) return /* @__PURE__ */ _jsxDEV("td", {
			className: "closed",
			children: "Nghỉ lễ"
		}, i, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 25
		}, this);
		if (lockAt(c.id, date, s.start, s.end)) return /* @__PURE__ */ _jsxDEV("td", {
			className: "locked",
			children: "🔒 Bảo trì"
		}, i, false, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 52
		}, this);
		const bk = blocker(c.id, date, s.start, s.end);
		if (bk) {
			if (bk.status === "playing") return /* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("div", {
				className: "cell play",
				children: ["Đang chơi", /* @__PURE__ */ _jsxDEV("small", { children: bk.member ? `#${bk.id}` : "Khách lẻ" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 91
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 55
			}, this) }, i, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 43
			}, this);
			const t = bk.status === "pending" ? "Chờ chuyển khoản" : bk.paid >= bk.total ? "Đã thu 100%" : `Đã cọc ${kfmt(bk.paid)}`;
			return /* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("div", {
				className: "cell hold",
				children: [t, /* @__PURE__ */ _jsxDEV("small", { children: bk.status === "overdue" ? "Quá giờ nhận sân" : `#${bk.id}` }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 56
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 26
			}, this) }, i, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 14
			}, this);
		}
		if (sel?.courtId === c.id && sel.idx === i) return /* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("button", {
			className: "cell sel",
			onClick: () => setSel(null),
			children: ["Đang chọn", /* @__PURE__ */ _jsxDEV("small", { children: money(slotPrice(c, s)) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 135
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 68
		}, this) }, i, false, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 56
		}, this);
		return /* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("button", {
			className: "cell free",
			onClick: () => setSel({
				courtId: c.id,
				idx: i
			}),
			children: ["Còn trống", /* @__PURE__ */ _jsxDEV("small", { children: money(slotPrice(c, s)) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 113
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 24
		}, this) }, i, false, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 12
		}, this);
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
		className: "card row between wrap g16",
		style: { padding: 16 },
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "row g16 wrap",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "row g8",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "t12 w600 c-s600",
					children: "Ngày đặt sân:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 35
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					type: "date",
					className: "input sm",
					style: { width: "auto" },
					value: date,
					min: TODAY,
					onChange: (e) => {
						setDate(e.target.value || TODAY);
						setSel(null);
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "row g8",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "t12 w600 c-s600",
					children: "Bộ môn:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 35
				}, this), /* @__PURE__ */ _jsxDEV("select", {
					className: "select sm fit",
					style: { background: "var(--s100)" },
					value: sport,
					onChange: (e) => setSport(e.target.value),
					children: [/* @__PURE__ */ _jsxDEV("option", {
						value: "all",
						children: [
							"Tất cả sân trong cơ sở (",
							bCourts.length,
							" sân)"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 15
					}, this), SPORTS.filter((s) => bCourts.some((c) => c.sport === s.key)).map((s) => /* @__PURE__ */ _jsxDEV("option", {
						value: s.key,
						children: [
							s.label,
							" (",
							bCourts.filter((c) => c.sport === s.key).length,
							" sân)"
						]
					}, s.key, true, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 88
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 75,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "row g16 wrap",
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					className: "legend",
					children: [/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 36
					}, this), "Còn trống"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "legend",
					children: [/* @__PURE__ */ _jsxDEV("i", { className: "sel" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 82
					}, this), "Đang chọn"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 57
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "legend",
					children: [/* @__PURE__ */ _jsxDEV("i", { className: "play" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 36
					}, this), "Khách đang chơi"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "legend",
					children: [/* @__PURE__ */ _jsxDEV("i", { className: "hold" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 105
					}, this), "Đã đặt trước"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 80
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 74,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "grid12",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "span7 col g16",
			children: /* @__PURE__ */ _jsxDEV("section", {
				className: "card card-lg col g16",
				style: { padding: 20 },
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "row between",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "t14 w800 c-ink",
							children: "Bảng lịch sân trực tiếp – Nhấp chọn ô trống để lập đơn"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "badge b-green-flat",
							style: { fontSize: 11 },
							children: ["Ca trực: ", user?.name]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 13
					}, this),
					holiday && /* @__PURE__ */ _jsxDEV("div", {
						className: "hint",
						style: {
							background: "var(--amber-50)",
							borderColor: "var(--amber-300)",
							color: "var(--amber-900)"
						},
						children: ["📅 ", holiday.note]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "sched",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("th", { children: "Tên sân" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 26
						}, this), COUNTER_SLOTS.map((s) => /* @__PURE__ */ _jsxDEV("th", { children: [
							s.start,
							" - ",
							s.end,
							/* @__PURE__ */ _jsxDEV("small", {
								className: s.label === "Cao điểm" ? "peak" : "",
								children: s.label
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 105
							}, this)
						] }, s.start, true, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 68
						}, this))] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 22
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: rows.map((c) => /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "t12 w800 c-ink",
							children: c.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "t11 c-s600",
							children: [
								Math.round(c.priceNormal / 1e3),
								"k - ",
								Math.round(c.pricePeak / 1e3),
								"k/h"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 71
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 21
						}, this), COUNTER_SLOTS.map((_, i) => cellFor(c, i))] }, c.id, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 19
						}, this)) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 13
					}, this),
					receipt && /* @__PURE__ */ _jsxDEV("div", {
						className: "col g6",
						style: {
							background: "var(--brand-50)",
							border: "1px solid var(--brand-300)",
							borderRadius: 12,
							padding: 14
						},
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							children: [/* @__PURE__ */ _jsxDEV("b", {
								className: "t12 c-brand9",
								children: "🧾 Phiếu thu gần nhất tại quầy"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 46
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "badge c-white",
								style: {
									background: "var(--brand-700)",
									borderRadius: 4,
									fontSize: 11
								},
								children: "Đã thu tiền & Giữ lịch"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 108
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "row g24 wrap t12",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: ["Mã phiếu: ", /* @__PURE__ */ _jsxDEV("b", { children: receipt.code }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 67
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 51
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: ["Mã đơn: ", /* @__PURE__ */ _jsxDEV("b", { children: receipt.order }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 109
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 95
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: ["Thực thu: ", /* @__PURE__ */ _jsxDEV("b", { children: [
									vnd(receipt.amount),
									" (",
									receipt.method,
									")"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 154
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 138
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: ["Thu ngân: ", /* @__PURE__ */ _jsxDEV("b", { children: receipt.cashier }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 224
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 208
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 15
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 91,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("aside", {
			className: "span5 card card-lg card-raise col g16",
			style: { padding: 20 },
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "row between head-rule",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "col g2",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "eyebrow",
							children: "Phiếu đặt sân tại quầy"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 37
						}, this), /* @__PURE__ */ _jsxDEV("h2", {
							className: "t16 w800 c-ink",
							style: { lineHeight: "24px" },
							children: "Thông tin khách & Thu tiền"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 92
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 13
					}, this), active ? /* @__PURE__ */ _jsxDEV("span", {
						className: "badge b-green-flat",
						style: { fontSize: 11 },
						children: [
							active.court.name,
							" (",
							active.slot.start,
							" - ",
							active.slot.end,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 23
					}, this) : /* @__PURE__ */ _jsxDEV("span", {
						className: "badge b-gray-o",
						style: { fontSize: 11 },
						children: "Chưa chọn sân"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col g8",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "label",
						style: { margin: 0 },
						children: "Loại khách hàng"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "row g8",
						children: [["walkin", "Khách vãng lai"], ["member", "Hội viên có tài khoản"]].map(([k, l]) => /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: `radio-card f1 center${kind === k ? " on" : ""}`,
							onClick: () => {
								setKind(k);
								if (k === "walkin") setIsMember(false);
							},
							children: l
						}, k, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "row g12",
					style: { alignItems: "flex-start" },
					children: [/* @__PURE__ */ _jsxDEV("div", {
						style: { width: "48%" },
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							children: ["Số điện thoại khách ", /* @__PURE__ */ _jsxDEV("span", {
								className: "req",
								children: "*"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 60
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "row g8",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								className: "input sm",
								placeholder: "09xxxxxxxx",
								value: phone,
								onChange: (e) => {
									setPhone(e.target.value);
									setLookupMsg("");
								},
								onKeyDown: (e) => e.key === "Enter" && lookup()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 39
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "btn btn-dark btn-sm",
								onClick: lookup,
								children: "Tra cứu"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "f1",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							children: ["Họ và tên khách ", /* @__PURE__ */ _jsxDEV("span", {
								className: "req",
								children: "*"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 74
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							className: "input sm",
							placeholder: "Nhập họ tên",
							value: name,
							onChange: (e) => setName(e.target.value)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: lookupMsg.startsWith("✓") ? "field-ok" : "t12 c-s600",
					style: { marginTop: -6 },
					children: lookupMsg || /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						"Khách đặt trực tiếp tại quầy chưa có tài khoản sẽ được ghi nhận là ",
						/* @__PURE__ */ _jsxDEV("b", { children: "Khách vãng lai" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 96
						}, this),
						"."
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 27
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "top-rule col g8",
					style: { paddingTop: 16 },
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							style: { margin: 0 },
							children: "Chương trình khuyến mãi / Mã giảm giá"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("select", {
							className: "select sm",
							value: promoCode,
							onChange: (e) => setPromoCode(e.target.value),
							children: [/* @__PURE__ */ _jsxDEV("option", {
								value: "",
								children: "Không áp dụng"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 15
							}, this), promos.filter((p) => p.active).map((p) => {
								const r = active ? evalPromo(p, active.court, date, active.slot, base, true) : null;
								return /* @__PURE__ */ _jsxDEV("option", {
									value: p.code,
									children: [p.counterOnly ? `Giảm ${p.percent}% ${p.name}` : `${p.code} – ${p.name} (-${p.percent}%)`, r?.ok ? ` (-${money(r.off)})` : ""]
								}, p.code, true, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 24
								}, this);
							})]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 13
						}, this),
						promoRes && !promoRes.ok && /* @__PURE__ */ _jsxDEV("p", {
							className: "field-err",
							children: promoRes.msg
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 42
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "top-rule col g8",
					style: { paddingTop: 16 },
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "label",
						style: { margin: 0 },
						children: "Mức thanh toán"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "row g8",
						children: [["full", "Thu đủ 100%"], ["deposit", `Thu cọc giữ sân (${active?.court.deposit ?? 30}%)`]].map(([k, l]) => /* @__PURE__ */ _jsxDEV("label", {
							className: `radio-card f1${level === k ? " on" : ""}`,
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "radio",
								name: "level",
								checked: level === k,
								onChange: () => setLevel(k)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 87
							}, this), l]
						}, k, true, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 158,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "top-rule col g8",
					style: { paddingTop: 16 },
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							style: { margin: 0 },
							children: "Hình thức thu tiền tại quầy"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 167,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g8",
							children: [["cash", "💵 Tiền mặt"], ["qr", "📱 Quét mã VietQR"]].map(([k, l]) => /* @__PURE__ */ _jsxDEV("label", {
								className: `radio-card f1${method === k ? " on" : ""}`,
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "radio",
									name: "method",
									checked: method === k,
									onChange: () => setMethod(k)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 88
								}, this), l]
							}, k, true, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 13
						}, this),
						method === "qr" && active && /* @__PURE__ */ _jsxDEV("div", {
							className: "row g12",
							style: {
								background: "var(--s100)",
								border: "1px solid var(--s300)",
								borderRadius: 12,
								padding: 12
							},
							children: [/* @__PURE__ */ _jsxDEV("img", {
								src: qr,
								alt: "VietQR",
								width: 96,
								height: 96
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "t12 c-s700 col g4",
								children: [
									/* @__PURE__ */ _jsxDEV("b", {
										className: "c-ink",
										children: ["Khách quét mã để chuyển ", vnd(pay)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 52
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: ["Nội dung: ", /* @__PURE__ */ _jsxDEV("b", { children: ["QUAY ", branch.short.toUpperCase()] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 127
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 111
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Sau khi thấy giao dịch báo có, nhấn xác nhận thu tiền." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 174
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 166,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "hint col g8",
					style: { padding: 16 },
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: "Tiền sân theo khung giờ:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 42
							}, this), /* @__PURE__ */ _jsxDEV("b", { children: vnd(base) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 98
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-brand w600",
								children: "Giảm giá khuyến mãi:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 42
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "c-brand",
								children: off ? `- ${vnd(off)}` : "0 VNĐ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 100
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between top-rule",
							style: { paddingTop: 8 },
							children: [/* @__PURE__ */ _jsxDEV("b", {
								className: "t14 c-brand9",
								children: "Cần thu khách ngay:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 77
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "t16 c-brand8 w800",
								children: vnd(pay)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 128
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between t11",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: "Còn lại thu khi nhận sân:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 46
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "c-s700",
								children: vnd(total - pay)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 103
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 13
						}, this),
						active && /* @__PURE__ */ _jsxDEV("span", {
							className: "t11 c-s500",
							children: [
								"Thời lượng: ",
								slotHours(active.slot),
								" giờ • ",
								branch.name
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 24
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "row g8",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						className: "btn btn-primary btn-lg f1",
						onClick: submit,
						children: "✓ Xác nhận thu tiền & Tạo đơn"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "btn btn-outline btn-lg",
						onClick: reset,
						children: "Hủy bỏ"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 90,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 73,
		columnNumber: 5
	}, this);
}
_s(StaffBooking, "+oisagZT4pdL2Ocy0zbV+xqmHCA=", false, function() {
	return [useApp];
});
_c = StaffBooking;
var _c;
$RefreshReg$(_c, "StaffBooking");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/StaffBooking.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/StaffBooking.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/StaffBooking.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/StaffBooking.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxlQUFlLFNBQVMsUUFBUSxPQUFPLFdBQVcsTUFBTSxPQUFPLFdBQVcsV0FBVyxXQUFXO0FBRXpHLFNBQVMsY0FBYztBQUN2QixPQUFPLFFBQVE7Ozs7QUFFZixlQUFlLFNBQVMsZUFBZTs7Q0FDckMsTUFBTSxFQUFFLE1BQU0sUUFBUSxVQUFVLFFBQVEsV0FBVyxTQUFTLFFBQVEsVUFBVSxZQUFZLFNBQVMsWUFBWSxVQUFVLE9BQU87Q0FDaEksTUFBTSxXQUFXLE1BQU0sWUFBWSxTQUFTLEVBQUUsQ0FBQztDQUMvQyxNQUFNLFNBQVMsU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLFFBQVE7Q0FDckQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUEyQixLQUFLO0NBQzFELE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBa0QsSUFBSTtDQUM1RSxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQThCLFFBQVE7Q0FDOUQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEVBQUU7Q0FDbkMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsS0FBSztDQUM5QyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxVQUFVO0NBQ3JELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBNkIsTUFBTTtDQUM3RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQXdCLE1BQU07Q0FFMUQsTUFBTSxVQUFVLE9BQU8sUUFBUSxNQUFNLEVBQUUsYUFBYSxZQUFZLEVBQUUsTUFBTTtDQUN4RSxNQUFNLE9BQU8sVUFBVSxRQUFRLFVBQVUsUUFBUSxRQUFRLE1BQU0sRUFBRSxVQUFVLEtBQUs7Q0FDaEYsTUFBTSxVQUFVLFNBQVMsTUFBTSxNQUFNLEVBQUUsU0FBUyxJQUFJO0NBQ3BELE1BQU0sUUFBUSxNQUFNLE9BQU8sTUFBTSxNQUFNLEVBQUUsT0FBTyxJQUFJLE9BQU8sSUFBSTtDQUMvRCxNQUFNLE9BQU8sTUFBTSxjQUFjLElBQUksT0FBTztDQUM1QyxNQUFNLE9BQU8sQ0FBQyxFQUFFLFNBQVMsUUFBUSxDQUFDLFFBQVEsTUFBTSxJQUFJLE1BQU0sS0FBSyxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUMsT0FBTyxNQUFNLElBQUksTUFBTSxLQUFLLE9BQU8sS0FBSyxHQUFHO0NBQy9ILE1BQU0sU0FBUyxRQUFRLFNBQVMsT0FBTztFQUFFO0VBQU87Q0FBSyxJQUFJO0NBRXpELE1BQU0sT0FBTyxTQUFTLFVBQVUsT0FBTyxPQUFPLE9BQU8sSUFBSSxJQUFJO0NBQzdELE1BQU0sV0FBVyxVQUFVLFlBQVksVUFBVSxPQUFPLE1BQU0sTUFBTSxFQUFFLFNBQVMsU0FBUyxHQUFHLE9BQU8sT0FBTyxNQUFNLE9BQU8sTUFBTSxNQUFNLElBQUksSUFBSTtDQUMxSSxNQUFNLE1BQU0sVUFBVSxLQUFLLFNBQVMsTUFBTTtDQUMxQyxNQUFNLFFBQVEsT0FBTztDQUNyQixNQUFNLE1BQU0sVUFBVSxTQUFTLFFBQVEsS0FBSyxNQUFPLFNBQVMsUUFBUSxNQUFNLFdBQVcsTUFBTyxHQUFHO0NBRS9GLE1BQU0sZUFBZTtFQUNuQixNQUFNLElBQUksUUFBUSxNQUFNLE1BQU0sRUFBRSxVQUFVLE1BQU0sS0FBSyxDQUFDO0VBQ3RELElBQUksR0FBRztHQUFFLFFBQVEsRUFBRSxJQUFJO0dBQUcsWUFBWSxJQUFJO0dBQUcsUUFBUSxRQUFRO0dBQUcsYUFBYSx3QkFBd0IsRUFBRSxLQUFLLEVBQUU7RUFBRSxPQUMzRztHQUFFLFlBQVksS0FBSztHQUFHLGFBQWEsdURBQXVEO0VBQUU7Q0FDbkc7Q0FDQSxNQUFNLGNBQWM7RUFBRSxPQUFPLElBQUk7RUFBRyxTQUFTLEVBQUU7RUFBRyxRQUFRLEVBQUU7RUFBRyxhQUFhLEVBQUU7RUFBRyxZQUFZLEtBQUs7RUFBRyxRQUFRLFFBQVE7RUFBRyxTQUFTLE1BQU07RUFBRyxVQUFVLE1BQU07Q0FBRTtDQUM1SixNQUFNLGVBQWU7RUFDbkIsSUFBSSxDQUFDLFFBQVEsT0FBTyxNQUFNLDZDQUE2QyxLQUFLO0VBQzVFLElBQUksQ0FBQyxXQUFXLEtBQUssTUFBTSxLQUFLLENBQUMsR0FBRyxPQUFPLE1BQU0saURBQWlELEtBQUs7RUFDdkcsSUFBSSxDQUFDLEtBQUssS0FBSyxHQUFHLE9BQU8sTUFBTSxrQ0FBa0MsS0FBSztFQUN0RSxNQUFNLEtBQUssV0FBVztHQUNwQixVQUFVLEtBQUssS0FBSztHQUFHLE9BQU8sTUFBTSxLQUFLO0dBQUcsUUFBUSxZQUFZLFNBQVM7R0FBVSxTQUFTLE9BQU8sTUFBTTtHQUFJO0dBQzdHLE9BQU8sT0FBTyxLQUFLO0dBQU8sS0FBSyxPQUFPLEtBQUs7R0FBSyxVQUFVO0dBQU0sVUFBVTtHQUFLO0dBQU8sTUFBTTtHQUFLLFNBQVM7R0FDMUc7R0FBUSxRQUFRO0dBQVcsUUFBUTtHQUFhLE9BQU8sVUFBVSxLQUFLLFlBQVk7RUFDcEYsQ0FBQztFQUNELElBQUksVUFBVSxJQUFJLFdBQVcsT0FBTyxHQUFHLEtBQUssTUFBTyxFQUFFLFNBQVMsWUFBWTtHQUFFLEdBQUc7R0FBRyxNQUFNLEVBQUUsT0FBTztFQUFFLElBQUksQ0FBRSxDQUFDO0VBQzFHLFdBQVc7R0FBRSxNQUFNLEtBQUssR0FBRyxHQUFHLE1BQU0sR0FBRyxDQUFDLElBQUksT0FBTyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksRUFBRSxJQUFJLEVBQUU7R0FBSyxPQUFPLElBQUksR0FBRztHQUFNLFFBQVE7R0FBSyxRQUFRLFdBQVcsU0FBUyxhQUFhO0dBQVUsU0FBUyxNQUFNLFFBQVE7RUFBRyxDQUFDO0VBQzFNLE1BQU0sVUFBVSxJQUFJLEdBQUcsRUFBRSxjQUFjLEdBQUcsR0FBRyxJQUFJLElBQUk7RUFDckQsTUFBTTtDQUNSO0NBRUEsTUFBTSxXQUFXLEdBQTBCLE1BQWM7RUFDdkQsTUFBTSxJQUFJLGNBQWM7RUFDeEIsSUFBSSxTQUFTLE9BQU8sd0JBQUMsTUFBRDtHQUFZLFdBQVU7YUFBUztFQUFXLEdBQWpDOzs7O1NBQWlDO0VBQzlELElBQUksT0FBTyxFQUFFLElBQUksTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHLEdBQUcsT0FBTyx3QkFBQyxNQUFEO0dBQVksV0FBVTthQUFTO0VBQWMsR0FBcEM7Ozs7U0FBb0M7RUFDNUYsTUFBTSxLQUFLLFFBQVEsRUFBRSxJQUFJLE1BQU0sRUFBRSxPQUFPLEVBQUUsR0FBRztFQUM3QyxJQUFJLElBQUk7R0FDTixJQUFJLEdBQUcsV0FBVyxXQUFXLE9BQU8sd0JBQUMsTUFBRCxZQUFZLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBMkIsYUFBUyx3QkFBQyxTQUFELFlBQVEsR0FBRyxTQUFTLElBQUksR0FBRyxPQUFPLFdBQWtCOzs7O1lBQU07Ozs7O1lBQUssR0FBdEc7Ozs7VUFBc0c7R0FDbkosTUFBTSxJQUFJLEdBQUcsV0FBVyxZQUFZLHFCQUFxQixHQUFHLFFBQVEsR0FBRyxRQUFRLGdCQUFnQixVQUFVLEtBQUssR0FBRyxJQUFJO0dBQ3JILE9BQU8sd0JBQUMsTUFBRCxZQUFZLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBNEIsR0FBRSx3QkFBQyxTQUFELFlBQVEsR0FBRyxXQUFXLFlBQVkscUJBQXFCLElBQUksR0FBRyxLQUFZOzs7O1lBQU07Ozs7O1lBQUssR0FBdEg7Ozs7VUFBc0g7RUFDeEk7RUFDQSxJQUFJLEtBQUssWUFBWSxFQUFFLE1BQU0sSUFBSSxRQUFRLEdBQUcsT0FBTyx3QkFBQyxNQUFELFlBQVksd0JBQUMsVUFBRDtHQUFRLFdBQVU7R0FBVyxlQUFlLE9BQU8sSUFBSTthQUF2RCxDQUEwRCxhQUFTLHdCQUFDLFNBQUQsWUFBUSxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsRUFBUzs7OztXQUFTOzs7OztXQUFLLEdBQTFIOzs7O1NBQTBIO0VBQ3RMLE9BQU8sd0JBQUMsTUFBRCxZQUFZLHdCQUFDLFVBQUQ7R0FBUSxXQUFVO0dBQVksZUFBZSxPQUFPO0lBQUUsU0FBUyxFQUFFO0lBQUksS0FBSztHQUFFLENBQUM7YUFBN0UsQ0FBZ0YsYUFBUyx3QkFBQyxTQUFELFlBQVEsTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEVBQVM7Ozs7V0FBUzs7Ozs7V0FBSyxHQUFoSjs7OztTQUFnSjtDQUNsSztDQUVBLE9BQ0UsZ0RBQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7RUFBNEIsT0FBTyxFQUFFLFNBQVMsR0FBRztZQUFwRSxDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQXdCLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWtCO0lBQW1COzs7O2NBQzNFLHdCQUFDLFNBQUQ7S0FBTyxNQUFLO0tBQU8sV0FBVTtLQUFXLE9BQU8sRUFBRSxPQUFPLE9BQU87S0FBRyxPQUFPO0tBQU0sS0FBSztLQUFPLFdBQVcsTUFBTTtNQUFFLFFBQVEsRUFBRSxPQUFPLFNBQVMsS0FBSztNQUFHLE9BQU8sSUFBSTtLQUFFO0lBQUk7Ozs7WUFBTTs7Ozs7YUFDekssd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUF3Qix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFrQjtJQUFhOzs7O2NBQ3JFLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO0tBQWdCLE9BQU8sRUFBRSxZQUFZLGNBQWM7S0FBRyxPQUFPO0tBQU8sV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQXlCO2VBQWxKLENBQ0Usd0JBQUMsVUFBRDtNQUFRLE9BQU07Z0JBQWQ7T0FBb0I7T0FBeUIsUUFBUTtPQUFPO01BQWE7Ozs7O2VBQ3hFLE9BQU8sUUFBUSxNQUFNLFFBQVEsTUFBTSxNQUFNLEVBQUUsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLHdCQUFDLFVBQUQ7TUFBb0IsT0FBTyxFQUFFO2dCQUE3QjtPQUFtQyxFQUFFO09BQU07T0FBRyxRQUFRLFFBQVEsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztPQUFPO01BQWE7UUFBOUYsRUFBRTs7OztZQUE0RixDQUFDLENBQy9LOzs7OztZQUFNOzs7OztXQUNiOzs7OztZQUNMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUF5Qix3QkFBQyxLQUFELENBQUk7Ozs7ZUFBQyxXQUFlOzs7Ozs7SUFBQyx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUF5Qix3QkFBQyxLQUFELEVBQUcsV0FBVSxNQUFPOzs7O2VBQUMsV0FBZTs7Ozs7O0lBQzNHLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQXlCLHdCQUFDLEtBQUQsRUFBRyxXQUFVLE9BQVE7Ozs7ZUFBQyxpQkFBcUI7Ozs7OztJQUFDLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQXlCLHdCQUFDLEtBQUQsRUFBRyxXQUFVLE9BQVE7Ozs7ZUFBQyxjQUFrQjs7Ozs7O0dBQ25JOzs7OztVQUNFOzs7OztXQUVULHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO0lBQXVCLE9BQU8sRUFBRSxTQUFTLEdBQUc7Y0FBL0Q7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFpQjtNQUEwRDs7OztnQkFDekYsd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBcUIsT0FBTyxFQUFFLFVBQVUsR0FBRztpQkFBM0QsQ0FBOEQsYUFBVSxNQUFNLElBQVc7Ozs7O2NBQ3RGOzs7Ozs7S0FDSixXQUFXLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQU8sT0FBTztPQUFFLFlBQVk7T0FBbUIsYUFBYTtPQUFvQixPQUFPO01BQW1CO2dCQUF6SCxDQUE0SCxPQUFJLFFBQVEsSUFBVTs7Ozs7O0tBQzlKLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFBTyx3QkFBQyxNQUFELGFBQUksd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7Z0JBQUUsY0FBYyxLQUFLLE1BQU0sd0JBQUMsTUFBRDtPQUFtQixFQUFFO09BQU07T0FBSSxFQUFFO09BQUksd0JBQUMsU0FBRDtRQUFPLFdBQVcsRUFBRSxVQUFVLGFBQWEsU0FBUztrQkFBSyxFQUFFO09BQWE7Ozs7O01BQUssS0FBekcsRUFBRTs7OzthQUF1RyxDQUFDLENBQU07Ozs7ZUFBUTs7OztnQkFDdEwsd0JBQUMsU0FBRCxZQUNHLEtBQUssS0FBSyxNQUNULHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxNQUFELGFBQUksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWtCLEVBQUU7TUFBVTs7OztnQkFBQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUE2QixLQUFLLE1BQU0sRUFBRSxjQUFjLEdBQUk7UUFBRTtRQUFLLEtBQUssTUFBTSxFQUFFLFlBQVksR0FBSTtRQUFFO09BQVE7Ozs7O2NBQUs7Ozs7Z0JBQ2hLLGNBQWMsS0FBSyxHQUFHLE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUN4QyxLQUhLLEVBQUU7Ozs7YUFHUCxDQUNMLEVBQ0k7Ozs7Y0FDRjs7Ozs7O0tBQ04sV0FDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFTLE9BQU87T0FBRSxZQUFZO09BQW1CLFFBQVE7T0FBOEIsY0FBYztPQUFJLFNBQVM7TUFBRztnQkFBcEksQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUE2Qix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBZTtPQUFpQzs7OztpQkFBQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUFnQixPQUFPO1NBQUUsWUFBWTtTQUFvQixjQUFjO1NBQUcsVUFBVTtRQUFHO2tCQUFHO09BQTRCOzs7O2VBQU07Ozs7O2dCQUN2Tyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUFrQyx3QkFBQyxRQUFELGFBQU0sY0FBVSx3QkFBQyxLQUFELFlBQUksUUFBUSxLQUFROzs7O2dCQUFPOzs7OztRQUFDLHdCQUFDLFFBQUQsYUFBTSxZQUFRLHdCQUFDLEtBQUQsWUFBSSxRQUFRLE1BQVM7Ozs7Z0JBQU87Ozs7O1FBQUMsd0JBQUMsUUFBRCxhQUFNLGNBQVUsd0JBQUMsS0FBRDtTQUFJLElBQUksUUFBUSxNQUFNO1NBQUU7U0FBRyxRQUFRO1NBQU87UUFBSTs7OztnQkFBTzs7Ozs7UUFBQyx3QkFBQyxRQUFELGFBQU0sY0FBVSx3QkFBQyxLQUFELFlBQUksUUFBUSxRQUFXOzs7O2dCQUFPOzs7OztPQUFNOzs7OztjQUNoUDs7Ozs7O0lBRUE7Ozs7OztFQUNOOzs7O1lBRUwsd0JBQUMsU0FBRDtHQUFPLFdBQVU7R0FBd0MsT0FBTyxFQUFFLFNBQVMsR0FBRzthQUE5RTtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUF3Qix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBVTtNQUE0Qjs7OztnQkFBQyx3QkFBQyxNQUFEO09BQUksV0FBVTtPQUFpQixPQUFPLEVBQUUsWUFBWSxPQUFPO2lCQUFHO01BQThCOzs7O2NBQU07Ozs7O2VBQ2hMLFNBQVMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7TUFBcUIsT0FBTyxFQUFFLFVBQVUsR0FBRztnQkFBM0Q7T0FBK0QsT0FBTyxNQUFNO09BQUs7T0FBRyxPQUFPLEtBQUs7T0FBTTtPQUFJLE9BQU8sS0FBSztPQUFJO01BQU87Ozs7O2dCQUN2SSx3QkFBQyxRQUFEO01BQU0sV0FBVTtNQUFpQixPQUFPLEVBQUUsVUFBVSxHQUFHO2dCQUFHO0tBQW1COzs7O2FBQzlFOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7TUFBUSxPQUFPLEVBQUUsUUFBUSxFQUFFO2dCQUFHO0tBQXNCOzs7O2VBQ3JFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNYLENBQUMsQ0FBQyxVQUFVLGdCQUFnQixHQUFHLENBQUMsVUFBVSx1QkFBdUIsQ0FBQyxDQUFDLENBQVcsS0FBSyxDQUFDLEdBQUcsT0FDdkYsd0JBQUMsVUFBRDtPQUFnQixNQUFLO09BQVMsV0FBVyx1QkFBdUIsU0FBUyxJQUFJLFFBQVE7T0FBTSxlQUFlO1FBQUUsUUFBUSxDQUFDO1FBQUcsSUFBSSxNQUFNLFVBQVUsWUFBWSxLQUFLO09BQUU7aUJBQUk7TUFBVSxHQUFoSzs7OzthQUFnSyxDQUM5SztLQUNFOzs7O2FBQ0Y7Ozs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQVUsT0FBTyxFQUFFLFlBQVksYUFBYTtlQUEzRCxDQUNFLHdCQUFDLE9BQUQ7TUFBSyxPQUFPLEVBQUUsT0FBTyxNQUFNO2dCQUEzQixDQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUF5Qix3QkFBb0Isd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQU07T0FBTzs7OztlQUFROzs7OztnQkFDbEYsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBd0Isd0JBQUMsU0FBRDtRQUFPLFdBQVU7UUFBVyxhQUFZO1FBQWEsT0FBTztRQUFPLFdBQVcsTUFBTTtTQUFFLFNBQVMsRUFBRSxPQUFPLEtBQUs7U0FBRyxhQUFhLEVBQUU7UUFBRTtRQUFHLFlBQVksTUFBTSxFQUFFLFFBQVEsV0FBVyxPQUFPO09BQUk7Ozs7aUJBQzVNLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsV0FBVTtRQUFzQixTQUFTO2tCQUFRO09BQWU7Ozs7ZUFBTTs7Ozs7Y0FDM0Y7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBb0Isd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQXlCLG9CQUFnQix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBTTtPQUFPOzs7O2VBQVE7Ozs7O2dCQUNoRyx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFXLGFBQVk7T0FBYyxPQUFPO09BQU0sV0FBVyxNQUFNLFFBQVEsRUFBRSxPQUFPLEtBQUs7TUFBSTs7OztjQUFNOzs7OzthQUNuSDs7Ozs7O0lBQ0wsd0JBQUMsS0FBRDtLQUFHLFdBQVcsVUFBVSxXQUFXLEdBQUcsSUFBSSxhQUFhO0tBQWMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxFQUFFO2VBQ3pGLGFBQWE7TUFBRTtNQUFtRSx3QkFBQyxLQUFELFlBQUcsaUJBQWlCOzs7OztNQUFDO0tBQUc7Ozs7O0lBQzFHOzs7OztJQUVILHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWtCLE9BQU8sRUFBRSxZQUFZLEdBQUc7ZUFBekQ7TUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFRLE9BQU8sRUFBRSxRQUFRLEVBQUU7aUJBQUc7TUFBNEM7Ozs7O01BQzNGLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQVksT0FBTztPQUFXLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO2lCQUE1RixDQUNFLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFHO09BQXFCOzs7O2lCQUNyQyxPQUFPLFFBQVEsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLEtBQUssTUFBTTtRQUN6QyxNQUFNLElBQUksU0FBUyxVQUFVLEdBQUcsT0FBTyxPQUFPLE1BQU0sT0FBTyxNQUFNLE1BQU0sSUFBSSxJQUFJO1FBQy9FLE9BQU8sd0JBQUMsVUFBRDtTQUFxQixPQUFPLEVBQUU7bUJBQTlCLENBQXFDLEVBQUUsY0FBYyxRQUFRLEVBQUUsUUFBUSxJQUFJLEVBQUUsU0FBUyxHQUFHLEVBQUUsS0FBSyxLQUFLLEVBQUUsS0FBSyxLQUFLLEVBQUUsUUFBUSxLQUFLLEdBQUcsS0FBSyxNQUFNLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFXO1dBQTlKLEVBQUU7Ozs7ZUFBNEo7T0FDcEwsQ0FBQyxDQUNLOzs7Ozs7TUFDUCxZQUFZLENBQUMsU0FBUyxNQUFNLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFhLFNBQVM7TUFBTzs7Ozs7S0FDcEU7Ozs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWtCLE9BQU8sRUFBRSxZQUFZLEdBQUc7ZUFBekQsQ0FDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtNQUFRLE9BQU8sRUFBRSxRQUFRLEVBQUU7Z0JBQUc7S0FBcUI7Ozs7ZUFDcEUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1gsQ0FBQyxDQUFDLFFBQVEsYUFBYSxHQUFHLENBQUMsV0FBVyxvQkFBb0IsUUFBUSxNQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFXLEtBQUssQ0FBQyxHQUFHLE9BQy9HLHdCQUFDLFNBQUQ7T0FBZSxXQUFXLGdCQUFnQixVQUFVLElBQUksUUFBUTtpQkFBaEUsQ0FBc0Usd0JBQUMsU0FBRDtRQUFPLE1BQUs7UUFBUSxNQUFLO1FBQVEsU0FBUyxVQUFVO1FBQUcsZ0JBQWdCLFNBQVMsQ0FBQztPQUFJOzs7O2lCQUFFLENBQVM7U0FBMUo7Ozs7YUFBMEosQ0FDdks7S0FDRTs7OzthQUNGOzs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFrQixPQUFPLEVBQUUsWUFBWSxHQUFHO2VBQXpEO01BQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7T0FBUSxPQUFPLEVBQUUsUUFBUSxFQUFFO2lCQUFHO01BQWtDOzs7OztNQUNqRix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCxDQUFDLENBQUMsUUFBUSxhQUFhLEdBQUcsQ0FBQyxNQUFNLG1CQUFtQixDQUFDLENBQUMsQ0FBVyxLQUFLLENBQUMsR0FBRyxPQUMxRSx3QkFBQyxTQUFEO1FBQWUsV0FBVyxnQkFBZ0IsV0FBVyxJQUFJLFFBQVE7a0JBQWpFLENBQXVFLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQVEsTUFBSztTQUFTLFNBQVMsV0FBVztTQUFHLGdCQUFnQixVQUFVLENBQUM7UUFBSTs7OztrQkFBRSxDQUFTO1VBQTlKOzs7O2NBQThKLENBQzNLO01BQ0U7Ozs7O01BQ0osV0FBVyxRQUFRLFVBQ2xCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVUsT0FBTztRQUFFLFlBQVk7UUFBZSxRQUFRO1FBQXlCLGNBQWM7UUFBSSxTQUFTO09BQUc7aUJBQTVILENBQ0Usd0JBQUMsT0FBRDtRQUFLLEtBQUs7UUFBSSxLQUFJO1FBQVMsT0FBTztRQUFJLFFBQVE7T0FBSzs7OztpQkFDbkQsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBbUMsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWIsQ0FBcUIsNEJBQXlCLElBQUksR0FBRyxDQUFLOzs7Ozs7U0FBQyx3QkFBQyxRQUFELGFBQU0sY0FBVSx3QkFBQyxLQUFELGFBQUcsU0FBTSxPQUFPLE1BQU0sWUFBWSxDQUFLOzs7O2lCQUFPOzs7OztTQUFDLHdCQUFDLFFBQUQsWUFBTSx5REFBNEQ7Ozs7O1FBQU07Ozs7O2VBQ2xPOzs7Ozs7S0FFSjs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBYyxPQUFPLEVBQUUsU0FBUyxHQUFHO2VBQWxEO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBNkIsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQVM7T0FBOEI7Ozs7aUJBQUMsd0JBQUMsS0FBRCxZQUFJLElBQUksSUFBSSxFQUFLOzs7O2VBQU07Ozs7OztNQUM1Ryx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUE2Qix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZTtPQUEwQjs7OztpQkFBQyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBVyxNQUFNLEtBQUssSUFBSSxHQUFHLE1BQU07T0FBVzs7OztlQUFNOzs7Ozs7TUFDeEosd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBdUIsT0FBTyxFQUFFLFlBQVksRUFBRTtpQkFBN0QsQ0FBZ0Usd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWU7T0FBc0I7Ozs7aUJBQUMsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQXFCLElBQUksR0FBRztPQUFLOzs7O2VBQU07Ozs7OztNQUN2Syx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUFpQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBUztPQUErQjs7OztpQkFBQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBVSxJQUFJLFFBQVEsR0FBRztPQUFROzs7O2VBQU07Ozs7OztNQUNoSixVQUFVLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQjtRQUE2QjtRQUFhLFVBQVUsT0FBTyxJQUFJO1FBQUU7UUFBUSxPQUFPO09BQVc7Ozs7OztLQUNuRzs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQTRCLFNBQVM7Z0JBQVE7S0FBcUM7Ozs7ZUFDcEcsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBeUIsU0FBUztnQkFBTztLQUFjOzs7O2FBQ3RFOzs7Ozs7R0FDQTs7Ozs7VUFDSjs7Ozs7U0FDTDs7Ozs7QUFFTiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTdGFmZkJvb2tpbmcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBDT1VOVEVSX1NMT1RTLCBNRU1CRVJTLCBTUE9SVFMsIFRPREFZLCBldmFsUHJvbW8sIGtmbXQsIG1vbmV5LCBzbG90SG91cnMsIHNsb3RQcmljZSwgdm5kIH0gZnJvbSAnLi4vZGF0YSdcbmltcG9ydCB0eXBlIHsgU3BvcnRLZXkgfSBmcm9tICcuLi9kYXRhJ1xuaW1wb3J0IHsgdXNlQXBwIH0gZnJvbSAnLi4vc3RvcmUnXG5pbXBvcnQgcXIgZnJvbSAnLi4vYXNzZXRzL2ljb25zL3FyLnN2ZydcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU3RhZmZCb29raW5nKCkge1xuICBjb25zdCB7IHVzZXIsIGNvdXJ0cywgYnJhbmNoZXMsIHByb21vcywgc2V0UHJvbW9zLCBibG9ja2VyLCBsb2NrQXQsIGhvbGlkYXlzLCBhZGRCb29raW5nLCByZWNlaXB0LCBzZXRSZWNlaXB0LCB0b2FzdCB9ID0gdXNlQXBwKClcbiAgY29uc3QgYnJhbmNoSWQgPSB1c2VyPy5icmFuY2hJZCA/PyBicmFuY2hlc1swXS5pZFxuICBjb25zdCBicmFuY2ggPSBicmFuY2hlcy5maW5kKChiKSA9PiBiLmlkID09PSBicmFuY2hJZCkhXG4gIGNvbnN0IFtkYXRlLCBzZXREYXRlXSA9IHVzZVN0YXRlKFRPREFZKVxuICBjb25zdCBbc3BvcnQsIHNldFNwb3J0XSA9IHVzZVN0YXRlPCdhbGwnIHwgU3BvcnRLZXk+KCdhbGwnKVxuICBjb25zdCBbc2VsLCBzZXRTZWxdID0gdXNlU3RhdGU8eyBjb3VydElkOiBzdHJpbmc7IGlkeDogbnVtYmVyIH0gfCBudWxsPihudWxsKVxuICBjb25zdCBba2luZCwgc2V0S2luZF0gPSB1c2VTdGF0ZTwnd2Fsa2luJyB8ICdtZW1iZXInPignd2Fsa2luJylcbiAgY29uc3QgW3Bob25lLCBzZXRQaG9uZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW25hbWUsIHNldE5hbWVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtsb29rdXBNc2csIHNldExvb2t1cE1zZ10gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2lzTWVtYmVyLCBzZXRJc01lbWJlcl0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3Byb21vQ29kZSwgc2V0UHJvbW9Db2RlXSA9IHVzZVN0YXRlKCdRVUFZQ0cxNScpXG4gIGNvbnN0IFtsZXZlbCwgc2V0TGV2ZWxdID0gdXNlU3RhdGU8J2Z1bGwnIHwgJ2RlcG9zaXQnPignZnVsbCcpXG4gIGNvbnN0IFttZXRob2QsIHNldE1ldGhvZF0gPSB1c2VTdGF0ZTwnY2FzaCcgfCAncXInPignY2FzaCcpXG5cbiAgY29uc3QgYkNvdXJ0cyA9IGNvdXJ0cy5maWx0ZXIoKGMpID0+IGMuYnJhbmNoSWQgPT09IGJyYW5jaElkICYmIGMuYWN0aXZlKVxuICBjb25zdCByb3dzID0gc3BvcnQgPT09ICdhbGwnID8gYkNvdXJ0cyA6IGJDb3VydHMuZmlsdGVyKChjKSA9PiBjLnNwb3J0ID09PSBzcG9ydClcbiAgY29uc3QgaG9saWRheSA9IGhvbGlkYXlzLmZpbmQoKGgpID0+IGguZGF0ZSA9PT0gZGF0ZSlcbiAgY29uc3QgY291cnQgPSBzZWwgPyBjb3VydHMuZmluZCgoYykgPT4gYy5pZCA9PT0gc2VsLmNvdXJ0SWQpIDogdW5kZWZpbmVkXG4gIGNvbnN0IHNsb3QgPSBzZWwgPyBDT1VOVEVSX1NMT1RTW3NlbC5pZHhdIDogdW5kZWZpbmVkXG4gIGNvbnN0IGZyZWUgPSAhIShjb3VydCAmJiBzbG90ICYmICFibG9ja2VyKGNvdXJ0LmlkLCBkYXRlLCBzbG90LnN0YXJ0LCBzbG90LmVuZCkgJiYgIWxvY2tBdChjb3VydC5pZCwgZGF0ZSwgc2xvdC5zdGFydCwgc2xvdC5lbmQpKVxuICBjb25zdCBhY3RpdmUgPSBmcmVlICYmIGNvdXJ0ICYmIHNsb3QgPyB7IGNvdXJ0LCBzbG90IH0gOiBudWxsXG5cbiAgY29uc3QgYmFzZSA9IGFjdGl2ZSA/IHNsb3RQcmljZShhY3RpdmUuY291cnQsIGFjdGl2ZS5zbG90KSA6IDBcbiAgY29uc3QgcHJvbW9SZXMgPSBhY3RpdmUgJiYgcHJvbW9Db2RlID8gZXZhbFByb21vKHByb21vcy5maW5kKChwKSA9PiBwLmNvZGUgPT09IHByb21vQ29kZSksIGFjdGl2ZS5jb3VydCwgZGF0ZSwgYWN0aXZlLnNsb3QsIGJhc2UsIHRydWUpIDogbnVsbFxuICBjb25zdCBvZmYgPSBwcm9tb1Jlcz8ub2sgPyBwcm9tb1Jlcy5vZmYgOiAwXG4gIGNvbnN0IHRvdGFsID0gYmFzZSAtIG9mZlxuICBjb25zdCBwYXkgPSBsZXZlbCA9PT0gJ2Z1bGwnID8gdG90YWwgOiBNYXRoLnJvdW5kKCh0b3RhbCAqIChhY3RpdmU/LmNvdXJ0LmRlcG9zaXQgPz8gMzApKSAvIDEwMClcblxuICBjb25zdCBsb29rdXAgPSAoKSA9PiB7XG4gICAgY29uc3QgbSA9IE1FTUJFUlMuZmluZCgoeCkgPT4geC5waG9uZSA9PT0gcGhvbmUudHJpbSgpKVxuICAgIGlmIChtKSB7IHNldE5hbWUobS5uYW1lKTsgc2V0SXNNZW1iZXIodHJ1ZSk7IHNldEtpbmQoJ21lbWJlcicpOyBzZXRMb29rdXBNc2coYOKckyBUw6xtIHRo4bqleSBo4buZaSB2acOqbjogJHttLm5hbWV9LmApIH1cbiAgICBlbHNlIHsgc2V0SXNNZW1iZXIoZmFsc2UpOyBzZXRMb29rdXBNc2coJ0tow7RuZyB0w6xtIHRo4bqleSBo4buZaSB2acOqbiDigJQgZ2hpIG5o4bqtbiBsw6Aga2jDoWNoIHbDo25nIGxhaS4nKSB9XG4gIH1cbiAgY29uc3QgcmVzZXQgPSAoKSA9PiB7IHNldFNlbChudWxsKTsgc2V0UGhvbmUoJycpOyBzZXROYW1lKCcnKTsgc2V0TG9va3VwTXNnKCcnKTsgc2V0SXNNZW1iZXIoZmFsc2UpOyBzZXRLaW5kKCd3YWxraW4nKTsgc2V0TGV2ZWwoJ2Z1bGwnKTsgc2V0TWV0aG9kKCdjYXNoJykgfVxuICBjb25zdCBzdWJtaXQgPSAoKSA9PiB7XG4gICAgaWYgKCFhY3RpdmUpIHJldHVybiB0b2FzdCgnVnVpIGzDsm5nIGNo4buNbiBt4buZdCDDtCB0cuG7kW5nIHRyw6puIGLhuqNuZyBs4buLY2guJywgJ2VycicpXG4gICAgaWYgKCEvXjBcXGR7OX0kLy50ZXN0KHBob25lLnRyaW0oKSkpIHJldHVybiB0b2FzdCgnU+G7kSDEkWnhu4duIHRob+G6oWkga2jDoWNoIGtow7RuZyBo4bujcCBs4buHICgxMCBjaOG7ryBz4buRKS4nLCAnZXJyJylcbiAgICBpZiAoIW5hbWUudHJpbSgpKSByZXR1cm4gdG9hc3QoJ1Z1aSBsw7JuZyBuaOG6rXAgaOG7jSB2w6AgdMOqbiBraMOhY2guJywgJ2VycicpXG4gICAgY29uc3QgbmIgPSBhZGRCb29raW5nKHtcbiAgICAgIGN1c3RvbWVyOiBuYW1lLnRyaW0oKSwgcGhvbmU6IHBob25lLnRyaW0oKSwgbWVtYmVyOiBpc01lbWJlciB8fCBraW5kID09PSAnbWVtYmVyJywgY291cnRJZDogYWN0aXZlLmNvdXJ0LmlkLCBkYXRlLFxuICAgICAgc3RhcnQ6IGFjdGl2ZS5zbG90LnN0YXJ0LCBlbmQ6IGFjdGl2ZS5zbG90LmVuZCwgc3VidG90YWw6IGJhc2UsIGRpc2NvdW50OiBvZmYsIHRvdGFsLCBwYWlkOiBwYXksIHBheU1vZGU6IGxldmVsLFxuICAgICAgbWV0aG9kLCBzb3VyY2U6ICdjb3VudGVyJywgc3RhdHVzOiAnY29uZmlybWVkJywgcHJvbW86IHByb21vUmVzPy5vayA/IHByb21vQ29kZSA6IHVuZGVmaW5lZCxcbiAgICB9KVxuICAgIGlmIChwcm9tb1Jlcz8ub2spIHNldFByb21vcygocHMpID0+IHBzLm1hcCgocCkgPT4gKHAuY29kZSA9PT0gcHJvbW9Db2RlID8geyAuLi5wLCB1c2VkOiBwLnVzZWQgKyAxIH0gOiBwKSkpXG4gICAgc2V0UmVjZWlwdCh7IGNvZGU6IGBQVCR7bmIuaWQuc2xpY2UoMiwgOCl9JHtTdHJpbmcoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogOTApICsgMTApfWAsIG9yZGVyOiBgIyR7bmIuaWR9YCwgYW1vdW50OiBwYXksIG1ldGhvZDogbWV0aG9kID09PSAnY2FzaCcgPyAnVGnhu4FuIG3hurd0JyA6ICdWaWV0UVInLCBjYXNoaWVyOiB1c2VyPy5uYW1lID8/ICcnIH0pXG4gICAgdG9hc3QoYMSQw6MgdGh1ICR7dm5kKHBheSl9ICYgdOG6oW8gxJHGoW4gIyR7bmIuaWR9LmAsICdvaycpXG4gICAgcmVzZXQoKVxuICB9XG5cbiAgY29uc3QgY2VsbEZvciA9IChjOiAodHlwZW9mIHJvd3MpW251bWJlcl0sIGk6IG51bWJlcikgPT4ge1xuICAgIGNvbnN0IHMgPSBDT1VOVEVSX1NMT1RTW2ldXG4gICAgaWYgKGhvbGlkYXkpIHJldHVybiA8dGQga2V5PXtpfSBjbGFzc05hbWU9XCJjbG9zZWRcIj5OZ2jhu4kgbOG7hTwvdGQ+XG4gICAgaWYgKGxvY2tBdChjLmlkLCBkYXRlLCBzLnN0YXJ0LCBzLmVuZCkpIHJldHVybiA8dGQga2V5PXtpfSBjbGFzc05hbWU9XCJsb2NrZWRcIj7wn5SSIELhuqNvIHRyw6w8L3RkPlxuICAgIGNvbnN0IGJrID0gYmxvY2tlcihjLmlkLCBkYXRlLCBzLnN0YXJ0LCBzLmVuZClcbiAgICBpZiAoYmspIHtcbiAgICAgIGlmIChiay5zdGF0dXMgPT09ICdwbGF5aW5nJykgcmV0dXJuIDx0ZCBrZXk9e2l9PjxkaXYgY2xhc3NOYW1lPVwiY2VsbCBwbGF5XCI+xJBhbmcgY2jGoWk8c21hbGw+e2JrLm1lbWJlciA/IGAjJHtiay5pZH1gIDogJ0tow6FjaCBs4bq7J308L3NtYWxsPjwvZGl2PjwvdGQ+XG4gICAgICBjb25zdCB0ID0gYmsuc3RhdHVzID09PSAncGVuZGluZycgPyAnQ2jhu50gY2h1eeG7g24ga2hv4bqjbicgOiBiay5wYWlkID49IGJrLnRvdGFsID8gJ8SQw6MgdGh1IDEwMCUnIDogYMSQw6MgY+G7jWMgJHtrZm10KGJrLnBhaWQpfWBcbiAgICAgIHJldHVybiA8dGQga2V5PXtpfT48ZGl2IGNsYXNzTmFtZT1cImNlbGwgaG9sZFwiPnt0fTxzbWFsbD57Ymsuc3RhdHVzID09PSAnb3ZlcmR1ZScgPyAnUXXDoSBnaeG7nSBuaOG6rW4gc8OibicgOiBgIyR7YmsuaWR9YH08L3NtYWxsPjwvZGl2PjwvdGQ+XG4gICAgfVxuICAgIGlmIChzZWw/LmNvdXJ0SWQgPT09IGMuaWQgJiYgc2VsLmlkeCA9PT0gaSkgcmV0dXJuIDx0ZCBrZXk9e2l9PjxidXR0b24gY2xhc3NOYW1lPVwiY2VsbCBzZWxcIiBvbkNsaWNrPXsoKSA9PiBzZXRTZWwobnVsbCl9PsSQYW5nIGNo4buNbjxzbWFsbD57bW9uZXkoc2xvdFByaWNlKGMsIHMpKX08L3NtYWxsPjwvYnV0dG9uPjwvdGQ+XG4gICAgcmV0dXJuIDx0ZCBrZXk9e2l9PjxidXR0b24gY2xhc3NOYW1lPVwiY2VsbCBmcmVlXCIgb25DbGljaz17KCkgPT4gc2V0U2VsKHsgY291cnRJZDogYy5pZCwgaWR4OiBpIH0pfT5Dw7JuIHRy4buRbmc8c21hbGw+e21vbmV5KHNsb3RQcmljZShjLCBzKSl9PC9zbWFsbD48L2J1dHRvbj48L3RkPlxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY2FyZCByb3cgYmV0d2VlbiB3cmFwIGcxNlwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2IH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTYgd3JhcFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGc4XCI+PHNwYW4gY2xhc3NOYW1lPVwidDEyIHc2MDAgYy1zNjAwXCI+TmfDoHkgxJHhurd0IHPDom46PC9zcGFuPlxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJkYXRlXCIgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiBzdHlsZT17eyB3aWR0aDogJ2F1dG8nIH19IHZhbHVlPXtkYXRlfSBtaW49e1RPREFZfSBvbkNoYW5nZT17KGUpID0+IHsgc2V0RGF0ZShlLnRhcmdldC52YWx1ZSB8fCBUT0RBWSk7IHNldFNlbChudWxsKSB9fSAvPjwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGc4XCI+PHNwYW4gY2xhc3NOYW1lPVwidDEyIHc2MDAgYy1zNjAwXCI+QuG7mSBtw7RuOjwvc3Bhbj5cbiAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwic2VsZWN0IHNtIGZpdFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1zMTAwKScgfX0gdmFsdWU9e3Nwb3J0fSBvbkNoYW5nZT17KGUpID0+IHNldFNwb3J0KGUudGFyZ2V0LnZhbHVlIGFzICdhbGwnIHwgU3BvcnRLZXkpfT5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFsbFwiPlThuqV0IGPhuqMgc8OibiB0cm9uZyBjxqEgc+G7nyAoe2JDb3VydHMubGVuZ3RofSBzw6JuKTwvb3B0aW9uPlxuICAgICAgICAgICAgICB7U1BPUlRTLmZpbHRlcigocykgPT4gYkNvdXJ0cy5zb21lKChjKSA9PiBjLnNwb3J0ID09PSBzLmtleSkpLm1hcCgocykgPT4gPG9wdGlvbiBrZXk9e3Mua2V5fSB2YWx1ZT17cy5rZXl9PntzLmxhYmVsfSAoe2JDb3VydHMuZmlsdGVyKChjKSA9PiBjLnNwb3J0ID09PSBzLmtleSkubGVuZ3RofSBzw6JuKTwvb3B0aW9uPil9XG4gICAgICAgICAgICA8L3NlbGVjdD48L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGcxNiB3cmFwXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGVnZW5kXCI+PGkgLz5Dw7JuIHRy4buRbmc8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwibGVnZW5kXCI+PGkgY2xhc3NOYW1lPVwic2VsXCIgLz7EkGFuZyBjaOG7jW48L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGVnZW5kXCI+PGkgY2xhc3NOYW1lPVwicGxheVwiIC8+S2jDoWNoIMSRYW5nIGNoxqFpPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImxlZ2VuZFwiPjxpIGNsYXNzTmFtZT1cImhvbGRcIiAvPsSQw6MgxJHhurd0IHRyxrDhu5tjPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkMTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFuNyBjb2wgZzE2XCI+XG4gICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY2FyZCBjYXJkLWxnIGNvbCBnMTZcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInQxNCB3ODAwIGMtaW5rXCI+QuG6o25nIGzhu4tjaCBzw6JuIHRy4buxYyB0aeG6v3Ag4oCTIE5o4bqlcCBjaOG7jW4gw7QgdHLhu5FuZyDEkeG7gyBs4bqtcCDEkcahbjwvaDI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGItZ3JlZW4tZmxhdFwiIHN0eWxlPXt7IGZvbnRTaXplOiAxMSB9fT5DYSB0cuG7sWM6IHt1c2VyPy5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2hvbGlkYXkgJiYgPGRpdiBjbGFzc05hbWU9XCJoaW50XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLWFtYmVyLTUwKScsIGJvcmRlckNvbG9yOiAndmFyKC0tYW1iZXItMzAwKScsIGNvbG9yOiAndmFyKC0tYW1iZXItOTAwKScgfX0+8J+ThSB7aG9saWRheS5ub3RlfTwvZGl2Pn1cbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJzY2hlZFwiPlxuICAgICAgICAgICAgICA8dGhlYWQ+PHRyPjx0aD5Uw6puIHPDom48L3RoPntDT1VOVEVSX1NMT1RTLm1hcCgocykgPT4gPHRoIGtleT17cy5zdGFydH0+e3Muc3RhcnR9IC0ge3MuZW5kfTxzbWFsbCBjbGFzc05hbWU9e3MubGFiZWwgPT09ICdDYW8gxJFp4buDbScgPyAncGVhaycgOiAnJ30+e3MubGFiZWx9PC9zbWFsbD48L3RoPil9PC90cj48L3RoZWFkPlxuICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAge3Jvd3MubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtjLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgPHRkPjxkaXYgY2xhc3NOYW1lPVwidDEyIHc4MDAgYy1pbmtcIj57Yy5uYW1lfTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwidDExIGMtczYwMFwiPntNYXRoLnJvdW5kKGMucHJpY2VOb3JtYWwgLyAxMDAwKX1rIC0ge01hdGgucm91bmQoYy5wcmljZVBlYWsgLyAxMDAwKX1rL2g8L2Rpdj48L3RkPlxuICAgICAgICAgICAgICAgICAgICB7Q09VTlRFUl9TTE9UUy5tYXAoKF8sIGkpID0+IGNlbGxGb3IoYywgaSkpfVxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICB7cmVjZWlwdCAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGc2XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLWJyYW5kLTUwKScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1icmFuZC0zMDApJywgYm9yZGVyUmFkaXVzOiAxMiwgcGFkZGluZzogMTQgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlblwiPjxiIGNsYXNzTmFtZT1cInQxMiBjLWJyYW5kOVwiPvCfp74gUGhp4bq/dSB0aHUgZ+G6p24gbmjhuqV0IHThuqFpIHF14bqneTwvYj48c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBjLXdoaXRlXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLWJyYW5kLTcwMCknLCBib3JkZXJSYWRpdXM6IDQsIGZvbnRTaXplOiAxMSB9fT7EkMOjIHRodSB0aeG7gW4gJiBHaeG7ryBs4buLY2g8L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzI0IHdyYXAgdDEyXCI+PHNwYW4+TcOjIHBoaeG6v3U6IDxiPntyZWNlaXB0LmNvZGV9PC9iPjwvc3Bhbj48c3Bhbj5Nw6MgxJHGoW46IDxiPntyZWNlaXB0Lm9yZGVyfTwvYj48L3NwYW4+PHNwYW4+VGjhu7FjIHRodTogPGI+e3ZuZChyZWNlaXB0LmFtb3VudCl9ICh7cmVjZWlwdC5tZXRob2R9KTwvYj48L3NwYW4+PHNwYW4+VGh1IG5nw6JuOiA8Yj57cmVjZWlwdC5jYXNoaWVyfTwvYj48L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJzcGFuNSBjYXJkIGNhcmQtbGcgY2FyZC1yYWlzZSBjb2wgZzE2XCIgc3R5bGU9e3sgcGFkZGluZzogMjAgfX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiBoZWFkLXJ1bGVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGcyXCI+PHNwYW4gY2xhc3NOYW1lPVwiZXllYnJvd1wiPlBoaeG6v3UgxJHhurd0IHPDom4gdOG6oWkgcXXhuqd5PC9zcGFuPjxoMiBjbGFzc05hbWU9XCJ0MTYgdzgwMCBjLWlua1wiIHN0eWxlPXt7IGxpbmVIZWlnaHQ6ICcyNHB4JyB9fT5UaMO0bmcgdGluIGtow6FjaCAmIFRodSB0aeG7gW48L2gyPjwvZGl2PlxuICAgICAgICAgICAge2FjdGl2ZSA/IDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGItZ3JlZW4tZmxhdFwiIHN0eWxlPXt7IGZvbnRTaXplOiAxMSB9fT57YWN0aXZlLmNvdXJ0Lm5hbWV9ICh7YWN0aXZlLnNsb3Quc3RhcnR9IC0ge2FjdGl2ZS5zbG90LmVuZH0pPC9zcGFuPlxuICAgICAgICAgICAgICA6IDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGItZ3JheS1vXCIgc3R5bGU9e3sgZm9udFNpemU6IDExIH19PkNoxrBhIGNo4buNbiBzw6JuPC9zcGFuPn1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGc4XCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIiBzdHlsZT17eyBtYXJnaW46IDAgfX0+TG/huqFpIGtow6FjaCBow6BuZzwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnOFwiPlxuICAgICAgICAgICAgICB7KFtbJ3dhbGtpbicsICdLaMOhY2ggdsOjbmcgbGFpJ10sIFsnbWVtYmVyJywgJ0jhu5lpIHZpw6puIGPDsyB0w6BpIGtob+G6o24nXV0gYXMgY29uc3QpLm1hcCgoW2ssIGxdKSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2t9IHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e2ByYWRpby1jYXJkIGYxIGNlbnRlciR7a2luZCA9PT0gayA/ICcgb24nIDogJyd9YH0gb25DbGljaz17KCkgPT4geyBzZXRLaW5kKGspOyBpZiAoayA9PT0gJ3dhbGtpbicpIHNldElzTWVtYmVyKGZhbHNlKSB9fT57bH08L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTJcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiAnZmxleC1zdGFydCcgfX0+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiAnNDglJyB9fT5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCI+U+G7kSDEkWnhu4duIHRob+G6oWkga2jDoWNoIDxzcGFuIGNsYXNzTmFtZT1cInJlcVwiPio8L3NwYW4+PC9sYWJlbD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzhcIj48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiBwbGFjZWhvbGRlcj1cIjA5eHh4eHh4eHhcIiB2YWx1ZT17cGhvbmV9IG9uQ2hhbmdlPXsoZSkgPT4geyBzZXRQaG9uZShlLnRhcmdldC52YWx1ZSk7IHNldExvb2t1cE1zZygnJykgfX0gb25LZXlEb3duPXsoZSkgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgbG9va3VwKCl9IC8+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuIGJ0bi1kYXJrIGJ0bi1zbVwiIG9uQ2xpY2s9e2xvb2t1cH0+VHJhIGPhu6l1PC9idXR0b24+PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjFcIj48bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIj5I4buNIHbDoCB0w6puIGtow6FjaCA8c3BhbiBjbGFzc05hbWU9XCJyZXFcIj4qPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dCBjbGFzc05hbWU9XCJpbnB1dCBzbVwiIHBsYWNlaG9sZGVyPVwiTmjhuq1wIGjhu40gdMOqblwiIHZhbHVlPXtuYW1lfSBvbkNoYW5nZT17KGUpID0+IHNldE5hbWUoZS50YXJnZXQudmFsdWUpfSAvPjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT17bG9va3VwTXNnLnN0YXJ0c1dpdGgoJ+KckycpID8gJ2ZpZWxkLW9rJyA6ICd0MTIgYy1zNjAwJ30gc3R5bGU9e3sgbWFyZ2luVG9wOiAtNiB9fT5cbiAgICAgICAgICAgIHtsb29rdXBNc2cgfHwgPD5LaMOhY2ggxJHhurd0IHRy4buxYyB0aeG6v3AgdOG6oWkgcXXhuqd5IGNoxrBhIGPDsyB0w6BpIGtob+G6o24gc+G6vSDEkcaw4bujYyBnaGkgbmjhuq1uIGzDoCA8Yj5LaMOhY2ggdsOjbmcgbGFpPC9iPi48Lz59XG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0b3AtcnVsZSBjb2wgZzhcIiBzdHlsZT17eyBwYWRkaW5nVG9wOiAxNiB9fT5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJsYWJlbFwiIHN0eWxlPXt7IG1hcmdpbjogMCB9fT5DaMawxqFuZyB0csOsbmgga2h1eeG6v24gbcOjaSAvIE3DoyBnaeG6o20gZ2nDoTwvbGFiZWw+XG4gICAgICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cInNlbGVjdCBzbVwiIHZhbHVlPXtwcm9tb0NvZGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHJvbW9Db2RlKGUudGFyZ2V0LnZhbHVlKX0+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5LaMO0bmcgw6FwIGThu6VuZzwvb3B0aW9uPlxuICAgICAgICAgICAgICB7cHJvbW9zLmZpbHRlcigocCkgPT4gcC5hY3RpdmUpLm1hcCgocCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHIgPSBhY3RpdmUgPyBldmFsUHJvbW8ocCwgYWN0aXZlLmNvdXJ0LCBkYXRlLCBhY3RpdmUuc2xvdCwgYmFzZSwgdHJ1ZSkgOiBudWxsXG4gICAgICAgICAgICAgICAgcmV0dXJuIDxvcHRpb24ga2V5PXtwLmNvZGV9IHZhbHVlPXtwLmNvZGV9PntwLmNvdW50ZXJPbmx5ID8gYEdp4bqjbSAke3AucGVyY2VudH0lICR7cC5uYW1lfWAgOiBgJHtwLmNvZGV9IOKAkyAke3AubmFtZX0gKC0ke3AucGVyY2VudH0lKWB9e3I/Lm9rID8gYCAoLSR7bW9uZXkoci5vZmYpfSlgIDogJyd9PC9vcHRpb24+XG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICB7cHJvbW9SZXMgJiYgIXByb21vUmVzLm9rICYmIDxwIGNsYXNzTmFtZT1cImZpZWxkLWVyclwiPntwcm9tb1Jlcy5tc2d9PC9wPn1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wLXJ1bGUgY29sIGc4XCIgc3R5bGU9e3sgcGFkZGluZ1RvcDogMTYgfX0+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIiBzdHlsZT17eyBtYXJnaW46IDAgfX0+TeG7qWMgdGhhbmggdG/DoW48L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzhcIj5cbiAgICAgICAgICAgICAgeyhbWydmdWxsJywgJ1RodSDEkeG7pyAxMDAlJ10sIFsnZGVwb3NpdCcsIGBUaHUgY+G7jWMgZ2nhu68gc8OibiAoJHthY3RpdmU/LmNvdXJ0LmRlcG9zaXQgPz8gMzB9JSlgXV0gYXMgY29uc3QpLm1hcCgoW2ssIGxdKSA9PiAoXG4gICAgICAgICAgICAgICAgPGxhYmVsIGtleT17a30gY2xhc3NOYW1lPXtgcmFkaW8tY2FyZCBmMSR7bGV2ZWwgPT09IGsgPyAnIG9uJyA6ICcnfWB9PjxpbnB1dCB0eXBlPVwicmFkaW9cIiBuYW1lPVwibGV2ZWxcIiBjaGVja2VkPXtsZXZlbCA9PT0ga30gb25DaGFuZ2U9eygpID0+IHNldExldmVsKGspfSAvPntsfTwvbGFiZWw+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0b3AtcnVsZSBjb2wgZzhcIiBzdHlsZT17eyBwYWRkaW5nVG9wOiAxNiB9fT5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJsYWJlbFwiIHN0eWxlPXt7IG1hcmdpbjogMCB9fT5Iw6xuaCB0aOG7qWMgdGh1IHRp4buBbiB04bqhaSBxdeG6p3k8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzhcIj5cbiAgICAgICAgICAgICAgeyhbWydjYXNoJywgJ/CfkrUgVGnhu4FuIG3hurd0J10sIFsncXInLCAn8J+TsSBRdcOpdCBtw6MgVmlldFFSJ11dIGFzIGNvbnN0KS5tYXAoKFtrLCBsXSkgPT4gKFxuICAgICAgICAgICAgICAgIDxsYWJlbCBrZXk9e2t9IGNsYXNzTmFtZT17YHJhZGlvLWNhcmQgZjEke21ldGhvZCA9PT0gayA/ICcgb24nIDogJyd9YH0+PGlucHV0IHR5cGU9XCJyYWRpb1wiIG5hbWU9XCJtZXRob2RcIiBjaGVja2VkPXttZXRob2QgPT09IGt9IG9uQ2hhbmdlPXsoKSA9PiBzZXRNZXRob2Qoayl9IC8+e2x9PC9sYWJlbD5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHttZXRob2QgPT09ICdxcicgJiYgYWN0aXZlICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzEyXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLXMxMDApJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLXMzMDApJywgYm9yZGVyUmFkaXVzOiAxMiwgcGFkZGluZzogMTIgfX0+XG4gICAgICAgICAgICAgICAgPGltZyBzcmM9e3FyfSBhbHQ9XCJWaWV0UVJcIiB3aWR0aD17OTZ9IGhlaWdodD17OTZ9IC8+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0MTIgYy1zNzAwIGNvbCBnNFwiPjxiIGNsYXNzTmFtZT1cImMtaW5rXCI+S2jDoWNoIHF1w6l0IG3DoyDEkeG7gyBjaHV54buDbiB7dm5kKHBheSl9PC9iPjxzcGFuPk7hu5lpIGR1bmc6IDxiPlFVQVkge2JyYW5jaC5zaG9ydC50b1VwcGVyQ2FzZSgpfTwvYj48L3NwYW4+PHNwYW4+U2F1IGtoaSB0aOG6pXkgZ2lhbyBk4buLY2ggYsOhbyBjw7MsIG5o4bqlbiB4w6FjIG5o4bqtbiB0aHUgdGnhu4FuLjwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaW50IGNvbCBnOFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2IH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlblwiPjxzcGFuIGNsYXNzTmFtZT1cImMtczYwMFwiPlRp4buBbiBzw6JuIHRoZW8ga2h1bmcgZ2nhu506PC9zcGFuPjxiPnt2bmQoYmFzZSl9PC9iPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlblwiPjxzcGFuIGNsYXNzTmFtZT1cImMtYnJhbmQgdzYwMFwiPkdp4bqjbSBnacOhIGtodXnhur9uIG3Do2k6PC9zcGFuPjxiIGNsYXNzTmFtZT1cImMtYnJhbmRcIj57b2ZmID8gYC0gJHt2bmQob2ZmKX1gIDogJzAgVk7EkCd9PC9iPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiB0b3AtcnVsZVwiIHN0eWxlPXt7IHBhZGRpbmdUb3A6IDggfX0+PGIgY2xhc3NOYW1lPVwidDE0IGMtYnJhbmQ5XCI+Q+G6p24gdGh1IGtow6FjaCBuZ2F5OjwvYj48YiBjbGFzc05hbWU9XCJ0MTYgYy1icmFuZDggdzgwMFwiPnt2bmQocGF5KX08L2I+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuIHQxMVwiPjxzcGFuIGNsYXNzTmFtZT1cImMtczYwMFwiPkPDsm4gbOG6oWkgdGh1IGtoaSBuaOG6rW4gc8Oibjo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiYy1zNzAwXCI+e3ZuZCh0b3RhbCAtIHBheSl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAge2FjdGl2ZSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0MTEgYy1zNTAwXCI+VGjhu51pIGzGsOG7o25nOiB7c2xvdEhvdXJzKGFjdGl2ZS5zbG90KX0gZ2nhu50g4oCiIHticmFuY2gubmFtZX08L3NwYW4+fVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGc4XCI+XG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tbGcgZjFcIiBvbkNsaWNrPXtzdWJtaXR9PuKckyBYw6FjIG5o4bqtbiB0aHUgdGnhu4FuICYgVOG6oW8gxJHGoW48L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1sZ1wiIG9uQ2xpY2s9e3Jlc2V0fT5I4buneSBi4buPPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvYXNpZGU+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKVxufVxuIl19