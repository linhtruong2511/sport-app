import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Payment.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { TODAY, branchOf, toVN, vnd } from "/src/data.ts";
import { useApp, useNow } from "/src/store.tsx";
import qr from "/src/assets/icons/qr.svg?import";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/Payment.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
export default function Payment() {
	_s();
	const { id } = useParams();
	const { bookings, courts, confirmPayment, cancelBooking, toast } = useApp();
	const nav = useNavigate();
	const now = useNow(1e3);
	const b = bookings.find((x) => x.id === id);
	const court = b && courts.find((c) => c.id === b.courtId);
	if (!b || !court) return /* @__PURE__ */ _jsxDEV("div", {
		className: "card col g12 center",
		style: { padding: 48 },
		children: [/* @__PURE__ */ _jsxDEV("h1", {
			className: "t18 w800",
			children: "Không tìm thấy đơn đặt sân"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 89
		}, this), /* @__PURE__ */ _jsxDEV(Link, {
			className: "btn btn-primary",
			to: "/booking",
			children: "Đặt sân mới"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 145
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 28
	}, this);
	if (b.status !== "pending") {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "card col g12",
			style: {
				padding: 40,
				alignItems: "center",
				maxWidth: 560,
				margin: "0 auto"
			},
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "t18 w800 c-ink",
					children: b.status === "cancelled" ? "Đơn đã bị hủy / hết hạn giữ chỗ" : "Đơn đã được thanh toán"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "t12 c-s600",
					style: { textAlign: "center" },
					children: b.status === "cancelled" ? "Khung giờ đã được mở lại cho khách khác. Vui lòng đặt lại khung giờ phù hợp." : `Đơn #${b.id} đã được xác nhận. Bạn có thể xem chi tiết trong "Lịch đặt của tôi".`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "row g8",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						className: "btn btn-outline",
						to: "/booking",
						children: "Đặt sân khác"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 33
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						className: "btn btn-primary",
						to: "/my-bookings",
						children: "Lịch đặt của tôi"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 100
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 7
		}, this);
	}
	const branch = branchOf(court.branchId);
	const left = Math.max(0, Math.floor(((b.holdUntil ?? now) - now) / 1e3));
	const mm = String(Math.floor(left / 60)).padStart(2, "0"), ss = String(left % 60).padStart(2, "0");
	const dueNow = b.payMode === "full" ? b.total : Math.round(b.total * (court.deposit / 100));
	const hrs = (parseInt(b.end) * 60 + (parseInt(b.end.split(":")[1]) || 0) - (parseInt(b.start) * 60 + (parseInt(b.start.split(":")[1]) || 0))) / 60;
	const when = b.date === TODAY ? "hôm nay" : toVN(b.date);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "col g24",
		style: {
			maxWidth: 976,
			margin: "0 auto",
			width: "100%"
		},
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "row between wrap g16",
			style: {
				background: "var(--amber-100)",
				border: "2px solid var(--amber-400)",
				borderRadius: 16,
				padding: 16
			},
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "row g14",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "center t20 w700 c-white",
					style: {
						width: 44,
						height: 44,
						borderRadius: 12,
						background: "var(--amber-500)"
					},
					children: "⏳"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "col",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "t14 w800",
						style: { color: "var(--amber-950)" },
						children: [
							"Đơn đặt sân #",
							b.id,
							" đang chờ bạn thanh toán"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "t12 w500",
						style: { color: "var(--amber-900)" },
						children: [
							court.name,
							" (",
							b.start,
							" - ",
							b.end,
							" ",
							when,
							") đang được giữ chỗ cho bạn. Vui lòng quét mã QR trước khi hết thời gian."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "col center",
				style: {
					background: "#fff",
					border: "1px solid var(--amber-400)",
					borderRadius: 12,
					padding: "8px 16px"
				},
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "t10 w700 upper",
					style: {
						color: "var(--s500)",
						lineHeight: "15px"
					},
					children: "Thời gian giữ chỗ"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "t18 w800 mono",
					style: { color: left < 60 ? "var(--rose-700)" : "var(--amber-800)" },
					children: [
						mm,
						":",
						ss
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid12",
			children: [/* @__PURE__ */ _jsxDEV("section", {
				className: "span7 card card-lg col g20",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "row between g12 head-rule",
						style: { paddingBottom: 16 },
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "col",
							children: [/* @__PURE__ */ _jsxDEV("h1", {
								className: "t18 w800 c-ink",
								children: "Quét mã QR để thanh toán"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 34
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "t12 c-s600",
								children: "Mở ứng dụng Ngân hàng bất kỳ và quét mã VietQR bên dưới"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 94
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "badge b-green-flat",
							style: {
								border: "1px solid var(--gray-200)",
								color: "var(--brand-800)"
							},
							children: "Xác nhận tự động 24/7"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "row g24",
						style: {
							background: "var(--s100)",
							border: "1px solid var(--s300)",
							borderRadius: 16,
							padding: 20
						},
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "col g8",
							style: {
								background: "#fff",
								border: "2px solid var(--brand-700)",
								borderRadius: 16,
								padding: 16,
								boxShadow: "var(--shadow-sm)",
								alignItems: "center"
							},
							children: [/* @__PURE__ */ _jsxDEV("img", {
								src: qr,
								alt: "Mã VietQR",
								width: 176,
								height: 176
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 55,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "t11 w700 c-brand8",
								children: "VietQR • Đã điền sẵn số tiền"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "col g10 f1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "hint",
									style: {
										background: "#fff",
										padding: 12
									},
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "c-s500",
										children: "Ngân hàng nhận:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 59,
										columnNumber: 81
									}, this), /* @__PURE__ */ _jsxDEV("b", {
										className: "t14 w800 c-ink",
										children: ["Vietcombank - Chi nhánh ", branch.short]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 59,
										columnNumber: 126
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 59,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "hint row between",
									style: {
										background: "#fff",
										padding: 12
									},
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "c-s500",
										children: "Số tài khoản:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 60,
										columnNumber: 98
									}, this), /* @__PURE__ */ _jsxDEV("b", {
										className: "t14 w800 c-ink",
										children: "1029384756"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 60,
										columnNumber: 141
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 60,
										columnNumber: 93
									}, this), /* @__PURE__ */ _jsxDEV("b", {
										className: "t11 c-brand8",
										children: ["SPORTHUB ", branch.short.toUpperCase()]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 60,
										columnNumber: 191
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 60,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "hint row between",
									style: {
										background: "rgba(209,250,229,.8)",
										borderColor: "var(--gray-200)",
										padding: 12
									},
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "col g2",
										children: [/* @__PURE__ */ _jsxDEV("b", {
											className: "c-brand9",
											children: [
												"Số tiền cần chuyển ",
												b.payMode === "full" ? "(100%)" : `(Cọc ${court.deposit}%)`,
												":"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 62,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("b", {
											className: "t16 w800 c-brand9",
											style: { lineHeight: "24px" },
											children: vnd(dueNow)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 62,
											columnNumber: 150
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 62,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "badge sq",
										style: {
											background: "#fff",
											border: "1px solid var(--gray-200)",
											color: "var(--brand-800)",
											fontSize: 11
										},
										children: "Đúng số tiền"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "hint",
									style: {
										background: "#fff",
										padding: 12
									},
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "c-s500",
										children: "Nội dung chuyển khoản:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 65,
										columnNumber: 81
									}, this), /* @__PURE__ */ _jsxDEV("b", {
										className: "t14 w800 c-ink",
										children: ["THANHTOAN ", b.id]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 65,
										columnNumber: 133
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 65,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "col g8",
						style: { paddingTop: 8 },
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "row g12 wrap",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-primary btn-lg f1",
								onClick: () => {
									confirmPayment(b.id);
									toast(`Thanh toán thành công! Đơn #${b.id} đã được xác nhận.`, "ok");
									nav("/my-bookings");
								},
								children: "✓ Tôi đã hoàn tất chuyển khoản"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-outline btn-lg",
								onClick: () => {
									cancelBooking(b.id, "Khách đổi khung giờ khác", false);
									toast("Đã hủy giữ chỗ. Vui lòng chọn khung giờ khác.");
									nav(`/booking?branch=${court.branchId}&sport=${court.sport}&date=${b.date}`);
								},
								children: "Đổi khung giờ khác"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "t11 c-s600",
							style: { textAlign: "center" },
							children: "Hệ thống sẽ tự động xác nhận lịch đặt sân của bạn ngay sau khi nhận được giao dịch chuyển khoản."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				className: "span5 col g16",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "card card-lg col g16",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "row between g12 head-rule",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "t16 w800 c-ink",
							style: { lineHeight: "24px" },
							children: ["Chi tiết đơn #", b.id]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "badge b-amber",
							children: "Chờ thanh toán"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "col g10 t12",
						children: [[
							[
								"Người đặt sân:",
								`${b.customer} (${b.phone})`,
								""
							],
							[
								"Địa điểm:",
								`${branch.name.replace(" - ", " - ")} • ${court.name}`,
								""
							],
							[
								"Khung giờ chơi:",
								`${toVN(b.date)} • ${b.start} - ${b.end} (${hrs} giờ)`,
								"c-brand w800"
							],
							[
								`Tổng tiền thuê sân${b.discount ? ` (đã giảm ${Math.round(b.discount / b.subtotal * 100)}%)` : ""}:`,
								vnd(b.total),
								""
							],
							[
								"Tiền đặt cọc thanh toán ngay:",
								vnd(dueNow),
								"c-brand w800"
							],
							[
								"Còn lại thanh toán khi nhận sân:",
								vnd(b.total - dueNow),
								""
							]
						].map(([k, v, c]) => /* @__PURE__ */ _jsxDEV("div", {
							className: "row between g12",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: k
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 87
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: c || "c-ink",
								style: { textAlign: "right" },
								children: v
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 122
							}, this)]
						}, k, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 46
						}, this)), /* @__PURE__ */ _jsxDEV("div", {
							className: "row between top-rule",
							style: { paddingTop: 8 },
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: "Trạng thái thanh toán:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 79
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "c-amber",
								children: "Chưa thanh toán"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 133
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "card col g8",
					children: [
						/* @__PURE__ */ _jsxDEV("b", {
							className: "t12 c-ink",
							children: "Quy định nhận sân & hoàn hủy:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "t12 c-s700",
							children: [
								"• Vui lòng có mặt tại quầy lễ tân trước giờ chơi 10 phút để thanh toán phần tiền còn thiếu (",
								vnd(b.total - dueNow),
								") và nhận sân."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "t12 c-s700",
							children: "• Các đơn hủy lịch hoặc quá giờ không đến nhận sân sẽ không được hoàn lại khoản tiền đã đặt cọc."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
}
_s(Payment, "rcJQTB9UIwR/DiiVpJpF4P8C5zc=", false, function() {
	return [
		useParams,
		useApp,
		useNavigate,
		useNow
	];
});
_c = Payment;
var _c;
$RefreshReg$(_c, "Payment");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Payment.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/Payment.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/Payment.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/Payment.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLGFBQWEsaUJBQWlCO0FBQzdDLFNBQVMsT0FBTyxVQUFVLE1BQU0sV0FBVztBQUMzQyxTQUFTLFFBQVEsY0FBYztBQUMvQixPQUFPLFFBQVE7Ozs7QUFFZixlQUFlLFNBQVMsVUFBVTs7Q0FDaEMsTUFBTSxFQUFFLE9BQU8sVUFBVTtDQUN6QixNQUFNLEVBQUUsVUFBVSxRQUFRLGdCQUFnQixlQUFlLFVBQVUsT0FBTztDQUMxRSxNQUFNLE1BQU0sWUFBWTtDQUN4QixNQUFNLE1BQU0sT0FBTyxHQUFJO0NBQ3ZCLE1BQU0sSUFBSSxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRTtDQUMxQyxNQUFNLFFBQVEsS0FBSyxPQUFPLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPO0NBRXhELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQXNCLE9BQU8sRUFBRSxTQUFTLEdBQUc7WUFBMUQsQ0FBNkQsd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFBVztFQUE4Qjs7OztZQUFDLHdCQUFDLE1BQUQ7R0FBTSxXQUFVO0dBQWtCLElBQUc7YUFBVztFQUFpQjs7OztVQUFNOzs7Ozs7Q0FDck4sSUFBSSxFQUFFLFdBQVcsV0FBVztFQUMxQixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQWUsT0FBTztJQUFFLFNBQVM7SUFBSSxZQUFZO0lBQVUsVUFBVTtJQUFLLFFBQVE7R0FBUzthQUExRztJQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWtCLEVBQUUsV0FBVyxjQUFjLG9DQUFvQztJQUE2Qjs7Ozs7SUFDNUgsd0JBQUMsS0FBRDtLQUFHLFdBQVU7S0FBYSxPQUFPLEVBQUUsV0FBVyxTQUFTO2VBQUksRUFBRSxXQUFXLGNBQWMsaUZBQWlGLFFBQVEsRUFBRSxHQUFHO0lBQXlFOzs7OztJQUM3UCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQXdCLHdCQUFDLE1BQUQ7TUFBTSxXQUFVO01BQWtCLElBQUc7Z0JBQVc7S0FBa0I7Ozs7ZUFBQyx3QkFBQyxNQUFEO01BQU0sV0FBVTtNQUFrQixJQUFHO2dCQUFlO0tBQXNCOzs7O2FBQU07Ozs7OztHQUN4Szs7Ozs7O0NBRVQ7Q0FDQSxNQUFNLFNBQVMsU0FBUyxNQUFNLFFBQVE7Q0FDdEMsTUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssUUFBUSxFQUFFLGFBQWEsT0FBTyxPQUFPLEdBQUksQ0FBQztDQUN4RSxNQUFNLEtBQUssT0FBTyxLQUFLLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEdBQUcsS0FBSyxPQUFPLE9BQU8sRUFBRSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7Q0FDakcsTUFBTSxTQUFTLEVBQUUsWUFBWSxTQUFTLEVBQUUsUUFBUSxLQUFLLE1BQU0sRUFBRSxTQUFTLE1BQU0sVUFBVSxJQUFJO0NBQzFGLE1BQU0sT0FBTyxTQUFTLEVBQUUsR0FBRyxJQUFJLE1BQU0sU0FBUyxFQUFFLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFLEtBQUssTUFBTSxTQUFTLEVBQUUsS0FBSyxJQUFJLE1BQU0sU0FBUyxFQUFFLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFLEtBQUssT0FBTztDQUNoSixNQUFNLE9BQU8sRUFBRSxTQUFTLFFBQVEsWUFBWSxLQUFLLEVBQUUsSUFBSTtDQUV2RCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQVUsT0FBTztHQUFFLFVBQVU7R0FBSyxRQUFRO0dBQVUsT0FBTztFQUFPO1lBQWpGLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7R0FBdUIsT0FBTztJQUFFLFlBQVk7SUFBb0IsUUFBUTtJQUE4QixjQUFjO0lBQUksU0FBUztHQUFHO2FBQW5KLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO0tBQTBCLE9BQU87TUFBRSxPQUFPO01BQUksUUFBUTtNQUFJLGNBQWM7TUFBSSxZQUFZO0tBQW1CO2VBQUc7SUFBTzs7OztjQUNySSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7TUFBVyxPQUFPLEVBQUUsT0FBTyxtQkFBbUI7Z0JBQTlEO09BQWlFO09BQWMsRUFBRTtPQUFHO01BQThCOzs7OztlQUNsSCx3QkFBQyxRQUFEO01BQU0sV0FBVTtNQUFXLE9BQU8sRUFBRSxPQUFPLG1CQUFtQjtnQkFBOUQ7T0FBa0UsTUFBTTtPQUFLO09BQUcsRUFBRTtPQUFNO09BQUksRUFBRTtPQUFJO09BQUU7T0FBSztNQUErRTs7Ozs7YUFDckw7Ozs7O1lBQ0Y7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBYSxPQUFPO0tBQUUsWUFBWTtLQUFRLFFBQVE7S0FBOEIsY0FBYztLQUFJLFNBQVM7SUFBVztjQUFySSxDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO0tBQWlCLE9BQU87TUFBRSxPQUFPO01BQWUsWUFBWTtLQUFPO2VBQUc7SUFBdUI7Ozs7Y0FDN0csd0JBQUMsUUFBRDtLQUFNLFdBQVU7S0FBZ0IsT0FBTyxFQUFFLE9BQU8sT0FBTyxLQUFLLG9CQUFvQixtQkFBbUI7ZUFBbkc7TUFBdUc7TUFBRztNQUFFO0tBQVM7Ozs7O1lBQ2xIOzs7OztXQUNGOzs7OztZQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQTRCLE9BQU8sRUFBRSxlQUFlLEdBQUc7Z0JBQXRFLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBcUIsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWlCO09BQTRCOzs7O2lCQUFDLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFhO09BQTBEOzs7O2VBQU07Ozs7O2dCQUMzSyx3QkFBQyxRQUFEO09BQU0sV0FBVTtPQUFxQixPQUFPO1FBQUUsUUFBUTtRQUE2QixPQUFPO09BQW1CO2lCQUFHO01BQTJCOzs7O2NBQ3hJOzs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFVLE9BQU87T0FBRSxZQUFZO09BQWUsUUFBUTtPQUF5QixjQUFjO09BQUksU0FBUztNQUFHO2dCQUE1SCxDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVMsT0FBTztRQUFFLFlBQVk7UUFBUSxRQUFRO1FBQThCLGNBQWM7UUFBSSxTQUFTO1FBQUksV0FBVztRQUFvQixZQUFZO09BQVM7aUJBQTlLLENBQ0Usd0JBQUMsT0FBRDtRQUFLLEtBQUs7UUFBSSxLQUFJO1FBQVksT0FBTztRQUFLLFFBQVE7T0FBTTs7OztpQkFDeEQsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW9CO09BQWtDOzs7O2VBQ25FOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQU8sT0FBTztVQUFFLFlBQVk7VUFBUSxTQUFTO1NBQUc7bUJBQS9ELENBQWtFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFTO1NBQW9COzs7O21CQUFDLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiLENBQThCLDRCQUF5QixPQUFPLEtBQVM7Ozs7O2lCQUFNOzs7Ozs7UUFDNUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBbUIsT0FBTztVQUFFLFlBQVk7VUFBUSxTQUFTO1NBQUc7bUJBQTNFLENBQThFLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBUztTQUFrQjs7OzttQkFBQyx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBaUI7U0FBYTs7OztpQkFBTTs7OzttQkFBQyx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYixDQUE0QixhQUFVLE9BQU8sTUFBTSxZQUFZLENBQUs7Ozs7O2lCQUFNOzs7Ozs7UUFDMVAsd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBbUIsT0FBTztVQUFFLFlBQVk7VUFBd0IsYUFBYTtVQUFtQixTQUFTO1NBQUc7bUJBQTNILENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FBd0Isd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWI7WUFBd0I7WUFBb0IsRUFBRSxZQUFZLFNBQVMsV0FBVyxRQUFRLE1BQU0sUUFBUTtZQUFJO1dBQUk7Ozs7O29CQUFDLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO1dBQW9CLE9BQU8sRUFBRSxZQUFZLE9BQU87cUJBQUksSUFBSSxNQUFNO1VBQUs7Ozs7a0JBQU07Ozs7O21CQUMzTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtVQUFXLE9BQU87V0FBRSxZQUFZO1dBQVEsUUFBUTtXQUE2QixPQUFPO1dBQW9CLFVBQVU7VUFBRztvQkFBRztTQUFrQjs7OztpQkFDdko7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQU8sT0FBTztVQUFFLFlBQVk7VUFBUSxTQUFTO1NBQUc7bUJBQS9ELENBQWtFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFTO1NBQTJCOzs7O21CQUFDLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiLENBQThCLGNBQVcsRUFBRSxFQUFNOzs7OztpQkFBTTs7Ozs7O09BQzFLOzs7OztjQUNGOzs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFTLE9BQU8sRUFBRSxZQUFZLEVBQUU7Z0JBQS9DLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUE0QixlQUFlO1NBQUUsZUFBZSxFQUFFLEVBQUU7U0FBRyxNQUFNLCtCQUErQixFQUFFLEdBQUcscUJBQXFCLElBQUk7U0FBRyxJQUFJLGNBQWM7UUFBRTtrQkFBRztPQUFzQzs7OztpQkFDeE4sd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBeUIsZUFBZTtTQUFFLGNBQWMsRUFBRSxJQUFJLDRCQUE0QixLQUFLO1NBQUcsTUFBTSwrQ0FBK0M7U0FBRyxJQUFJLG1CQUFtQixNQUFNLFNBQVMsU0FBUyxNQUFNLE1BQU0sUUFBUSxFQUFFLE1BQU07UUFBRTtrQkFBRztPQUEwQjs7OztlQUNuUjs7Ozs7Z0JBQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7T0FBYSxPQUFPLEVBQUUsV0FBVyxTQUFTO2lCQUFHO01BQW1HOzs7O2NBQzFKOzs7Ozs7SUFDRTs7Ozs7YUFFVCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO09BQWlCLE9BQU8sRUFBRSxZQUFZLE9BQU87aUJBQTNELENBQThELGtCQUFlLEVBQUUsRUFBTzs7Ozs7Z0JBQ3RGLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnQjtNQUFvQjs7OztjQUNqRDs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJO09BQ0E7UUFBQztRQUFrQixHQUFHLEVBQUUsU0FBUyxJQUFJLEVBQUUsTUFBTTtRQUFJO09BQUU7T0FBRztRQUFDO1FBQWEsR0FBRyxPQUFPLEtBQUssUUFBUSxPQUFPLEtBQUssRUFBRSxLQUFLLE1BQU07UUFBUTtPQUFFO09BQzlIO1FBQUM7UUFBbUIsR0FBRyxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxNQUFNLEtBQUssRUFBRSxJQUFJLElBQUksSUFBSTtRQUFRO09BQWM7T0FDMUY7UUFBQyxxQkFBcUIsRUFBRSxXQUFXLGFBQWEsS0FBSyxNQUFPLEVBQUUsV0FBVyxFQUFFLFdBQVksR0FBRyxFQUFFLE1BQU0sR0FBRztRQUFJLElBQUksRUFBRSxLQUFLO1FBQUc7T0FBRTtPQUN6SDtRQUFDO1FBQWlDLElBQUksTUFBTTtRQUFHO09BQWM7T0FBRztRQUFDO1FBQW9DLElBQUksRUFBRSxRQUFRLE1BQU07UUFBRztPQUFFO01BQ2hJLENBQUMsQ0FBVyxLQUFLLENBQUMsR0FBRyxHQUFHLE9BQU8sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBeUMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQVU7T0FBUTs7OztpQkFBQyx3QkFBQyxLQUFEO1FBQUcsV0FBVyxLQUFLO1FBQVMsT0FBTyxFQUFFLFdBQVcsUUFBUTtrQkFBSTtPQUFLOzs7O2VBQU07U0FBN0c7Ozs7YUFBNkcsQ0FBQyxHQUNuTCx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUF1QixPQUFPLEVBQUUsWUFBWSxFQUFFO2lCQUE3RCxDQUFnRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBUztPQUE0Qjs7OztpQkFBQyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBVTtPQUFrQjs7OztlQUFNOzs7OztjQUNsSzs7Ozs7YUFDRjs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQVk7TUFBZ0M7Ozs7O01BQ3pELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQTBCO1FBQTZGLElBQUksRUFBRSxRQUFRLE1BQU07UUFBRTtPQUFpQjs7Ozs7O01BQzlKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFhO01BQW1HOzs7OztLQUMxSDs7Ozs7WUFDQTs7Ozs7V0FDSjs7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUGF5bWVudC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBUT0RBWSwgYnJhbmNoT2YsIHRvVk4sIHZuZCB9IGZyb20gJy4uL2RhdGEnXG5pbXBvcnQgeyB1c2VBcHAsIHVzZU5vdyB9IGZyb20gJy4uL3N0b3JlJ1xuaW1wb3J0IHFyIGZyb20gJy4uL2Fzc2V0cy9pY29ucy9xci5zdmcnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBheW1lbnQoKSB7XG4gIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtcygpXG4gIGNvbnN0IHsgYm9va2luZ3MsIGNvdXJ0cywgY29uZmlybVBheW1lbnQsIGNhbmNlbEJvb2tpbmcsIHRvYXN0IH0gPSB1c2VBcHAoKVxuICBjb25zdCBuYXYgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IG5vdyA9IHVzZU5vdygxMDAwKVxuICBjb25zdCBiID0gYm9va2luZ3MuZmluZCgoeCkgPT4geC5pZCA9PT0gaWQpXG4gIGNvbnN0IGNvdXJ0ID0gYiAmJiBjb3VydHMuZmluZCgoYykgPT4gYy5pZCA9PT0gYi5jb3VydElkKVxuXG4gIGlmICghYiB8fCAhY291cnQpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgY29sIGcxMiBjZW50ZXJcIiBzdHlsZT17eyBwYWRkaW5nOiA0OCB9fT48aDEgY2xhc3NOYW1lPVwidDE4IHc4MDBcIj5LaMO0bmcgdMOsbSB0aOG6pXkgxJHGoW4gxJHhurd0IHPDom48L2gxPjxMaW5rIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeVwiIHRvPVwiL2Jvb2tpbmdcIj7EkOG6t3Qgc8OibiBt4bubaTwvTGluaz48L2Rpdj5cbiAgaWYgKGIuc3RhdHVzICE9PSAncGVuZGluZycpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGNvbCBnMTJcIiBzdHlsZT17eyBwYWRkaW5nOiA0MCwgYWxpZ25JdGVtczogJ2NlbnRlcicsIG1heFdpZHRoOiA1NjAsIG1hcmdpbjogJzAgYXV0bycgfX0+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0MTggdzgwMCBjLWlua1wiPntiLnN0YXR1cyA9PT0gJ2NhbmNlbGxlZCcgPyAnxJDGoW4gxJHDoyBi4buLIGjhu6d5IC8gaOG6v3QgaOG6oW4gZ2nhu68gY2jhu5cnIDogJ8SQxqFuIMSRw6MgxJHGsOG7o2MgdGhhbmggdG/DoW4nfTwvaDE+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIiBzdHlsZT17eyB0ZXh0QWxpZ246ICdjZW50ZXInIH19PntiLnN0YXR1cyA9PT0gJ2NhbmNlbGxlZCcgPyAnS2h1bmcgZ2nhu50gxJHDoyDEkcaw4bujYyBt4bufIGzhuqFpIGNobyBraMOhY2gga2jDoWMuIFZ1aSBsw7JuZyDEkeG6t3QgbOG6oWkga2h1bmcgZ2nhu50gcGjDuSBo4bujcC4nIDogYMSQxqFuICMke2IuaWR9IMSRw6MgxJHGsOG7o2MgeMOhYyBuaOG6rW4uIELhuqFuIGPDsyB0aOG7gyB4ZW0gY2hpIHRp4bq/dCB0cm9uZyBcIkzhu4tjaCDEkeG6t3QgY+G7p2EgdMO0aVwiLmB9PC9wPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnOFwiPjxMaW5rIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZVwiIHRvPVwiL2Jvb2tpbmdcIj7EkOG6t3Qgc8OibiBraMOhYzwvTGluaz48TGluayBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnlcIiB0bz1cIi9teS1ib29raW5nc1wiPkzhu4tjaCDEkeG6t3QgY+G7p2EgdMO0aTwvTGluaz48L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxuICBjb25zdCBicmFuY2ggPSBicmFuY2hPZihjb3VydC5icmFuY2hJZClcbiAgY29uc3QgbGVmdCA9IE1hdGgubWF4KDAsIE1hdGguZmxvb3IoKChiLmhvbGRVbnRpbCA/PyBub3cpIC0gbm93KSAvIDEwMDApKVxuICBjb25zdCBtbSA9IFN0cmluZyhNYXRoLmZsb29yKGxlZnQgLyA2MCkpLnBhZFN0YXJ0KDIsICcwJyksIHNzID0gU3RyaW5nKGxlZnQgJSA2MCkucGFkU3RhcnQoMiwgJzAnKVxuICBjb25zdCBkdWVOb3cgPSBiLnBheU1vZGUgPT09ICdmdWxsJyA/IGIudG90YWwgOiBNYXRoLnJvdW5kKGIudG90YWwgKiAoY291cnQuZGVwb3NpdCAvIDEwMCkpXG4gIGNvbnN0IGhycyA9IChwYXJzZUludChiLmVuZCkgKiA2MCArIChwYXJzZUludChiLmVuZC5zcGxpdCgnOicpWzFdKSB8fCAwKSAtIChwYXJzZUludChiLnN0YXJ0KSAqIDYwICsgKHBhcnNlSW50KGIuc3RhcnQuc3BsaXQoJzonKVsxXSkgfHwgMCkpKSAvIDYwXG4gIGNvbnN0IHdoZW4gPSBiLmRhdGUgPT09IFRPREFZID8gJ2jDtG0gbmF5JyA6IHRvVk4oYi5kYXRlKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzI0XCIgc3R5bGU9e3sgbWF4V2lkdGg6IDk3NiwgbWFyZ2luOiAnMCBhdXRvJywgd2lkdGg6ICcxMDAlJyB9fT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gd3JhcCBnMTZcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAndmFyKC0tYW1iZXItMTAwKScsIGJvcmRlcjogJzJweCBzb2xpZCB2YXIoLS1hbWJlci00MDApJywgYm9yZGVyUmFkaXVzOiAxNiwgcGFkZGluZzogMTYgfX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGcxNFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNlbnRlciB0MjAgdzcwMCBjLXdoaXRlXCIgc3R5bGU9e3sgd2lkdGg6IDQ0LCBoZWlnaHQ6IDQ0LCBib3JkZXJSYWRpdXM6IDEyLCBiYWNrZ3JvdW5kOiAndmFyKC0tYW1iZXItNTAwKScgfX0+4o+zPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0MTQgdzgwMFwiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tYW1iZXItOTUwKScgfX0+xJDGoW4gxJHhurd0IHPDom4gI3tiLmlkfSDEkWFuZyBjaOG7nSBi4bqhbiB0aGFuaCB0b8Ohbjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NTAwXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1hbWJlci05MDApJyB9fT57Y291cnQubmFtZX0gKHtiLnN0YXJ0fSAtIHtiLmVuZH0ge3doZW59KSDEkWFuZyDEkcaw4bujYyBnaeG7ryBjaOG7lyBjaG8gYuG6oW4uIFZ1aSBsw7JuZyBxdcOpdCBtw6MgUVIgdHLGsOG7m2Mga2hpIGjhur90IHRo4budaSBnaWFuLjwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGNlbnRlclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjZmZmJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWFtYmVyLTQwMCknLCBib3JkZXJSYWRpdXM6IDEyLCBwYWRkaW5nOiAnOHB4IDE2cHgnIH19PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMCB3NzAwIHVwcGVyXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1zNTAwKScsIGxpbmVIZWlnaHQ6ICcxNXB4JyB9fT5UaOG7nWkgZ2lhbiBnaeG7ryBjaOG7lzwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0MTggdzgwMCBtb25vXCIgc3R5bGU9e3sgY29sb3I6IGxlZnQgPCA2MCA/ICd2YXIoLS1yb3NlLTcwMCknIDogJ3ZhcigtLWFtYmVyLTgwMCknIH19PnttbX06e3NzfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkMTJcIj5cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhbjcgY2FyZCBjYXJkLWxnIGNvbCBnMjBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuIGcxMiBoZWFkLXJ1bGVcIiBzdHlsZT17eyBwYWRkaW5nQm90dG9tOiAxNiB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sXCI+PGgxIGNsYXNzTmFtZT1cInQxOCB3ODAwIGMtaW5rXCI+UXXDqXQgbcOjIFFSIMSR4buDIHRoYW5oIHRvw6FuPC9oMT48cCBjbGFzc05hbWU9XCJ0MTIgYy1zNjAwXCI+TeG7nyDhu6luZyBk4bulbmcgTmfDom4gaMOgbmcgYuG6pXQga+G7syB2w6AgcXXDqXQgbcOjIFZpZXRRUiBiw6puIGTGsOG7m2k8L3A+PC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBiLWdyZWVuLWZsYXRcIiBzdHlsZT17eyBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tZ3JheS0yMDApJywgY29sb3I6ICd2YXIoLS1icmFuZC04MDApJyB9fT5Yw6FjIG5o4bqtbiB04buxIMSR4buZbmcgMjQvNzwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMjRcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAndmFyKC0tczEwMCknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tczMwMCknLCBib3JkZXJSYWRpdXM6IDE2LCBwYWRkaW5nOiAyMCB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGc4XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNmZmYnLCBib3JkZXI6ICcycHggc29saWQgdmFyKC0tYnJhbmQtNzAwKScsIGJvcmRlclJhZGl1czogMTYsIHBhZGRpbmc6IDE2LCBib3hTaGFkb3c6ICd2YXIoLS1zaGFkb3ctc20pJywgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+XG4gICAgICAgICAgICAgIDxpbWcgc3JjPXtxcn0gYWx0PVwiTcOjIFZpZXRRUlwiIHdpZHRoPXsxNzZ9IGhlaWdodD17MTc2fSAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0MTEgdzcwMCBjLWJyYW5kOFwiPlZpZXRRUiDigKIgxJDDoyDEkWnhu4FuIHPhurVuIHPhu5EgdGnhu4FuPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnMTAgZjFcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaW50XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNmZmYnLCBwYWRkaW5nOiAxMiB9fT48ZGl2IGNsYXNzTmFtZT1cImMtczUwMFwiPk5nw6JuIGjDoG5nIG5o4bqtbjo8L2Rpdj48YiBjbGFzc05hbWU9XCJ0MTQgdzgwMCBjLWlua1wiPlZpZXRjb21iYW5rIC0gQ2hpIG5ow6FuaCB7YnJhbmNoLnNob3J0fTwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaW50IHJvdyBiZXR3ZWVuXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNmZmYnLCBwYWRkaW5nOiAxMiB9fT48ZGl2PjxkaXYgY2xhc3NOYW1lPVwiYy1zNTAwXCI+U+G7kSB0w6BpIGtob+G6o246PC9kaXY+PGIgY2xhc3NOYW1lPVwidDE0IHc4MDAgYy1pbmtcIj4xMDI5Mzg0NzU2PC9iPjwvZGl2PjxiIGNsYXNzTmFtZT1cInQxMSBjLWJyYW5kOFwiPlNQT1JUSFVCIHticmFuY2guc2hvcnQudG9VcHBlckNhc2UoKX08L2I+PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGludCByb3cgYmV0d2VlblwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICdyZ2JhKDIwOSwyNTAsMjI5LC44KScsIGJvcmRlckNvbG9yOiAndmFyKC0tZ3JheS0yMDApJywgcGFkZGluZzogMTIgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzJcIj48YiBjbGFzc05hbWU9XCJjLWJyYW5kOVwiPlPhu5EgdGnhu4FuIGPhuqduIGNodXnhu4NuIHtiLnBheU1vZGUgPT09ICdmdWxsJyA/ICcoMTAwJSknIDogYChD4buNYyAke2NvdXJ0LmRlcG9zaXR9JSlgfTo8L2I+PGIgY2xhc3NOYW1lPVwidDE2IHc4MDAgYy1icmFuZDlcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMjRweCcgfX0+e3ZuZChkdWVOb3cpfTwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBzcVwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjZmZmJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWdyYXktMjAwKScsIGNvbG9yOiAndmFyKC0tYnJhbmQtODAwKScsIGZvbnRTaXplOiAxMSB9fT7EkMO6bmcgc+G7kSB0aeG7gW48L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpbnRcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnI2ZmZicsIHBhZGRpbmc6IDEyIH19PjxkaXYgY2xhc3NOYW1lPVwiYy1zNTAwXCI+TuG7mWkgZHVuZyBjaHV54buDbiBraG/huqNuOjwvZGl2PjxiIGNsYXNzTmFtZT1cInQxNCB3ODAwIGMtaW5rXCI+VEhBTkhUT0FOIHtiLmlkfTwvYj48L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGc4XCIgc3R5bGU9e3sgcGFkZGluZ1RvcDogOCB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGcxMiB3cmFwXCI+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1sZyBmMVwiIG9uQ2xpY2s9eygpID0+IHsgY29uZmlybVBheW1lbnQoYi5pZCk7IHRvYXN0KGBUaGFuaCB0b8OhbiB0aMOgbmggY8O0bmchIMSQxqFuICMke2IuaWR9IMSRw6MgxJHGsOG7o2MgeMOhYyBuaOG6rW4uYCwgJ29rJyk7IG5hdignL215LWJvb2tpbmdzJykgfX0+4pyTIFTDtGkgxJHDoyBob8OgbiB04bqldCBjaHV54buDbiBraG/huqNuPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1sZ1wiIG9uQ2xpY2s9eygpID0+IHsgY2FuY2VsQm9va2luZyhiLmlkLCAnS2jDoWNoIMSR4buVaSBraHVuZyBnaeG7nSBraMOhYycsIGZhbHNlKTsgdG9hc3QoJ8SQw6MgaOG7p3kgZ2nhu68gY2jhu5cuIFZ1aSBsw7JuZyBjaOG7jW4ga2h1bmcgZ2nhu50ga2jDoWMuJyk7IG5hdihgL2Jvb2tpbmc/YnJhbmNoPSR7Y291cnQuYnJhbmNoSWR9JnNwb3J0PSR7Y291cnQuc3BvcnR9JmRhdGU9JHtiLmRhdGV9YCkgfX0+xJDhu5VpIGtodW5nIGdp4budIGtow6FjPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMSBjLXM2MDBcIiBzdHlsZT17eyB0ZXh0QWxpZ246ICdjZW50ZXInIH19Pkjhu4cgdGjhu5FuZyBz4bq9IHThu7EgxJHhu5luZyB4w6FjIG5o4bqtbiBs4buLY2ggxJHhurd0IHPDom4gY+G7p2EgYuG6oW4gbmdheSBzYXUga2hpIG5o4bqtbiDEkcaw4bujYyBnaWFvIGThu4tjaCBjaHV54buDbiBraG/huqNuLjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJzcGFuNSBjb2wgZzE2XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGNhcmQtbGcgY29sIGcxNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiBnMTIgaGVhZC1ydWxlXCI+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0MTYgdzgwMCBjLWlua1wiIHN0eWxlPXt7IGxpbmVIZWlnaHQ6ICcyNHB4JyB9fT5DaGkgdGnhur90IMSRxqFuICN7Yi5pZH08L2gyPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBiLWFtYmVyXCI+Q2jhu50gdGhhbmggdG/DoW48L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGcxMCB0MTJcIj5cbiAgICAgICAgICAgICAgeyhbXG4gICAgICAgICAgICAgICAgWydOZ8aw4budaSDEkeG6t3Qgc8OibjonLCBgJHtiLmN1c3RvbWVyfSAoJHtiLnBob25lfSlgLCAnJ10sIFsnxJDhu4thIMSRaeG7g206JywgYCR7YnJhbmNoLm5hbWUucmVwbGFjZSgnIC0gJywgJyAtICcpfSDigKIgJHtjb3VydC5uYW1lfWAsICcnXSxcbiAgICAgICAgICAgICAgICBbJ0todW5nIGdp4budIGNoxqFpOicsIGAke3RvVk4oYi5kYXRlKX0g4oCiICR7Yi5zdGFydH0gLSAke2IuZW5kfSAoJHtocnN9IGdp4budKWAsICdjLWJyYW5kIHc4MDAnXSxcbiAgICAgICAgICAgICAgICBbYFThu5VuZyB0aeG7gW4gdGh1w6ogc8OibiR7Yi5kaXNjb3VudCA/IGAgKMSRw6MgZ2nhuqNtICR7TWF0aC5yb3VuZCgoYi5kaXNjb3VudCAvIGIuc3VidG90YWwpICogMTAwKX0lKWAgOiAnJ306YCwgdm5kKGIudG90YWwpLCAnJ10sXG4gICAgICAgICAgICAgICAgWydUaeG7gW4gxJHhurd0IGPhu41jIHRoYW5oIHRvw6FuIG5nYXk6Jywgdm5kKGR1ZU5vdyksICdjLWJyYW5kIHc4MDAnXSwgWydDw7JuIGzhuqFpIHRoYW5oIHRvw6FuIGtoaSBuaOG6rW4gc8OibjonLCB2bmQoYi50b3RhbCAtIGR1ZU5vdyksICcnXSxcbiAgICAgICAgICAgICAgXSBhcyBjb25zdCkubWFwKChbaywgdiwgY10pID0+IDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gZzEyXCIga2V5PXtrfT48c3BhbiBjbGFzc05hbWU9XCJjLXM2MDBcIj57a308L3NwYW4+PGIgY2xhc3NOYW1lPXtjIHx8ICdjLWluayd9IHN0eWxlPXt7IHRleHRBbGlnbjogJ3JpZ2h0JyB9fT57dn08L2I+PC9kaXY+KX1cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiB0b3AtcnVsZVwiIHN0eWxlPXt7IHBhZGRpbmdUb3A6IDggfX0+PHNwYW4gY2xhc3NOYW1lPVwiYy1zNjAwXCI+VHLhuqFuZyB0aMOhaSB0aGFuaCB0b8Ohbjo8L3NwYW4+PGIgY2xhc3NOYW1lPVwiYy1hbWJlclwiPkNoxrBhIHRoYW5oIHRvw6FuPC9iPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGNvbCBnOFwiPlxuICAgICAgICAgICAgPGIgY2xhc3NOYW1lPVwidDEyIGMtaW5rXCI+UXV5IMSR4buLbmggbmjhuq1uIHPDom4gJiBob8OgbiBo4buneTo8L2I+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0MTIgYy1zNzAwXCI+4oCiIFZ1aSBsw7JuZyBjw7MgbeG6t3QgdOG6oWkgcXXhuqd5IGzhu4UgdMOibiB0csaw4bubYyBnaeG7nSBjaMahaSAxMCBwaMO6dCDEkeG7gyB0aGFuaCB0b8OhbiBwaOG6p24gdGnhu4FuIGPDsm4gdGhp4bq/dSAoe3ZuZChiLnRvdGFsIC0gZHVlTm93KX0pIHbDoCBuaOG6rW4gc8Oibi48L3A+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0MTIgYy1zNzAwXCI+4oCiIEPDoWMgxJHGoW4gaOG7p3kgbOG7i2NoIGhv4bq3YyBxdcOhIGdp4budIGtow7RuZyDEkeG6v24gbmjhuq1uIHPDom4gc+G6vSBraMO0bmcgxJHGsOG7o2MgaG/DoG4gbOG6oWkga2hv4bqjbiB0aeG7gW4gxJHDoyDEkeG6t3QgY+G7jWMuPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2FzaWRlPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==