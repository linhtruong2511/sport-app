import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Home.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { SPORTS, TODAY, toVN, money } from "/src/data.ts";
import { useApp } from "/src/store.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/Home.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
const FRAMES = [
	"Buổi sáng (05:00 - 11:00)",
	"Buổi trưa (11:00 - 15:00)",
	"Buổi chiều (15:00 - 17:30)",
	"Buổi tối (17:30 - 22:00)"
];
const CLUSTERS = [
	{
		branch: "cs1",
		sport: "pickleball",
		free: 5,
		title: "Cụm Sân Pickleball Mái Che 01 - 03",
		note: "Thảm tiêu chuẩn thi đấu, mái che kín"
	},
	{
		branch: "cs1",
		sport: "football",
		free: 3,
		title: "Sân Bóng đá Mini 01 - 02 (Sân 7 người)",
		note: "Cỏ nhân tạo mới, hỗ trợ tìm đối giao hữu"
	},
	{
		branch: "cs2",
		sport: "badminton",
		free: 6,
		title: "Nhà Thi Đấu Cầu Lông Thảm PVC 01 - 05",
		note: "Trần cao 10m, kín gió, ánh sáng chống lóa"
	},
	{
		branch: "cs3",
		sport: "tennis",
		free: 4,
		title: "Tổ hợp Sân Tennis & Bóng rổ Ngoài trời",
		note: "Có bãi đỗ xe ô tô miễn phí, tủ đồ cá nhân"
	}
];
const TONE = {
	green: "b-green",
	sky: "b-sky",
	indigo: "b-indigo",
	amber: "b-amber"
};
export default function Home() {
	_s();
	const { courts, promos, branches } = useApp();
	const nav = useNavigate();
	const [f, setF] = useState({
		branch: "cs1",
		sport: "pickleball",
		date: TODAY,
		frame: FRAMES[3]
	});
	const [focusBranch, setFocusBranch] = useState("cs1");
	const count = (k) => courts.filter((c) => c.sport === k && c.active).length;
	const go = (p) => nav(`/booking?${new URLSearchParams(p).toString()}`);
	const search = () => go({
		branch: f.branch,
		sport: f.sport,
		date: f.date,
		frame: f.frame
	});
	const pub = promos.filter((p) => !p.counterOnly);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("section", {
			className: "hero col g20",
			style: { padding: "32px 32px 28px" },
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					className: "badge",
					style: {
						alignSelf: "flex-start",
						background: "rgba(4,120,87,.8)",
						border: "1px solid rgba(16,185,129,.4)",
						color: "var(--brand-100)"
					},
					children: [
						"⚡ Hệ thống ",
						branches.length,
						" Chi nhánh • ",
						courts.length,
						" Sân tiêu chuẩn thi đấu"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", {
					style: {
						fontSize: 32,
						lineHeight: "40px",
						fontWeight: 800,
						maxWidth: 700,
						letterSpacing: -.4
					},
					children: "Tìm sân nhanh, xem giờ trống trực tiếp & giữ sân chỉ trong 1 phút"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "t14",
					style: {
						maxWidth: 720,
						color: "var(--brand-100)",
						lineHeight: "22.75px"
					},
					children: "Không cần gọi điện chờ đợi. Chọn khung giờ yêu thích trên bảng lịch, đặt cọc giữ chỗ 30% hoặc thanh toán trọn gói qua mã QR và nhận thông báo nhắc lịch trước giờ chơi."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "search-card",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							children: "Chi nhánh"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 16
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							className: "select",
							value: f.branch,
							onChange: (e) => setF({
								...f,
								branch: e.target.value
							}),
							children: branches.map((b) => /* @__PURE__ */ _jsxDEV("option", {
								value: b.id,
								children: b.name
							}, b.id, false, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 36
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							children: "Bộ môn thể thao"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 16
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							className: "select",
							value: f.sport,
							onChange: (e) => setF({
								...f,
								sport: e.target.value
							}),
							children: SPORTS.map((s) => /* @__PURE__ */ _jsxDEV("option", {
								value: s.key,
								children: [s.label, s.key === "pickleball" ? " (Sân mái che)" : ""]
							}, s.key, true, {
								fileName: _jsxFileName,
								lineNumber: 44,
								columnNumber: 34
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							children: "Ngày chơi"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 16
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							className: "input",
							type: "date",
							value: f.date,
							min: TODAY,
							onChange: (e) => setF({
								...f,
								date: e.target.value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							children: "Khung giờ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 16
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							className: "select",
							value: f.frame,
							onChange: (e) => setF({
								...f,
								frame: e.target.value
							}),
							children: FRAMES.map((x) => /* @__PURE__ */ _jsxDEV("option", { children: x }, x, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 34
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "btn btn-primary btn-lg",
							style: { height: 44 },
							onClick: search,
							children: "Tìm sân trống ngay →"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "row g8 wrap",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "t12 w700",
						style: { color: "var(--brand-100)" },
						children: "Bộ môn phổ biến:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 11
					}, this), SPORTS.map((s) => /* @__PURE__ */ _jsxDEV("button", {
						className: `sport-chip${f.sport === s.key ? " on" : ""}`,
						onClick: () => setF({
							...f,
							sport: s.key
						}),
						children: [
							s.emoji,
							" ",
							s.label,
							" (",
							count(s.key),
							" sân)"
						]
					}, s.key, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 13
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "col g12",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "row between",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "col g2",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "t18 w800 c-ink",
						children: "Mã ưu đãi dành cho bạn"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "t12 c-s600",
						children: "Dùng mã giảm giá ở bước đặt sân để tiết kiệm chi phí thuê sân."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: "link-btn",
					onClick: () => nav("/booking"),
					children: "Đặt sân & dùng mã →"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "row g16",
				style: { alignItems: "stretch" },
				children: pub.slice(0, 3).map((p, i) => /* @__PURE__ */ _jsxDEV("div", {
					className: `promo-card f1${i === 0 ? " first" : ""}`,
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between g12",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: `badge sq ${TONE[p.tone]}`,
								style: {
									padding: "2px 10px",
									fontSize: 11
								},
								children: p.tag
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "code-chip",
								children: p.code
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "t14 w800 c-ink",
							style: { marginTop: 4 },
							children: [p.percent === 10 ? "Giảm 10% tất cả khung giờ" : `Giảm ${p.percent}%${p.maxOff ? ` (Tối đa ${money(p.maxOff)})` : ""}`, p.fromHour === 11 && " khung 11:00 - 15:00"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "t12 c-s600",
							children: [
								p.scope,
								p.fromHour === 0 ? " & Mọi khung giờ" : p.fromHour !== 11 ? ` • Khung ${String(p.fromHour).padStart(2, "0")}:00 – ${String(p.toHour).padStart(2, "0")}:00` : "",
								" • HSD: ",
								toVN(p.end)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							style: { marginTop: "auto" },
							children: [/* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: "link-btn",
								onClick: () => go({ promo: p.code }),
								children: "Dùng ngay"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 15
						}, this)
					]
				}, p.code, true, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 65,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "grid12",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "span8 col g16",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "row between",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "t18 w800 c-ink",
						children: "Các cụm sân đang mở nhận lịch hôm nay"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "t12 w600 c-s600",
						children: "Tất cả giá hiển thị đã bao gồm đèn chiếu sáng"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "row wrap g16",
					style: { alignItems: "stretch" },
					children: CLUSTERS.map((c) => {
						const b = branches.find((x) => x.id === c.branch);
						const cs = courts.filter((x) => x.branchId === c.branch && x.sport === c.sport);
						const lo = Math.min(...cs.map((x) => x.priceNormal)), hi = Math.max(...cs.map((x) => x.pricePeak));
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "cluster",
							style: { width: "calc(50% - 8px)" },
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "cluster-body",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "row between",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: `badge sq ${TONE[b.tone]}`,
											style: {
												padding: "2px 10px",
												fontSize: 11
											},
											children: b.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 110,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "badge b-green-flat",
											style: {
												padding: "2px 10px",
												fontSize: 11
											},
											children: [
												"● Còn ",
												c.free,
												" khung giờ trống"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 111,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 109,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "t16 w800 c-ink",
										children: c.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 113,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "t12 c-s600",
										children: ["📍 ", b.address]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 114,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "row g24",
										style: { marginTop: 4 },
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "col",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "t11 c-s500",
												children: "Giờ mở cửa:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 116,
												columnNumber: 44
											}, this), /* @__PURE__ */ _jsxDEV("b", {
												className: "t12 c-ink w800",
												children: [
													b.open,
													" – ",
													b.close
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 116,
												columnNumber: 91
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 116,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "col",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "t11 c-s500",
												children: "Giá thuê sân:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 117,
												columnNumber: 44
											}, this), /* @__PURE__ */ _jsxDEV("b", {
												className: "t12 c-brand w800",
												children: [
													money(lo),
													" - ",
													money(hi),
													"/h"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 117,
												columnNumber: 93
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 117,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 115,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "cluster-foot",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: c.note }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									className: "btn btn-primary btn-sm",
									onClick: () => go({
										branch: c.branch,
										sport: c.sport,
										date: TODAY
									}),
									children: "Chọn giờ đặt"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 19
							}, this)]
						}, c.title, true, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				className: "span4 col g16",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "card col g12",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "row between",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "t14 w800 c-ink",
							children: "Hệ thống chi nhánh SportHub"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "t11 w700 c-brand",
							children: "Khu vực Hà Nội"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 13
					}, this), branches.map((b) => /* @__PURE__ */ _jsxDEV("button", {
						className: `branch-card${focusBranch === b.id ? " on" : ""}`,
						onClick: () => {
							setFocusBranch(b.id);
							setF((x) => ({
								...x,
								branch: b.id
							}));
						},
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "t12 w800 c-ink",
								children: ["📍 ", b.name]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 46
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "t12 w700 c-s800",
								children: [courts.filter((c) => c.branchId === b.id).length, " sân"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 97
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "t11 c-s600",
							style: { marginTop: 2 },
							children: [
								b.address.split(",")[0],
								" • SĐT: ",
								b.phone
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 17
						}, this)]
					}, b.id, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 15
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 131,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "card col g12",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "t14 w800 c-ink",
						children: "Hướng dẫn đặt lịch nhanh"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 13
					}, this), [
						["Chọn khung giờ trống:", "Nhấp trực tiếp vào ô giờ còn trống trên bảng lịch của cơ sở."],
						["Đặt cọc hoặc trả đủ:", "Quét mã VietQR để giữ sân ngay lập tức mà không cần chờ duyệt."],
						["Nhận sân đúng giờ:", "Hệ thống gửi thông báo nhắc lịch trước 1 tiếng. Lưu ý đơn hủy hoặc quá giờ không đến nhận sân sẽ không hoàn lại tiền cọc."]
					].map(([a, b], i) => /* @__PURE__ */ _jsxDEV("div", {
						className: "row g12",
						style: { alignItems: "flex-start" },
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "step-no",
							children: i + 1
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "t12 c-s700",
							style: { lineHeight: "19px" },
							children: [
								/* @__PURE__ */ _jsxDEV("b", {
									className: "c-ink",
									children: a
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 74
								}, this),
								" ",
								b
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 152,
							columnNumber: 17
						}, this)]
					}, a, true, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 15
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 130,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
}
_s(Home, "5vIULqCJxewiQRw6uyZ+k4lgjnc=", false, function() {
	return [useApp, useNavigate];
});
_c = Home;
var _c;
$RefreshReg$(_c, "Home");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Home.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/Home.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/Home.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/Home.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxRQUFRLE9BQU8sTUFBTSxhQUFhO0FBRTNDLFNBQVMsY0FBYzs7OztBQUV2QixNQUFNLFNBQVM7Q0FBQztDQUE2QjtDQUE2QjtDQUE4QjtBQUEwQjtBQUNsSSxNQUFNLFdBQVc7Q0FDZjtFQUFFLFFBQVE7RUFBTyxPQUFPO0VBQTBCLE1BQU07RUFBRyxPQUFPO0VBQXNDLE1BQU07Q0FBdUM7Q0FDcko7RUFBRSxRQUFRO0VBQU8sT0FBTztFQUF3QixNQUFNO0VBQUcsT0FBTztFQUEwQyxNQUFNO0NBQTJDO0NBQzNKO0VBQUUsUUFBUTtFQUFPLE9BQU87RUFBeUIsTUFBTTtFQUFHLE9BQU87RUFBeUMsTUFBTTtDQUE0QztDQUM1SjtFQUFFLFFBQVE7RUFBTyxPQUFPO0VBQXNCLE1BQU07RUFBRyxPQUFPO0VBQTBDLE1BQU07Q0FBNEM7QUFDNUo7QUFDQSxNQUFNLE9BQU87Q0FBRSxPQUFPO0NBQVcsS0FBSztDQUFTLFFBQVE7Q0FBWSxPQUFPO0FBQVU7QUFFcEYsZUFBZSxTQUFTLE9BQU87O0NBQzdCLE1BQU0sRUFBRSxRQUFRLFFBQVEsYUFBYSxPQUFPO0NBQzVDLE1BQU0sTUFBTSxZQUFZO0NBQ3hCLE1BQU0sQ0FBQyxHQUFHLFFBQVEsU0FBUztFQUFFLFFBQVE7RUFBTyxPQUFPO0VBQTBCLE1BQU07RUFBTyxPQUFPLE9BQU87Q0FBRyxDQUFDO0NBQzVHLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxTQUFTLE1BQWdCLE9BQU8sUUFBUSxNQUFNLEVBQUUsVUFBVSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7Q0FDL0UsTUFBTSxNQUFNLE1BQThCLElBQUksWUFBWSxJQUFJLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUc7Q0FDN0YsTUFBTSxlQUFlLEdBQUc7RUFBRSxRQUFRLEVBQUU7RUFBUSxPQUFPLEVBQUU7RUFBTyxNQUFNLEVBQUU7RUFBTSxPQUFPLEVBQUU7Q0FBTSxDQUFDO0NBQzFGLE1BQU0sTUFBTSxPQUFPLFFBQVEsTUFBTSxDQUFDLEVBQUUsV0FBVztDQUUvQyxPQUNFO0VBRUUsd0JBQUMsV0FBRDtHQUFTLFdBQVU7R0FBZSxPQUFPLEVBQUUsU0FBUyxpQkFBaUI7YUFBckU7SUFDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtLQUFRLE9BQU87TUFBRSxXQUFXO01BQWMsWUFBWTtNQUFxQixRQUFRO01BQWlDLE9BQU87S0FBbUI7ZUFBOUo7TUFBaUs7TUFDbkosU0FBUztNQUFPO01BQWMsT0FBTztNQUFPO0tBQ3BEOzs7Ozs7SUFDTix3QkFBQyxNQUFEO0tBQUksT0FBTztNQUFFLFVBQVU7TUFBSSxZQUFZO01BQVEsWUFBWTtNQUFLLFVBQVU7TUFBSyxlQUFlLENBQUM7S0FBSTtlQUFHO0lBQXFFOzs7OztJQUMzSyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtLQUFNLE9BQU87TUFBRSxVQUFVO01BQUssT0FBTztNQUFvQixZQUFZO0tBQVU7ZUFBRztJQUU1Rjs7Ozs7SUFDSCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFRO01BQWdCOzs7O2dCQUM1Qyx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFTLE9BQU8sRUFBRTtPQUFRLFdBQVcsTUFBTSxLQUFLO1FBQUUsR0FBRztRQUFHLFFBQVEsRUFBRSxPQUFPO09BQU0sQ0FBQztpQkFDL0YsU0FBUyxLQUFLLE1BQU0sd0JBQUMsVUFBRDtRQUFtQixPQUFPLEVBQUU7a0JBQUssRUFBRTtPQUFhLEdBQW5DLEVBQUU7Ozs7Y0FBaUMsQ0FBQztNQUNoRTs7OztjQUFNOzs7OztNQUNoQix3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQVE7TUFBc0I7Ozs7Z0JBQ2xELHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQVMsT0FBTyxFQUFFO09BQU8sV0FBVyxNQUFNLEtBQUs7UUFBRSxHQUFHO1FBQUcsT0FBTyxFQUFFLE9BQU87T0FBa0IsQ0FBQztpQkFDekcsT0FBTyxLQUFLLE1BQU0sd0JBQUMsVUFBRDtRQUFvQixPQUFPLEVBQUU7a0JBQTdCLENBQW1DLEVBQUUsT0FBTyxFQUFFLFFBQVEsZUFBZSxtQkFBbUIsRUFBVztVQUF0RixFQUFFOzs7O2NBQW9GLENBQUM7TUFDakg7Ozs7Y0FBTTs7Ozs7TUFDaEIsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFRO01BQWdCOzs7O2dCQUM1Qyx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFRLE1BQUs7T0FBTyxPQUFPLEVBQUU7T0FBTSxLQUFLO09BQU8sV0FBVyxNQUFNLEtBQUs7UUFBRSxHQUFHO1FBQUcsTUFBTSxFQUFFLE9BQU87T0FBTSxDQUFDO01BQUk7Ozs7Y0FBTTs7Ozs7TUFDaEksd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFRO01BQWdCOzs7O2dCQUM1Qyx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFTLE9BQU8sRUFBRTtPQUFPLFdBQVcsTUFBTSxLQUFLO1FBQUUsR0FBRztRQUFHLE9BQU8sRUFBRSxPQUFPO09BQU0sQ0FBQztpQkFDN0YsT0FBTyxLQUFLLE1BQU0sd0JBQUMsVUFBRCxZQUFpQixFQUFVLEdBQWQ7Ozs7Y0FBYyxDQUFDO01BQ3pDOzs7O2NBQU07Ozs7O01BQ2hCLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQXlCLE9BQU8sRUFBRSxRQUFRLEdBQUc7T0FBRyxTQUFTO2lCQUFRO01BQTRCOzs7OztLQUM1Rzs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQVcsT0FBTyxFQUFFLE9BQU8sbUJBQW1CO2dCQUFHO0tBQXNCOzs7O2VBQ3RGLE9BQU8sS0FBSyxNQUNYLHdCQUFDLFVBQUQ7TUFBb0IsV0FBVyxhQUFhLEVBQUUsVUFBVSxFQUFFLE1BQU0sUUFBUTtNQUFNLGVBQWUsS0FBSztPQUFFLEdBQUc7T0FBRyxPQUFPLEVBQUU7TUFBSSxDQUFDO2dCQUF4SDtPQUNHLEVBQUU7T0FBTTtPQUFFLEVBQUU7T0FBTTtPQUFHLE1BQU0sRUFBRSxHQUFHO09BQUU7TUFDN0I7UUFGSyxFQUFFOzs7O1lBRVAsQ0FDVCxDQUNFOzs7Ozs7R0FDRTs7Ozs7O0VBR1Qsd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkIsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFpQjtLQUEwQjs7OztlQUN6RCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYTtLQUFpRTs7OzthQUN4Rjs7Ozs7Y0FDTCx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFXLGVBQWUsSUFBSSxVQUFVO2VBQUc7SUFBMkI7Ozs7WUFDckY7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBVSxPQUFPLEVBQUUsWUFBWSxVQUFVO2NBQ3JELElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUN2Qix3QkFBQyxPQUFEO0tBQWtCLFdBQVcsZ0JBQWdCLE1BQU0sSUFBSSxXQUFXO2VBQWxFO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVyxZQUFZLEtBQUssRUFBRTtRQUFTLE9BQU87U0FBRSxTQUFTO1NBQVksVUFBVTtRQUFHO2tCQUFJLEVBQUU7T0FBVTs7OztpQkFDeEcsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWEsRUFBRTtPQUFXOzs7O2VBQ3ZDOzs7Ozs7TUFDTCx3QkFBQyxNQUFEO09BQUksV0FBVTtPQUFpQixPQUFPLEVBQUUsV0FBVyxFQUFFO2lCQUFyRCxDQUNHLEVBQUUsWUFBWSxLQUFLLDhCQUE4QixRQUFRLEVBQUUsUUFBUSxHQUFHLEVBQUUsU0FBUyxZQUFZLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxNQUNsSCxFQUFFLGFBQWEsTUFBTSxzQkFDcEI7Ozs7OztNQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQTJCLEVBQUU7UUFBTyxFQUFFLGFBQWEsSUFBSSxxQkFBcUIsRUFBRSxhQUFhLEtBQUssWUFBWSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRSxRQUFRLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRyxFQUFFLE9BQU87UUFBRztRQUFTLEtBQUssRUFBRSxHQUFHO09BQUs7Ozs7OztNQUM1Tix3QkFBQyxPQUFEO09BQUssV0FBVTtPQUFjLE9BQU8sRUFBRSxXQUFXLE9BQU87aUJBQXhELENBQ0Usd0JBQUMsUUFBRCxDQUFPOzs7O2lCQUNQLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQVcsZUFBZSxHQUFHLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQztrQkFBRztPQUFpQjs7OztlQUNqRjs7Ozs7O0tBQ0Y7T0FkSyxFQUFFOzs7O1dBY1AsQ0FDTjtHQUNFOzs7O1dBQ0U7Ozs7OztFQUdULHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBaUI7S0FBeUM7Ozs7ZUFDeEUsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWtCO0tBQW1EOzs7O2FBQ2xGOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWUsT0FBTyxFQUFFLFlBQVksVUFBVTtlQUMxRCxTQUFTLEtBQUssTUFBTTtNQUNuQixNQUFNLElBQUksU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTTtNQUNoRCxNQUFNLEtBQUssT0FBTyxRQUFRLE1BQU0sRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxLQUFLO01BQzlFLE1BQU0sS0FBSyxLQUFLLElBQUksR0FBRyxHQUFHLEtBQUssTUFBTSxFQUFFLFdBQVcsQ0FBQyxHQUFHLEtBQUssS0FBSyxJQUFJLEdBQUcsR0FBRyxLQUFLLE1BQU0sRUFBRSxTQUFTLENBQUM7TUFDakcsT0FDRSx3QkFBQyxPQUFEO09BQW1CLFdBQVU7T0FBVSxPQUFPLEVBQUUsT0FBTyxrQkFBa0I7aUJBQXpFLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFXLFlBQVksS0FBSyxFQUFFO1dBQVMsT0FBTztZQUFFLFNBQVM7WUFBWSxVQUFVO1dBQUc7cUJBQUksRUFBRTtVQUFXOzs7O29CQUN6Ryx3QkFBQyxRQUFEO1dBQU0sV0FBVTtXQUFxQixPQUFPO1lBQUUsU0FBUztZQUFZLFVBQVU7V0FBRztxQkFBaEY7WUFBbUY7WUFBTyxFQUFFO1lBQUs7V0FBc0I7Ozs7O2tCQUNwSDs7Ozs7O1NBQ0wsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWtCLEVBQUU7U0FBVTs7Ozs7U0FDNUMsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWIsQ0FBMEIsT0FBSSxFQUFFLE9BQVc7Ozs7OztTQUMzQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtVQUFVLE9BQU8sRUFBRSxXQUFXLEVBQUU7b0JBQS9DLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FBcUIsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWE7V0FBaUI7Ozs7cUJBQUMsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQWI7YUFBK0IsRUFBRTthQUFLO2FBQUksRUFBRTtZQUFTOzs7OzttQkFBTTs7Ozs7b0JBQy9ILHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQXFCLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFhO1dBQW1COzs7O3FCQUFDLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFiO2FBQWlDLE1BQU0sRUFBRTthQUFFO2FBQUksTUFBTSxFQUFFO2FBQUU7WUFBSzs7Ozs7bUJBQU07Ozs7O2tCQUN2STs7Ozs7O1FBQ0Y7Ozs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFPLEVBQUUsS0FBVzs7OztrQkFDcEIsd0JBQUMsVUFBRDtTQUFRLFdBQVU7U0FBeUIsZUFBZSxHQUFHO1VBQUUsUUFBUSxFQUFFO1VBQVEsT0FBTyxFQUFFO1VBQU8sTUFBTTtTQUFNLENBQUM7bUJBQUc7UUFBb0I7Ozs7Z0JBQ2xJOzs7OztlQUNGO1NBakJLLEVBQUU7Ozs7YUFpQlA7S0FFVCxDQUFDO0lBQ0U7Ozs7WUFDRjs7Ozs7YUFFTCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFpQjtNQUErQjs7OztnQkFDOUQsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW1CO01BQW9COzs7O2NBQ3BEOzs7OztlQUNKLFNBQVMsS0FBSyxNQUNiLHdCQUFDLFVBQUQ7TUFBbUIsV0FBVyxjQUFjLGdCQUFnQixFQUFFLEtBQUssUUFBUTtNQUFNLGVBQWU7T0FBRSxlQUFlLEVBQUUsRUFBRTtPQUFHLE1BQU0sT0FBTztRQUFFLEdBQUc7UUFBRyxRQUFRLEVBQUU7T0FBRyxFQUFFO01BQUU7Z0JBQTlKLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBNkIsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQWlDLE9BQUksRUFBRSxJQUFXOzs7OztpQkFBQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FBbUMsT0FBTyxRQUFRLE1BQU0sRUFBRSxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBTyxNQUFVOzs7OztlQUFNOzs7OztnQkFDcEwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBYSxPQUFPLEVBQUUsV0FBVyxFQUFFO2lCQUFsRDtRQUFzRCxFQUFFLFFBQVEsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUFHO1FBQVMsRUFBRTtPQUFXOzs7OztjQUM5RjtRQUhLLEVBQUU7Ozs7WUFHUCxDQUNULENBQ0U7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFpQjtLQUE0Qjs7OztlQUMxRDtNQUNDLENBQUMseUJBQXlCLDhEQUE4RDtNQUN4RixDQUFDLHdCQUF3QixnRUFBZ0U7TUFDekYsQ0FBQyxzQkFBc0IsMkhBQTJIO0tBQ3BKLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLE1BQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBa0IsT0FBTyxFQUFFLFlBQVksYUFBYTtnQkFBbkUsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBVyxJQUFJO01BQVE7Ozs7Z0JBQ3ZDLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO09BQWEsT0FBTyxFQUFFLFlBQVksT0FBTztpQkFBdEQ7UUFBeUQsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQVM7UUFBSzs7Ozs7UUFBQztRQUFFO09BQUs7Ozs7O2NBQ3pGO1FBSHlCOzs7O1lBR3pCLENBQ04sQ0FDRTs7Ozs7WUFDQTs7Ozs7V0FDQTs7Ozs7O0NBQ1Q7Ozs7O0FBRU4iLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSG9tZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IFNQT1JUUywgVE9EQVksIHRvVk4sIG1vbmV5IH0gZnJvbSAnLi4vZGF0YSdcbmltcG9ydCB0eXBlIHsgU3BvcnRLZXkgfSBmcm9tICcuLi9kYXRhJ1xuaW1wb3J0IHsgdXNlQXBwIH0gZnJvbSAnLi4vc3RvcmUnXG5cbmNvbnN0IEZSQU1FUyA9IFsnQnXhu5VpIHPDoW5nICgwNTowMCAtIDExOjAwKScsICdCdeG7lWkgdHLGsGEgKDExOjAwIC0gMTU6MDApJywgJ0J14buVaSBjaGnhu4F1ICgxNTowMCAtIDE3OjMwKScsICdCdeG7lWkgdOG7kWkgKDE3OjMwIC0gMjI6MDApJ11cbmNvbnN0IENMVVNURVJTID0gW1xuICB7IGJyYW5jaDogJ2NzMScsIHNwb3J0OiAncGlja2xlYmFsbCcgYXMgU3BvcnRLZXksIGZyZWU6IDUsIHRpdGxlOiAnQ+G7pW0gU8OibiBQaWNrbGViYWxsIE3DoWkgQ2hlIDAxIC0gMDMnLCBub3RlOiAnVGjhuqNtIHRpw6p1IGNodeG6qW4gdGhpIMSR4bqldSwgbcOhaSBjaGUga8OtbicgfSxcbiAgeyBicmFuY2g6ICdjczEnLCBzcG9ydDogJ2Zvb3RiYWxsJyBhcyBTcG9ydEtleSwgZnJlZTogMywgdGl0bGU6ICdTw6JuIELDs25nIMSRw6EgTWluaSAwMSAtIDAyIChTw6JuIDcgbmfGsOG7nWkpJywgbm90ZTogJ0Phu48gbmjDom4gdOG6oW8gbeG7m2ksIGjhu5cgdHLhu6MgdMOsbSDEkeG7kWkgZ2lhbyBo4buvdScgfSxcbiAgeyBicmFuY2g6ICdjczInLCBzcG9ydDogJ2JhZG1pbnRvbicgYXMgU3BvcnRLZXksIGZyZWU6IDYsIHRpdGxlOiAnTmjDoCBUaGkgxJDhuqV1IEPhuqd1IEzDtG5nIFRo4bqjbSBQVkMgMDEgLSAwNScsIG5vdGU6ICdUcuG6p24gY2FvIDEwbSwga8OtbiBnacOzLCDDoW5oIHPDoW5nIGNo4buRbmcgbMOzYScgfSxcbiAgeyBicmFuY2g6ICdjczMnLCBzcG9ydDogJ3Rlbm5pcycgYXMgU3BvcnRLZXksIGZyZWU6IDQsIHRpdGxlOiAnVOG7lSBo4bujcCBTw6JuIFRlbm5pcyAmIELDs25nIHLhu5UgTmdvw6BpIHRy4budaScsIG5vdGU6ICdDw7MgYsOjaSDEkeG7lyB4ZSDDtCB0w7QgbWnhu4VuIHBow60sIHThu6cgxJHhu5MgY8OhIG5ow6JuJyB9LFxuXVxuY29uc3QgVE9ORSA9IHsgZ3JlZW46ICdiLWdyZWVuJywgc2t5OiAnYi1za3knLCBpbmRpZ286ICdiLWluZGlnbycsIGFtYmVyOiAnYi1hbWJlcicgfSBhcyBjb25zdFxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuICBjb25zdCB7IGNvdXJ0cywgcHJvbW9zLCBicmFuY2hlcyB9ID0gdXNlQXBwKClcbiAgY29uc3QgbmF2ID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBbZiwgc2V0Rl0gPSB1c2VTdGF0ZSh7IGJyYW5jaDogJ2NzMScsIHNwb3J0OiAncGlja2xlYmFsbCcgYXMgU3BvcnRLZXksIGRhdGU6IFRPREFZLCBmcmFtZTogRlJBTUVTWzNdIH0pXG4gIGNvbnN0IFtmb2N1c0JyYW5jaCwgc2V0Rm9jdXNCcmFuY2hdID0gdXNlU3RhdGUoJ2NzMScpXG4gIGNvbnN0IGNvdW50ID0gKGs6IFNwb3J0S2V5KSA9PiBjb3VydHMuZmlsdGVyKChjKSA9PiBjLnNwb3J0ID09PSBrICYmIGMuYWN0aXZlKS5sZW5ndGhcbiAgY29uc3QgZ28gPSAocDogUmVjb3JkPHN0cmluZywgc3RyaW5nPikgPT4gbmF2KGAvYm9va2luZz8ke25ldyBVUkxTZWFyY2hQYXJhbXMocCkudG9TdHJpbmcoKX1gKVxuICBjb25zdCBzZWFyY2ggPSAoKSA9PiBnbyh7IGJyYW5jaDogZi5icmFuY2gsIHNwb3J0OiBmLnNwb3J0LCBkYXRlOiBmLmRhdGUsIGZyYW1lOiBmLmZyYW1lIH0pXG4gIGNvbnN0IHB1YiA9IHByb21vcy5maWx0ZXIoKHApID0+ICFwLmNvdW50ZXJPbmx5KVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHsvKiBIZXJvICsga2h1bmcgdMOsbSBraeG6v20gKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJoZXJvIGNvbCBnMjBcIiBzdHlsZT17eyBwYWRkaW5nOiAnMzJweCAzMnB4IDI4cHgnIH19PlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZVwiIHN0eWxlPXt7IGFsaWduU2VsZjogJ2ZsZXgtc3RhcnQnLCBiYWNrZ3JvdW5kOiAncmdiYSg0LDEyMCw4NywuOCknLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSgxNiwxODUsMTI5LC40KScsIGNvbG9yOiAndmFyKC0tYnJhbmQtMTAwKScgfX0+XG4gICAgICAgICAg4pqhIEjhu4cgdGjhu5FuZyB7YnJhbmNoZXMubGVuZ3RofSBDaGkgbmjDoW5oIOKAoiB7Y291cnRzLmxlbmd0aH0gU8OibiB0acOqdSBjaHXhuqluIHRoaSDEkeG6pXVcbiAgICAgICAgPC9zcGFuPlxuICAgICAgICA8aDEgc3R5bGU9e3sgZm9udFNpemU6IDMyLCBsaW5lSGVpZ2h0OiAnNDBweCcsIGZvbnRXZWlnaHQ6IDgwMCwgbWF4V2lkdGg6IDcwMCwgbGV0dGVyU3BhY2luZzogLTAuNCB9fT5Uw6xtIHPDom4gbmhhbmgsIHhlbSBnaeG7nSB0cuG7kW5nIHRy4buxYyB0aeG6v3AgJiBnaeG7ryBzw6JuIGNo4buJIHRyb25nIDEgcGjDunQ8L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0MTRcIiBzdHlsZT17eyBtYXhXaWR0aDogNzIwLCBjb2xvcjogJ3ZhcigtLWJyYW5kLTEwMCknLCBsaW5lSGVpZ2h0OiAnMjIuNzVweCcgfX0+XG4gICAgICAgICAgS2jDtG5nIGPhuqduIGfhu41pIMSRaeG7h24gY2jhu50gxJHhu6NpLiBDaOG7jW4ga2h1bmcgZ2nhu50gecOqdSB0aMOtY2ggdHLDqm4gYuG6o25nIGzhu4tjaCwgxJHhurd0IGPhu41jIGdp4buvIGNo4buXIDMwJSBob+G6t2MgdGhhbmggdG/DoW4gdHLhu41uIGfDs2kgcXVhIG3DoyBRUiB2w6Agbmjhuq1uIHRow7RuZyBiw6FvIG5o4bqvYyBs4buLY2ggdHLGsOG7m2MgZ2nhu50gY2jGoWkuXG4gICAgICAgIDwvcD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWFyY2gtY2FyZFwiPlxuICAgICAgICAgIDxkaXY+PGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCI+Q2hpIG5ow6FuaDwvbGFiZWw+XG4gICAgICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cInNlbGVjdFwiIHZhbHVlPXtmLmJyYW5jaH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGKHsgLi4uZiwgYnJhbmNoOiBlLnRhcmdldC52YWx1ZSB9KX0+XG4gICAgICAgICAgICAgIHticmFuY2hlcy5tYXAoKGIpID0+IDxvcHRpb24ga2V5PXtiLmlkfSB2YWx1ZT17Yi5pZH0+e2IubmFtZX08L29wdGlvbj4pfVxuICAgICAgICAgICAgPC9zZWxlY3Q+PC9kaXY+XG4gICAgICAgICAgPGRpdj48bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIj5C4buZIG3DtG4gdGjhu4MgdGhhbzwvbGFiZWw+XG4gICAgICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cInNlbGVjdFwiIHZhbHVlPXtmLnNwb3J0fSBvbkNoYW5nZT17KGUpID0+IHNldEYoeyAuLi5mLCBzcG9ydDogZS50YXJnZXQudmFsdWUgYXMgU3BvcnRLZXkgfSl9PlxuICAgICAgICAgICAgICB7U1BPUlRTLm1hcCgocykgPT4gPG9wdGlvbiBrZXk9e3Mua2V5fSB2YWx1ZT17cy5rZXl9PntzLmxhYmVsfXtzLmtleSA9PT0gJ3BpY2tsZWJhbGwnID8gJyAoU8OibiBtw6FpIGNoZSknIDogJyd9PC9vcHRpb24+KX1cbiAgICAgICAgICAgIDwvc2VsZWN0PjwvZGl2PlxuICAgICAgICAgIDxkaXY+PGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCI+TmfDoHkgY2jGoWk8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IGNsYXNzTmFtZT1cImlucHV0XCIgdHlwZT1cImRhdGVcIiB2YWx1ZT17Zi5kYXRlfSBtaW49e1RPREFZfSBvbkNoYW5nZT17KGUpID0+IHNldEYoeyAuLi5mLCBkYXRlOiBlLnRhcmdldC52YWx1ZSB9KX0gLz48L2Rpdj5cbiAgICAgICAgICA8ZGl2PjxsYWJlbCBjbGFzc05hbWU9XCJsYWJlbFwiPktodW5nIGdp4budPC9sYWJlbD5cbiAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwic2VsZWN0XCIgdmFsdWU9e2YuZnJhbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rih7IC4uLmYsIGZyYW1lOiBlLnRhcmdldC52YWx1ZSB9KX0+XG4gICAgICAgICAgICAgIHtGUkFNRVMubWFwKCh4KSA9PiA8b3B0aW9uIGtleT17eH0+e3h9PC9vcHRpb24+KX1cbiAgICAgICAgICAgIDwvc2VsZWN0PjwvZGl2PlxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1sZ1wiIHN0eWxlPXt7IGhlaWdodDogNDQgfX0gb25DbGljaz17c2VhcmNofT5Uw6xtIHPDom4gdHLhu5FuZyBuZ2F5IOKGkjwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzggd3JhcFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NzAwXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1icmFuZC0xMDApJyB9fT5C4buZIG3DtG4gcGjhu5UgYmnhur9uOjwvc3Bhbj5cbiAgICAgICAgICB7U1BPUlRTLm1hcCgocykgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e3Mua2V5fSBjbGFzc05hbWU9e2BzcG9ydC1jaGlwJHtmLnNwb3J0ID09PSBzLmtleSA/ICcgb24nIDogJyd9YH0gb25DbGljaz17KCkgPT4gc2V0Rih7IC4uLmYsIHNwb3J0OiBzLmtleSB9KX0+XG4gICAgICAgICAgICAgIHtzLmVtb2ppfSB7cy5sYWJlbH0gKHtjb3VudChzLmtleSl9IHPDom4pXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiBLaHV54bq/biBtw6NpICovfVxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY29sIGcxMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzJcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0MTggdzgwMCBjLWlua1wiPk3DoyDGsHUgxJHDo2kgZMOgbmggY2hvIGLhuqFuPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj5Ew7luZyBtw6MgZ2nhuqNtIGdpw6Eg4bufIGLGsOG7m2MgxJHhurd0IHPDom4gxJHhu4MgdGnhur90IGtp4buHbSBjaGkgcGjDrSB0aHXDqiBzw6JuLjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImxpbmstYnRuXCIgb25DbGljaz17KCkgPT4gbmF2KCcvYm9va2luZycpfT7EkOG6t3Qgc8OibiAmIGTDuW5nIG3DoyDihpI8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGcxNlwiIHN0eWxlPXt7IGFsaWduSXRlbXM6ICdzdHJldGNoJyB9fT5cbiAgICAgICAgICB7cHViLnNsaWNlKDAsIDMpLm1hcCgocCwgaSkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e3AuY29kZX0gY2xhc3NOYW1lPXtgcHJvbW8tY2FyZCBmMSR7aSA9PT0gMCA/ICcgZmlyc3QnIDogJyd9YH0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gZzEyXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgYmFkZ2Ugc3EgJHtUT05FW3AudG9uZV19YH0gc3R5bGU9e3sgcGFkZGluZzogJzJweCAxMHB4JywgZm9udFNpemU6IDExIH19PntwLnRhZ308L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29kZS1jaGlwXCI+e3AuY29kZX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidDE0IHc4MDAgYy1pbmtcIiBzdHlsZT17eyBtYXJnaW5Ub3A6IDQgfX0+XG4gICAgICAgICAgICAgICAge3AucGVyY2VudCA9PT0gMTAgPyAnR2nhuqNtIDEwJSB04bqldCBj4bqjIGtodW5nIGdp4budJyA6IGBHaeG6o20gJHtwLnBlcmNlbnR9JSR7cC5tYXhPZmYgPyBgIChU4buRaSDEkWEgJHttb25leShwLm1heE9mZil9KWAgOiAnJ31gfVxuICAgICAgICAgICAgICAgIHtwLmZyb21Ib3VyID09PSAxMSAmJiAnIGtodW5nIDExOjAwIC0gMTU6MDAnfVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0MTIgYy1zNjAwXCI+e3Auc2NvcGV9e3AuZnJvbUhvdXIgPT09IDAgPyAnICYgTeG7jWkga2h1bmcgZ2nhu50nIDogcC5mcm9tSG91ciAhPT0gMTEgPyBgIOKAoiBLaHVuZyAke1N0cmluZyhwLmZyb21Ib3VyKS5wYWRTdGFydCgyLCAnMCcpfTowMCDigJMgJHtTdHJpbmcocC50b0hvdXIpLnBhZFN0YXJ0KDIsICcwJyl9OjAwYCA6ICcnfSDigKIgSFNEOiB7dG9WTihwLmVuZCl9PC9wPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuXCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAnYXV0bycgfX0+XG4gICAgICAgICAgICAgICAgPHNwYW4gLz5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImxpbmstYnRuXCIgb25DbGljaz17KCkgPT4gZ28oeyBwcm9tbzogcC5jb2RlIH0pfT5Ew7luZyBuZ2F5PC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogQ+G7pW0gc8OibiAmIGNoaSBuaMOhbmggKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJncmlkMTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFuOCBjb2wgZzE2XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlblwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInQxOCB3ODAwIGMtaW5rXCI+Q8OhYyBj4bulbSBzw6JuIMSRYW5nIG3hu58gbmjhuq1uIGzhu4tjaCBow7RtIG5heTwvaDI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0MTIgdzYwMCBjLXM2MDBcIj5U4bqldCBj4bqjIGdpw6EgaGnhu4NuIHRo4buLIMSRw6MgYmFvIGfhu5NtIMSRw6huIGNoaeG6v3Ugc8Ohbmc8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgd3JhcCBnMTZcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiAnc3RyZXRjaCcgfX0+XG4gICAgICAgICAgICB7Q0xVU1RFUlMubWFwKChjKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGIgPSBicmFuY2hlcy5maW5kKCh4KSA9PiB4LmlkID09PSBjLmJyYW5jaCkhXG4gICAgICAgICAgICAgIGNvbnN0IGNzID0gY291cnRzLmZpbHRlcigoeCkgPT4geC5icmFuY2hJZCA9PT0gYy5icmFuY2ggJiYgeC5zcG9ydCA9PT0gYy5zcG9ydClcbiAgICAgICAgICAgICAgY29uc3QgbG8gPSBNYXRoLm1pbiguLi5jcy5tYXAoKHgpID0+IHgucHJpY2VOb3JtYWwpKSwgaGkgPSBNYXRoLm1heCguLi5jcy5tYXAoKHgpID0+IHgucHJpY2VQZWFrKSlcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17Yy50aXRsZX0gY2xhc3NOYW1lPVwiY2x1c3RlclwiIHN0eWxlPXt7IHdpZHRoOiAnY2FsYyg1MCUgLSA4cHgpJyB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2x1c3Rlci1ib2R5XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BiYWRnZSBzcSAke1RPTkVbYi50b25lXX1gfSBzdHlsZT17eyBwYWRkaW5nOiAnMnB4IDEwcHgnLCBmb250U2l6ZTogMTEgfX0+e2IubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYi1ncmVlbi1mbGF0XCIgc3R5bGU9e3sgcGFkZGluZzogJzJweCAxMHB4JywgZm9udFNpemU6IDExIH19PuKXjyBDw7JuIHtjLmZyZWV9IGtodW5nIGdp4budIHRy4buRbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidDE2IHc4MDAgYy1pbmtcIj57Yy50aXRsZX08L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0MTIgYy1zNjAwXCI+8J+TjSB7Yi5hZGRyZXNzfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzI0XCIgc3R5bGU9e3sgbWFyZ2luVG9wOiA0IH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sXCI+PHNwYW4gY2xhc3NOYW1lPVwidDExIGMtczUwMFwiPkdp4budIG3hu58gY+G7rWE6PC9zcGFuPjxiIGNsYXNzTmFtZT1cInQxMiBjLWluayB3ODAwXCI+e2Iub3Blbn0g4oCTIHtiLmNsb3NlfTwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbFwiPjxzcGFuIGNsYXNzTmFtZT1cInQxMSBjLXM1MDBcIj5HacOhIHRodcOqIHPDom46PC9zcGFuPjxiIGNsYXNzTmFtZT1cInQxMiBjLWJyYW5kIHc4MDBcIj57bW9uZXkobG8pfSAtIHttb25leShoaSl9L2g8L2I+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNsdXN0ZXItZm9vdFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Yy5ub3RlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLXNtXCIgb25DbGljaz17KCkgPT4gZ28oeyBicmFuY2g6IGMuYnJhbmNoLCBzcG9ydDogYy5zcG9ydCwgZGF0ZTogVE9EQVkgfSl9PkNo4buNbiBnaeG7nSDEkeG6t3Q8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInNwYW40IGNvbCBnMTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgY29sIGcxMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidDE0IHc4MDAgYy1pbmtcIj5I4buHIHRo4buRbmcgY2hpIG5ow6FuaCBTcG9ydEh1YjwvaDM+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMSB3NzAwIGMtYnJhbmRcIj5LaHUgduG7sWMgSMOgIE7hu5lpPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7YnJhbmNoZXMubWFwKChiKSA9PiAoXG4gICAgICAgICAgICAgIDxidXR0b24ga2V5PXtiLmlkfSBjbGFzc05hbWU9e2BicmFuY2gtY2FyZCR7Zm9jdXNCcmFuY2ggPT09IGIuaWQgPyAnIG9uJyA6ICcnfWB9IG9uQ2xpY2s9eygpID0+IHsgc2V0Rm9jdXNCcmFuY2goYi5pZCk7IHNldEYoKHgpID0+ICh7IC4uLngsIGJyYW5jaDogYi5pZCB9KSkgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlblwiPjxzcGFuIGNsYXNzTmFtZT1cInQxMiB3ODAwIGMtaW5rXCI+8J+TjSB7Yi5uYW1lfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJ0MTIgdzcwMCBjLXM4MDBcIj57Y291cnRzLmZpbHRlcigoYykgPT4gYy5icmFuY2hJZCA9PT0gYi5pZCkubGVuZ3RofSBzw6JuPC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidDExIGMtczYwMFwiIHN0eWxlPXt7IG1hcmdpblRvcDogMiB9fT57Yi5hZGRyZXNzLnNwbGl0KCcsJylbMF19IOKAoiBTxJBUOiB7Yi5waG9uZX08L2Rpdj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgY29sIGcxMlwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInQxNCB3ODAwIGMtaW5rXCI+SMaw4bubbmcgZOG6q24gxJHhurd0IGzhu4tjaCBuaGFuaDwvaDM+XG4gICAgICAgICAgICB7W1xuICAgICAgICAgICAgICBbJ0No4buNbiBraHVuZyBnaeG7nSB0cuG7kW5nOicsICdOaOG6pXAgdHLhu7FjIHRp4bq/cCB2w6BvIMO0IGdp4budIGPDsm4gdHLhu5FuZyB0csOqbiBi4bqjbmcgbOG7i2NoIGPhu6dhIGPGoSBz4bufLiddLFxuICAgICAgICAgICAgICBbJ8SQ4bq3dCBj4buNYyBob+G6t2MgdHLhuqMgxJHhu6c6JywgJ1F1w6l0IG3DoyBWaWV0UVIgxJHhu4MgZ2nhu68gc8OibiBuZ2F5IGzhuq1wIHThu6ljIG3DoCBraMO0bmcgY+G6p24gY2jhu50gZHV54buHdC4nXSxcbiAgICAgICAgICAgICAgWydOaOG6rW4gc8OibiDEkcO6bmcgZ2nhu506JywgJ0jhu4cgdGjhu5FuZyBn4butaSB0aMO0bmcgYsOhbyBuaOG6r2MgbOG7i2NoIHRyxrDhu5tjIDEgdGnhur9uZy4gTMawdSDDvSDEkcahbiBo4buneSBob+G6t2MgcXXDoSBnaeG7nSBraMO0bmcgxJHhur9uIG5o4bqtbiBzw6JuIHPhur0ga2jDtG5nIGhvw6BuIGzhuqFpIHRp4buBbiBj4buNYy4nXSxcbiAgICAgICAgICAgIF0ubWFwKChbYSwgYl0sIGkpID0+IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzEyXCIga2V5PXthfSBzdHlsZT17eyBhbGlnbkl0ZW1zOiAnZmxleC1zdGFydCcgfX0+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3RlcC1ub1wiPntpICsgMX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidDEyIGMtczcwMFwiIHN0eWxlPXt7IGxpbmVIZWlnaHQ6ICcxOXB4JyB9fT48YiBjbGFzc05hbWU9XCJjLWlua1wiPnthfTwvYj4ge2J9PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2FzaWRlPlxuICAgICAgPC9zZWN0aW9uPlxuICAgIDwvPlxuICApXG59XG4iXX0=