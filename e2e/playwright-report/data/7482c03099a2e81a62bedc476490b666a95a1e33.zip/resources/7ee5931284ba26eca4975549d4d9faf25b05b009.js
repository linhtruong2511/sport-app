import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OwnerCourts.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { SPORTS, TODAY, sportOf, toVN } from "/src/data.ts";
import { useApp } from "/src/store.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/OwnerCourts.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
const emptyForm = {
	name: "",
	branchId: "cs1",
	sport: "pickleball",
	deposit: 30,
	priceNormal: 15e4,
	pricePeak: 25e4,
	active: true
};
const f = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
export default function OwnerCourts() {
	_s();
	const { courts, setCourts, branches, setBranches, locks, setLocks, holidays, setHolidays, toast } = useApp();
	const { branchFilter } = useOutletContext();
	const [tab, setTab] = useState(1);
	const [editId, setEditId] = useState(null);
	const [form, setForm] = useState(emptyForm);
	const [err, setErr] = useState("");
	const [hol, setHol] = useState({
		date: "",
		note: ""
	});
	const [lk, setLk] = useState({
		courtId: "",
		from: `${TODAY}T08:00`,
		to: `${TODAY}T18:00`,
		reason: "Bảo trì mặt sân"
	});
	const list = courts.filter((c) => branchFilter === "all" || c.branchId === branchFilter);
	const bName = (id) => branches.find((b) => b.id === id)?.name ?? "";
	const lockOf = (id) => locks.find((l) => l.courtId === id && l.to.slice(0, 10) >= TODAY);
	const edit = (c) => {
		setEditId(c.id);
		setForm({
			name: c.name,
			branchId: c.branchId,
			sport: c.sport,
			deposit: c.deposit,
			priceNormal: c.priceNormal,
			pricePeak: c.pricePeak,
			active: c.active
		});
		setErr("");
	};
	const reset = () => {
		setEditId(null);
		setForm({
			...emptyForm,
			branchId: branchFilter === "all" ? "cs1" : branchFilter
		});
		setErr("");
	};
	const save = () => {
		if (!form.name.trim()) return setErr("Vui lòng nhập tên sân thi đấu.");
		if (courts.some((c) => c.id !== editId && c.branchId === form.branchId && c.name.toLowerCase() === form.name.trim().toLowerCase())) return setErr("Tên sân đã tồn tại trong chi nhánh này.");
		if (!(form.deposit >= 0 && form.deposit <= 100)) return setErr("Tỷ lệ đặt cọc phải nằm trong khoảng 0 – 100%.");
		if (form.priceNormal <= 0 || form.pricePeak <= 0) return setErr("Đơn giá thuê phải lớn hơn 0.");
		if (editId) {
			setCourts((cs) => cs.map((c) => c.id === editId ? {
				...c,
				...form,
				name: form.name.trim()
			} : c));
			toast(`Đã cập nhật ${form.name}. Giá mới áp dụng cho các đơn phát sinh sau thời điểm lưu.`, "ok");
		} else {
			const sp = sportOf(form.sport);
			const n = Math.max(0, ...courts.filter((c) => c.sport === form.sport).map((c) => parseInt(c.id.split("_")[2], 10))) + 1;
			setCourts((cs) => [...cs, {
				...form,
				name: form.name.trim(),
				id: `SAN_${sp.code}_${String(n).padStart(2, "0")}`
			}]);
			toast(`Đã thêm sân mới ${form.name}.`, "ok");
		}
		reset();
	};
	const tabs = [
		[1, "Danh sách sân & Bảng giá thuê"],
		[2, "Giờ mở cửa & Lịch nghỉ lễ"],
		[3, "Tạm khóa bảo trì sân"]
	];
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("section", {
			className: "card row between wrap g16",
			style: { padding: 16 },
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "row g8 wrap",
				children: tabs.map(([t, l]) => /* @__PURE__ */ _jsxDEV("button", {
					className: `btn btn-md ${tab === t ? "btn-primary" : "btn-ghost"}`,
					style: {
						background: tab === t ? undefined : "var(--s100)",
						padding: tab === t ? "9px 16px" : "8px 16px"
					},
					onClick: () => setTab(t),
					children: l
				}, t, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 33
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "t12 w600 c-s600",
				children: [
					"Tổng số: ",
					courts.length,
					" sân thuộc ",
					branches.length,
					" chi nhánh"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 7
		}, this),
		tab === 1 && /* @__PURE__ */ _jsxDEV("div", {
			className: "grid12",
			children: [/* @__PURE__ */ _jsxDEV("section", {
				className: "span7 card col g16",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "row between",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "t14 w800 c-ink",
							children: "Danh sách sân & Cấu hình giá theo khung giờ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 42
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "t12 c-s600",
							children: "Nhấp \"Cập nhật\" để điều chỉnh giá hoặc mức cọc"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 121
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "tbl-wrap",
						style: {
							maxHeight: 520,
							overflowY: "auto"
						},
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "tbl",
							children: [/* @__PURE__ */ _jsxDEV("thead", {
								style: {
									position: "sticky",
									top: 0
								},
								children: /* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("th", { children: "Mã / Tên sân" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 67
									}, this),
									/* @__PURE__ */ _jsxDEV("th", { children: "Chi nhánh & Bộ môn" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 88
									}, this),
									/* @__PURE__ */ _jsxDEV("th", { children: "Đơn giá theo giờ" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 115
									}, this),
									/* @__PURE__ */ _jsxDEV("th", { children: "Đặt cọc" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 140
									}, this),
									/* @__PURE__ */ _jsxDEV("th", { children: "Trạng thái" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 156
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "r",
										children: "Thao tác"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 175
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 63,
									columnNumber: 63
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: list.map((c) => {
								const l = lockOf(c.id);
								return /* @__PURE__ */ _jsxDEV("tr", {
									className: l ? "warn-row" : editId === c.id ? "hl" : "",
									children: [
										/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "mono w800",
											style: { fontSize: 11.1 },
											children: c.id
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 69,
											columnNumber: 29
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "w700 c-s800",
											children: c.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 69,
											columnNumber: 95
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 69,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w700 c-brand8",
											children: bName(c.branchId)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 70,
											columnNumber: 29
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "c-s600",
											children: sportOf(c.sport).detail
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 70,
											columnNumber: 85
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 70,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", { children: ["05h-16h: ", /* @__PURE__ */ _jsxDEV("b", { children: [f(c.priceNormal), "đ/h"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 71,
											columnNumber: 43
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 71,
											columnNumber: 29
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: ["16h-23h: ", /* @__PURE__ */ _jsxDEV("b", { children: [f(c.pricePeak), "đ/h"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 71,
											columnNumber: 91
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 71,
											columnNumber: 77
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 71,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("b", {
											className: "w800",
											children: [c.deposit, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 72,
											columnNumber: 29
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 72,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("td", { children: !c.active ? /* @__PURE__ */ _jsxDEV("span", {
											className: "badge b-gray",
											children: "Ngừng hoạt động"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 73,
											columnNumber: 42
										}, this) : l ? /* @__PURE__ */ _jsxDEV("span", {
											className: "badge",
											style: {
												background: "var(--amber-200)",
												color: "var(--amber-950)"
											},
											children: "Đang bảo trì"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 73,
											columnNumber: 102
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "badge b-green",
											children: "Đang mở"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 73,
											columnNumber: 218
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 73,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "r",
											children: l ? /* @__PURE__ */ _jsxDEV("button", {
												className: "btn btn-warn-o btn-sm",
												onClick: () => {
													setLocks((ls) => ls.filter((x) => x.courtId !== c.id));
													toast(`Đã mở lại ${c.name}.`, "ok");
												},
												children: "Mở lại sân"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 75,
												columnNumber: 29
											}, this) : /* @__PURE__ */ _jsxDEV("button", {
												className: "btn btn-outline btn-sm",
												style: { color: "var(--brand-800)" },
												onClick: () => edit(c),
												children: "Cập nhật"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 76,
												columnNumber: 29
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 74,
											columnNumber: 25
										}, this)
									]
								}, c.id, true, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 23
								}, this);
							}) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "hint hint-green",
						style: { padding: 14 },
						children: "💡 Khi thay đổi bảng giá thuê hoặc mức đặt cọc, mức giá mới sẽ áp dụng cho các đơn đặt sân phát sinh sau thời điểm lưu; các đơn khách đã đặt trước đó vẫn được giữ nguyên mức giá ban đầu."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				className: "span5 card card-lg card-raise col g16",
				style: { padding: 20 },
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "row between head-rule",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "col",
						style: {
							gap: 1.5,
							paddingTop: 5.5
						},
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "eyebrow",
							children: "Thông tin sân thi đấu"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 74
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "t16 w800 c-ink",
							style: { lineHeight: "24px" },
							children: editId ? "Chỉnh sửa sân" : "Thêm sân mới"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 128
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "badge sq b-gray mono",
						style: {
							fontSize: 11.3,
							fontWeight: 800,
							color: "var(--s900)"
						},
						children: editId ?? "SAN_MỚI"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("form", {
					className: "col g14",
					onSubmit: (e) => {
						e.preventDefault();
						save();
					},
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g12",
							style: { alignItems: "flex-start" },
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "label",
									style: { marginBottom: 4 },
									children: "Tên sân thi đấu *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									className: "input sm",
									value: form.name,
									onChange: (e) => setForm({
										...form,
										name: e.target.value
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 115
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 93,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "label",
									style: { marginBottom: 4 },
									children: "Thuộc chi nhánh *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									className: "select sm",
									value: form.branchId,
									onChange: (e) => setForm({
										...form,
										branchId: e.target.value
									}),
									children: branches.map((b) => /* @__PURE__ */ _jsxDEV("option", {
										value: b.id,
										children: b.name
									}, b.id, false, {
										fileName: _jsxFileName,
										lineNumber: 95,
										columnNumber: 157
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g12",
							style: { alignItems: "flex-start" },
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "label",
									style: { marginBottom: 4 },
									children: "Bộ môn thể thao *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 98,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									className: "select sm",
									value: form.sport,
									disabled: !!editId,
									onChange: (e) => setForm({
										...form,
										sport: e.target.value
									}),
									children: SPORTS.map((s) => /* @__PURE__ */ _jsxDEV("option", {
										value: s.key,
										children: s.detail
									}, s.key, false, {
										fileName: _jsxFileName,
										lineNumber: 99,
										columnNumber: 181
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "label",
									style: { marginBottom: 4 },
									children: "Tỷ lệ đặt cọc giữ sân (%) *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 100,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									className: "input sm",
									style: {
										color: "var(--brand-700)",
										fontWeight: 800
									},
									type: "number",
									min: 0,
									max: 100,
									value: form.deposit,
									onChange: (e) => setForm({
										...form,
										deposit: Number(e.target.value)
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 100,
									columnNumber: 125
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "col g8",
							style: { paddingTop: 4 },
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "label",
								style: { margin: 0 },
								children: "Bảng giá thuê theo khung giờ (VNĐ/giờ) *"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "row g10",
								style: {
									background: "var(--s100)",
									border: "1px solid var(--s300)",
									borderRadius: 12,
									padding: 12
								},
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "f1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "t11 w600 c-s600",
										children: "Giờ thường (06:00 - 16:00)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 105,
										columnNumber: 39
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										className: "input sm bold",
										type: "number",
										min: 0,
										step: 1e3,
										value: form.priceNormal,
										onChange: (e) => setForm({
											...form,
											priceNormal: Number(e.target.value)
										}),
										style: { marginTop: 4 }
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 105,
										columnNumber: 106
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "f1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "t11 w600 c-s600",
										children: "Giờ cao điểm (16:00 - 22:00)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 39
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										className: "input sm",
										style: {
											marginTop: 4,
											color: "var(--brand-700)",
											fontWeight: 800
										},
										type: "number",
										min: 0,
										step: 1e3,
										value: form.pricePeak,
										onChange: (e) => setForm({
											...form,
											pricePeak: Number(e.target.value)
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 108
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							style: { marginBottom: 4 },
							children: "Trạng thái nhận lịch"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 20
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							className: "select sm",
							value: form.active ? "1" : "0",
							onChange: (e) => setForm({
								...form,
								active: e.target.value === "1"
							}),
							children: [/* @__PURE__ */ _jsxDEV("option", {
								value: "1",
								children: "Đang hoạt động"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 150
							}, this), /* @__PURE__ */ _jsxDEV("option", {
								value: "0",
								children: "Ngừng hoạt động"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 191
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 15
						}, this),
						err && /* @__PURE__ */ _jsxDEV("p", {
							className: "field-err",
							children: err
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 23
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g8",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-primary btn-md f1",
								type: "submit",
								children: "Lưu thông tin sân"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 39
							}, this), editId && /* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-outline btn-md",
								type: "button",
								onClick: reset,
								children: "Thêm sân mới"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 136
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 9
		}, this),
		tab === 2 && /* @__PURE__ */ _jsxDEV("div", {
			className: "grid12",
			children: [/* @__PURE__ */ _jsxDEV("section", {
				className: "span7 card col g16",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "col g2",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "t14 w800 c-ink",
							children: "Giờ mở cửa theo chi nhánh"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 37
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "t12 c-s600",
							children: "Khung giờ này quyết định bảng lịch khách có thể đặt trực tuyến."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 98
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "col g12",
						children: branches.map((b) => /* @__PURE__ */ _jsxDEV("div", {
							className: "row between g12 wrap hint",
							style: { padding: 14 },
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "col",
								children: [/* @__PURE__ */ _jsxDEV("b", {
									className: "t12 c-ink",
									children: b.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 40
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "t11 c-s600",
									children: [
										courts.filter((c) => c.branchId === b.id).length,
										" sân • ",
										b.address.split(",")[0]
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 77
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "row g8",
								children: [
									/* @__PURE__ */ _jsxDEV("input", {
										type: "time",
										className: "input sm",
										style: { width: "auto" },
										value: b.open,
										onChange: (e) => setBranches((bs) => bs.map((x) => x.id === b.id ? {
											...x,
											open: e.target.value
										} : x))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 127,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "t12 c-s600",
										children: "đến"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "time",
										className: "input sm",
										style: { width: "auto" },
										value: b.close,
										onChange: (e) => setBranches((bs) => bs.map((x) => x.id === b.id ? {
											...x,
											close: e.target.value
										} : x))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 129,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 19
							}, this)]
						}, b.id, true, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "btn btn-primary btn-md",
						style: { alignSelf: "flex-start" },
						onClick: () => toast("Đã lưu giờ mở cửa các chi nhánh.", "ok"),
						children: "Lưu giờ mở cửa"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 120,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				className: "span5 card card-lg card-raise col g16",
				style: { padding: 20 },
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "col head-rule",
						style: { gap: 2 },
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "eyebrow",
							children: "Lịch nghỉ lễ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 63
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "t16 w800 c-ink",
							style: { lineHeight: "24px" },
							children: "Ngày đóng cửa toàn hệ thống"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 108
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "col g8",
						children: [holidays.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
							className: "t12 c-s600",
							children: "Chưa có ngày nghỉ lễ nào."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 41
						}, this), holidays.map((h) => /* @__PURE__ */ _jsxDEV("div", {
							className: "row between hint",
							style: { padding: 12 },
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "col",
								children: [/* @__PURE__ */ _jsxDEV("b", {
									className: "c-ink",
									children: toVN(h.date)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 107
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: h.note }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 146
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 86
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-danger-o btn-xs",
								onClick: () => setHolidays((hs) => hs.filter((x) => x.id !== h.id)),
								children: "Xóa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 19
							}, this)]
						}, h.id, true, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 17
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						className: "col g10",
						onSubmit: (e) => {
							e.preventDefault();
							if (!hol.date) return toast("Vui lòng chọn ngày nghỉ.", "err");
							setHolidays((hs) => [...hs, {
								id: `H${Date.now()}`,
								date: hol.date,
								note: hol.note || "Nghỉ lễ"
							}]);
							setHol({
								date: "",
								note: ""
							});
						},
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "row g8",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								className: "input sm",
								type: "date",
								min: TODAY,
								value: hol.date,
								onChange: (e) => setHol({
									...hol,
									date: e.target.value
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 39
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								className: "input sm",
								style: { fontWeight: 500 },
								placeholder: "Ghi chú (vd: Nghỉ Tết)",
								value: hol.note,
								onChange: (e) => setHol({
									...hol,
									note: e.target.value
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 169
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: "btn btn-primary btn-md",
							children: "+ Thêm ngày nghỉ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 136,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 119,
			columnNumber: 9
		}, this),
		tab === 3 && /* @__PURE__ */ _jsxDEV("div", {
			className: "grid12",
			children: [/* @__PURE__ */ _jsxDEV("section", {
				className: "span7 card col g16",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "col g2",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "t14 w800 c-ink",
							children: "Các sân đang tạm khóa bảo trì"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 37
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "t12 c-s600",
							children: "Sân bị khóa sẽ không nhận lịch đặt trong khoảng thời gian bảo trì."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 102
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 13
					}, this),
					locks.length === 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "hint",
						style: {
							textAlign: "center",
							padding: 24
						},
						children: "Hiện không có sân nào đang bảo trì."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 36
					}, this),
					locks.map((l) => {
						const c = courts.find((x) => x.id === l.courtId);
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "row between g12",
							style: {
								background: "var(--amber-50)",
								border: "2px solid var(--amber-400)",
								borderRadius: 12,
								padding: 14
							},
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "col g2",
								children: [
									/* @__PURE__ */ _jsxDEV("b", {
										className: "t12 c-ink",
										children: [
											c?.name,
											" • ",
											c && bName(c.branchId)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 162,
										columnNumber: 43
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "t12 c-s700",
										children: [
											l.from.slice(8, 10),
											"/",
											l.from.slice(5, 7),
											" ",
											l.from.slice(11),
											" → ",
											l.to.slice(8, 10),
											"/",
											l.to.slice(5, 7),
											" ",
											l.to.slice(11)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 162,
										columnNumber: 108
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "t11 c-amber",
										children: l.reason
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 162,
										columnNumber: 263
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-warn-o btn-sm",
								onClick: () => {
									setLocks((ls) => ls.filter((x) => x.id !== l.id));
									toast(`Đã mở lại ${c?.name}.`, "ok");
								},
								children: "Mở lại sân"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 19
							}, this)]
						}, l.id, true, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 17
						}, this);
					})
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				className: "span5 card card-lg card-raise col g16",
				style: { padding: 20 },
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "col head-rule",
					style: { gap: 2 },
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "eyebrow",
						style: { color: "var(--amber-800)" },
						children: "Tạm khóa sân"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 63
					}, this), /* @__PURE__ */ _jsxDEV("h3", {
						className: "t16 w800 c-ink",
						style: { lineHeight: "24px" },
						children: "Lên lịch bảo trì sân"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 146
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 169,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("form", {
					className: "col g14",
					onSubmit: (e) => {
						e.preventDefault();
						if (!lk.courtId) return toast("Vui lòng chọn sân cần khóa.", "err");
						if (!lk.from || !lk.to || lk.to <= lk.from) return toast("Thời gian kết thúc phải sau thời gian bắt đầu.", "err");
						setLocks((ls) => [...ls, {
							id: `L${Date.now()}`,
							...lk
						}]);
						toast("Đã tạm khóa sân. Các ô giờ trong khoảng này sẽ hiển thị \"Bảo trì\".", "ok");
					},
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							style: { marginBottom: 4 },
							children: "Sân cần khóa *"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 20
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							className: "select sm",
							value: lk.courtId,
							onChange: (e) => setLk({
								...lk,
								courtId: e.target.value
							}),
							children: [/* @__PURE__ */ _jsxDEV("option", {
								value: "",
								children: "— Chọn sân —"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 19
							}, this), courts.filter((c) => branchFilter === "all" || c.branchId === branchFilter).map((c) => /* @__PURE__ */ _jsxDEV("option", {
								value: c.id,
								children: [
									c.name,
									" – ",
									bName(c.branchId)
								]
							}, c.id, true, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 107
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g12",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "label",
									style: { marginBottom: 4 },
									children: "Từ *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 60
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									className: "input sm",
									type: "datetime-local",
									value: lk.from,
									onChange: (e) => setLk({
										...lk,
										from: e.target.value
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 125
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 40
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "label",
									style: { marginBottom: 4 },
									children: "Đến *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									className: "input sm",
									type: "datetime-local",
									value: lk.to,
									onChange: (e) => setLk({
										...lk,
										to: e.target.value
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 103
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 181,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							style: { marginBottom: 4 },
							children: "Lý do bảo trì"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 20
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							className: "input sm",
							style: { fontWeight: 500 },
							value: lk.reason,
							onChange: (e) => setLk({
								...lk,
								reason: e.target.value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 94
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "btn btn-danger btn-md",
							children: "Tạm khóa sân"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 170,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 168,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 154,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 5
	}, this);
}
_s(OwnerCourts, "HlLzxGugwuC3gVg7yKBvcEdw/WA=", false, function() {
	return [useApp, useOutletContext];
});
_c = OwnerCourts;
var _c;
$RefreshReg$(_c, "OwnerCourts");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/OwnerCourts.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/OwnerCourts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/OwnerCourts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/OwnerCourts.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxRQUFRLE9BQU8sU0FBUyxZQUFZO0FBRzdDLFNBQVMsY0FBYzs7OztBQUd2QixNQUFNLFlBQVk7Q0FBRSxNQUFNO0NBQUksVUFBVTtDQUFPLE9BQU87Q0FBMEIsU0FBUztDQUFJLGFBQWE7Q0FBUSxXQUFXO0NBQVEsUUFBUTtBQUFLO0FBQ2xKLE1BQU0sS0FBSyxNQUFjLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSx5QkFBeUIsR0FBRztBQUV2RSxlQUFlLFNBQVMsY0FBYzs7Q0FDcEMsTUFBTSxFQUFFLFFBQVEsV0FBVyxVQUFVLGFBQWEsT0FBTyxVQUFVLFVBQVUsYUFBYSxVQUFVLE9BQU87Q0FDM0csTUFBTSxFQUFFLGlCQUFpQixpQkFBOEI7Q0FDdkQsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFjLENBQUM7Q0FDckMsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUF3QixJQUFJO0NBQ3hELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxTQUFTO0NBQzFDLE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBUyxFQUFFO0NBQ2pDLE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBUztFQUFFLE1BQU07RUFBSSxNQUFNO0NBQUcsQ0FBQztDQUNyRCxNQUFNLENBQUMsSUFBSSxTQUFTLFNBQVM7RUFBRSxTQUFTO0VBQUksTUFBTSxHQUFHLE1BQU07RUFBUyxJQUFJLEdBQUcsTUFBTTtFQUFTLFFBQVE7Q0FBa0IsQ0FBQztDQUVySCxNQUFNLE9BQU8sT0FBTyxRQUFRLE1BQU0saUJBQWlCLFNBQVMsRUFBRSxhQUFhLFlBQVk7Q0FDdkYsTUFBTSxTQUFTLE9BQWUsU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFFBQVE7Q0FDekUsTUFBTSxVQUFVLE9BQWUsTUFBTSxNQUFNLE1BQU0sRUFBRSxZQUFZLE1BQU0sRUFBRSxHQUFHLE1BQU0sR0FBRyxFQUFFLEtBQUssS0FBSztDQUUvRixNQUFNLFFBQVEsTUFBYTtFQUFFLFVBQVUsRUFBRSxFQUFFO0VBQUcsUUFBUTtHQUFFLE1BQU0sRUFBRTtHQUFNLFVBQVUsRUFBRTtHQUFVLE9BQU8sRUFBRTtHQUFPLFNBQVMsRUFBRTtHQUFTLGFBQWEsRUFBRTtHQUFhLFdBQVcsRUFBRTtHQUFXLFFBQVEsRUFBRTtFQUFPLENBQUM7RUFBRyxPQUFPLEVBQUU7Q0FBRTtDQUNwTixNQUFNLGNBQWM7RUFBRSxVQUFVLElBQUk7RUFBRyxRQUFRO0dBQUUsR0FBRztHQUFXLFVBQVUsaUJBQWlCLFFBQVEsUUFBUTtFQUFhLENBQUM7RUFBRyxPQUFPLEVBQUU7Q0FBRTtDQUV0SSxNQUFNLGFBQWE7RUFDakIsSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLEdBQUcsT0FBTyxPQUFPLGdDQUFnQztFQUNyRSxJQUFJLE9BQU8sTUFBTSxNQUFNLEVBQUUsT0FBTyxVQUFVLEVBQUUsYUFBYSxLQUFLLFlBQVksRUFBRSxLQUFLLFlBQVksTUFBTSxLQUFLLEtBQUssS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLEdBQUcsT0FBTyxPQUFPLHlDQUF5QztFQUMzTCxJQUFJLEVBQUUsS0FBSyxXQUFXLEtBQUssS0FBSyxXQUFXLE1BQU0sT0FBTyxPQUFPLCtDQUErQztFQUM5RyxJQUFJLEtBQUssZUFBZSxLQUFLLEtBQUssYUFBYSxHQUFHLE9BQU8sT0FBTyw4QkFBOEI7RUFDOUYsSUFBSSxRQUFRO0dBQ1YsV0FBVyxPQUFPLEdBQUcsS0FBSyxNQUFPLEVBQUUsT0FBTyxTQUFTO0lBQUUsR0FBRztJQUFHLEdBQUc7SUFBTSxNQUFNLEtBQUssS0FBSyxLQUFLO0dBQUUsSUFBSSxDQUFFLENBQUM7R0FDbEcsTUFBTSxlQUFlLEtBQUssS0FBSyw2REFBNkQsSUFBSTtFQUNsRyxPQUFPO0dBQ0wsTUFBTSxLQUFLLFFBQVEsS0FBSyxLQUFLO0dBQzdCLE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxHQUFHLE9BQU8sUUFBUSxNQUFNLEVBQUUsVUFBVSxLQUFLLEtBQUssQ0FBQyxDQUFDLEtBQUssTUFBTSxTQUFTLEVBQUUsR0FBRyxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSTtHQUN0SCxXQUFXLE9BQU8sQ0FBQyxHQUFHLElBQUk7SUFBRSxHQUFHO0lBQU0sTUFBTSxLQUFLLEtBQUssS0FBSztJQUFHLElBQUksT0FBTyxHQUFHLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0dBQUksQ0FBQyxDQUFDO0dBQ2xILE1BQU0sbUJBQW1CLEtBQUssS0FBSyxJQUFJLElBQUk7RUFDN0M7RUFDQSxNQUFNO0NBQ1I7Q0FFQSxNQUFNLE9BQXdCO0VBQUMsQ0FBQyxHQUFHLCtCQUErQjtFQUFHLENBQUMsR0FBRywyQkFBMkI7RUFBRyxDQUFDLEdBQUcsc0JBQXNCO0NBQUM7Q0FFbEksT0FDRTtFQUNFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO0dBQTRCLE9BQU8sRUFBRSxTQUFTLEdBQUc7YUFBcEUsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLEtBQUssS0FBSyxDQUFDLEdBQUcsT0FBTyx3QkFBQyxVQUFEO0tBQWdCLFdBQVcsY0FBYyxRQUFRLElBQUksZ0JBQWdCO0tBQWUsT0FBTztNQUFFLFlBQVksUUFBUSxJQUFJLFlBQVk7TUFBZSxTQUFTLFFBQVEsSUFBSSxhQUFhO0tBQVc7S0FBRyxlQUFlLE9BQU8sQ0FBQztlQUFJO0lBQVUsR0FBeE47Ozs7V0FBd04sQ0FBQztHQUN6UDs7OzthQUNMLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCO0tBQWtDO0tBQVUsT0FBTztLQUFPO0tBQVksU0FBUztLQUFPO0lBQWdCOzs7OztXQUMvRjs7Ozs7O0VBRVIsUUFBUSxLQUNQLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQTZCLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFpQjtNQUErQzs7OztnQkFBQyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBYTtNQUFvRDs7OztjQUFNOzs7Ozs7S0FDbk0sd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBVyxPQUFPO09BQUUsV0FBVztPQUFLLFdBQVc7TUFBTztnQkFDbkUsd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtRQUFPLE9BQU87U0FBRSxVQUFVO1NBQVUsS0FBSztRQUFFO2tCQUFHLHdCQUFDLE1BQUQ7U0FBSSx3QkFBQyxNQUFELFlBQUksZUFBZ0I7Ozs7O1NBQUMsd0JBQUMsTUFBRCxZQUFJLHFCQUFzQjs7Ozs7U0FBQyx3QkFBQyxNQUFELFlBQUksbUJBQW9COzs7OztTQUFDLHdCQUFDLE1BQUQsWUFBSSxVQUFXOzs7OztTQUFDLHdCQUFDLE1BQUQsWUFBSSxhQUFjOzs7OztTQUFDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFJO1NBQVk7Ozs7O1FBQUs7Ozs7O09BQVE7Ozs7aUJBQ3pNLHdCQUFDLFNBQUQsWUFDRyxLQUFLLEtBQUssTUFBTTtRQUNmLE1BQU0sSUFBSSxPQUFPLEVBQUUsRUFBRTtRQUNyQixPQUNFLHdCQUFDLE1BQUQ7U0FBZSxXQUFXLElBQUksYUFBYSxXQUFXLEVBQUUsS0FBSyxPQUFPO21CQUFwRTtVQUNFLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUFZLE9BQU8sRUFBRSxVQUFVLEtBQUs7cUJBQUksRUFBRTtVQUFROzs7O29CQUFDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFlLEVBQUU7VUFBVTs7OztrQkFBSzs7Ozs7VUFDckgsd0JBQUMsTUFBRCxhQUFJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFpQixNQUFNLEVBQUUsUUFBUTtVQUFPOzs7O29CQUFDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFVLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztVQUFZOzs7O2tCQUFLOzs7OztVQUN2SCx3QkFBQyxNQUFELGFBQUksd0JBQUMsT0FBRCxhQUFLLGFBQVMsd0JBQUMsS0FBRCxhQUFJLEVBQUUsRUFBRSxXQUFXLEdBQUUsS0FBTTs7OztrQkFBTTs7OztvQkFBQyx3QkFBQyxPQUFELGFBQUssYUFBUyx3QkFBQyxLQUFELGFBQUksRUFBRSxFQUFFLFNBQVMsR0FBRSxLQUFNOzs7O2tCQUFNOzs7O2tCQUFLOzs7OztVQUN0Ryx3QkFBQyxNQUFELFlBQUksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWIsQ0FBcUIsRUFBRSxTQUFRLEdBQUk7Ozs7O21CQUFLOzs7OztVQUM1Qyx3QkFBQyxNQUFELFlBQUssQ0FBQyxFQUFFLFNBQVMsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWU7VUFBcUI7Ozs7cUJBQUksSUFBSSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtXQUFRLE9BQU87WUFBRSxZQUFZO1lBQW9CLE9BQU87V0FBbUI7cUJBQUc7VUFBa0I7Ozs7cUJBQUksd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdCO1VBQWE7Ozs7bUJBQU07Ozs7O1VBQ3BQLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFLLElBQ2Ysd0JBQUMsVUFBRDtZQUFRLFdBQVU7WUFBd0IsZUFBZTthQUFFLFVBQVUsT0FBTyxHQUFHLFFBQVEsTUFBTSxFQUFFLFlBQVksRUFBRSxFQUFFLENBQUM7YUFBRyxNQUFNLGFBQWEsRUFBRSxLQUFLLElBQUksSUFBSTtZQUFFO3NCQUFHO1dBQWtCOzs7O3NCQUM1Syx3QkFBQyxVQUFEO1lBQVEsV0FBVTtZQUF5QixPQUFPLEVBQUUsT0FBTyxtQkFBbUI7WUFBRyxlQUFlLEtBQUssQ0FBQztzQkFBRztXQUFnQjs7Ozs7VUFBTTs7Ozs7U0FDakk7V0FUSyxFQUFFOzs7O2VBU1A7T0FFUixDQUFDLEVBQ0k7Ozs7ZUFDRjs7Ozs7O0tBQ0o7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBa0IsT0FBTyxFQUFFLFNBQVMsR0FBRztnQkFBRztLQUErTDs7Ozs7SUFDalA7Ozs7O2FBRVQsd0JBQUMsU0FBRDtJQUFPLFdBQVU7SUFBd0MsT0FBTyxFQUFFLFNBQVMsR0FBRztjQUE5RSxDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFNLE9BQU87T0FBRSxLQUFLO09BQUssWUFBWTtNQUFJO2dCQUF4RCxDQUEyRCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBVTtNQUEyQjs7OztnQkFBQyx3QkFBQyxNQUFEO09BQUksV0FBVTtPQUFpQixPQUFPLEVBQUUsWUFBWSxPQUFPO2lCQUFJLFNBQVMsa0JBQWtCO01BQW1COzs7O2NBQU07Ozs7O2VBQ3BPLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQXVCLE9BQU87T0FBRSxVQUFVO09BQU0sWUFBWTtPQUFLLE9BQU87TUFBYztnQkFBSSxVQUFVO0tBQWdCOzs7O2FBQ2pJOzs7OztjQUNMLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO0tBQVUsV0FBVyxNQUFNO01BQUUsRUFBRSxlQUFlO01BQUcsS0FBSztLQUFFO2VBQXhFO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBVSxPQUFPLEVBQUUsWUFBWSxhQUFhO2lCQUEzRCxDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQW9CLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO1NBQVEsT0FBTyxFQUFFLGNBQWMsRUFBRTttQkFBRztRQUF3Qjs7OztrQkFBQyx3QkFBQyxTQUFEO1NBQU8sV0FBVTtTQUFXLE9BQU8sS0FBSztTQUFNLFdBQVcsTUFBTSxRQUFRO1VBQUUsR0FBRztVQUFNLE1BQU0sRUFBRSxPQUFPO1NBQU0sQ0FBQztRQUFJOzs7O2dCQUFNOzs7OztpQkFDcE4sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBb0Isd0JBQUMsU0FBRDtTQUFPLFdBQVU7U0FBUSxPQUFPLEVBQUUsY0FBYyxFQUFFO21CQUFHO1FBQXdCOzs7O2tCQUMvRix3QkFBQyxVQUFEO1NBQVEsV0FBVTtTQUFZLE9BQU8sS0FBSztTQUFVLFdBQVcsTUFBTSxRQUFRO1VBQUUsR0FBRztVQUFNLFVBQVUsRUFBRSxPQUFPO1NBQU0sQ0FBQzttQkFBSSxTQUFTLEtBQUssTUFBTSx3QkFBQyxVQUFEO1VBQW1CLE9BQU8sRUFBRTtvQkFBSyxFQUFFO1NBQWEsR0FBbkMsRUFBRTs7OztnQkFBaUMsQ0FBQztRQUFVOzs7O2dCQUFNOzs7OztlQUMxTTs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBVSxPQUFPLEVBQUUsWUFBWSxhQUFhO2lCQUEzRCxDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQW9CLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO1NBQVEsT0FBTyxFQUFFLGNBQWMsRUFBRTttQkFBRztRQUF3Qjs7OztrQkFDL0Ysd0JBQUMsVUFBRDtTQUFRLFdBQVU7U0FBWSxPQUFPLEtBQUs7U0FBTyxVQUFVLENBQUMsQ0FBQztTQUFRLFdBQVcsTUFBTSxRQUFRO1VBQUUsR0FBRztVQUFNLE9BQU8sRUFBRSxPQUFPO1NBQWtCLENBQUM7bUJBQUksT0FBTyxLQUFLLE1BQU0sd0JBQUMsVUFBRDtVQUFvQixPQUFPLEVBQUU7b0JBQU0sRUFBRTtTQUFlLEdBQXZDLEVBQUU7Ozs7Z0JBQXFDLENBQUM7UUFBVTs7OztnQkFBTTs7Ozs7aUJBQ3pPLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQW9CLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO1NBQVEsT0FBTyxFQUFFLGNBQWMsRUFBRTttQkFBRztRQUFrQzs7OztrQkFBQyx3QkFBQyxTQUFEO1NBQU8sV0FBVTtTQUFXLE9BQU87VUFBRSxPQUFPO1VBQW9CLFlBQVk7U0FBSTtTQUFHLE1BQUs7U0FBUyxLQUFLO1NBQUcsS0FBSztTQUFLLE9BQU8sS0FBSztTQUFTLFdBQVcsTUFBTSxRQUFRO1VBQUUsR0FBRztVQUFNLFNBQVMsT0FBTyxFQUFFLE9BQU8sS0FBSztTQUFFLENBQUM7UUFBSTs7OztnQkFBTTs7Ozs7ZUFDaFU7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVMsT0FBTyxFQUFFLFlBQVksRUFBRTtpQkFBL0MsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtRQUFRLE9BQU8sRUFBRSxRQUFRLEVBQUU7a0JBQUc7T0FBK0M7Ozs7aUJBQzlGLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQVUsT0FBTztTQUFFLFlBQVk7U0FBZSxRQUFRO1NBQXlCLGNBQWM7U0FBSSxTQUFTO1FBQUc7a0JBQTVILENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FBb0Isd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWtCO1NBQWdDOzs7O21CQUFDLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO1VBQWdCLE1BQUs7VUFBUyxLQUFLO1VBQUcsTUFBTTtVQUFNLE9BQU8sS0FBSztVQUFhLFdBQVcsTUFBTSxRQUFRO1dBQUUsR0FBRztXQUFNLGFBQWEsT0FBTyxFQUFFLE9BQU8sS0FBSztVQUFFLENBQUM7VUFBRyxPQUFPLEVBQUUsV0FBVyxFQUFFO1NBQUk7Ozs7aUJBQU07Ozs7O2tCQUMvUix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUFvQix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBa0I7U0FBa0M7Ozs7bUJBQUMsd0JBQUMsU0FBRDtVQUFPLFdBQVU7VUFBVyxPQUFPO1dBQUUsV0FBVztXQUFHLE9BQU87V0FBb0IsWUFBWTtVQUFJO1VBQUcsTUFBSztVQUFTLEtBQUs7VUFBRyxNQUFNO1VBQU0sT0FBTyxLQUFLO1VBQVcsV0FBVyxNQUFNLFFBQVE7V0FBRSxHQUFHO1dBQU0sV0FBVyxPQUFPLEVBQUUsT0FBTyxLQUFLO1VBQUUsQ0FBQztTQUFJOzs7O2lCQUFNOzs7OztnQkFDalU7Ozs7O2VBQ0Y7Ozs7OztNQUNMLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFRLE9BQU8sRUFBRSxjQUFjLEVBQUU7aUJBQUc7TUFBMkI7Ozs7Z0JBQ25GLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQVksT0FBTyxLQUFLLFNBQVMsTUFBTTtPQUFLLFdBQVcsTUFBTSxRQUFRO1FBQUUsR0FBRztRQUFNLFFBQVEsRUFBRSxPQUFPLFVBQVU7T0FBSSxDQUFDO2lCQUFsSSxDQUFxSSx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBSTtPQUFzQjs7OztpQkFBQyx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBSTtPQUF1Qjs7OztlQUFTOzs7OztjQUFNOzs7OztNQUN2TyxPQUFPLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFhO01BQU87Ozs7O01BQ3pDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQXdCLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQTRCLE1BQUs7a0JBQVM7T0FBeUI7Ozs7aUJBQUUsVUFBVSx3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUF5QixNQUFLO1FBQVMsU0FBUztrQkFBTztPQUFvQjs7OztlQUFPOzs7Ozs7S0FDek47Ozs7O1lBQ0Q7Ozs7O1dBQ0o7Ozs7OztFQUdOLFFBQVEsS0FDUCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkI7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUF3Qix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBaUI7TUFBNkI7Ozs7Z0JBQUMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWE7TUFBcUU7Ozs7Y0FBTTs7Ozs7O0tBQzdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLFNBQVMsS0FBSyxNQUNiLHdCQUFDLE9BQUQ7T0FBZ0IsV0FBVTtPQUE0QixPQUFPLEVBQUUsU0FBUyxHQUFHO2lCQUEzRSxDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQXFCLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFhLEVBQUU7UUFBUTs7OztrQkFBQyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEI7VUFBOEIsT0FBTyxRQUFRLE1BQU0sRUFBRSxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUM7VUFBTztVQUFRLEVBQUUsUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDO1NBQVM7Ozs7O2dCQUFNOzs7OztpQkFDckwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLFdBQVU7VUFBVyxPQUFPLEVBQUUsT0FBTyxPQUFPO1VBQUcsT0FBTyxFQUFFO1VBQU0sV0FBVyxNQUFNLGFBQWEsT0FBTyxHQUFHLEtBQUssTUFBTyxFQUFFLE9BQU8sRUFBRSxLQUFLO1dBQUUsR0FBRztXQUFHLE1BQU0sRUFBRSxPQUFPO1VBQU0sSUFBSSxDQUFFLENBQUM7U0FBSTs7Ozs7U0FDN0wsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWE7U0FBUzs7Ozs7U0FDdEMsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxXQUFVO1VBQVcsT0FBTyxFQUFFLE9BQU8sT0FBTztVQUFHLE9BQU8sRUFBRTtVQUFPLFdBQVcsTUFBTSxhQUFhLE9BQU8sR0FBRyxLQUFLLE1BQU8sRUFBRSxPQUFPLEVBQUUsS0FBSztXQUFFLEdBQUc7V0FBRyxPQUFPLEVBQUUsT0FBTztVQUFNLElBQUksQ0FBRSxDQUFDO1NBQUk7Ozs7O1FBQzVMOzs7OztlQUNGO1NBUEssRUFBRTs7OzthQU9QLENBQ047S0FDRTs7Ozs7S0FDTCx3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUF5QixPQUFPLEVBQUUsV0FBVyxhQUFhO01BQUcsZUFBZSxNQUFNLG9DQUFvQyxJQUFJO2dCQUFHO0tBQXNCOzs7OztJQUM5Sjs7Ozs7YUFDVCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtJQUF3QyxPQUFPLEVBQUUsU0FBUyxHQUFHO2NBQTlFO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBZ0IsT0FBTyxFQUFFLEtBQUssRUFBRTtnQkFBL0MsQ0FBa0Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVU7TUFBa0I7Ozs7Z0JBQUMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7T0FBaUIsT0FBTyxFQUFFLFlBQVksT0FBTztpQkFBRztNQUErQjs7OztjQUFNOzs7Ozs7S0FDbE0sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRyxTQUFTLFdBQVcsS0FBSyx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYTtNQUE0Qjs7OztnQkFDL0UsU0FBUyxLQUFLLE1BQ2Isd0JBQUMsT0FBRDtPQUFnQixXQUFVO09BQW1CLE9BQU8sRUFBRSxTQUFTLEdBQUc7aUJBQWxFLENBQXFFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQXFCLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFTLEtBQUssRUFBRSxJQUFJO1FBQUs7Ozs7a0JBQUMsd0JBQUMsUUFBRCxZQUFPLEVBQUUsS0FBVzs7OztnQkFBTTs7Ozs7aUJBQ3pKLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQTBCLGVBQWUsYUFBYSxPQUFPLEdBQUcsUUFBUSxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUUsQ0FBQztrQkFBRztPQUFXOzs7O2VBQU07U0FEMUgsRUFBRTs7OzthQUN3SCxDQUNySSxDQUNFOzs7Ozs7S0FDTCx3QkFBQyxRQUFEO01BQU0sV0FBVTtNQUFVLFdBQVcsTUFBTTtPQUFFLEVBQUUsZUFBZTtPQUFHLElBQUksQ0FBQyxJQUFJLE1BQU0sT0FBTyxNQUFNLDRCQUE0QixLQUFLO09BQUcsYUFBYSxPQUFPLENBQUMsR0FBRyxJQUFJO1FBQUUsSUFBSSxJQUFJLEtBQUssSUFBSTtRQUFLLE1BQU0sSUFBSTtRQUFNLE1BQU0sSUFBSSxRQUFRO09BQVUsQ0FBQyxDQUFDO09BQUcsT0FBTztRQUFFLE1BQU07UUFBSSxNQUFNO09BQUcsQ0FBQztNQUFFO2dCQUFyUSxDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQXdCLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO1FBQVcsTUFBSztRQUFPLEtBQUs7UUFBTyxPQUFPLElBQUk7UUFBTSxXQUFXLE1BQU0sT0FBTztTQUFFLEdBQUc7U0FBSyxNQUFNLEVBQUUsT0FBTztRQUFNLENBQUM7T0FBSTs7OztpQkFBQyx3QkFBQyxTQUFEO1FBQU8sV0FBVTtRQUFXLE9BQU8sRUFBRSxZQUFZLElBQUk7UUFBRyxhQUFZO1FBQXlCLE9BQU8sSUFBSTtRQUFNLFdBQVcsTUFBTSxPQUFPO1NBQUUsR0FBRztTQUFLLE1BQU0sRUFBRSxPQUFPO1FBQU0sQ0FBQztPQUFJOzs7O2VBQU07Ozs7O2dCQUMxVSx3QkFBQyxVQUFEO09BQVEsV0FBVTtpQkFBeUI7TUFBd0I7Ozs7Y0FDL0Q7Ozs7OztJQUNEOzs7OztXQUNKOzs7Ozs7RUFHTixRQUFRLEtBQ1Asd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBd0Isd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWlCO01BQWlDOzs7O2dCQUFDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFhO01BQXdFOzs7O2NBQU07Ozs7OztLQUNuTSxNQUFNLFdBQVcsS0FBSyx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFPLE9BQU87T0FBRSxXQUFXO09BQVUsU0FBUztNQUFHO2dCQUFHO0tBQXdDOzs7OztLQUNqSSxNQUFNLEtBQUssTUFBTTtNQUNoQixNQUFNLElBQUksT0FBTyxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTztNQUMvQyxPQUNFLHdCQUFDLE9BQUQ7T0FBZ0IsV0FBVTtPQUFrQixPQUFPO1FBQUUsWUFBWTtRQUFtQixRQUFRO1FBQThCLGNBQWM7UUFBSSxTQUFTO09BQUc7aUJBQXhKLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBd0Isd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWI7V0FBMEIsR0FBRztXQUFLO1dBQUksS0FBSyxNQUFNLEVBQUUsUUFBUTtVQUFLOzs7Ozs7U0FBQyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEI7V0FBOEIsRUFBRSxLQUFLLE1BQU0sR0FBRyxFQUFFO1dBQUU7V0FBRSxFQUFFLEtBQUssTUFBTSxHQUFHLENBQUM7V0FBRTtXQUFFLEVBQUUsS0FBSyxNQUFNLEVBQUU7V0FBRTtXQUFJLEVBQUUsR0FBRyxNQUFNLEdBQUcsRUFBRTtXQUFFO1dBQUUsRUFBRSxHQUFHLE1BQU0sR0FBRyxDQUFDO1dBQUU7V0FBRSxFQUFFLEdBQUcsTUFBTSxFQUFFO1VBQVE7Ozs7OztTQUFDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFlLEVBQUU7U0FBYTs7Ozs7UUFBTTs7Ozs7aUJBQ3hTLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQXdCLGVBQWU7U0FBRSxVQUFVLE9BQU8sR0FBRyxRQUFRLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDO1NBQUcsTUFBTSxhQUFhLEdBQUcsS0FBSyxJQUFJLElBQUk7UUFBRTtrQkFBRztPQUFrQjs7OztlQUNySztTQUhLLEVBQUU7Ozs7YUFHUDtLQUVULENBQUM7SUFDTTs7Ozs7YUFDVCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtJQUF3QyxPQUFPLEVBQUUsU0FBUyxHQUFHO2NBQTlFLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBZ0IsT0FBTyxFQUFFLEtBQUssRUFBRTtlQUEvQyxDQUFrRCx3QkFBQyxRQUFEO01BQU0sV0FBVTtNQUFVLE9BQU8sRUFBRSxPQUFPLG1CQUFtQjtnQkFBRztLQUFrQjs7OztlQUFDLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO01BQWlCLE9BQU8sRUFBRSxZQUFZLE9BQU87Z0JBQUc7S0FBd0I7Ozs7YUFBTTs7Ozs7Y0FDak8sd0JBQUMsUUFBRDtLQUFNLFdBQVU7S0FBVSxXQUFXLE1BQU07TUFDekMsRUFBRSxlQUFlO01BQ2pCLElBQUksQ0FBQyxHQUFHLFNBQVMsT0FBTyxNQUFNLCtCQUErQixLQUFLO01BQ2xFLElBQUksQ0FBQyxHQUFHLFFBQVEsQ0FBQyxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxPQUFPLE1BQU0sa0RBQWtELEtBQUs7TUFDaEgsVUFBVSxPQUFPLENBQUMsR0FBRyxJQUFJO09BQUUsSUFBSSxJQUFJLEtBQUssSUFBSTtPQUFLLEdBQUc7TUFBRyxDQUFDLENBQUM7TUFBRyxNQUFNLHdFQUFzRSxJQUFJO0tBQzlJO2VBTEE7TUFNRSx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRDtPQUFPLFdBQVU7T0FBUSxPQUFPLEVBQUUsY0FBYyxFQUFFO2lCQUFHO01BQXFCOzs7O2dCQUM3RSx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFZLE9BQU8sR0FBRztPQUFTLFdBQVcsTUFBTSxNQUFNO1FBQUUsR0FBRztRQUFJLFNBQVMsRUFBRSxPQUFPO09BQU0sQ0FBQztpQkFBMUcsQ0FDRSx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBRztPQUFvQjs7OztpQkFDcEMsT0FBTyxRQUFRLE1BQU0saUJBQWlCLFNBQVMsRUFBRSxhQUFhLFlBQVksQ0FBQyxDQUFDLEtBQUssTUFBTSx3QkFBQyxVQUFEO1FBQW1CLE9BQU8sRUFBRTtrQkFBNUI7U0FBaUMsRUFBRTtTQUFLO1NBQUksTUFBTSxFQUFFLFFBQVE7UUFBVTtVQUF6RCxFQUFFOzs7O2NBQXVELENBQUMsQ0FDeko7Ozs7O2NBQU07Ozs7O01BQ2hCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQXlCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQW9CLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO1NBQVEsT0FBTyxFQUFFLGNBQWMsRUFBRTttQkFBRztRQUFXOzs7O2tCQUFDLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO1NBQVcsTUFBSztTQUFpQixPQUFPLEdBQUc7U0FBTSxXQUFXLE1BQU0sTUFBTTtVQUFFLEdBQUc7VUFBSSxNQUFNLEVBQUUsT0FBTztTQUFNLENBQUM7UUFBSTs7OztnQkFBTTs7Ozs7aUJBQzlPLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQW9CLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO1NBQVEsT0FBTyxFQUFFLGNBQWMsRUFBRTttQkFBRztRQUFZOzs7O2tCQUFDLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO1NBQVcsTUFBSztTQUFpQixPQUFPLEdBQUc7U0FBSSxXQUFXLE1BQU0sTUFBTTtVQUFFLEdBQUc7VUFBSSxJQUFJLEVBQUUsT0FBTztTQUFNLENBQUM7UUFBSTs7OztnQkFBTTs7Ozs7ZUFBTTs7Ozs7O01BQzVOLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFRLE9BQU8sRUFBRSxjQUFjLEVBQUU7aUJBQUc7TUFBb0I7Ozs7Z0JBQUMsd0JBQUMsU0FBRDtPQUFPLFdBQVU7T0FBVyxPQUFPLEVBQUUsWUFBWSxJQUFJO09BQUcsT0FBTyxHQUFHO09BQVEsV0FBVyxNQUFNLE1BQU07UUFBRSxHQUFHO1FBQUksUUFBUSxFQUFFLE9BQU87T0FBTSxDQUFDO01BQUk7Ozs7Y0FBTTs7Ozs7TUFDM04sd0JBQUMsVUFBRDtPQUFRLFdBQVU7aUJBQXdCO01BQW9COzs7OztLQUMxRDs7Ozs7WUFDRDs7Ozs7V0FDSjs7Ozs7O0NBRVA7Ozs7O0FBRU4iLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiT3duZXJDb3VydHMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VPdXRsZXRDb250ZXh0IH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IFNQT1JUUywgVE9EQVksIHNwb3J0T2YsIHRvVk4gfSBmcm9tICcuLi9kYXRhJ1xuaW1wb3J0IHR5cGUgeyBDb3VydCwgU3BvcnRLZXkgfSBmcm9tICcuLi9kYXRhJ1xuaW1wb3J0IHR5cGUgeyBTdGFmZk91dGxldCB9IGZyb20gJy4uL2xheW91dHMnXG5pbXBvcnQgeyB1c2VBcHAgfSBmcm9tICcuLi9zdG9yZSdcblxudHlwZSBUYWIgPSAxIHwgMiB8IDNcbmNvbnN0IGVtcHR5Rm9ybSA9IHsgbmFtZTogJycsIGJyYW5jaElkOiAnY3MxJywgc3BvcnQ6ICdwaWNrbGViYWxsJyBhcyBTcG9ydEtleSwgZGVwb3NpdDogMzAsIHByaWNlTm9ybWFsOiAxNTAwMDAsIHByaWNlUGVhazogMjUwMDAwLCBhY3RpdmU6IHRydWUgfVxuY29uc3QgZiA9IChuOiBudW1iZXIpID0+IFN0cmluZyhuKS5yZXBsYWNlKC9cXEIoPz0oXFxkezN9KSsoPyFcXGQpKS9nLCAnLicpXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE93bmVyQ291cnRzKCkge1xuICBjb25zdCB7IGNvdXJ0cywgc2V0Q291cnRzLCBicmFuY2hlcywgc2V0QnJhbmNoZXMsIGxvY2tzLCBzZXRMb2NrcywgaG9saWRheXMsIHNldEhvbGlkYXlzLCB0b2FzdCB9ID0gdXNlQXBwKClcbiAgY29uc3QgeyBicmFuY2hGaWx0ZXIgfSA9IHVzZU91dGxldENvbnRleHQ8U3RhZmZPdXRsZXQ+KClcbiAgY29uc3QgW3RhYiwgc2V0VGFiXSA9IHVzZVN0YXRlPFRhYj4oMSlcbiAgY29uc3QgW2VkaXRJZCwgc2V0RWRpdElkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKGVtcHR5Rm9ybSlcbiAgY29uc3QgW2Vyciwgc2V0RXJyXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbaG9sLCBzZXRIb2xdID0gdXNlU3RhdGUoeyBkYXRlOiAnJywgbm90ZTogJycgfSlcbiAgY29uc3QgW2xrLCBzZXRMa10gPSB1c2VTdGF0ZSh7IGNvdXJ0SWQ6ICcnLCBmcm9tOiBgJHtUT0RBWX1UMDg6MDBgLCB0bzogYCR7VE9EQVl9VDE4OjAwYCwgcmVhc29uOiAnQuG6o28gdHLDrCBt4bq3dCBzw6JuJyB9KVxuXG4gIGNvbnN0IGxpc3QgPSBjb3VydHMuZmlsdGVyKChjKSA9PiBicmFuY2hGaWx0ZXIgPT09ICdhbGwnIHx8IGMuYnJhbmNoSWQgPT09IGJyYW5jaEZpbHRlcilcbiAgY29uc3QgYk5hbWUgPSAoaWQ6IHN0cmluZykgPT4gYnJhbmNoZXMuZmluZCgoYikgPT4gYi5pZCA9PT0gaWQpPy5uYW1lID8/ICcnXG4gIGNvbnN0IGxvY2tPZiA9IChpZDogc3RyaW5nKSA9PiBsb2Nrcy5maW5kKChsKSA9PiBsLmNvdXJ0SWQgPT09IGlkICYmIGwudG8uc2xpY2UoMCwgMTApID49IFRPREFZKVxuXG4gIGNvbnN0IGVkaXQgPSAoYzogQ291cnQpID0+IHsgc2V0RWRpdElkKGMuaWQpOyBzZXRGb3JtKHsgbmFtZTogYy5uYW1lLCBicmFuY2hJZDogYy5icmFuY2hJZCwgc3BvcnQ6IGMuc3BvcnQsIGRlcG9zaXQ6IGMuZGVwb3NpdCwgcHJpY2VOb3JtYWw6IGMucHJpY2VOb3JtYWwsIHByaWNlUGVhazogYy5wcmljZVBlYWssIGFjdGl2ZTogYy5hY3RpdmUgfSk7IHNldEVycignJykgfVxuICBjb25zdCByZXNldCA9ICgpID0+IHsgc2V0RWRpdElkKG51bGwpOyBzZXRGb3JtKHsgLi4uZW1wdHlGb3JtLCBicmFuY2hJZDogYnJhbmNoRmlsdGVyID09PSAnYWxsJyA/ICdjczEnIDogYnJhbmNoRmlsdGVyIH0pOyBzZXRFcnIoJycpIH1cblxuICBjb25zdCBzYXZlID0gKCkgPT4ge1xuICAgIGlmICghZm9ybS5uYW1lLnRyaW0oKSkgcmV0dXJuIHNldEVycignVnVpIGzDsm5nIG5o4bqtcCB0w6puIHPDom4gdGhpIMSR4bqldS4nKVxuICAgIGlmIChjb3VydHMuc29tZSgoYykgPT4gYy5pZCAhPT0gZWRpdElkICYmIGMuYnJhbmNoSWQgPT09IGZvcm0uYnJhbmNoSWQgJiYgYy5uYW1lLnRvTG93ZXJDYXNlKCkgPT09IGZvcm0ubmFtZS50cmltKCkudG9Mb3dlckNhc2UoKSkpIHJldHVybiBzZXRFcnIoJ1TDqm4gc8OibiDEkcOjIHThu5NuIHThuqFpIHRyb25nIGNoaSBuaMOhbmggbsOgeS4nKVxuICAgIGlmICghKGZvcm0uZGVwb3NpdCA+PSAwICYmIGZvcm0uZGVwb3NpdCA8PSAxMDApKSByZXR1cm4gc2V0RXJyKCdU4bu3IGzhu4cgxJHhurd0IGPhu41jIHBo4bqjaSBu4bqxbSB0cm9uZyBraG/huqNuZyAwIOKAkyAxMDAlLicpXG4gICAgaWYgKGZvcm0ucHJpY2VOb3JtYWwgPD0gMCB8fCBmb3JtLnByaWNlUGVhayA8PSAwKSByZXR1cm4gc2V0RXJyKCfEkMahbiBnacOhIHRodcOqIHBo4bqjaSBs4bubbiBoxqFuIDAuJylcbiAgICBpZiAoZWRpdElkKSB7XG4gICAgICBzZXRDb3VydHMoKGNzKSA9PiBjcy5tYXAoKGMpID0+IChjLmlkID09PSBlZGl0SWQgPyB7IC4uLmMsIC4uLmZvcm0sIG5hbWU6IGZvcm0ubmFtZS50cmltKCkgfSA6IGMpKSlcbiAgICAgIHRvYXN0KGDEkMOjIGPhuq1wIG5o4bqtdCAke2Zvcm0ubmFtZX0uIEdpw6EgbeG7m2kgw6FwIGThu6VuZyBjaG8gY8OhYyDEkcahbiBwaMOhdCBzaW5oIHNhdSB0aOG7nWkgxJFp4buDbSBsxrB1LmAsICdvaycpXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHNwID0gc3BvcnRPZihmb3JtLnNwb3J0KVxuICAgICAgY29uc3QgbiA9IE1hdGgubWF4KDAsIC4uLmNvdXJ0cy5maWx0ZXIoKGMpID0+IGMuc3BvcnQgPT09IGZvcm0uc3BvcnQpLm1hcCgoYykgPT4gcGFyc2VJbnQoYy5pZC5zcGxpdCgnXycpWzJdLCAxMCkpKSArIDFcbiAgICAgIHNldENvdXJ0cygoY3MpID0+IFsuLi5jcywgeyAuLi5mb3JtLCBuYW1lOiBmb3JtLm5hbWUudHJpbSgpLCBpZDogYFNBTl8ke3NwLmNvZGV9XyR7U3RyaW5nKG4pLnBhZFN0YXJ0KDIsICcwJyl9YCB9XSlcbiAgICAgIHRvYXN0KGDEkMOjIHRow6ptIHPDom4gbeG7m2kgJHtmb3JtLm5hbWV9LmAsICdvaycpXG4gICAgfVxuICAgIHJlc2V0KClcbiAgfVxuXG4gIGNvbnN0IHRhYnM6IFtUYWIsIHN0cmluZ11bXSA9IFtbMSwgJ0Rhbmggc8OhY2ggc8OibiAmIELhuqNuZyBnacOhIHRodcOqJ10sIFsyLCAnR2nhu50gbeG7nyBj4butYSAmIEzhu4tjaCBuZ2jhu4kgbOG7hSddLCBbMywgJ1ThuqFtIGtow7NhIGLhuqNvIHRyw6wgc8OibiddXVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNhcmQgcm93IGJldHdlZW4gd3JhcCBnMTZcIiBzdHlsZT17eyBwYWRkaW5nOiAxNiB9fT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzggd3JhcFwiPlxuICAgICAgICAgIHt0YWJzLm1hcCgoW3QsIGxdKSA9PiA8YnV0dG9uIGtleT17dH0gY2xhc3NOYW1lPXtgYnRuIGJ0bi1tZCAke3RhYiA9PT0gdCA/ICdidG4tcHJpbWFyeScgOiAnYnRuLWdob3N0J31gfSBzdHlsZT17eyBiYWNrZ3JvdW5kOiB0YWIgPT09IHQgPyB1bmRlZmluZWQgOiAndmFyKC0tczEwMCknLCBwYWRkaW5nOiB0YWIgPT09IHQgPyAnOXB4IDE2cHgnIDogJzhweCAxNnB4JyB9fSBvbkNsaWNrPXsoKSA9PiBzZXRUYWIodCl9PntsfTwvYnV0dG9uPil9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0MTIgdzYwMCBjLXM2MDBcIj5U4buVbmcgc+G7kToge2NvdXJ0cy5sZW5ndGh9IHPDom4gdGh14buZYyB7YnJhbmNoZXMubGVuZ3RofSBjaGkgbmjDoW5oPC9zcGFuPlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7dGFiID09PSAxICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkMTJcIj5cbiAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFuNyBjYXJkIGNvbCBnMTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj48aDIgY2xhc3NOYW1lPVwidDE0IHc4MDAgYy1pbmtcIj5EYW5oIHPDoWNoIHPDom4gJiBD4bqldSBow6xuaCBnacOhIHRoZW8ga2h1bmcgZ2nhu508L2gyPjxzcGFuIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj5OaOG6pXAgXCJD4bqtcCBuaOG6rXRcIiDEkeG7gyDEkWnhu4F1IGNo4buJbmggZ2nDoSBob+G6t2MgbeG7qWMgY+G7jWM8L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRibC13cmFwXCIgc3R5bGU9e3sgbWF4SGVpZ2h0OiA1MjAsIG92ZXJmbG93WTogJ2F1dG8nIH19PlxuICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidGJsXCI+XG4gICAgICAgICAgICAgICAgPHRoZWFkIHN0eWxlPXt7IHBvc2l0aW9uOiAnc3RpY2t5JywgdG9wOiAwIH19Pjx0cj48dGg+TcOjIC8gVMOqbiBzw6JuPC90aD48dGg+Q2hpIG5ow6FuaCAmIELhu5kgbcO0bjwvdGg+PHRoPsSQxqFuIGdpw6EgdGhlbyBnaeG7nTwvdGg+PHRoPsSQ4bq3dCBj4buNYzwvdGg+PHRoPlRy4bqhbmcgdGjDoWk8L3RoPjx0aCBjbGFzc05hbWU9XCJyXCI+VGhhbyB0w6FjPC90aD48L3RyPjwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAge2xpc3QubWFwKChjKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGwgPSBsb2NrT2YoYy5pZClcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtjLmlkfSBjbGFzc05hbWU9e2wgPyAnd2Fybi1yb3cnIDogZWRpdElkID09PSBjLmlkID8gJ2hsJyA6ICcnfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD48ZGl2IGNsYXNzTmFtZT1cIm1vbm8gdzgwMFwiIHN0eWxlPXt7IGZvbnRTaXplOiAxMS4xIH19PntjLmlkfTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwidzcwMCBjLXM4MDBcIj57Yy5uYW1lfTwvZGl2PjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+PGRpdiBjbGFzc05hbWU9XCJ3NzAwIGMtYnJhbmQ4XCI+e2JOYW1lKGMuYnJhbmNoSWQpfTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiYy1zNjAwXCI+e3Nwb3J0T2YoYy5zcG9ydCkuZGV0YWlsfTwvZGl2PjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+PGRpdj4wNWgtMTZoOiA8Yj57ZihjLnByaWNlTm9ybWFsKX3EkS9oPC9iPjwvZGl2PjxkaXY+MTZoLTIzaDogPGI+e2YoYy5wcmljZVBlYWspfcSRL2g8L2I+PC9kaXY+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD48YiBjbGFzc05hbWU9XCJ3ODAwXCI+e2MuZGVwb3NpdH0lPC9iPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+eyFjLmFjdGl2ZSA/IDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGItZ3JheVwiPk5n4burbmcgaG/huqF0IMSR4buZbmc8L3NwYW4+IDogbCA/IDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLWFtYmVyLTIwMCknLCBjb2xvcjogJ3ZhcigtLWFtYmVyLTk1MCknIH19PsSQYW5nIGLhuqNvIHRyw6w8L3NwYW4+IDogPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYi1ncmVlblwiPsSQYW5nIG3hu588L3NwYW4+fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiclwiPntsXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXdhcm4tbyBidG4tc21cIiBvbkNsaWNrPXsoKSA9PiB7IHNldExvY2tzKChscykgPT4gbHMuZmlsdGVyKCh4KSA9PiB4LmNvdXJ0SWQgIT09IGMuaWQpKTsgdG9hc3QoYMSQw6MgbeG7nyBs4bqhaSAke2MubmFtZX0uYCwgJ29rJykgfX0+TeG7nyBs4bqhaSBzw6JuPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUgYnRuLXNtXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1icmFuZC04MDApJyB9fSBvbkNsaWNrPXsoKSA9PiBlZGl0KGMpfT5D4bqtcCBuaOG6rXQ8L2J1dHRvbj59PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpbnQgaGludC1ncmVlblwiIHN0eWxlPXt7IHBhZGRpbmc6IDE0IH19PvCfkqEgS2hpIHRoYXkgxJHhu5VpIGLhuqNuZyBnacOhIHRodcOqIGhv4bq3YyBt4bupYyDEkeG6t3QgY+G7jWMsIG3hu6ljIGdpw6EgbeG7m2kgc+G6vSDDoXAgZOG7pW5nIGNobyBjw6FjIMSRxqFuIMSR4bq3dCBzw6JuIHBow6F0IHNpbmggc2F1IHRo4budaSDEkWnhu4NtIGzGsHU7IGPDoWMgxJHGoW4ga2jDoWNoIMSRw6MgxJHhurd0IHRyxrDhu5tjIMSRw7MgduG6q24gxJHGsOG7o2MgZ2nhu68gbmd1ecOqbiBt4bupYyBnacOhIGJhbiDEkeG6p3UuPC9kaXY+XG4gICAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInNwYW41IGNhcmQgY2FyZC1sZyBjYXJkLXJhaXNlIGNvbCBnMTZcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gaGVhZC1ydWxlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sXCIgc3R5bGU9e3sgZ2FwOiAxLjUsIHBhZGRpbmdUb3A6IDUuNSB9fT48c3BhbiBjbGFzc05hbWU9XCJleWVicm93XCI+VGjDtG5nIHRpbiBzw6JuIHRoaSDEkeG6pXU8L3NwYW4+PGgzIGNsYXNzTmFtZT1cInQxNiB3ODAwIGMtaW5rXCIgc3R5bGU9e3sgbGluZUhlaWdodDogJzI0cHgnIH19PntlZGl0SWQgPyAnQ2jhu4luaCBz4butYSBzw6JuJyA6ICdUaMOqbSBzw6JuIG3hu5tpJ308L2gzPjwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBzcSBiLWdyYXkgbW9ub1wiIHN0eWxlPXt7IGZvbnRTaXplOiAxMS4zLCBmb250V2VpZ2h0OiA4MDAsIGNvbG9yOiAndmFyKC0tczkwMCknIH19PntlZGl0SWQgPz8gJ1NBTl9N4buaSSd9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJjb2wgZzE0XCIgb25TdWJtaXQ9eyhlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgc2F2ZSgpIH19PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTJcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiAnZmxleC1zdGFydCcgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmMVwiPjxsYWJlbCBjbGFzc05hbWU9XCJsYWJlbFwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogNCB9fT5Uw6puIHPDom4gdGhpIMSR4bqldSAqPC9sYWJlbD48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiB2YWx1ZT17Zm9ybS5uYW1lfSBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KX0gLz48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImYxXCI+PGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiA0IH19PlRodeG7mWMgY2hpIG5ow6FuaCAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwic2VsZWN0IHNtXCIgdmFsdWU9e2Zvcm0uYnJhbmNoSWR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGJyYW5jaElkOiBlLnRhcmdldC52YWx1ZSB9KX0+e2JyYW5jaGVzLm1hcCgoYikgPT4gPG9wdGlvbiBrZXk9e2IuaWR9IHZhbHVlPXtiLmlkfT57Yi5uYW1lfTwvb3B0aW9uPil9PC9zZWxlY3Q+PC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTJcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiAnZmxleC1zdGFydCcgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmMVwiPjxsYWJlbCBjbGFzc05hbWU9XCJsYWJlbFwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogNCB9fT5C4buZIG3DtG4gdGjhu4MgdGhhbyAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwic2VsZWN0IHNtXCIgdmFsdWU9e2Zvcm0uc3BvcnR9IGRpc2FibGVkPXshIWVkaXRJZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgc3BvcnQ6IGUudGFyZ2V0LnZhbHVlIGFzIFNwb3J0S2V5IH0pfT57U1BPUlRTLm1hcCgocykgPT4gPG9wdGlvbiBrZXk9e3Mua2V5fSB2YWx1ZT17cy5rZXl9PntzLmRldGFpbH08L29wdGlvbj4pfTwvc2VsZWN0PjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjFcIj48bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDQgfX0+VOG7tyBs4buHIMSR4bq3dCBj4buNYyBnaeG7ryBzw6JuICglKSAqPC9sYWJlbD48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWJyYW5kLTcwMCknLCBmb250V2VpZ2h0OiA4MDAgfX0gdHlwZT1cIm51bWJlclwiIG1pbj17MH0gbWF4PXsxMDB9IHZhbHVlPXtmb3JtLmRlcG9zaXR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGRlcG9zaXQ6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSl9IC8+PC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnOFwiIHN0eWxlPXt7IHBhZGRpbmdUb3A6IDQgfX0+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCIgc3R5bGU9e3sgbWFyZ2luOiAwIH19PkLhuqNuZyBnacOhIHRodcOqIHRoZW8ga2h1bmcgZ2nhu50gKFZOxJAvZ2nhu50pICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGcxMFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1zMTAwKScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1zMzAwKScsIGJvcmRlclJhZGl1czogMTIsIHBhZGRpbmc6IDEyIH19PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmMVwiPjxzcGFuIGNsYXNzTmFtZT1cInQxMSB3NjAwIGMtczYwMFwiPkdp4budIHRoxrDhu51uZyAoMDY6MDAgLSAxNjowMCk8L3NwYW4+PGlucHV0IGNsYXNzTmFtZT1cImlucHV0IHNtIGJvbGRcIiB0eXBlPVwibnVtYmVyXCIgbWluPXswfSBzdGVwPXsxMDAwfSB2YWx1ZT17Zm9ybS5wcmljZU5vcm1hbH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgcHJpY2VOb3JtYWw6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSl9IHN0eWxlPXt7IG1hcmdpblRvcDogNCB9fSAvPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmMVwiPjxzcGFuIGNsYXNzTmFtZT1cInQxMSB3NjAwIGMtczYwMFwiPkdp4budIGNhbyDEkWnhu4NtICgxNjowMCAtIDIyOjAwKTwvc3Bhbj48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiBzdHlsZT17eyBtYXJnaW5Ub3A6IDQsIGNvbG9yOiAndmFyKC0tYnJhbmQtNzAwKScsIGZvbnRXZWlnaHQ6IDgwMCB9fSB0eXBlPVwibnVtYmVyXCIgbWluPXswfSBzdGVwPXsxMDAwfSB2YWx1ZT17Zm9ybS5wcmljZVBlYWt9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHByaWNlUGVhazogTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSB9KX0gLz48L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+PGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiA0IH19PlRy4bqhbmcgdGjDoWkgbmjhuq1uIGzhu4tjaDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJzZWxlY3Qgc21cIiB2YWx1ZT17Zm9ybS5hY3RpdmUgPyAnMScgOiAnMCd9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGFjdGl2ZTogZS50YXJnZXQudmFsdWUgPT09ICcxJyB9KX0+PG9wdGlvbiB2YWx1ZT1cIjFcIj7EkGFuZyBob+G6oXQgxJHhu5luZzwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCIwXCI+Tmfhu6tuZyBob+G6oXQgxJHhu5luZzwvb3B0aW9uPjwvc2VsZWN0PjwvZGl2PlxuICAgICAgICAgICAgICB7ZXJyICYmIDxwIGNsYXNzTmFtZT1cImZpZWxkLWVyclwiPntlcnJ9PC9wPn1cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzhcIj48YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tbWQgZjFcIiB0eXBlPVwic3VibWl0XCI+TMawdSB0aMO0bmcgdGluIHPDom48L2J1dHRvbj57ZWRpdElkICYmIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1tZFwiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtyZXNldH0+VGjDqm0gc8OibiBt4bubaTwvYnV0dG9uPn08L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2FzaWRlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHt0YWIgPT09IDIgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQxMlwiPlxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYW43IGNhcmQgY29sIGcxNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzJcIj48aDIgY2xhc3NOYW1lPVwidDE0IHc4MDAgYy1pbmtcIj5HaeG7nSBt4bufIGPhu61hIHRoZW8gY2hpIG5ow6FuaDwvaDI+PHNwYW4gY2xhc3NOYW1lPVwidDEyIGMtczYwMFwiPktodW5nIGdp4budIG7DoHkgcXV54bq/dCDEkeG7i25oIGLhuqNuZyBs4buLY2gga2jDoWNoIGPDsyB0aOG7gyDEkeG6t3QgdHLhu7FjIHR1eeG6v24uPC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzEyXCI+XG4gICAgICAgICAgICAgIHticmFuY2hlcy5tYXAoKGIpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17Yi5pZH0gY2xhc3NOYW1lPVwicm93IGJldHdlZW4gZzEyIHdyYXAgaGludFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE0IH19PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2xcIj48YiBjbGFzc05hbWU9XCJ0MTIgYy1pbmtcIj57Yi5uYW1lfTwvYj48c3BhbiBjbGFzc05hbWU9XCJ0MTEgYy1zNjAwXCI+e2NvdXJ0cy5maWx0ZXIoKGMpID0+IGMuYnJhbmNoSWQgPT09IGIuaWQpLmxlbmd0aH0gc8OibiDigKIge2IuYWRkcmVzcy5zcGxpdCgnLCcpWzBdfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGc4XCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGltZVwiIGNsYXNzTmFtZT1cImlucHV0IHNtXCIgc3R5bGU9e3sgd2lkdGg6ICdhdXRvJyB9fSB2YWx1ZT17Yi5vcGVufSBvbkNoYW5nZT17KGUpID0+IHNldEJyYW5jaGVzKChicykgPT4gYnMubWFwKCh4KSA9PiAoeC5pZCA9PT0gYi5pZCA/IHsgLi4ueCwgb3BlbjogZS50YXJnZXQudmFsdWUgfSA6IHgpKSl9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj7EkeG6v248L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGltZVwiIGNsYXNzTmFtZT1cImlucHV0IHNtXCIgc3R5bGU9e3sgd2lkdGg6ICdhdXRvJyB9fSB2YWx1ZT17Yi5jbG9zZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRCcmFuY2hlcygoYnMpID0+IGJzLm1hcCgoeCkgPT4gKHguaWQgPT09IGIuaWQgPyB7IC4uLngsIGNsb3NlOiBlLnRhcmdldC52YWx1ZSB9IDogeCkpKX0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLW1kXCIgc3R5bGU9e3sgYWxpZ25TZWxmOiAnZmxleC1zdGFydCcgfX0gb25DbGljaz17KCkgPT4gdG9hc3QoJ8SQw6MgbMawdSBnaeG7nSBt4bufIGPhu61hIGPDoWMgY2hpIG5ow6FuaC4nLCAnb2snKX0+TMawdSBnaeG7nSBt4bufIGPhu61hPC9idXR0b24+XG4gICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJzcGFuNSBjYXJkIGNhcmQtbGcgY2FyZC1yYWlzZSBjb2wgZzE2XCIgc3R5bGU9e3sgcGFkZGluZzogMjAgfX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBoZWFkLXJ1bGVcIiBzdHlsZT17eyBnYXA6IDIgfX0+PHNwYW4gY2xhc3NOYW1lPVwiZXllYnJvd1wiPkzhu4tjaCBuZ2jhu4kgbOG7hTwvc3Bhbj48aDMgY2xhc3NOYW1lPVwidDE2IHc4MDAgYy1pbmtcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMjRweCcgfX0+TmfDoHkgxJHDs25nIGPhu61hIHRvw6BuIGjhu4cgdGjhu5FuZzwvaDM+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnOFwiPlxuICAgICAgICAgICAgICB7aG9saWRheXMubGVuZ3RoID09PSAwICYmIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj5DaMawYSBjw7MgbmfDoHkgbmdo4buJIGzhu4UgbsOgby48L3A+fVxuICAgICAgICAgICAgICB7aG9saWRheXMubWFwKChoKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2guaWR9IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuIGhpbnRcIiBzdHlsZT17eyBwYWRkaW5nOiAxMiB9fT48ZGl2IGNsYXNzTmFtZT1cImNvbFwiPjxiIGNsYXNzTmFtZT1cImMtaW5rXCI+e3RvVk4oaC5kYXRlKX08L2I+PHNwYW4+e2gubm90ZX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tZGFuZ2VyLW8gYnRuLXhzXCIgb25DbGljaz17KCkgPT4gc2V0SG9saWRheXMoKGhzKSA9PiBocy5maWx0ZXIoKHgpID0+IHguaWQgIT09IGguaWQpKX0+WMOzYTwvYnV0dG9uPjwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiY29sIGcxMFwiIG9uU3VibWl0PXsoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IGlmICghaG9sLmRhdGUpIHJldHVybiB0b2FzdCgnVnVpIGzDsm5nIGNo4buNbiBuZ8OgeSBuZ2jhu4kuJywgJ2VycicpOyBzZXRIb2xpZGF5cygoaHMpID0+IFsuLi5ocywgeyBpZDogYEgke0RhdGUubm93KCl9YCwgZGF0ZTogaG9sLmRhdGUsIG5vdGU6IGhvbC5ub3RlIHx8ICdOZ2jhu4kgbOG7hScgfV0pOyBzZXRIb2woeyBkYXRlOiAnJywgbm90ZTogJycgfSkgfX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGc4XCI+PGlucHV0IGNsYXNzTmFtZT1cImlucHV0IHNtXCIgdHlwZT1cImRhdGVcIiBtaW49e1RPREFZfSB2YWx1ZT17aG9sLmRhdGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0SG9sKHsgLi4uaG9sLCBkYXRlOiBlLnRhcmdldC52YWx1ZSB9KX0gLz48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiBzdHlsZT17eyBmb250V2VpZ2h0OiA1MDAgfX0gcGxhY2Vob2xkZXI9XCJHaGkgY2jDuiAodmQ6IE5naOG7iSBU4bq/dClcIiB2YWx1ZT17aG9sLm5vdGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0SG9sKHsgLi4uaG9sLCBub3RlOiBlLnRhcmdldC52YWx1ZSB9KX0gLz48L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLW1kXCI+KyBUaMOqbSBuZ8OgeSBuZ2jhu4k8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2FzaWRlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHt0YWIgPT09IDMgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQxMlwiPlxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYW43IGNhcmQgY29sIGcxNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzJcIj48aDIgY2xhc3NOYW1lPVwidDE0IHc4MDAgYy1pbmtcIj5Dw6FjIHPDom4gxJFhbmcgdOG6oW0ga2jDs2EgYuG6o28gdHLDrDwvaDI+PHNwYW4gY2xhc3NOYW1lPVwidDEyIGMtczYwMFwiPlPDom4gYuG7iyBraMOzYSBz4bq9IGtow7RuZyBuaOG6rW4gbOG7i2NoIMSR4bq3dCB0cm9uZyBraG/huqNuZyB0aOG7nWkgZ2lhbiBi4bqjbyB0csOsLjwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgIHtsb2Nrcy5sZW5ndGggPT09IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJoaW50XCIgc3R5bGU9e3sgdGV4dEFsaWduOiAnY2VudGVyJywgcGFkZGluZzogMjQgfX0+SGnhu4duIGtow7RuZyBjw7Mgc8OibiBuw6BvIMSRYW5nIGLhuqNvIHRyw6wuPC9kaXY+fVxuICAgICAgICAgICAge2xvY2tzLm1hcCgobCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBjID0gY291cnRzLmZpbmQoKHgpID0+IHguaWQgPT09IGwuY291cnRJZClcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17bC5pZH0gY2xhc3NOYW1lPVwicm93IGJldHdlZW4gZzEyXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLWFtYmVyLTUwKScsIGJvcmRlcjogJzJweCBzb2xpZCB2YXIoLS1hbWJlci00MDApJywgYm9yZGVyUmFkaXVzOiAxMiwgcGFkZGluZzogMTQgfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnMlwiPjxiIGNsYXNzTmFtZT1cInQxMiBjLWlua1wiPntjPy5uYW1lfSDigKIge2MgJiYgYk5hbWUoYy5icmFuY2hJZCl9PC9iPjxzcGFuIGNsYXNzTmFtZT1cInQxMiBjLXM3MDBcIj57bC5mcm9tLnNsaWNlKDgsIDEwKX0ve2wuZnJvbS5zbGljZSg1LCA3KX0ge2wuZnJvbS5zbGljZSgxMSl9IOKGkiB7bC50by5zbGljZSg4LCAxMCl9L3tsLnRvLnNsaWNlKDUsIDcpfSB7bC50by5zbGljZSgxMSl9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInQxMSBjLWFtYmVyXCI+e2wucmVhc29ufTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi13YXJuLW8gYnRuLXNtXCIgb25DbGljaz17KCkgPT4geyBzZXRMb2NrcygobHMpID0+IGxzLmZpbHRlcigoeCkgPT4geC5pZCAhPT0gbC5pZCkpOyB0b2FzdChgxJDDoyBt4bufIGzhuqFpICR7Yz8ubmFtZX0uYCwgJ29rJykgfX0+TeG7nyBs4bqhaSBzw6JuPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwic3BhbjUgY2FyZCBjYXJkLWxnIGNhcmQtcmFpc2UgY29sIGcxNlwiIHN0eWxlPXt7IHBhZGRpbmc6IDIwIH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgaGVhZC1ydWxlXCIgc3R5bGU9e3sgZ2FwOiAyIH19PjxzcGFuIGNsYXNzTmFtZT1cImV5ZWJyb3dcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWFtYmVyLTgwMCknIH19PlThuqFtIGtow7NhIHPDom48L3NwYW4+PGgzIGNsYXNzTmFtZT1cInQxNiB3ODAwIGMtaW5rXCIgc3R5bGU9e3sgbGluZUhlaWdodDogJzI0cHgnIH19PkzDqm4gbOG7i2NoIGLhuqNvIHRyw6wgc8OibjwvaDM+PC9kaXY+XG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJjb2wgZzE0XCIgb25TdWJtaXQ9eyhlKSA9PiB7XG4gICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICAgICAgICBpZiAoIWxrLmNvdXJ0SWQpIHJldHVybiB0b2FzdCgnVnVpIGzDsm5nIGNo4buNbiBzw6JuIGPhuqduIGtow7NhLicsICdlcnInKVxuICAgICAgICAgICAgICBpZiAoIWxrLmZyb20gfHwgIWxrLnRvIHx8IGxrLnRvIDw9IGxrLmZyb20pIHJldHVybiB0b2FzdCgnVGjhu51pIGdpYW4ga+G6v3QgdGjDumMgcGjhuqNpIHNhdSB0aOG7nWkgZ2lhbiBi4bqvdCDEkeG6p3UuJywgJ2VycicpXG4gICAgICAgICAgICAgIHNldExvY2tzKChscykgPT4gWy4uLmxzLCB7IGlkOiBgTCR7RGF0ZS5ub3coKX1gLCAuLi5sayB9XSk7IHRvYXN0KCfEkMOjIHThuqFtIGtow7NhIHPDom4uIEPDoWMgw7QgZ2nhu50gdHJvbmcga2hv4bqjbmcgbsOgeSBz4bq9IGhp4buDbiB0aOG7iyBcIkLhuqNvIHRyw6xcIi4nLCAnb2snKVxuICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgIDxkaXY+PGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiA0IH19PlPDom4gY+G6p24ga2jDs2EgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJzZWxlY3Qgc21cIiB2YWx1ZT17bGsuY291cnRJZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRMayh7IC4uLmxrLCBjb3VydElkOiBlLnRhcmdldC52YWx1ZSB9KX0+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+4oCUIENo4buNbiBzw6JuIOKAlDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAge2NvdXJ0cy5maWx0ZXIoKGMpID0+IGJyYW5jaEZpbHRlciA9PT0gJ2FsbCcgfHwgYy5icmFuY2hJZCA9PT0gYnJhbmNoRmlsdGVyKS5tYXAoKGMpID0+IDxvcHRpb24ga2V5PXtjLmlkfSB2YWx1ZT17Yy5pZH0+e2MubmFtZX0g4oCTIHtiTmFtZShjLmJyYW5jaElkKX08L29wdGlvbj4pfVxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PjwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTJcIj48ZGl2IGNsYXNzTmFtZT1cImYxXCI+PGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiA0IH19PlThu6sgKjwvbGFiZWw+PGlucHV0IGNsYXNzTmFtZT1cImlucHV0IHNtXCIgdHlwZT1cImRhdGV0aW1lLWxvY2FsXCIgdmFsdWU9e2xrLmZyb219IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TGsoeyAuLi5saywgZnJvbTogZS50YXJnZXQudmFsdWUgfSl9IC8+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmMVwiPjxsYWJlbCBjbGFzc05hbWU9XCJsYWJlbFwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogNCB9fT7EkOG6v24gKjwvbGFiZWw+PGlucHV0IGNsYXNzTmFtZT1cImlucHV0IHNtXCIgdHlwZT1cImRhdGV0aW1lLWxvY2FsXCIgdmFsdWU9e2xrLnRvfSBvbkNoYW5nZT17KGUpID0+IHNldExrKHsgLi4ubGssIHRvOiBlLnRhcmdldC52YWx1ZSB9KX0gLz48L2Rpdj48L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj48bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDQgfX0+TMO9IGRvIGLhuqNvIHRyw6w8L2xhYmVsPjxpbnB1dCBjbGFzc05hbWU9XCJpbnB1dCBzbVwiIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDUwMCB9fSB2YWx1ZT17bGsucmVhc29ufSBvbkNoYW5nZT17KGUpID0+IHNldExrKHsgLi4ubGssIHJlYXNvbjogZS50YXJnZXQudmFsdWUgfSl9IC8+PC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1kYW5nZXIgYnRuLW1kXCI+VOG6oW0ga2jDs2Egc8OibjwvYnV0dG9uPlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgIDwvYXNpZGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8Lz5cbiAgKVxufVxuIl19