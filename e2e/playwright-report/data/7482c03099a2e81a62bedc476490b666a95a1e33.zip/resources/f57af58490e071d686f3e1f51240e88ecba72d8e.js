import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Booking.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { ONLINE_SLOTS, SPORTS, TODAY, dow, evalPromo, hh, money, rateAt, slotPrice, toVN, vnd } from "/src/data.ts";
import { useApp } from "/src/store.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/Booking.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
export default function Booking() {
	_s();
	const { courts, branches, promos, setPromos, blocker, lockAt, holidays, addBooking, user, toast } = useApp();
	const nav = useNavigate();
	const [sp] = useSearchParams();
	const [branchId, setBranchId] = useState(sp.get("branch") || "cs1");
	const [sport, setSport] = useState(sp.get("sport") || "pickleball");
	const [date, setDate] = useState(sp.get("date") || TODAY);
	const [sel, setSel] = useState(null);
	const [code, setCode] = useState(sp.get("promo") || "");
	const [applied, setApplied] = useState(sp.get("promo"));
	const [payMode, setPayMode] = useState("deposit");
	const branch = branches.find((b) => b.id === branchId);
	const branchCourts = courts.filter((c) => c.branchId === branchId && c.active);
	const sportsHere = SPORTS.filter((s) => branchCourts.some((c) => c.sport === s.key));
	useEffect(() => {
		if (!sportsHere.some((s) => s.key === sport) && sportsHere[0]) setSport(sportsHere[0].key);
	}, [branchId]);
	const rows = branchCourts.filter((c) => c.sport === sport);
	const holiday = holidays.find((h) => h.date === date);
	const past = date < TODAY;
	const spInfo = SPORTS.find((s) => s.key === sport);
	const pick = (courtId, idx) => setSel({
		courtId,
		idx
	});
	const selCourt = sel ? courts.find((c) => c.id === sel.courtId) : undefined;
	const selSlot = sel ? ONLINE_SLOTS[sel.idx] : undefined;
	const stillValid = !!(sel && selCourt && rows.some((c) => c.id === sel.courtId) && !blocker(sel.courtId, date, selSlot.start, selSlot.end) && !lockAt(sel.courtId, date, selSlot.start, selSlot.end));
	const active = stillValid && selCourt && selSlot ? {
		court: selCourt,
		slot: selSlot
	} : null;
	const base = active ? slotPrice(active.court, active.slot) : 0;
	const promoRes = active && applied ? evalPromo(promos.find((p) => p.code === applied), active.court, date, active.slot, base) : null;
	const off = promoRes?.ok ? promoRes.off : 0;
	const total = base - off;
	const pct = active?.court.deposit ?? 30;
	const deposit = Math.round(total * pct / 100);
	const dueNow = payMode === "full" ? total : deposit;
	const apply = (c = code) => {
		const v = c.trim().toUpperCase();
		if (!v) return toast("Vui lòng nhập mã giảm giá.", "err");
		setCode(v);
		setApplied(v);
	};
	const clearPromo = () => {
		setApplied(null);
		setCode("");
	};
	const submit = () => {
		if (!active || !user) return;
		const hold = Date.now() + 10 * 6e4;
		const nb = addBooking({
			customer: user.name,
			phone: user.phone,
			member: true,
			courtId: active.court.id,
			date,
			start: active.slot.start,
			end: active.slot.end,
			subtotal: base,
			discount: off,
			total,
			paid: 0,
			payMode,
			method: "qr",
			source: "online",
			status: "pending",
			promo: promoRes?.ok ? applied : undefined,
			holdUntil: hold
		});
		if (promoRes?.ok) setPromos((ps) => ps.map((p) => p.code === applied ? {
			...p,
			used: p.used + 1
		} : p));
		toast(`Đã giữ chỗ đơn #${nb.id} trong 10 phút.`, "ok");
		nav(`/payment/${nb.id}`);
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
		className: "card card-lg col g16",
		style: { borderRadius: 16 },
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "row between wrap g16",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "col g2",
				children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "t20 w800 c-ink",
					children: "Chọn khung giờ đặt sân trực tuyến"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "t12 c-s600",
					children: "Nhấp vào ô màu trắng (Còn trống) trên bảng lịch bên dưới để chọn khung giờ bạn muốn thuê."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "row g12 wrap",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "legend",
						children: [/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 38
						}, this), "Còn trống"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "legend",
						children: [/* @__PURE__ */ _jsxDEV("i", { className: "sel" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 84
						}, this), "Đang chọn"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 59
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "legend",
						children: [/* @__PURE__ */ _jsxDEV("i", { className: "busy" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 38
						}, this), "Đã có người đặt"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "legend",
						children: [/* @__PURE__ */ _jsxDEV("i", { className: "lock" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 107
						}, this), "Bảo trì / Đóng cửa"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 82
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 66,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "row g16",
			style: { alignItems: "flex-end" },
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "f1",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "label",
						children: "Chi nhánh"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 31
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						className: "select",
						value: branchId,
						onChange: (e) => {
							setBranchId(e.target.value);
							setSel(null);
						},
						children: branches.map((b) => /* @__PURE__ */ _jsxDEV("option", {
							value: b.id,
							children: [
								b.name,
								" (",
								b.open,
								" - ",
								b.close,
								")"
							]
						}, b.id, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 36
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "f1",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "label",
						children: "Bộ môn"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 31
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						className: "select",
						value: sport,
						onChange: (e) => {
							setSport(e.target.value);
							setSel(null);
						},
						children: sportsHere.map((s) => /* @__PURE__ */ _jsxDEV("option", {
							value: s.key,
							children: [
								s.label,
								" (",
								branchCourts.filter((c) => c.sport === s.key).length,
								" sân",
								s.key === "pickleball" ? " mái che" : "",
								")"
							]
						}, s.key, true, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 38
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "f1",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "label",
						children: "Ngày đặt lịch"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 31
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						className: "input",
						type: "date",
						value: date,
						min: TODAY,
						onChange: (e) => {
							setDate(e.target.value || TODAY);
							setSel(null);
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "f1 hint hint-green col g2",
					style: {
						borderColor: "var(--brand-100)",
						background: "var(--brand-50)"
					},
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "w700 c-brand9",
						children: [
							"Đơn giá thuê sân ",
							spInfo.label,
							":"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("b", {
						className: "c-brand8",
						children: rows[0] ? `05h–16h: ${Math.round(rows[0].priceNormal / 1e3)}k/h • 16h–23h: ${Math.round(rows[0].pricePeak / 1e3)}k/h` : "—"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 65,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "grid12",
		children: [/* @__PURE__ */ _jsxDEV("section", {
			className: "span8 card card-lg col g16",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "row between",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "t16 w800 c-ink",
						children: [
							"Lịch sân ",
							dow(date),
							", ",
							toVN(date),
							" – ",
							branch.name.replace(" - ", " ")
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "badge b-green-flat",
						style: { fontSize: 11 },
						children: [
							"Giờ mở cửa: ",
							branch.open,
							" – ",
							branch.close
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 11
				}, this),
				holiday && /* @__PURE__ */ _jsxDEV("div", {
					className: "hint",
					style: {
						background: "var(--amber-50)",
						borderColor: "var(--amber-300)",
						color: "var(--amber-900)"
					},
					children: [
						"📅 ",
						toVN(date),
						" là ngày nghỉ: ",
						holiday.note,
						". Hệ thống không nhận lịch trong ngày này."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 23
				}, this),
				past && /* @__PURE__ */ _jsxDEV("div", {
					className: "hint",
					children: "Không thể đặt lịch cho ngày đã qua."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 20
				}, this),
				/* @__PURE__ */ _jsxDEV("table", {
					className: "sched",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("th", { children: "Sân thi đấu" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 17
					}, this), ONLINE_SLOTS.map((s) => /* @__PURE__ */ _jsxDEV("th", { children: [
						s.start,
						" - ",
						s.end,
						/* @__PURE__ */ _jsxDEV("small", {
							className: hh(s.start) >= 16 && !s.closed ? "peak" : "",
							children: s.closed ? "Đóng cửa" : rows[0] ? `${Math.round(rateAt(rows[0], hh(s.start)) / 1e3)}k/h` : ""
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 21
						}, this)
					] }, s.start, true, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 19
					}, this))] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [rows.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
						colSpan: ONLINE_SLOTS.length + 1,
						className: "closed",
						style: { padding: 24 },
						children: "Chi nhánh chưa có sân cho bộ môn này."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 41
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 37
					}, this), rows.map((c) => {
						const lockedAny = ONLINE_SLOTS.some((s) => !s.closed && lockAt(c.id, date, s.start, s.end));
						const cells = [];
						for (let i = 0; i < ONLINE_SLOTS.length; i++) {
							const s = ONLINE_SLOTS[i];
							if (s.closed || holiday) {
								cells.push(/* @__PURE__ */ _jsxDEV("td", {
									className: "closed",
									children: "Đóng cửa"
								}, i, false, {
									fileName: _jsxFileName,
									lineNumber: 120,
									columnNumber: 57
								}, this));
								continue;
							}
							const lk = lockAt(c.id, date, s.start, s.end);
							if (lk) {
								let span = 1;
								while (i + span < ONLINE_SLOTS.length && !ONLINE_SLOTS[i + span].closed && lockAt(c.id, date, ONLINE_SLOTS[i + span].start, ONLINE_SLOTS[i + span].end)) span++;
								cells.push(/* @__PURE__ */ _jsxDEV("td", {
									colSpan: span,
									className: "locked",
									children: ["🔒 Tạm ngưng nhận lịch để ", lk.reason.toLowerCase()]
								}, i, true, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 32
								}, this));
								i += span - 1;
								continue;
							}
							const bk = blocker(c.id, date, s.start, s.end);
							const price = money(slotPrice(c, s));
							if (bk) {
								cells.push(/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("div", {
									className: "cell busy",
									children: ["Đã đặt", /* @__PURE__ */ _jsxDEV("small", { children: bk.status === "pending" ? "Đang giữ chỗ" : bk.phone === user?.phone || user?.role !== "customer" && bk.phone === "0987654321" ? "Lịch của bạn" : bk.label ?? "Kín lịch" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 131,
										columnNumber: 77
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 44
								}, this) }, i, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 32
								}, this));
							} else if (active && sel?.courtId === c.id && sel.idx === i) {
								cells.push(/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("button", {
									className: "cell sel",
									onClick: () => setSel(null),
									children: ["Đang chọn", /* @__PURE__ */ _jsxDEV("small", { children: price }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 133,
										columnNumber: 111
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 44
								}, this) }, i, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 32
								}, this));
							} else {
								cells.push(/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("button", {
									className: "cell free",
									disabled: past,
									onClick: () => pick(c.id, i),
									children: ["Còn trống", /* @__PURE__ */ _jsxDEV("small", { children: price }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 135,
										columnNumber: 129
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 44
								}, this) }, i, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 32
								}, this));
							}
						}
						return /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "t12 w800 c-ink",
							children: c.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "t11 w600",
							style: { color: lockedAny ? "var(--amber-800)" : "var(--brand-700)" },
							children: ["● ", lockedAny ? "Bảo trì" : "Sẵn sàng"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 23
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 21
						}, this), cells] }, c.id, true, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 19
						}, this);
					})] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "hint row g4 wrap",
					style: { borderRadius: 12 },
					children: [
						"💡 Sau khi nhấn ",
						/* @__PURE__ */ _jsxDEV("b", { children: "\"Tiếp tục thanh toán\"" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 29
						}, this),
						", hệ thống sẽ giữ chỗ tạm thời khung giờ này trong ",
						/* @__PURE__ */ _jsxDEV("b", { children: "10 phút" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 108
						}, this),
						" để bạn hoàn tất chuyển khoản ",
						/* @__PURE__ */ _jsxDEV("b", { children: "QR" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 152
						}, this),
						"."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("aside", {
			className: "span4 card card-lg card-raise col g16",
			style: {
				position: "sticky",
				top: 80
			},
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "col g2 head-rule",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "eyebrow",
					children: "Phiếu đặt sân"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("h2", {
					className: "t16 w800 c-ink",
					style: { lineHeight: "24px" },
					children: "Thông tin lịch đã chọn"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 154,
				columnNumber: 11
			}, this), !active ? /* @__PURE__ */ _jsxDEV("div", {
				className: "hint",
				style: {
					textAlign: "center",
					padding: 24
				},
				children: [
					"Chưa chọn khung giờ. Nhấp vào một ô ",
					/* @__PURE__ */ _jsxDEV("b", { children: "Còn trống" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 116
					}, this),
					" trên bảng lịch để bắt đầu."
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 159,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col g10 t12",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: "Chi nhánh:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 46
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "c-ink",
								children: branch.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 88
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: "Sân thi đấu:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 46
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "c-brand w800",
								children: active.court.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 90
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between g12",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600 nowrap",
								children: "Thời gian thuê:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 50
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "c-ink",
								style: { textAlign: "right" },
								children: [
									toVN(date),
									" • ",
									active.slot.start,
									" - ",
									active.slot.end,
									" (",
									base / rateAt(active.court, hh(active.slot.start)),
									" giờ)"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 104
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 162,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col g8 top-rule",
					style: { paddingTop: 16 },
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "label",
							style: { margin: 0 },
							children: "Mã giảm giá / Ưu đãi hội viên"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g8",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								className: "input sm bold",
								style: {
									padding: "10px 14px",
									fontSize: 14
								},
								value: code,
								placeholder: "Nhập mã ưu đãi",
								onChange: (e) => setCode(e.target.value),
								onKeyDown: (e) => e.key === "Enter" && apply()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-dark btn-md",
								onClick: () => apply(),
								children: "Áp dụng"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g6 wrap",
							children: [promos.filter((p) => !p.counterOnly).slice(0, 2).map((p) => /* @__PURE__ */ _jsxDEV("button", {
								className: `badge ${applied === p.code ? "b-green" : "b-gray-o"}`,
								style: { fontSize: 11 },
								onClick: () => apply(p.code),
								children: [
									p.code,
									" (-",
									p.percent,
									"%)"
								]
							}, p.code, true, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 21
							}, this)), /* @__PURE__ */ _jsxDEV("button", {
								className: "badge b-gray-o",
								style: {
									fontWeight: 500,
									fontSize: 11
								},
								onClick: clearPromo,
								children: "Bỏ chọn"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 17
						}, this),
						promoRes && /* @__PURE__ */ _jsxDEV("p", {
							className: promoRes.ok ? "field-ok" : "field-err",
							children: promoRes.msg
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 30
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 167,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col g8 top-rule",
					style: { paddingTop: 16 },
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "label",
						style: { margin: 0 },
						children: "Phương thức giữ sân"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 17
					}, this), [[
						"deposit",
						`Đặt cọc giữ sân (${pct}%)`,
						deposit,
						`Thanh toán trước ${pct}% để giữ lịch. Phần còn lại thanh toán tại quầy khi đến nhận sân.`
					], [
						"full",
						"Thanh toán đủ 100%",
						total,
						"Tất toán toàn bộ đơn đặt sân, đến giờ vào sân chơi ngay."
					]].map(([k, t, amt, d]) => /* @__PURE__ */ _jsxDEV("label", {
						className: `radio-card${payMode === k ? " on" : ""}`,
						style: {
							alignItems: "flex-start",
							padding: payMode === k ? 11 : 12,
							borderRadius: 12
						},
						children: [/* @__PURE__ */ _jsxDEV("input", {
							type: "radio",
							name: "paymode",
							checked: payMode === k,
							onChange: () => setPayMode(k),
							style: { marginTop: 3 }
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "col g2 f1",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "row between",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "t12 w800 c-ink",
									children: t
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 186,
									columnNumber: 77
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "t12 w800 c-ink",
									children: vnd(amt)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 186,
									columnNumber: 120
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 48
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "t11 c-s600",
								style: {
									fontWeight: 400,
									lineHeight: "15px"
								},
								children: d
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 23
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 21
						}, this)]
					}, k, true, {
						fileName: _jsxFileName,
						lineNumber: 184,
						columnNumber: 19
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "hint col g8",
					style: { padding: 14 },
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: "Giá thuê sân gốc:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 192,
								columnNumber: 46
							}, this), /* @__PURE__ */ _jsxDEV("b", { children: vnd(base) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 192,
								columnNumber: 95
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: "Ưu đãi giảm giá:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 46
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "c-brand",
								children: off ? `- ${vnd(off)}` : "0 VNĐ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 94
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between top-rule",
							style: { paddingTop: 8 },
							children: [/* @__PURE__ */ _jsxDEV("b", {
								className: "c-ink",
								children: "Tổng tiền sau giảm:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 81
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "c-ink",
								children: vnd(total)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 125
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 194,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between",
							children: [/* @__PURE__ */ _jsxDEV("b", {
								className: "c-brand t14",
								children: "Cần thanh toán ngay:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 46
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "c-brand t16",
								children: vnd(dueNow)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 97
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 195,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row between t11",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: "Thanh toán thêm khi nhận sân:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 50
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "c-s600",
								children: vnd(total - dueNow)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 111
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					className: "btn btn-primary btn-lg btn-block",
					onClick: submit,
					children: "Tiếp tục thanh toán QR →"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 15
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 161,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 153,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 94,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 5
	}, this);
}
_s(Booking, "briqAFNDmQy8vQwHJcC6jNjtzig=", false, function() {
	return [
		useApp,
		useNavigate,
		useSearchParams
	];
});
_c = Booking;
var _c;
$RefreshReg$(_c, "Booking");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Booking.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/Booking.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/Booking.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/Booking.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGFBQWEsdUJBQXVCO0FBQzdDLFNBQVMsY0FBYyxRQUFRLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxRQUFRLFdBQVcsTUFBTSxXQUFXO0FBRXJHLFNBQVMsY0FBYzs7OztBQUV2QixlQUFlLFNBQVMsVUFBVTs7Q0FDaEMsTUFBTSxFQUFFLFFBQVEsVUFBVSxRQUFRLFdBQVcsU0FBUyxRQUFRLFVBQVUsWUFBWSxNQUFNLFVBQVUsT0FBTztDQUMzRyxNQUFNLE1BQU0sWUFBWTtDQUN4QixNQUFNLENBQUMsTUFBTSxnQkFBZ0I7Q0FFN0IsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEdBQUcsSUFBSSxRQUFRLEtBQUssS0FBSztDQUNsRSxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQW9CLEdBQUcsSUFBSSxPQUFPLEtBQWtCLFlBQVk7Q0FDMUYsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEdBQUcsSUFBSSxNQUFNLEtBQUssS0FBSztDQUN4RCxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQWtELElBQUk7Q0FDNUUsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEdBQUcsSUFBSSxPQUFPLEtBQUssRUFBRTtDQUN0RCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQXdCLEdBQUcsSUFBSSxPQUFPLENBQUM7Q0FDckUsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUE2QixTQUFTO0NBRXBFLE1BQU0sU0FBUyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sUUFBUTtDQUNyRCxNQUFNLGVBQWUsT0FBTyxRQUFRLE1BQU0sRUFBRSxhQUFhLFlBQVksRUFBRSxNQUFNO0NBQzdFLE1BQU0sYUFBYSxPQUFPLFFBQVEsTUFBTSxhQUFhLE1BQU0sTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUM7Q0FDbkYsZ0JBQWdCO0VBQUUsSUFBSSxDQUFDLFdBQVcsTUFBTSxNQUFNLEVBQUUsUUFBUSxLQUFLLEtBQUssV0FBVyxJQUFJLFNBQVMsV0FBVyxFQUFFLENBQUMsR0FBRztDQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FDMUgsTUFBTSxPQUFPLGFBQWEsUUFBUSxNQUFNLEVBQUUsVUFBVSxLQUFLO0NBQ3pELE1BQU0sVUFBVSxTQUFTLE1BQU0sTUFBTSxFQUFFLFNBQVMsSUFBSTtDQUNwRCxNQUFNLE9BQU8sT0FBTztDQUNwQixNQUFNLFNBQVMsT0FBTyxNQUFNLE1BQU0sRUFBRSxRQUFRLEtBQUs7Q0FFakQsTUFBTSxRQUFRLFNBQWlCLFFBQWdCLE9BQU87RUFBRTtFQUFTO0NBQUksQ0FBQztDQUN0RSxNQUFNLFdBQThCLE1BQU0sT0FBTyxNQUFNLE1BQU0sRUFBRSxPQUFPLElBQUksT0FBTyxJQUFJO0NBQ3JGLE1BQU0sVUFBVSxNQUFNLGFBQWEsSUFBSSxPQUFPO0NBQzlDLE1BQU0sYUFBYSxDQUFDLEVBQUUsT0FBTyxZQUFZLEtBQUssTUFBTSxNQUFNLEVBQUUsT0FBTyxJQUFJLE9BQU8sS0FBSyxDQUFDLFFBQVEsSUFBSSxTQUFTLE1BQU0sUUFBUyxPQUFPLFFBQVMsR0FBRyxLQUFLLENBQUMsT0FBTyxJQUFJLFNBQVMsTUFBTSxRQUFTLE9BQU8sUUFBUyxHQUFHO0NBQ3ZNLE1BQU0sU0FBUyxjQUFjLFlBQVksVUFBVTtFQUFFLE9BQU87RUFBVSxNQUFNO0NBQVEsSUFBSTtDQUV4RixNQUFNLE9BQU8sU0FBUyxVQUFVLE9BQU8sT0FBTyxPQUFPLElBQUksSUFBSTtDQUM3RCxNQUFNLFdBQVcsVUFBVSxVQUFVLFVBQVUsT0FBTyxNQUFNLE1BQU0sRUFBRSxTQUFTLE9BQU8sR0FBRyxPQUFPLE9BQU8sTUFBTSxPQUFPLE1BQU0sSUFBSSxJQUFJO0NBQ2hJLE1BQU0sTUFBTSxVQUFVLEtBQUssU0FBUyxNQUFNO0NBQzFDLE1BQU0sUUFBUSxPQUFPO0NBQ3JCLE1BQU0sTUFBTSxRQUFRLE1BQU0sV0FBVztDQUNyQyxNQUFNLFVBQVUsS0FBSyxNQUFPLFFBQVEsTUFBTyxHQUFHO0NBQzlDLE1BQU0sU0FBUyxZQUFZLFNBQVMsUUFBUTtDQUU1QyxNQUFNLFNBQVMsSUFBSSxTQUFTO0VBQzFCLE1BQU0sSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDL0IsSUFBSSxDQUFDLEdBQUcsT0FBTyxNQUFNLDhCQUE4QixLQUFLO0VBQ3hELFFBQVEsQ0FBQztFQUFHLFdBQVcsQ0FBQztDQUMxQjtDQUNBLE1BQU0sbUJBQW1CO0VBQUUsV0FBVyxJQUFJO0VBQUcsUUFBUSxFQUFFO0NBQUU7Q0FFekQsTUFBTSxlQUFlO0VBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTTtFQUN0QixNQUFNLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSztFQUMvQixNQUFNLEtBQUssV0FBVztHQUNwQixVQUFVLEtBQUs7R0FBTSxPQUFPLEtBQUs7R0FBTyxRQUFRO0dBQU0sU0FBUyxPQUFPLE1BQU07R0FBSTtHQUNoRixPQUFPLE9BQU8sS0FBSztHQUFPLEtBQUssT0FBTyxLQUFLO0dBQUssVUFBVTtHQUFNLFVBQVU7R0FBSztHQUFPLE1BQU07R0FBRztHQUMvRixRQUFRO0dBQU0sUUFBUTtHQUFVLFFBQVE7R0FBVyxPQUFPLFVBQVUsS0FBSyxVQUFXO0dBQVcsV0FBVztFQUM1RyxDQUFDO0VBQ0QsSUFBSSxVQUFVLElBQUksV0FBVyxPQUFPLEdBQUcsS0FBSyxNQUFPLEVBQUUsU0FBUyxVQUFVO0dBQUUsR0FBRztHQUFHLE1BQU0sRUFBRSxPQUFPO0VBQUUsSUFBSSxDQUFFLENBQUM7RUFDeEcsTUFBTSxtQkFBbUIsR0FBRyxHQUFHLGtCQUFrQixJQUFJO0VBQ3JELElBQUksWUFBWSxHQUFHLElBQUk7Q0FDekI7Q0FFQSxPQUNFLGdEQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO0VBQXVCLE9BQU8sRUFBRSxjQUFjLEdBQUc7WUFBcEUsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWlCO0lBQXFDOzs7O2NBQ3BFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWE7SUFBNEY7Ozs7WUFDbkg7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUF5Qix3QkFBQyxLQUFELENBQUk7Ozs7Z0JBQUMsV0FBZTs7Ozs7O0tBQUMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQXlCLHdCQUFDLEtBQUQsRUFBRyxXQUFVLE1BQU87Ozs7Z0JBQUMsV0FBZTs7Ozs7O0tBQzNHLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUF5Qix3QkFBQyxLQUFELEVBQUcsV0FBVSxPQUFROzs7O2dCQUFDLGlCQUFxQjs7Ozs7O0tBQUMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQXlCLHdCQUFDLEtBQUQsRUFBRyxXQUFVLE9BQVE7Ozs7Z0JBQUMsb0JBQXdCOzs7Ozs7SUFDekk7Ozs7O1dBQ0Y7Ozs7O1lBQ0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7R0FBVSxPQUFPLEVBQUUsWUFBWSxXQUFXO2FBQXpEO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUFvQix3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBUTtLQUFnQjs7OztlQUMzRCx3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUFTLE9BQU87TUFBVSxXQUFXLE1BQU07T0FBRSxZQUFZLEVBQUUsT0FBTyxLQUFLO09BQUcsT0FBTyxJQUFJO01BQUU7Z0JBQ3RHLFNBQVMsS0FBSyxNQUFNLHdCQUFDLFVBQUQ7T0FBbUIsT0FBTyxFQUFFO2lCQUE1QjtRQUFpQyxFQUFFO1FBQUs7UUFBRyxFQUFFO1FBQUs7UUFBSSxFQUFFO1FBQU07T0FBUztTQUExRCxFQUFFOzs7O2FBQXdELENBQUM7S0FDdkY7Ozs7YUFBTTs7Ozs7O0lBQ2hCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FBb0Isd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQVE7S0FBYTs7OztlQUN4RCx3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUFTLE9BQU87TUFBTyxXQUFXLE1BQU07T0FBRSxTQUFTLEVBQUUsT0FBTyxLQUFpQjtPQUFHLE9BQU8sSUFBSTtNQUFFO2dCQUM1RyxXQUFXLEtBQUssTUFBTSx3QkFBQyxVQUFEO09BQW9CLE9BQU8sRUFBRTtpQkFBN0I7UUFBbUMsRUFBRTtRQUFNO1FBQUcsYUFBYSxRQUFRLE1BQU0sRUFBRSxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFBTztRQUFLLEVBQUUsUUFBUSxlQUFlLGFBQWE7UUFBRztPQUFTO1NBQTdJLEVBQUU7Ozs7YUFBMkksQ0FBQztLQUM1Szs7OzthQUFNOzs7Ozs7SUFDaEIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUFvQix3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBUTtLQUFvQjs7OztlQUMvRCx3QkFBQyxTQUFEO01BQU8sV0FBVTtNQUFRLE1BQUs7TUFBTyxPQUFPO01BQU0sS0FBSztNQUFPLFdBQVcsTUFBTTtPQUFFLFFBQVEsRUFBRSxPQUFPLFNBQVMsS0FBSztPQUFHLE9BQU8sSUFBSTtNQUFFO0tBQUk7Ozs7YUFBTTs7Ozs7O0lBQzVJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQTRCLE9BQU87TUFBRSxhQUFhO01BQW9CLFlBQVk7S0FBa0I7ZUFBbkgsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FBZ0M7T0FBa0IsT0FBTztPQUFNO01BQU87Ozs7O2VBQ3RFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFZLEtBQUssS0FBSyxZQUFZLEtBQUssTUFBTSxLQUFLLEVBQUUsQ0FBQyxjQUFjLEdBQUksRUFBRSxpQkFBaUIsS0FBSyxNQUFNLEtBQUssRUFBRSxDQUFDLFlBQVksR0FBSSxFQUFFLE9BQU87S0FBTzs7OzthQUN2Sjs7Ozs7O0dBQ0Y7Ozs7O1VBQ0U7Ozs7O1dBRVQsd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkO09BQStCO09BQVUsSUFBSSxJQUFJO09BQUU7T0FBRyxLQUFLLElBQUk7T0FBRTtPQUFJLE9BQU8sS0FBSyxRQUFRLE9BQU8sR0FBRztNQUFNOzs7OztlQUN6Ryx3QkFBQyxRQUFEO01BQU0sV0FBVTtNQUFxQixPQUFPLEVBQUUsVUFBVSxHQUFHO2dCQUEzRDtPQUE4RDtPQUFhLE9BQU87T0FBSztPQUFJLE9BQU87TUFBWTs7Ozs7YUFDM0c7Ozs7OztJQUNKLFdBQVcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBTyxPQUFPO01BQUUsWUFBWTtNQUFtQixhQUFhO01BQW9CLE9BQU87S0FBbUI7ZUFBekg7TUFBNEg7TUFBSSxLQUFLLElBQUk7TUFBRTtNQUFnQixRQUFRO01BQUs7S0FBK0M7Ozs7OztJQUNsTyxRQUFRLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQU87SUFBd0M7Ozs7O0lBQ3ZFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksY0FBZTs7OztlQUNsQixhQUFhLEtBQUssTUFDakIsd0JBQUMsTUFBRDtNQUFtQixFQUFFO01BQU07TUFBSSxFQUFFO01BQy9CLHdCQUFDLFNBQUQ7T0FBTyxXQUFXLEdBQUcsRUFBRSxLQUFLLEtBQUssTUFBTSxDQUFDLEVBQUUsU0FBUyxTQUFTO2lCQUFLLEVBQUUsU0FBUyxhQUFhLEtBQUssS0FBSyxHQUFHLEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksR0FBSSxFQUFFLE9BQU87TUFBVTs7Ozs7S0FDckssS0FGSyxFQUFFOzs7O1lBRVAsQ0FDTCxDQUNDOzs7O2NBQ0M7Ozs7ZUFDUCx3QkFBQyxTQUFELGFBQ0csS0FBSyxXQUFXLEtBQUssd0JBQUMsTUFBRCxZQUFJLHdCQUFDLE1BQUQ7TUFBSSxTQUFTLGFBQWEsU0FBUztNQUFHLFdBQVU7TUFBUyxPQUFPLEVBQUUsU0FBUyxHQUFHO2dCQUFHO0tBQXlDOzs7O2NBQUs7Ozs7ZUFDeEosS0FBSyxLQUFLLE1BQU07TUFDZixNQUFNLFlBQVksYUFBYSxNQUFNLE1BQU0sQ0FBQyxFQUFFLFVBQVUsT0FBTyxFQUFFLElBQUksTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHLENBQUM7TUFDMUYsTUFBTSxRQUEyQixDQUFDO01BQ2xDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxhQUFhLFFBQVEsS0FBSztPQUM1QyxNQUFNLElBQUksYUFBYTtPQUN2QixJQUFJLEVBQUUsVUFBVSxTQUFTO1FBQUUsTUFBTSxLQUFLLHdCQUFDLE1BQUQ7U0FBWSxXQUFVO21CQUFTO1FBQVksR0FBbEM7Ozs7ZUFBa0MsQ0FBQztRQUFHO09BQVM7T0FDOUYsTUFBTSxLQUFLLE9BQU8sRUFBRSxJQUFJLE1BQU0sRUFBRSxPQUFPLEVBQUUsR0FBRztPQUM1QyxJQUFJLElBQUk7UUFDTixJQUFJLE9BQU87UUFDWCxPQUFPLElBQUksT0FBTyxhQUFhLFVBQVUsQ0FBQyxhQUFhLElBQUksS0FBSyxDQUFDLFVBQVUsT0FBTyxFQUFFLElBQUksTUFBTSxhQUFhLElBQUksS0FBSyxDQUFDLE9BQU8sYUFBYSxJQUFJLEtBQUssQ0FBQyxHQUFHLEdBQUc7UUFDekosTUFBTSxLQUFLLHdCQUFDLE1BQUQ7U0FBWSxTQUFTO1NBQU0sV0FBVTttQkFBckMsQ0FBOEMsOEJBQTJCLEdBQUcsT0FBTyxZQUFZLENBQU07V0FBNUY7Ozs7ZUFBNEYsQ0FBQztRQUNqSCxLQUFLLE9BQU87UUFBRztPQUNqQjtPQUNBLE1BQU0sS0FBSyxRQUFRLEVBQUUsSUFBSSxNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUc7T0FDN0MsTUFBTSxRQUFRLE1BQU0sVUFBVSxHQUFHLENBQUMsQ0FBQztPQUNuQyxJQUFJLElBQUk7UUFDTixNQUFNLEtBQUssd0JBQUMsTUFBRCxZQUFZLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQTJCLFVBQU0sd0JBQUMsU0FBRCxZQUFRLEdBQUcsV0FBVyxZQUFZLGlCQUFpQixHQUFHLFVBQVUsTUFBTSxTQUFVLE1BQU0sU0FBUyxjQUFjLEdBQUcsVUFBVSxlQUFnQixpQkFBaUIsR0FBRyxTQUFTLFdBQWtCOzs7O2lCQUFNOzs7OztpQkFBSyxHQUF4Tzs7OztlQUF3TyxDQUFDO09BQy9QLE9BQU8sSUFBSSxVQUFVLEtBQUssWUFBWSxFQUFFLE1BQU0sSUFBSSxRQUFRLEdBQUc7UUFDM0QsTUFBTSxLQUFLLHdCQUFDLE1BQUQsWUFBWSx3QkFBQyxVQUFEO1NBQVEsV0FBVTtTQUFXLGVBQWUsT0FBTyxJQUFJO21CQUF2RCxDQUEwRCxhQUFTLHdCQUFDLFNBQUQsWUFBUSxNQUFhOzs7O2lCQUFTOzs7OztpQkFBSyxHQUF6Rzs7OztlQUF5RyxDQUFDO09BQ2hJLE9BQU87UUFDTCxNQUFNLEtBQUssd0JBQUMsTUFBRCxZQUFZLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO1NBQVksVUFBVTtTQUFNLGVBQWUsS0FBSyxFQUFFLElBQUksQ0FBQzttQkFBekUsQ0FBNEUsYUFBUyx3QkFBQyxTQUFELFlBQVEsTUFBYTs7OztpQkFBUzs7Ozs7aUJBQUssR0FBM0g7Ozs7ZUFBMkgsQ0FBQztPQUNsSjtNQUNGO01BQ0EsT0FDRSx3QkFBQyxNQUFELGFBQ0Usd0JBQUMsTUFBRCxhQUFJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFrQixFQUFFO01BQVU7Ozs7Z0JBQy9DLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVcsT0FBTyxFQUFFLE9BQU8sWUFBWSxxQkFBcUIsbUJBQW1CO2lCQUE5RixDQUFpRyxNQUFHLFlBQVksWUFBWSxVQUFnQjs7Ozs7Y0FBSzs7OztnQkFDbEosS0FDQyxLQUpLLEVBQUU7Ozs7YUFJUDtLQUVSLENBQUMsQ0FDSTs7OzthQUNGOzs7Ozs7SUFDUCx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFtQixPQUFPLEVBQUUsY0FBYyxHQUFHO2VBQTVEO01BQStEO01BQzdDLHdCQUFDLEtBQUQsWUFBRywwQkFBd0I7Ozs7O01BQUM7TUFBbUQsd0JBQUMsS0FBRCxZQUFHLFVBQVU7Ozs7O01BQUM7TUFBOEIsd0JBQUMsS0FBRCxZQUFHLEtBQUs7Ozs7O01BQUM7S0FDako7Ozs7OztHQUNFOzs7OztZQUVULHdCQUFDLFNBQUQ7R0FBTyxXQUFVO0dBQXdDLE9BQU87SUFBRSxVQUFVO0lBQVUsS0FBSztHQUFHO2FBQTlGLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQVU7SUFBbUI7Ozs7Y0FDN0Msd0JBQUMsTUFBRDtLQUFJLFdBQVU7S0FBaUIsT0FBTyxFQUFFLFlBQVksT0FBTztlQUFHO0lBQTBCOzs7O1lBQ3JGOzs7OzthQUNKLENBQUMsU0FDQSx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFPLE9BQU87S0FBRSxXQUFXO0tBQVUsU0FBUztJQUFHO2NBQWhFO0tBQW1FO0tBQW9DLHdCQUFDLEtBQUQsWUFBRyxZQUFZOzs7OztLQUFDO0lBQWdDOzs7OztjQUV2SjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUE2Qix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBUztPQUFnQjs7OztpQkFBQyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBUyxPQUFPO09BQVE7Ozs7ZUFBTTs7Ozs7O01BQ2xILHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQTZCLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFTO09BQWtCOzs7O2lCQUFDLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFnQixPQUFPLE1BQU07T0FBUTs7OztlQUFNOzs7Ozs7TUFDakksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBaUMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWdCO09BQXFCOzs7O2lCQUFDLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO1FBQVEsT0FBTyxFQUFFLFdBQVcsUUFBUTtrQkFBakQ7U0FBcUQsS0FBSyxJQUFJO1NBQUU7U0FBSSxPQUFPLEtBQUs7U0FBTTtTQUFJLE9BQU8sS0FBSztTQUFJO1NBQUksT0FBTyxPQUFPLE9BQU8sT0FBTyxHQUFHLE9BQU8sS0FBSyxLQUFLLENBQUM7U0FBRztRQUFROzs7OztlQUFNOzs7Ozs7S0FDcFE7Ozs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWtCLE9BQU8sRUFBRSxZQUFZLEdBQUc7ZUFBekQ7TUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFRLE9BQU8sRUFBRSxRQUFRLEVBQUU7aUJBQUc7TUFBb0M7Ozs7O01BQ25GLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7UUFBZ0IsT0FBTztTQUFFLFNBQVM7U0FBYSxVQUFVO1FBQUc7UUFBRyxPQUFPO1FBQU0sYUFBWTtRQUFpQixXQUFXLE1BQU0sUUFBUSxFQUFFLE9BQU8sS0FBSztRQUFHLFlBQVksTUFBTSxFQUFFLFFBQVEsV0FBVyxNQUFNO09BQUk7Ozs7aUJBQ3JOLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQXNCLGVBQWUsTUFBTTtrQkFBRztPQUFlOzs7O2VBQzVFOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNHLE9BQU8sUUFBUSxNQUFNLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUNyRCx3QkFBQyxVQUFEO1FBQXFCLFdBQVcsU0FBUyxZQUFZLEVBQUUsT0FBTyxZQUFZO1FBQWMsT0FBTyxFQUFFLFVBQVUsR0FBRztRQUFHLGVBQWUsTUFBTSxFQUFFLElBQUk7a0JBQTVJO1NBQWdKLEVBQUU7U0FBSztTQUFJLEVBQUU7U0FBUTtRQUFVO1VBQWxLLEVBQUU7Ozs7Y0FBZ0ssQ0FDaEwsR0FDRCx3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUFpQixPQUFPO1NBQUUsWUFBWTtTQUFLLFVBQVU7UUFBRztRQUFHLFNBQVM7a0JBQVk7T0FBZTs7OztlQUM5Rzs7Ozs7O01BQ0osWUFBWSx3QkFBQyxLQUFEO09BQUcsV0FBVyxTQUFTLEtBQUssYUFBYTtpQkFBYyxTQUFTO01BQU87Ozs7O0tBQ2pGOzs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFrQixPQUFPLEVBQUUsWUFBWSxHQUFHO2VBQXpELENBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7TUFBUSxPQUFPLEVBQUUsUUFBUSxFQUFFO2dCQUFHO0tBQTBCOzs7O2VBQ3ZFLENBQUM7TUFBQztNQUFXLG9CQUFvQixJQUFJO01BQUs7TUFBUyxvQkFBb0IsSUFBSTtLQUFrRSxHQUFHO01BQUM7TUFBUTtNQUFzQjtNQUFPO0tBQTBELENBQUMsQ0FBQyxDQUFXLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSyxPQUM5USx3QkFBQyxTQUFEO01BQWUsV0FBVyxhQUFhLFlBQVksSUFBSSxRQUFRO01BQU0sT0FBTztPQUFFLFlBQVk7T0FBYyxTQUFTLFlBQVksSUFBSSxLQUFLO09BQUksY0FBYztNQUFHO2dCQUEzSixDQUNFLHdCQUFDLFNBQUQ7T0FBTyxNQUFLO09BQVEsTUFBSztPQUFVLFNBQVMsWUFBWTtPQUFHLGdCQUFnQixXQUFXLENBQUM7T0FBRyxPQUFPLEVBQUUsV0FBVyxFQUFFO01BQUk7Ozs7Z0JBQ3BILHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQTJCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQTZCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFrQjtRQUFROzs7O2tCQUFDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFrQixJQUFJLEdBQUc7UUFBUTs7OztnQkFBTTs7Ozs7aUJBQ3hKLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO1FBQWEsT0FBTztTQUFFLFlBQVk7U0FBSyxZQUFZO1FBQU87a0JBQUk7T0FBUTs7OztlQUFNOzs7OztjQUN6RjtRQUpLOzs7O1lBSUwsQ0FDUixDQUNFOzs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFjLE9BQU8sRUFBRSxTQUFTLEdBQUc7ZUFBbEQ7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUE2Qix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBUztPQUF1Qjs7OztpQkFBQyx3QkFBQyxLQUFELFlBQUksSUFBSSxJQUFJLEVBQUs7Ozs7ZUFBTTs7Ozs7O01BQ3JHLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQTZCLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFTO09BQXNCOzs7O2lCQUFDLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFXLE1BQU0sS0FBSyxJQUFJLEdBQUcsTUFBTTtPQUFXOzs7O2VBQU07Ozs7OztNQUM5SSx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUF1QixPQUFPLEVBQUUsWUFBWSxFQUFFO2lCQUE3RCxDQUFnRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBUTtPQUFzQjs7OztpQkFBQyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBUyxJQUFJLEtBQUs7T0FBSzs7OztlQUFNOzs7Ozs7TUFDdEosd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBNkIsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWM7T0FBdUI7Ozs7aUJBQUMsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWUsSUFBSSxNQUFNO09BQUs7Ozs7ZUFBTTs7Ozs7O01BQ2pJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQWlDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFTO09BQW1DOzs7O2lCQUFDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFVLElBQUksUUFBUSxNQUFNO09BQVE7Ozs7ZUFBTTs7Ozs7O0tBQ3JKOzs7Ozs7SUFDTCx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFtQyxTQUFTO2VBQVE7SUFBZ0M7Ozs7O0dBQ3RHOzs7O1dBRUM7Ozs7O1VBQ0o7Ozs7O1NBQ0w7Ozs7O0FBRU4iLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQm9va2luZy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBPTkxJTkVfU0xPVFMsIFNQT1JUUywgVE9EQVksIGRvdywgZXZhbFByb21vLCBoaCwgbW9uZXksIHJhdGVBdCwgc2xvdFByaWNlLCB0b1ZOLCB2bmQgfSBmcm9tICcuLi9kYXRhJ1xuaW1wb3J0IHR5cGUgeyBDb3VydCwgU3BvcnRLZXkgfSBmcm9tICcuLi9kYXRhJ1xuaW1wb3J0IHsgdXNlQXBwIH0gZnJvbSAnLi4vc3RvcmUnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEJvb2tpbmcoKSB7XG4gIGNvbnN0IHsgY291cnRzLCBicmFuY2hlcywgcHJvbW9zLCBzZXRQcm9tb3MsIGJsb2NrZXIsIGxvY2tBdCwgaG9saWRheXMsIGFkZEJvb2tpbmcsIHVzZXIsIHRvYXN0IH0gPSB1c2VBcHAoKVxuICBjb25zdCBuYXYgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IFtzcF0gPSB1c2VTZWFyY2hQYXJhbXMoKVxuXG4gIGNvbnN0IFticmFuY2hJZCwgc2V0QnJhbmNoSWRdID0gdXNlU3RhdGUoc3AuZ2V0KCdicmFuY2gnKSB8fCAnY3MxJylcbiAgY29uc3QgW3Nwb3J0LCBzZXRTcG9ydF0gPSB1c2VTdGF0ZTxTcG9ydEtleT4oKHNwLmdldCgnc3BvcnQnKSBhcyBTcG9ydEtleSkgfHwgJ3BpY2tsZWJhbGwnKVxuICBjb25zdCBbZGF0ZSwgc2V0RGF0ZV0gPSB1c2VTdGF0ZShzcC5nZXQoJ2RhdGUnKSB8fCBUT0RBWSlcbiAgY29uc3QgW3NlbCwgc2V0U2VsXSA9IHVzZVN0YXRlPHsgY291cnRJZDogc3RyaW5nOyBpZHg6IG51bWJlciB9IHwgbnVsbD4obnVsbClcbiAgY29uc3QgW2NvZGUsIHNldENvZGVdID0gdXNlU3RhdGUoc3AuZ2V0KCdwcm9tbycpIHx8ICcnKVxuICBjb25zdCBbYXBwbGllZCwgc2V0QXBwbGllZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihzcC5nZXQoJ3Byb21vJykpXG4gIGNvbnN0IFtwYXlNb2RlLCBzZXRQYXlNb2RlXSA9IHVzZVN0YXRlPCdkZXBvc2l0JyB8ICdmdWxsJz4oJ2RlcG9zaXQnKVxuXG4gIGNvbnN0IGJyYW5jaCA9IGJyYW5jaGVzLmZpbmQoKGIpID0+IGIuaWQgPT09IGJyYW5jaElkKSFcbiAgY29uc3QgYnJhbmNoQ291cnRzID0gY291cnRzLmZpbHRlcigoYykgPT4gYy5icmFuY2hJZCA9PT0gYnJhbmNoSWQgJiYgYy5hY3RpdmUpXG4gIGNvbnN0IHNwb3J0c0hlcmUgPSBTUE9SVFMuZmlsdGVyKChzKSA9PiBicmFuY2hDb3VydHMuc29tZSgoYykgPT4gYy5zcG9ydCA9PT0gcy5rZXkpKVxuICB1c2VFZmZlY3QoKCkgPT4geyBpZiAoIXNwb3J0c0hlcmUuc29tZSgocykgPT4gcy5rZXkgPT09IHNwb3J0KSAmJiBzcG9ydHNIZXJlWzBdKSBzZXRTcG9ydChzcG9ydHNIZXJlWzBdLmtleSkgfSwgW2JyYW5jaElkXSkgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICBjb25zdCByb3dzID0gYnJhbmNoQ291cnRzLmZpbHRlcigoYykgPT4gYy5zcG9ydCA9PT0gc3BvcnQpXG4gIGNvbnN0IGhvbGlkYXkgPSBob2xpZGF5cy5maW5kKChoKSA9PiBoLmRhdGUgPT09IGRhdGUpXG4gIGNvbnN0IHBhc3QgPSBkYXRlIDwgVE9EQVlcbiAgY29uc3Qgc3BJbmZvID0gU1BPUlRTLmZpbmQoKHMpID0+IHMua2V5ID09PSBzcG9ydCkhXG5cbiAgY29uc3QgcGljayA9IChjb3VydElkOiBzdHJpbmcsIGlkeDogbnVtYmVyKSA9PiBzZXRTZWwoeyBjb3VydElkLCBpZHggfSlcbiAgY29uc3Qgc2VsQ291cnQ6IENvdXJ0IHwgdW5kZWZpbmVkID0gc2VsID8gY291cnRzLmZpbmQoKGMpID0+IGMuaWQgPT09IHNlbC5jb3VydElkKSA6IHVuZGVmaW5lZFxuICBjb25zdCBzZWxTbG90ID0gc2VsID8gT05MSU5FX1NMT1RTW3NlbC5pZHhdIDogdW5kZWZpbmVkXG4gIGNvbnN0IHN0aWxsVmFsaWQgPSAhIShzZWwgJiYgc2VsQ291cnQgJiYgcm93cy5zb21lKChjKSA9PiBjLmlkID09PSBzZWwuY291cnRJZCkgJiYgIWJsb2NrZXIoc2VsLmNvdXJ0SWQsIGRhdGUsIHNlbFNsb3QhLnN0YXJ0LCBzZWxTbG90IS5lbmQpICYmICFsb2NrQXQoc2VsLmNvdXJ0SWQsIGRhdGUsIHNlbFNsb3QhLnN0YXJ0LCBzZWxTbG90IS5lbmQpKVxuICBjb25zdCBhY3RpdmUgPSBzdGlsbFZhbGlkICYmIHNlbENvdXJ0ICYmIHNlbFNsb3QgPyB7IGNvdXJ0OiBzZWxDb3VydCwgc2xvdDogc2VsU2xvdCB9IDogbnVsbFxuXG4gIGNvbnN0IGJhc2UgPSBhY3RpdmUgPyBzbG90UHJpY2UoYWN0aXZlLmNvdXJ0LCBhY3RpdmUuc2xvdCkgOiAwXG4gIGNvbnN0IHByb21vUmVzID0gYWN0aXZlICYmIGFwcGxpZWQgPyBldmFsUHJvbW8ocHJvbW9zLmZpbmQoKHApID0+IHAuY29kZSA9PT0gYXBwbGllZCksIGFjdGl2ZS5jb3VydCwgZGF0ZSwgYWN0aXZlLnNsb3QsIGJhc2UpIDogbnVsbFxuICBjb25zdCBvZmYgPSBwcm9tb1Jlcz8ub2sgPyBwcm9tb1Jlcy5vZmYgOiAwXG4gIGNvbnN0IHRvdGFsID0gYmFzZSAtIG9mZlxuICBjb25zdCBwY3QgPSBhY3RpdmU/LmNvdXJ0LmRlcG9zaXQgPz8gMzBcbiAgY29uc3QgZGVwb3NpdCA9IE1hdGgucm91bmQoKHRvdGFsICogcGN0KSAvIDEwMClcbiAgY29uc3QgZHVlTm93ID0gcGF5TW9kZSA9PT0gJ2Z1bGwnID8gdG90YWwgOiBkZXBvc2l0XG5cbiAgY29uc3QgYXBwbHkgPSAoYyA9IGNvZGUpID0+IHtcbiAgICBjb25zdCB2ID0gYy50cmltKCkudG9VcHBlckNhc2UoKVxuICAgIGlmICghdikgcmV0dXJuIHRvYXN0KCdWdWkgbMOybmcgbmjhuq1wIG3DoyBnaeG6o20gZ2nDoS4nLCAnZXJyJylcbiAgICBzZXRDb2RlKHYpOyBzZXRBcHBsaWVkKHYpXG4gIH1cbiAgY29uc3QgY2xlYXJQcm9tbyA9ICgpID0+IHsgc2V0QXBwbGllZChudWxsKTsgc2V0Q29kZSgnJykgfVxuXG4gIGNvbnN0IHN1Ym1pdCA9ICgpID0+IHtcbiAgICBpZiAoIWFjdGl2ZSB8fCAhdXNlcikgcmV0dXJuXG4gICAgY29uc3QgaG9sZCA9IERhdGUubm93KCkgKyAxMCAqIDYwMDAwXG4gICAgY29uc3QgbmIgPSBhZGRCb29raW5nKHtcbiAgICAgIGN1c3RvbWVyOiB1c2VyLm5hbWUsIHBob25lOiB1c2VyLnBob25lLCBtZW1iZXI6IHRydWUsIGNvdXJ0SWQ6IGFjdGl2ZS5jb3VydC5pZCwgZGF0ZSxcbiAgICAgIHN0YXJ0OiBhY3RpdmUuc2xvdC5zdGFydCwgZW5kOiBhY3RpdmUuc2xvdC5lbmQsIHN1YnRvdGFsOiBiYXNlLCBkaXNjb3VudDogb2ZmLCB0b3RhbCwgcGFpZDogMCwgcGF5TW9kZSxcbiAgICAgIG1ldGhvZDogJ3FyJywgc291cmNlOiAnb25saW5lJywgc3RhdHVzOiAncGVuZGluZycsIHByb21vOiBwcm9tb1Jlcz8ub2sgPyBhcHBsaWVkISA6IHVuZGVmaW5lZCwgaG9sZFVudGlsOiBob2xkLFxuICAgIH0pXG4gICAgaWYgKHByb21vUmVzPy5vaykgc2V0UHJvbW9zKChwcykgPT4gcHMubWFwKChwKSA9PiAocC5jb2RlID09PSBhcHBsaWVkID8geyAuLi5wLCB1c2VkOiBwLnVzZWQgKyAxIH0gOiBwKSkpXG4gICAgdG9hc3QoYMSQw6MgZ2nhu68gY2jhu5cgxJHGoW4gIyR7bmIuaWR9IHRyb25nIDEwIHBow7p0LmAsICdvaycpXG4gICAgbmF2KGAvcGF5bWVudC8ke25iLmlkfWApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjYXJkIGNhcmQtbGcgY29sIGcxNlwiIHN0eWxlPXt7IGJvcmRlclJhZGl1czogMTYgfX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gd3JhcCBnMTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnMlwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInQyMCB3ODAwIGMtaW5rXCI+Q2jhu41uIGtodW5nIGdp4budIMSR4bq3dCBzw6JuIHRy4buxYyB0dXnhur9uPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj5OaOG6pXAgdsOgbyDDtCBtw6B1IHRy4bqvbmcgKEPDsm4gdHLhu5FuZykgdHLDqm4gYuG6o25nIGzhu4tjaCBiw6puIGTGsOG7m2kgxJHhu4MgY2jhu41uIGtodW5nIGdp4budIGLhuqFuIG114buRbiB0aHXDqi48L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzEyIHdyYXBcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxlZ2VuZFwiPjxpIC8+Q8OybiB0cuG7kW5nPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImxlZ2VuZFwiPjxpIGNsYXNzTmFtZT1cInNlbFwiIC8+xJBhbmcgY2jhu41uPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGVnZW5kXCI+PGkgY2xhc3NOYW1lPVwiYnVzeVwiIC8+xJDDoyBjw7MgbmfGsOG7nWkgxJHhurd0PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImxlZ2VuZFwiPjxpIGNsYXNzTmFtZT1cImxvY2tcIiAvPkLhuqNvIHRyw6wgLyDEkMOzbmcgY+G7rWE8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTZcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiAnZmxleC1lbmQnIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjFcIj48bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIj5DaGkgbmjDoW5oPC9sYWJlbD5cbiAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwic2VsZWN0XCIgdmFsdWU9e2JyYW5jaElkfSBvbkNoYW5nZT17KGUpID0+IHsgc2V0QnJhbmNoSWQoZS50YXJnZXQudmFsdWUpOyBzZXRTZWwobnVsbCkgfX0+XG4gICAgICAgICAgICAgIHticmFuY2hlcy5tYXAoKGIpID0+IDxvcHRpb24ga2V5PXtiLmlkfSB2YWx1ZT17Yi5pZH0+e2IubmFtZX0gKHtiLm9wZW59IC0ge2IuY2xvc2V9KTwvb3B0aW9uPil9XG4gICAgICAgICAgICA8L3NlbGVjdD48L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImYxXCI+PGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCI+QuG7mSBtw7RuPC9sYWJlbD5cbiAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwic2VsZWN0XCIgdmFsdWU9e3Nwb3J0fSBvbkNoYW5nZT17KGUpID0+IHsgc2V0U3BvcnQoZS50YXJnZXQudmFsdWUgYXMgU3BvcnRLZXkpOyBzZXRTZWwobnVsbCkgfX0+XG4gICAgICAgICAgICAgIHtzcG9ydHNIZXJlLm1hcCgocykgPT4gPG9wdGlvbiBrZXk9e3Mua2V5fSB2YWx1ZT17cy5rZXl9PntzLmxhYmVsfSAoe2JyYW5jaENvdXJ0cy5maWx0ZXIoKGMpID0+IGMuc3BvcnQgPT09IHMua2V5KS5sZW5ndGh9IHPDom57cy5rZXkgPT09ICdwaWNrbGViYWxsJyA/ICcgbcOhaSBjaGUnIDogJyd9KTwvb3B0aW9uPil9XG4gICAgICAgICAgICA8L3NlbGVjdD48L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImYxXCI+PGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCI+TmfDoHkgxJHhurd0IGzhu4tjaDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXRcIiB0eXBlPVwiZGF0ZVwiIHZhbHVlPXtkYXRlfSBtaW49e1RPREFZfSBvbkNoYW5nZT17KGUpID0+IHsgc2V0RGF0ZShlLnRhcmdldC52YWx1ZSB8fCBUT0RBWSk7IHNldFNlbChudWxsKSB9fSAvPjwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjEgaGludCBoaW50LWdyZWVuIGNvbCBnMlwiIHN0eWxlPXt7IGJvcmRlckNvbG9yOiAndmFyKC0tYnJhbmQtMTAwKScsIGJhY2tncm91bmQ6ICd2YXIoLS1icmFuZC01MCknIH19PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidzcwMCBjLWJyYW5kOVwiPsSQxqFuIGdpw6EgdGh1w6ogc8OibiB7c3BJbmZvLmxhYmVsfTo8L3NwYW4+XG4gICAgICAgICAgICA8YiBjbGFzc05hbWU9XCJjLWJyYW5kOFwiPntyb3dzWzBdID8gYDA1aOKAkzE2aDogJHtNYXRoLnJvdW5kKHJvd3NbMF0ucHJpY2VOb3JtYWwgLyAxMDAwKX1rL2gg4oCiIDE2aOKAkzIzaDogJHtNYXRoLnJvdW5kKHJvd3NbMF0ucHJpY2VQZWFrIC8gMTAwMCl9ay9oYCA6ICfigJQnfTwvYj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZDEyXCI+XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYW44IGNhcmQgY2FyZC1sZyBjb2wgZzE2XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlblwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInQxNiB3ODAwIGMtaW5rXCI+TOG7i2NoIHPDom4ge2RvdyhkYXRlKX0sIHt0b1ZOKGRhdGUpfSDigJMge2JyYW5jaC5uYW1lLnJlcGxhY2UoJyAtICcsICcgJyl9PC9oMj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGItZ3JlZW4tZmxhdFwiIHN0eWxlPXt7IGZvbnRTaXplOiAxMSB9fT5HaeG7nSBt4bufIGPhu61hOiB7YnJhbmNoLm9wZW59IOKAkyB7YnJhbmNoLmNsb3NlfTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7aG9saWRheSAmJiA8ZGl2IGNsYXNzTmFtZT1cImhpbnRcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAndmFyKC0tYW1iZXItNTApJywgYm9yZGVyQ29sb3I6ICd2YXIoLS1hbWJlci0zMDApJywgY29sb3I6ICd2YXIoLS1hbWJlci05MDApJyB9fT7wn5OFIHt0b1ZOKGRhdGUpfSBsw6AgbmfDoHkgbmdo4buJOiB7aG9saWRheS5ub3RlfS4gSOG7hyB0aOG7kW5nIGtow7RuZyBuaOG6rW4gbOG7i2NoIHRyb25nIG5nw6B5IG7DoHkuPC9kaXY+fVxuICAgICAgICAgIHtwYXN0ICYmIDxkaXYgY2xhc3NOYW1lPVwiaGludFwiPktow7RuZyB0aOG7gyDEkeG6t3QgbOG7i2NoIGNobyBuZ8OgeSDEkcOjIHF1YS48L2Rpdj59XG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInNjaGVkXCI+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGg+U8OibiB0aGkgxJHhuqV1PC90aD5cbiAgICAgICAgICAgICAgICB7T05MSU5FX1NMT1RTLm1hcCgocykgPT4gKFxuICAgICAgICAgICAgICAgICAgPHRoIGtleT17cy5zdGFydH0+e3Muc3RhcnR9IC0ge3MuZW5kfVxuICAgICAgICAgICAgICAgICAgICA8c21hbGwgY2xhc3NOYW1lPXtoaChzLnN0YXJ0KSA+PSAxNiAmJiAhcy5jbG9zZWQgPyAncGVhaycgOiAnJ30+e3MuY2xvc2VkID8gJ8SQw7NuZyBj4butYScgOiByb3dzWzBdID8gYCR7TWF0aC5yb3VuZChyYXRlQXQocm93c1swXSwgaGgocy5zdGFydCkpIC8gMTAwMCl9ay9oYCA6ICcnfTwvc21hbGw+XG4gICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAge3Jvd3MubGVuZ3RoID09PSAwICYmIDx0cj48dGQgY29sU3Bhbj17T05MSU5FX1NMT1RTLmxlbmd0aCArIDF9IGNsYXNzTmFtZT1cImNsb3NlZFwiIHN0eWxlPXt7IHBhZGRpbmc6IDI0IH19PkNoaSBuaMOhbmggY2jGsGEgY8OzIHPDom4gY2hvIGLhu5kgbcO0biBuw6B5LjwvdGQ+PC90cj59XG4gICAgICAgICAgICAgIHtyb3dzLm1hcCgoYykgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGxvY2tlZEFueSA9IE9OTElORV9TTE9UUy5zb21lKChzKSA9PiAhcy5jbG9zZWQgJiYgbG9ja0F0KGMuaWQsIGRhdGUsIHMuc3RhcnQsIHMuZW5kKSlcbiAgICAgICAgICAgICAgICBjb25zdCBjZWxsczogUmVhY3QuUmVhY3ROb2RlW10gPSBbXVxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgT05MSU5FX1NMT1RTLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBzID0gT05MSU5FX1NMT1RTW2ldXG4gICAgICAgICAgICAgICAgICBpZiAocy5jbG9zZWQgfHwgaG9saWRheSkgeyBjZWxscy5wdXNoKDx0ZCBrZXk9e2l9IGNsYXNzTmFtZT1cImNsb3NlZFwiPsSQw7NuZyBj4butYTwvdGQ+KTsgY29udGludWUgfVxuICAgICAgICAgICAgICAgICAgY29uc3QgbGsgPSBsb2NrQXQoYy5pZCwgZGF0ZSwgcy5zdGFydCwgcy5lbmQpXG4gICAgICAgICAgICAgICAgICBpZiAobGspIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNwYW4gPSAxXG4gICAgICAgICAgICAgICAgICAgIHdoaWxlIChpICsgc3BhbiA8IE9OTElORV9TTE9UUy5sZW5ndGggJiYgIU9OTElORV9TTE9UU1tpICsgc3Bhbl0uY2xvc2VkICYmIGxvY2tBdChjLmlkLCBkYXRlLCBPTkxJTkVfU0xPVFNbaSArIHNwYW5dLnN0YXJ0LCBPTkxJTkVfU0xPVFNbaSArIHNwYW5dLmVuZCkpIHNwYW4rK1xuICAgICAgICAgICAgICAgICAgICBjZWxscy5wdXNoKDx0ZCBrZXk9e2l9IGNvbFNwYW49e3NwYW59IGNsYXNzTmFtZT1cImxvY2tlZFwiPvCflJIgVOG6oW0gbmfGsG5nIG5o4bqtbiBs4buLY2ggxJHhu4Mge2xrLnJlYXNvbi50b0xvd2VyQ2FzZSgpfTwvdGQ+KVxuICAgICAgICAgICAgICAgICAgICBpICs9IHNwYW4gLSAxOyBjb250aW51ZVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgY29uc3QgYmsgPSBibG9ja2VyKGMuaWQsIGRhdGUsIHMuc3RhcnQsIHMuZW5kKVxuICAgICAgICAgICAgICAgICAgY29uc3QgcHJpY2UgPSBtb25leShzbG90UHJpY2UoYywgcykpXG4gICAgICAgICAgICAgICAgICBpZiAoYmspIHtcbiAgICAgICAgICAgICAgICAgICAgY2VsbHMucHVzaCg8dGQga2V5PXtpfT48ZGl2IGNsYXNzTmFtZT1cImNlbGwgYnVzeVwiPsSQw6MgxJHhurd0PHNtYWxsPntiay5zdGF0dXMgPT09ICdwZW5kaW5nJyA/ICfEkGFuZyBnaeG7ryBjaOG7lycgOiBiay5waG9uZSA9PT0gdXNlcj8ucGhvbmUgfHwgKHVzZXI/LnJvbGUgIT09ICdjdXN0b21lcicgJiYgYmsucGhvbmUgPT09ICcwOTg3NjU0MzIxJykgPyAnTOG7i2NoIGPhu6dhIGLhuqFuJyA6IGJrLmxhYmVsID8/ICdLw61uIGzhu4tjaCd9PC9zbWFsbD48L2Rpdj48L3RkPilcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoYWN0aXZlICYmIHNlbD8uY291cnRJZCA9PT0gYy5pZCAmJiBzZWwuaWR4ID09PSBpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNlbGxzLnB1c2goPHRkIGtleT17aX0+PGJ1dHRvbiBjbGFzc05hbWU9XCJjZWxsIHNlbFwiIG9uQ2xpY2s9eygpID0+IHNldFNlbChudWxsKX0+xJBhbmcgY2jhu41uPHNtYWxsPntwcmljZX08L3NtYWxsPjwvYnV0dG9uPjwvdGQ+KVxuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY2VsbHMucHVzaCg8dGQga2V5PXtpfT48YnV0dG9uIGNsYXNzTmFtZT1cImNlbGwgZnJlZVwiIGRpc2FibGVkPXtwYXN0fSBvbkNsaWNrPXsoKSA9PiBwaWNrKGMuaWQsIGkpfT5Dw7JuIHRy4buRbmc8c21hbGw+e3ByaWNlfTwvc21hbGw+PC9idXR0b24+PC90ZD4pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtjLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgPHRkPjxkaXYgY2xhc3NOYW1lPVwidDEyIHc4MDAgYy1pbmtcIj57Yy5uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidDExIHc2MDBcIiBzdHlsZT17eyBjb2xvcjogbG9ja2VkQW55ID8gJ3ZhcigtLWFtYmVyLTgwMCknIDogJ3ZhcigtLWJyYW5kLTcwMCknIH19PuKXjyB7bG9ja2VkQW55ID8gJ0LhuqNvIHRyw6wnIDogJ1PhurVuIHPDoG5nJ308L2Rpdj48L3RkPlxuICAgICAgICAgICAgICAgICAgICB7Y2VsbHN9XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaW50IHJvdyBnNCB3cmFwXCIgc3R5bGU9e3sgYm9yZGVyUmFkaXVzOiAxMiB9fT5cbiAgICAgICAgICAgIPCfkqEgU2F1IGtoaSBuaOG6pW4gPGI+XCJUaeG6v3AgdOG7pWMgdGhhbmggdG/DoW5cIjwvYj4sIGjhu4cgdGjhu5FuZyBz4bq9IGdp4buvIGNo4buXIHThuqFtIHRo4budaSBraHVuZyBnaeG7nSBuw6B5IHRyb25nIDxiPjEwIHBow7p0PC9iPiDEkeG7gyBi4bqhbiBob8OgbiB04bqldCBjaHV54buDbiBraG/huqNuIDxiPlFSPC9iPi5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJzcGFuNCBjYXJkIGNhcmQtbGcgY2FyZC1yYWlzZSBjb2wgZzE2XCIgc3R5bGU9e3sgcG9zaXRpb246ICdzdGlja3knLCB0b3A6IDgwIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGcyIGhlYWQtcnVsZVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXllYnJvd1wiPlBoaeG6v3UgxJHhurd0IHPDom48L3NwYW4+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidDE2IHc4MDAgYy1pbmtcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMjRweCcgfX0+VGjDtG5nIHRpbiBs4buLY2ggxJHDoyBjaOG7jW48L2gyPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHshYWN0aXZlID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaW50XCIgc3R5bGU9e3sgdGV4dEFsaWduOiAnY2VudGVyJywgcGFkZGluZzogMjQgfX0+Q2jGsGEgY2jhu41uIGtodW5nIGdp4budLiBOaOG6pXAgdsOgbyBt4buZdCDDtCA8Yj5Dw7JuIHRy4buRbmc8L2I+IHRyw6puIGLhuqNuZyBs4buLY2ggxJHhu4MgYuG6r3QgxJHhuqd1LjwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnMTAgdDEyXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlblwiPjxzcGFuIGNsYXNzTmFtZT1cImMtczYwMFwiPkNoaSBuaMOhbmg6PC9zcGFuPjxiIGNsYXNzTmFtZT1cImMtaW5rXCI+e2JyYW5jaC5uYW1lfTwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuXCI+PHNwYW4gY2xhc3NOYW1lPVwiYy1zNjAwXCI+U8OibiB0aGkgxJHhuqV1Ojwvc3Bhbj48YiBjbGFzc05hbWU9XCJjLWJyYW5kIHc4MDBcIj57YWN0aXZlLmNvdXJ0Lm5hbWV9PC9iPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gZzEyXCI+PHNwYW4gY2xhc3NOYW1lPVwiYy1zNjAwIG5vd3JhcFwiPlRo4budaSBnaWFuIHRodcOqOjwvc3Bhbj48YiBjbGFzc05hbWU9XCJjLWlua1wiIHN0eWxlPXt7IHRleHRBbGlnbjogJ3JpZ2h0JyB9fT57dG9WTihkYXRlKX0g4oCiIHthY3RpdmUuc2xvdC5zdGFydH0gLSB7YWN0aXZlLnNsb3QuZW5kfSAoeyhiYXNlIC8gcmF0ZUF0KGFjdGl2ZS5jb3VydCwgaGgoYWN0aXZlLnNsb3Quc3RhcnQpKSl9IGdp4budKTwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGc4IHRvcC1ydWxlXCIgc3R5bGU9e3sgcGFkZGluZ1RvcDogMTYgfX0+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCIgc3R5bGU9e3sgbWFyZ2luOiAwIH19Pk3DoyBnaeG6o20gZ2nDoSAvIMavdSDEkcOjaSBo4buZaSB2acOqbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzhcIj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBjbGFzc05hbWU9XCJpbnB1dCBzbSBib2xkXCIgc3R5bGU9e3sgcGFkZGluZzogJzEwcHggMTRweCcsIGZvbnRTaXplOiAxNCB9fSB2YWx1ZT17Y29kZX0gcGxhY2Vob2xkZXI9XCJOaOG6rXAgbcOjIMawdSDEkcOjaVwiIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29kZShlLnRhcmdldC52YWx1ZSl9IG9uS2V5RG93bj17KGUpID0+IGUua2V5ID09PSAnRW50ZXInICYmIGFwcGx5KCl9IC8+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tZGFyayBidG4tbWRcIiBvbkNsaWNrPXsoKSA9PiBhcHBseSgpfT7DgXAgZOG7pW5nPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzYgd3JhcFwiPlxuICAgICAgICAgICAgICAgICAge3Byb21vcy5maWx0ZXIoKHApID0+ICFwLmNvdW50ZXJPbmx5KS5zbGljZSgwLCAyKS5tYXAoKHApID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e3AuY29kZX0gY2xhc3NOYW1lPXtgYmFkZ2UgJHthcHBsaWVkID09PSBwLmNvZGUgPyAnYi1ncmVlbicgOiAnYi1ncmF5LW8nfWB9IHN0eWxlPXt7IGZvbnRTaXplOiAxMSB9fSBvbkNsaWNrPXsoKSA9PiBhcHBseShwLmNvZGUpfT57cC5jb2RlfSAoLXtwLnBlcmNlbnR9JSk8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJiYWRnZSBiLWdyYXktb1wiIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDUwMCwgZm9udFNpemU6IDExIH19IG9uQ2xpY2s9e2NsZWFyUHJvbW99PkLhu48gY2jhu41uPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge3Byb21vUmVzICYmIDxwIGNsYXNzTmFtZT17cHJvbW9SZXMub2sgPyAnZmllbGQtb2snIDogJ2ZpZWxkLWVycid9Pntwcm9tb1Jlcy5tc2d9PC9wPn1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGc4IHRvcC1ydWxlXCIgc3R5bGU9e3sgcGFkZGluZ1RvcDogMTYgfX0+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCIgc3R5bGU9e3sgbWFyZ2luOiAwIH19PlBoxrDGoW5nIHRo4bupYyBnaeG7ryBzw6JuPC9sYWJlbD5cbiAgICAgICAgICAgICAgICB7KFtbJ2RlcG9zaXQnLCBgxJDhurd0IGPhu41jIGdp4buvIHPDom4gKCR7cGN0fSUpYCwgZGVwb3NpdCwgYFRoYW5oIHRvw6FuIHRyxrDhu5tjICR7cGN0fSUgxJHhu4MgZ2nhu68gbOG7i2NoLiBQaOG6p24gY8OybiBs4bqhaSB0aGFuaCB0b8OhbiB04bqhaSBxdeG6p3kga2hpIMSR4bq/biBuaOG6rW4gc8Oibi5gXSwgWydmdWxsJywgJ1RoYW5oIHRvw6FuIMSR4bunIDEwMCUnLCB0b3RhbCwgJ1ThuqV0IHRvw6FuIHRvw6BuIGLhu5kgxJHGoW4gxJHhurd0IHPDom4sIMSR4bq/biBnaeG7nSB2w6BvIHPDom4gY2jGoWkgbmdheS4nXV0gYXMgY29uc3QpLm1hcCgoW2ssIHQsIGFtdCwgZF0pID0+IChcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBrZXk9e2t9IGNsYXNzTmFtZT17YHJhZGlvLWNhcmQke3BheU1vZGUgPT09IGsgPyAnIG9uJyA6ICcnfWB9IHN0eWxlPXt7IGFsaWduSXRlbXM6ICdmbGV4LXN0YXJ0JywgcGFkZGluZzogcGF5TW9kZSA9PT0gayA/IDExIDogMTIsIGJvcmRlclJhZGl1czogMTIgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicmFkaW9cIiBuYW1lPVwicGF5bW9kZVwiIGNoZWNrZWQ9e3BheU1vZGUgPT09IGt9IG9uQ2hhbmdlPXsoKSA9PiBzZXRQYXlNb2RlKGspfSBzdHlsZT17eyBtYXJnaW5Ub3A6IDMgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzIgZjFcIj48ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuXCI+PHNwYW4gY2xhc3NOYW1lPVwidDEyIHc4MDAgYy1pbmtcIj57dH08L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwidDEyIHc4MDAgYy1pbmtcIj57dm5kKGFtdCl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMSBjLXM2MDBcIiBzdHlsZT17eyBmb250V2VpZ2h0OiA0MDAsIGxpbmVIZWlnaHQ6ICcxNXB4JyB9fT57ZH08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaW50IGNvbCBnOFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE0IH19PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj48c3BhbiBjbGFzc05hbWU9XCJjLXM2MDBcIj5HacOhIHRodcOqIHPDom4gZ+G7kWM6PC9zcGFuPjxiPnt2bmQoYmFzZSl9PC9iPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj48c3BhbiBjbGFzc05hbWU9XCJjLXM2MDBcIj7Gr3UgxJHDo2kgZ2nhuqNtIGdpw6E6PC9zcGFuPjxiIGNsYXNzTmFtZT1cImMtYnJhbmRcIj57b2ZmID8gYC0gJHt2bmQob2ZmKX1gIDogJzAgVk7EkCd9PC9iPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gdG9wLXJ1bGVcIiBzdHlsZT17eyBwYWRkaW5nVG9wOiA4IH19PjxiIGNsYXNzTmFtZT1cImMtaW5rXCI+VOG7lW5nIHRp4buBbiBzYXUgZ2nhuqNtOjwvYj48YiBjbGFzc05hbWU9XCJjLWlua1wiPnt2bmQodG90YWwpfTwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuXCI+PGIgY2xhc3NOYW1lPVwiYy1icmFuZCB0MTRcIj5D4bqnbiB0aGFuaCB0b8OhbiBuZ2F5OjwvYj48YiBjbGFzc05hbWU9XCJjLWJyYW5kIHQxNlwiPnt2bmQoZHVlTm93KX08L2I+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiB0MTFcIj48c3BhbiBjbGFzc05hbWU9XCJjLXM2MDBcIj5UaGFuaCB0b8OhbiB0aMOqbSBraGkgbmjhuq1uIHPDom46PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImMtczYwMFwiPnt2bmQodG90YWwgLSBkdWVOb3cpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1sZyBidG4tYmxvY2tcIiBvbkNsaWNrPXtzdWJtaXR9PlRp4bq/cCB04bulYyB0aGFuaCB0b8OhbiBRUiDihpI8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvYXNpZGU+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKVxufVxuIl19