import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport18_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport18_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { Link, NavLink, Navigate, Outlet, useLocation, useNavigate, useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { useApp } from "/src/store.tsx";
import { TODAY, dow, toVN, branchOf } from "/src/data.ts";
import bell from "/src/assets/icons/bell.svg?import";
import iBooking from "/src/assets/icons/nav-booking.svg?import";
import iBookingA from "/src/assets/icons/nav-booking-active.svg?import";
import iOrders from "/src/assets/icons/nav-orders.svg?import";
import iOrdersA from "/src/assets/icons/nav-orders-active.svg?import";
import iStats from "/src/assets/icons/nav-stats.svg?import";
import iStatsA from "/src/assets/icons/nav-stats-active.svg?import";
import iExternal from "/src/assets/icons/nav-external.svg?import";
import iStaff from "/src/assets/icons/nav-staff.svg?import";
import iStaffA from "/src/assets/icons/nav-staff-active.svg?import";
import iCourts from "/src/assets/icons/nav-courts.svg?import";
import iCourtsA from "/src/assets/icons/nav-courts-active.svg?import";
import iPromo from "/src/assets/icons/nav-promo.svg?import";
import iPromoA from "/src/assets/icons/nav-promo-active.svg?import";
var _jsxFileName = "D:/Jobs/Sports/app/src/layouts.tsx";
import __vite__cjsImport18_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
export const initials = (name) => {
	const w = name.split(" ").filter(Boolean);
	return ((w[0]?.[0] ?? "") + (w.length > 1 ? w[w.length - 1][0] : "")).toUpperCase();
};
export const homeOf = (role) => role === "customer" ? "/" : role === "staff" ? "/staff/booking" : "/owner/staff";
/** Chặn truy cập theo vai trò. Vai trò sau kế thừa giao diện của vai trò trước. */
export function Guard({ min }) {
	_s();
	const { user } = useApp();
	const loc = useLocation();
	const ctx = useOutletContext();
	const rank = {
		customer: 0,
		staff: 1,
		owner: 2
	};
	if (!user) return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: "/login",
		replace: true,
		state: { from: loc.pathname }
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 21
	}, this);
	if (rank[user.role] < rank[min]) return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: homeOf(user.role),
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 43
	}, this);
	return /* @__PURE__ */ _jsxDEV(Outlet, { context: ctx }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 10
	}, this);
}
_s(Guard, "pOaH405yIGTJGMgxbTsChLqHo2Y=", false, function() {
	return [
		useApp,
		useLocation,
		useOutletContext
	];
});
_c = Guard;
export function CustomerLayout() {
	_s2();
	const { user, logout, bookings } = useApp();
	const nav = useNavigate();
	const pend = bookings.filter((b) => b.status === "pending").length;
	if (!user) return null;
	const cls = ({ isActive }) => `nav-link${isActive ? " active" : ""}`;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "col",
		style: { minHeight: "100vh" },
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "hdr",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "container hdr-in",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "row g32",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						className: "row g10",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "logo-mark",
							children: "S"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "col g4",
							style: { paddingBottom: 2 },
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "logo-name",
								children: "SportHub"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "logo-sub",
								children: "Đặt sân thể thao trực tuyến"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("nav", {
						className: "row g6",
						children: [
							/* @__PURE__ */ _jsxDEV(NavLink, {
								to: "/",
								end: true,
								className: cls,
								children: "Trang chủ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(NavLink, {
								to: "/booking",
								className: cls,
								children: "Đặt sân trực tuyến"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 55,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(NavLink, {
								to: "/my-bookings",
								className: cls,
								children: "Lịch đặt của tôi"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "row g12",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: "/my-bookings",
						className: "bell",
						"aria-label": "Thông báo",
						title: "Thông báo",
						children: [/* @__PURE__ */ _jsxDEV("img", {
							src: bell,
							alt: "",
							width: 20,
							height: 20
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 15
						}, this), pend > 0 && /* @__PURE__ */ _jsxDEV("span", { className: "dot" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 28
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "user-box",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "avatar",
								children: user.role === "customer" ? "AN" : initials(user.name)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "col right",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "t12 w700 c-ink nowrap",
									children: user.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "t11 w500 c-brand nowrap",
									children: user.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 15
							}, this),
							user.role !== "customer" && /* @__PURE__ */ _jsxDEV(Link, {
								to: homeOf(user.role),
								className: "btn btn-outline btn-sm",
								style: { marginLeft: 4 },
								children: "← Về quản lý"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-outline btn-sm",
								style: {
									marginLeft: 4,
									fontWeight: 600
								},
								onClick: () => {
									logout();
									nav("/login");
								},
								children: "Đăng xuất"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "container col g24",
			style: {
				flex: 1,
				padding: "32px 24px 64px"
			},
			children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 78,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 42,
		columnNumber: 5
	}, this);
}
_s2(CustomerLayout, "XSCnk2DCK1GiEXyuxe99J57nGRY=", false, function() {
	return [useApp, useNavigate];
});
_c2 = CustomerLayout;
function SideItem({ to, label, icon, iconActive }) {
	return /* @__PURE__ */ _jsxDEV(NavLink, {
		to,
		className: ({ isActive }) => `side-item${isActive ? " active" : ""}`,
		children: ({ isActive }) => /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("img", {
			src: isActive ? iconActive : icon,
			alt: ""
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 88,
			columnNumber: 29
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 88,
			columnNumber: 78
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 88,
			columnNumber: 27
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 87,
		columnNumber: 5
	}, this);
}
_c3 = SideItem;
const META = {
	"/staff/booking": {
		title: "Đặt sân tại quầy & Thu ngân",
		desc: "Lập đơn nhanh cho khách vãng lai hoặc khách có tài khoản, áp dụng khuyến mãi và thu tiền trực tiếp"
	},
	"/staff/orders": {
		title: "Quản lý đơn đặt & Bàn giao sân",
		desc: "Tra cứu lịch đặt của khách, thu nốt tiền còn thiếu khi nhận sân và cập nhật trạng thái sân"
	},
	"/staff/stats": {
		title: "Tổng quan vận hành & Doanh thu trong ngày",
		desc: "Theo dõi nhanh tình trạng lấp đầy sân, các đơn sắp nhận sân và tổng tiền thực thu trong ca trực"
	},
	"/owner/staff": {
		title: "Quản lý đội ngũ nhân viên",
		desc: "Phân công nhân viên theo từng chi nhánh, cấp mới hoặc khóa tài khoản nhân sự nghỉ việc",
		pick: true
	},
	"/owner/courts": {
		title: "Quản lý sân bãi, Bảng giá & Lịch bảo trì",
		desc: "Thêm sân mới, điều chỉnh đơn giá thuê theo khung giờ, cài đặt giờ mở cửa và tạm khóa sân bảo trì",
		pick: true
	},
	"/owner/reports": {
		title: "Quản lý Khuyến mãi & Báo cáo doanh thu chuyên sâu",
		desc: "Thống kê doanh thu thực thu theo từng chi nhánh, tỷ lệ lấp đầy sân và quản lý các chương trình giảm giá",
		pick: true
	}
};
export function StaffLayout() {
	_s3();
	const loc = useLocation();
	const meta = META[loc.pathname] ?? META["/staff/booking"];
	const [branchFilter, setBranchFilter] = useState("all");
	const { user, logout, branches } = useApp();
	const nav = useNavigate();
	if (!user) return null;
	const owner = user.role === "owner";
	const branch = user.branchId ? branchOf(user.branchId) : branches[0];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "staff-shell",
		children: [/* @__PURE__ */ _jsxDEV("aside", {
			className: "sidebar",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "side-logo",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "mk",
						children: "S"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "col g4",
						style: { paddingBottom: 1.5 },
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "t16 w800 c-white",
							style: {
								lineHeight: "16px",
								letterSpacing: -.4
							},
							children: "SportHub POS"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "t11 w500",
							style: { color: "var(--s400)" },
							children: "Quản lý & Vận hành sân"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					className: "side-menu",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "side-sec",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "side-title",
									children: "Nghiệp vụ tại quầy"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(SideItem, {
									to: "/staff/booking",
									label: "Đặt sân tại quầy",
									icon: iBooking,
									iconActive: iBookingA
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(SideItem, {
									to: "/staff/orders",
									label: "Quản lý đơn & Nhận sân",
									icon: iOrders,
									iconActive: iOrdersA
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 126,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(SideItem, {
									to: "/staff/stats",
									label: "Thống kê trong ngày",
									icon: iStats,
									iconActive: iStatsA
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 11
						}, this),
						owner && /* @__PURE__ */ _jsxDEV("div", {
							className: "side-sec",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "side-title gold",
									children: "Quản trị hệ thống"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(SideItem, {
									to: "/owner/staff",
									label: "Quản lý nhân viên",
									icon: iStaff,
									iconActive: iStaffA
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(SideItem, {
									to: "/owner/courts",
									label: "Quản lý sân bãi",
									icon: iCourts,
									iconActive: iCourtsA
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(SideItem, {
									to: "/owner/reports",
									label: "Khuyến mãi & Báo cáo",
									icon: iPromo,
									iconActive: iPromoA
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "side-sec",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "side-title",
								children: "Kênh khách hàng"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								className: "side-item",
								children: [/* @__PURE__ */ _jsxDEV("img", {
									src: iExternal,
									alt: ""
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: owner ? "Giao diện Khách đặt sân" : "Quay lại" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 45
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "side-user",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "row g10",
						style: { minWidth: 0 },
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "avatar lg",
							style: { background: "var(--brand-700)" },
							children: initials(user.name)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "col",
							style: { minWidth: 0 },
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "t12 w700 c-white nowrap",
								children: user.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "t11 w500 nowrap",
								style: { color: "var(--brand-400)" },
								children: user.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "side-exit",
						onClick: () => {
							logout();
							nav("/login");
						},
						children: "Thoát"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 114,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "work",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "topbar",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "col",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "t18 w800 c-ink",
						children: meta.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "t12 c-s600",
						children: meta.desc
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 157,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "row g12",
					children: [meta.pick ? /* @__PURE__ */ _jsxDEV("div", {
						className: "row g8",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "t12 w600 c-s600",
							children: "Chi nhánh:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 39
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							className: "select sm bold fit",
							style: {
								background: "var(--s100)",
								padding: "8px 30px 8px 18px"
							},
							value: branchFilter,
							onChange: (e) => setBranchFilter(e.target.value),
							children: [/* @__PURE__ */ _jsxDEV("option", {
								value: "all",
								children: [
									"Tất cả chi nhánh (",
									branches.length,
									" cơ sở)"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 19
							}, this), branches.map((b) => /* @__PURE__ */ _jsxDEV("option", {
								value: b.id,
								children: b.name
							}, b.id, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 40
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "chip-box row g8",
						children: [/* @__PURE__ */ _jsxDEV("i", { style: {
							width: 10,
							height: 10,
							borderRadius: 9999,
							background: "var(--brand-600)"
						} }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 48
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							style: { fontWeight: 700 },
							children: ["Chi nhánh: ", /* @__PURE__ */ _jsxDEV("b", {
								className: "w900",
								children: branch.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 62
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 170,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "chip-box",
						children: [
							dow(TODAY),
							", ",
							toVN(TODAY)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 161,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 156,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "work-body",
				children: /* @__PURE__ */ _jsxDEV(Outlet, { context: {
					branchFilter,
					setBranchFilter
				} }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 175,
					columnNumber: 36
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 175,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 155,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 113,
		columnNumber: 5
	}, this);
}
_s3(StaffLayout, "Br9fz7SPTGUPIRJqrt5nalT+jJc=", false, function() {
	return [
		useLocation,
		useApp,
		useNavigate
	];
});
_c4 = StaffLayout;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "Guard");
$RefreshReg$(_c2, "CustomerLayout");
$RefreshReg$(_c3, "SideItem");
$RefreshReg$(_c4, "StaffLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/layouts.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/layouts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/layouts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/layouts.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLFNBQVMsVUFBVSxRQUFRLGFBQWEsYUFBYSx3QkFBd0I7QUFDNUYsU0FBUyxjQUFjO0FBRXZCLFNBQVMsT0FBTyxLQUFLLE1BQU0sZ0JBQWdCO0FBQzNDLE9BQU8sVUFBVTtBQUNqQixPQUFPLGNBQWM7QUFDckIsT0FBTyxlQUFlO0FBQ3RCLE9BQU8sYUFBYTtBQUNwQixPQUFPLGNBQWM7QUFDckIsT0FBTyxZQUFZO0FBQ25CLE9BQU8sYUFBYTtBQUNwQixPQUFPLGVBQWU7QUFDdEIsT0FBTyxZQUFZO0FBQ25CLE9BQU8sYUFBYTtBQUNwQixPQUFPLGFBQWE7QUFDcEIsT0FBTyxjQUFjO0FBQ3JCLE9BQU8sWUFBWTtBQUNuQixPQUFPLGFBQWE7Ozs7QUFFcEIsT0FBTyxNQUFNLFlBQVksU0FBaUI7Q0FBRSxNQUFNLElBQUksS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU8sT0FBTztDQUFHLFNBQVMsRUFBRSxFQUFFLEdBQUcsTUFBTSxPQUFPLEVBQUUsU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxLQUFLLElBQUcsQ0FBRSxZQUFZO0FBQUU7QUFDM0ssT0FBTyxNQUFNLFVBQVUsU0FBZ0IsU0FBUyxhQUFhLE1BQU0sU0FBUyxVQUFVLG1CQUFtQjs7QUFHekcsT0FBTyxTQUFTLE1BQU0sRUFBRSxPQUFzQjs7Q0FDNUMsTUFBTSxFQUFFLFNBQVMsT0FBTztDQUN4QixNQUFNLE1BQU0sWUFBWTtDQUN4QixNQUFNLE1BQU0saUJBQWlCO0NBQzdCLE1BQU0sT0FBTztFQUFFLFVBQVU7RUFBRyxPQUFPO0VBQUcsT0FBTztDQUFFO0NBQy9DLElBQUksQ0FBQyxNQUFNLE9BQU8sd0JBQUMsVUFBRDtFQUFVLElBQUc7RUFBUztFQUFRLE9BQU8sRUFBRSxNQUFNLElBQUksU0FBUztDQUFJOzs7OztDQUNoRixJQUFJLEtBQUssS0FBSyxRQUFRLEtBQUssTUFBTSxPQUFPLHdCQUFDLFVBQUQ7RUFBVSxJQUFJLE9BQU8sS0FBSyxJQUFJO0VBQUc7Q0FBUzs7Ozs7Q0FDbEYsT0FBTyx3QkFBQyxRQUFELEVBQVEsU0FBUyxJQUFNOzs7OztBQUNoQzs7Ozs7Ozs7O0FBRUEsT0FBTyxTQUFTLGlCQUFpQjs7Q0FDL0IsTUFBTSxFQUFFLE1BQU0sUUFBUSxhQUFhLE9BQU87Q0FDMUMsTUFBTSxNQUFNLFlBQVk7Q0FDeEIsTUFBTSxPQUFPLFNBQVMsUUFBUSxNQUFNLEVBQUUsV0FBVyxTQUFTLENBQUMsQ0FBQztDQUM1RCxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLE1BQU0sT0FBTyxFQUFFLGVBQXNDLFdBQVcsV0FBVyxZQUFZO0NBQ3ZGLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBTSxPQUFPLEVBQUUsV0FBVyxRQUFRO1lBQWpELENBQ0Usd0JBQUMsVUFBRDtHQUFRLFdBQVU7YUFDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQU0sSUFBRztNQUFJLFdBQVU7Z0JBQXZCLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQVk7TUFBTTs7OztnQkFDakMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBUyxPQUFPLEVBQUUsZUFBZSxFQUFFO2lCQUFsRCxDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFZO09BQWM7Ozs7aUJBQzFDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFXO09BQWlDOzs7O2VBQ3pEOzs7OztjQUNEOzs7OztlQUNOLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsU0FBRDtRQUFTLElBQUc7UUFBSTtRQUFJLFdBQVc7a0JBQUs7T0FBa0I7Ozs7O09BQ3RELHdCQUFDLFNBQUQ7UUFBUyxJQUFHO1FBQVcsV0FBVztrQkFBSztPQUEyQjs7Ozs7T0FDbEUsd0JBQUMsU0FBRDtRQUFTLElBQUc7UUFBZSxXQUFXO2tCQUFLO09BQXlCOzs7OztNQUNqRTs7Ozs7YUFDRjs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFNLElBQUc7TUFBZSxXQUFVO01BQU8sY0FBVztNQUFZLE9BQU07Z0JBQXRFLENBQ0Usd0JBQUMsT0FBRDtPQUFLLEtBQUs7T0FBTSxLQUFJO09BQUcsT0FBTztPQUFJLFFBQVE7TUFBSzs7OztnQkFDOUMsT0FBTyxLQUFLLHdCQUFDLFFBQUQsRUFBTSxXQUFVLE1BQU87Ozs7Y0FDaEM7Ozs7O2VBQ04sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBVSxLQUFLLFNBQVMsYUFBYSxPQUFPLFNBQVMsS0FBSyxJQUFJO09BQU87Ozs7O09BQ3BGLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXlCLEtBQUs7UUFBVzs7OztrQkFDekQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTJCLEtBQUs7UUFBWTs7OztnQkFDekQ7Ozs7OztPQUNKLEtBQUssU0FBUyxjQUNiLHdCQUFDLE1BQUQ7UUFBTSxJQUFJLE9BQU8sS0FBSyxJQUFJO1FBQUcsV0FBVTtRQUF5QixPQUFPLEVBQUUsWUFBWSxFQUFFO2tCQUFHO09BQWtCOzs7OztPQUU5Ryx3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUF5QixPQUFPO1NBQUUsWUFBWTtTQUFHLFlBQVk7UUFBSTtRQUFHLGVBQWU7U0FBRSxPQUFPO1NBQUcsSUFBSSxRQUFRO1FBQUU7a0JBQUc7T0FBaUI7Ozs7O01BQ2hKOzs7OzthQUNGOzs7OztZQUNGOzs7Ozs7RUFDQzs7OztZQUNSLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO0dBQW9CLE9BQU87SUFBRSxNQUFNO0lBQUcsU0FBUztHQUFpQjthQUM5RSx3QkFBQyxRQUFELENBQVM7Ozs7O0VBQ0w7Ozs7VUFDSDs7Ozs7O0FBRVQ7Ozs7O0FBRUEsU0FBUyxTQUFTLEVBQUUsSUFBSSxPQUFPLE1BQU0sY0FBK0U7Q0FDbEgsT0FDRSx3QkFBQyxTQUFEO0VBQWE7RUFBSSxZQUFZLEVBQUUsZUFBZSxZQUFZLFdBQVcsWUFBWTthQUM3RSxFQUFFLGVBQWdCLGdEQUFFLHdCQUFDLE9BQUQ7R0FBSyxLQUFLLFdBQVcsYUFBYTtHQUFNLEtBQUk7RUFBSTs7OztZQUFDLHdCQUFDLFFBQUQsWUFBTyxNQUFZOzs7O1VBQUc7Ozs7O0NBQ3RGOzs7OztBQUViOztBQUVBLE1BQU0sT0FBd0U7Q0FDNUUsa0JBQWtCO0VBQUUsT0FBTztFQUErQixNQUFNO0NBQXFHO0NBQ3JLLGlCQUFpQjtFQUFFLE9BQU87RUFBa0MsTUFBTTtDQUE2RjtDQUMvSixnQkFBZ0I7RUFBRSxPQUFPO0VBQTZDLE1BQU07Q0FBa0c7Q0FDOUssZ0JBQWdCO0VBQUUsT0FBTztFQUE2QixNQUFNO0VBQTBGLE1BQU07Q0FBSztDQUNqSyxpQkFBaUI7RUFBRSxPQUFPO0VBQTRDLE1BQU07RUFBb0csTUFBTTtDQUFLO0NBQzNMLGtCQUFrQjtFQUFFLE9BQU87RUFBcUQsTUFBTTtFQUEyRyxNQUFNO0NBQUs7QUFDOU07QUFHQSxPQUFPLFNBQVMsY0FBYzs7Q0FDNUIsTUFBTSxNQUFNLFlBQVk7Q0FDeEIsTUFBTSxPQUFPLEtBQUssSUFBSSxhQUFhLEtBQUs7Q0FDeEMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLEVBQUUsTUFBTSxRQUFRLGFBQWEsT0FBTztDQUMxQyxNQUFNLE1BQU0sWUFBWTtDQUN4QixJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLE1BQU0sUUFBUSxLQUFLLFNBQVM7Q0FDNUIsTUFBTSxTQUFTLEtBQUssV0FBVyxTQUFTLEtBQUssUUFBUSxJQUFJLFNBQVM7Q0FDbEUsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsU0FBRDtHQUFPLFdBQVU7YUFBakI7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQUs7S0FBTTs7OztlQUMxQix3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFTLE9BQU8sRUFBRSxlQUFlLElBQUk7Z0JBQXBELENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBbUIsT0FBTztRQUFFLFlBQVk7UUFBUSxlQUFlLENBQUM7T0FBSTtpQkFBRztNQUFrQjs7OztnQkFDekcsd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBVyxPQUFPLEVBQUUsT0FBTyxjQUFjO2lCQUFHO01BQTRCOzs7O2NBQ3JGOzs7OzthQUNGOzs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBYTtRQUF1Qjs7Ozs7UUFDbkQsd0JBQUMsVUFBRDtTQUFVLElBQUc7U0FBaUIsT0FBTTtTQUFtQixNQUFNO1NBQVUsWUFBWTtRQUFZOzs7OztRQUMvRix3QkFBQyxVQUFEO1NBQVUsSUFBRztTQUFnQixPQUFNO1NBQXlCLE1BQU07U0FBUyxZQUFZO1FBQVc7Ozs7O1FBQ2xHLHdCQUFDLFVBQUQ7U0FBVSxJQUFHO1NBQWUsT0FBTTtTQUFzQixNQUFNO1NBQVEsWUFBWTtRQUFVOzs7OztPQUN6Rjs7Ozs7O01BQ0osU0FDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFrQjtRQUFzQjs7Ozs7UUFDdkQsd0JBQUMsVUFBRDtTQUFVLElBQUc7U0FBZSxPQUFNO1NBQW9CLE1BQU07U0FBUSxZQUFZO1FBQVU7Ozs7O1FBQzFGLHdCQUFDLFVBQUQ7U0FBVSxJQUFHO1NBQWdCLE9BQU07U0FBa0IsTUFBTTtTQUFTLFlBQVk7UUFBVzs7Ozs7UUFDM0Ysd0JBQUMsVUFBRDtTQUFVLElBQUc7U0FBaUIsT0FBTTtTQUF1QixNQUFNO1NBQVEsWUFBWTtRQUFVOzs7OztPQUM1Rjs7Ozs7O01BRVAsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBYTtPQUFvQjs7OztpQkFDaEQsd0JBQUMsTUFBRDtRQUFNLElBQUc7UUFBSSxXQUFVO2tCQUF2QixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxLQUFLO1NBQVcsS0FBSTtRQUFJOzs7O2tCQUFDLHdCQUFDLFFBQUQsWUFBTyxRQUFRLDRCQUE0QixXQUFpQjs7OztnQkFDdEY7Ozs7O2VBQ0g7Ozs7OztLQUNGOzs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBVSxPQUFPLEVBQUUsVUFBVSxFQUFFO2dCQUE5QyxDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVksT0FBTyxFQUFFLFlBQVksbUJBQW1CO2lCQUFJLFNBQVMsS0FBSyxJQUFJO01BQU87Ozs7Z0JBQ2hHLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQU0sT0FBTyxFQUFFLFVBQVUsRUFBRTtpQkFBMUMsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkIsS0FBSztPQUFXOzs7O2lCQUMzRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUFrQixPQUFPLEVBQUUsT0FBTyxtQkFBbUI7a0JBQUksS0FBSztPQUFZOzs7O2VBQ3ZGOzs7OztjQUNGOzs7OztlQUNMLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQVksZUFBZTtPQUFFLE9BQU87T0FBRyxJQUFJLFFBQVE7TUFBRTtnQkFBRztLQUFhOzs7O2FBQ3BGOzs7Ozs7R0FDQTs7Ozs7WUFDUCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBa0IsS0FBSztLQUFVOzs7O2VBQy9DLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFjLEtBQUs7S0FBUTs7OzthQUNyQzs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0csS0FBSyxPQUNKLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQXdCLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFrQjtNQUFnQjs7OztnQkFDeEUsd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBcUIsT0FBTztRQUFFLFlBQVk7UUFBZSxTQUFTO09BQW9CO09BQUcsT0FBTztPQUFjLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7aUJBQS9LLENBQ0Usd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQWQ7U0FBb0I7U0FBbUIsU0FBUztTQUFPO1FBQWU7Ozs7O2lCQUNyRSxTQUFTLEtBQUssTUFBTSx3QkFBQyxVQUFEO1FBQW1CLE9BQU8sRUFBRTtrQkFBSyxFQUFFO09BQWEsR0FBbkMsRUFBRTs7OztjQUFpQyxDQUFDLENBQ2hFOzs7OztjQUFNOzs7OztnQkFFaEIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBaUMsd0JBQUMsS0FBRCxFQUFHLE9BQU87T0FBRSxPQUFPO09BQUksUUFBUTtPQUFJLGNBQWM7T0FBTSxZQUFZO01BQW1CLEVBQUk7Ozs7Z0JBQ3pILHdCQUFDLFFBQUQ7T0FBTSxPQUFPLEVBQUUsWUFBWSxJQUFJO2lCQUEvQixDQUFrQyxlQUFXLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFRLE9BQU87T0FBUTs7OztlQUFPOzs7OztjQUFNOzs7OztlQUVsRyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUEyQixJQUFJLEtBQUs7T0FBRTtPQUFHLEtBQUssS0FBSztNQUFPOzs7OzthQUN2RDs7Ozs7WUFDRjs7Ozs7YUFDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFZLHdCQUFDLFFBQUQsRUFBUSxTQUFTO0tBQUU7S0FBYztJQUFnQixFQUEwQjs7Ozs7R0FBTTs7OztXQUN6Rzs7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibGF5b3V0cy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IExpbmssIE5hdkxpbmssIE5hdmlnYXRlLCBPdXRsZXQsIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSwgdXNlT3V0bGV0Q29udGV4dCB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyB1c2VBcHAgfSBmcm9tICcuL3N0b3JlJ1xuaW1wb3J0IHR5cGUgeyBSb2xlIH0gZnJvbSAnLi9kYXRhJ1xuaW1wb3J0IHsgVE9EQVksIGRvdywgdG9WTiwgYnJhbmNoT2YgfSBmcm9tICcuL2RhdGEnXG5pbXBvcnQgYmVsbCBmcm9tICcuL2Fzc2V0cy9pY29ucy9iZWxsLnN2ZydcbmltcG9ydCBpQm9va2luZyBmcm9tICcuL2Fzc2V0cy9pY29ucy9uYXYtYm9va2luZy5zdmcnXG5pbXBvcnQgaUJvb2tpbmdBIGZyb20gJy4vYXNzZXRzL2ljb25zL25hdi1ib29raW5nLWFjdGl2ZS5zdmcnXG5pbXBvcnQgaU9yZGVycyBmcm9tICcuL2Fzc2V0cy9pY29ucy9uYXYtb3JkZXJzLnN2ZydcbmltcG9ydCBpT3JkZXJzQSBmcm9tICcuL2Fzc2V0cy9pY29ucy9uYXYtb3JkZXJzLWFjdGl2ZS5zdmcnXG5pbXBvcnQgaVN0YXRzIGZyb20gJy4vYXNzZXRzL2ljb25zL25hdi1zdGF0cy5zdmcnXG5pbXBvcnQgaVN0YXRzQSBmcm9tICcuL2Fzc2V0cy9pY29ucy9uYXYtc3RhdHMtYWN0aXZlLnN2ZydcbmltcG9ydCBpRXh0ZXJuYWwgZnJvbSAnLi9hc3NldHMvaWNvbnMvbmF2LWV4dGVybmFsLnN2ZydcbmltcG9ydCBpU3RhZmYgZnJvbSAnLi9hc3NldHMvaWNvbnMvbmF2LXN0YWZmLnN2ZydcbmltcG9ydCBpU3RhZmZBIGZyb20gJy4vYXNzZXRzL2ljb25zL25hdi1zdGFmZi1hY3RpdmUuc3ZnJ1xuaW1wb3J0IGlDb3VydHMgZnJvbSAnLi9hc3NldHMvaWNvbnMvbmF2LWNvdXJ0cy5zdmcnXG5pbXBvcnQgaUNvdXJ0c0EgZnJvbSAnLi9hc3NldHMvaWNvbnMvbmF2LWNvdXJ0cy1hY3RpdmUuc3ZnJ1xuaW1wb3J0IGlQcm9tbyBmcm9tICcuL2Fzc2V0cy9pY29ucy9uYXYtcHJvbW8uc3ZnJ1xuaW1wb3J0IGlQcm9tb0EgZnJvbSAnLi9hc3NldHMvaWNvbnMvbmF2LXByb21vLWFjdGl2ZS5zdmcnXG5cbmV4cG9ydCBjb25zdCBpbml0aWFscyA9IChuYW1lOiBzdHJpbmcpID0+IHsgY29uc3QgdyA9IG5hbWUuc3BsaXQoJyAnKS5maWx0ZXIoQm9vbGVhbik7IHJldHVybiAoKHdbMF0/LlswXSA/PyAnJykgKyAody5sZW5ndGggPiAxID8gd1t3Lmxlbmd0aCAtIDFdWzBdIDogJycpKS50b1VwcGVyQ2FzZSgpIH1cbmV4cG9ydCBjb25zdCBob21lT2YgPSAocm9sZTogUm9sZSkgPT4gKHJvbGUgPT09ICdjdXN0b21lcicgPyAnLycgOiByb2xlID09PSAnc3RhZmYnID8gJy9zdGFmZi9ib29raW5nJyA6ICcvb3duZXIvc3RhZmYnKVxuXG4vKiogQ2jhurduIHRydXkgY+G6rXAgdGhlbyB2YWkgdHLDsi4gVmFpIHRyw7Igc2F1IGvhur8gdGjhu6thIGdpYW8gZGnhu4duIGPhu6dhIHZhaSB0csOyIHRyxrDhu5tjLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEd1YXJkKHsgbWluIH06IHsgbWluOiBSb2xlIH0pIHtcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBcHAoKVxuICBjb25zdCBsb2MgPSB1c2VMb2NhdGlvbigpXG4gIGNvbnN0IGN0eCA9IHVzZU91dGxldENvbnRleHQoKVxuICBjb25zdCByYW5rID0geyBjdXN0b21lcjogMCwgc3RhZmY6IDEsIG93bmVyOiAyIH1cbiAgaWYgKCF1c2VyKSByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZSBzdGF0ZT17eyBmcm9tOiBsb2MucGF0aG5hbWUgfX0gLz5cbiAgaWYgKHJhbmtbdXNlci5yb2xlXSA8IHJhbmtbbWluXSkgcmV0dXJuIDxOYXZpZ2F0ZSB0bz17aG9tZU9mKHVzZXIucm9sZSl9IHJlcGxhY2UgLz5cbiAgcmV0dXJuIDxPdXRsZXQgY29udGV4dD17Y3R4fSAvPlxufVxuXG5leHBvcnQgZnVuY3Rpb24gQ3VzdG9tZXJMYXlvdXQoKSB7XG4gIGNvbnN0IHsgdXNlciwgbG9nb3V0LCBib29raW5ncyB9ID0gdXNlQXBwKClcbiAgY29uc3QgbmF2ID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBwZW5kID0gYm9va2luZ3MuZmlsdGVyKChiKSA9PiBiLnN0YXR1cyA9PT0gJ3BlbmRpbmcnKS5sZW5ndGhcbiAgaWYgKCF1c2VyKSByZXR1cm4gbnVsbFxuICBjb25zdCBjbHMgPSAoeyBpc0FjdGl2ZSB9OiB7IGlzQWN0aXZlOiBib29sZWFuIH0pID0+IGBuYXYtbGluayR7aXNBY3RpdmUgPyAnIGFjdGl2ZScgOiAnJ31gXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb2xcIiBzdHlsZT17eyBtaW5IZWlnaHQ6ICcxMDB2aCcgfX0+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImhkclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciBoZHItaW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMzJcIj5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cInJvdyBnMTBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2dvLW1hcmtcIj5TPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGc0XCIgc3R5bGU9e3sgcGFkZGluZ0JvdHRvbTogMiB9fT5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsb2dvLW5hbWVcIj5TcG9ydEh1Yjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsb2dvLXN1YlwiPsSQ4bq3dCBzw6JuIHRo4buDIHRoYW8gdHLhu7FjIHR1eeG6v248L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJyb3cgZzZcIj5cbiAgICAgICAgICAgICAgPE5hdkxpbmsgdG89XCIvXCIgZW5kIGNsYXNzTmFtZT17Y2xzfT5UcmFuZyBjaOG7pzwvTmF2TGluaz5cbiAgICAgICAgICAgICAgPE5hdkxpbmsgdG89XCIvYm9va2luZ1wiIGNsYXNzTmFtZT17Y2xzfT7EkOG6t3Qgc8OibiB0cuG7sWMgdHV54bq/bjwvTmF2TGluaz5cbiAgICAgICAgICAgICAgPE5hdkxpbmsgdG89XCIvbXktYm9va2luZ3NcIiBjbGFzc05hbWU9e2Nsc30+TOG7i2NoIMSR4bq3dCBj4bunYSB0w7RpPC9OYXZMaW5rPlxuICAgICAgICAgICAgPC9uYXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzEyXCI+XG4gICAgICAgICAgICA8TGluayB0bz1cIi9teS1ib29raW5nc1wiIGNsYXNzTmFtZT1cImJlbGxcIiBhcmlhLWxhYmVsPVwiVGjDtG5nIGLDoW9cIiB0aXRsZT1cIlRow7RuZyBiw6FvXCI+XG4gICAgICAgICAgICAgIDxpbWcgc3JjPXtiZWxsfSBhbHQ9XCJcIiB3aWR0aD17MjB9IGhlaWdodD17MjB9IC8+XG4gICAgICAgICAgICAgIHtwZW5kID4gMCAmJiA8c3BhbiBjbGFzc05hbWU9XCJkb3RcIiAvPn1cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidXNlci1ib3hcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdmF0YXJcIj57dXNlci5yb2xlID09PSAnY3VzdG9tZXInID8gJ0FOJyA6IGluaXRpYWxzKHVzZXIubmFtZSl9PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIHJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDEyIHc3MDAgYy1pbmsgbm93cmFwXCI+e3VzZXIubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDExIHc1MDAgYy1icmFuZCBub3dyYXBcIj57dXNlci50aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICB7dXNlci5yb2xlICE9PSAnY3VzdG9tZXInICYmIChcbiAgICAgICAgICAgICAgICA8TGluayB0bz17aG9tZU9mKHVzZXIucm9sZSl9IGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZSBidG4tc21cIiBzdHlsZT17eyBtYXJnaW5MZWZ0OiA0IH19PuKGkCBW4buBIHF14bqjbiBsw708L0xpbms+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1zbVwiIHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDQsIGZvbnRXZWlnaHQ6IDYwMCB9fSBvbkNsaWNrPXsoKSA9PiB7IGxvZ291dCgpOyBuYXYoJy9sb2dpbicpIH19PsSQxINuZyB4deG6pXQ8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiY29udGFpbmVyIGNvbCBnMjRcIiBzdHlsZT17eyBmbGV4OiAxLCBwYWRkaW5nOiAnMzJweCAyNHB4IDY0cHgnIH19PlxuICAgICAgICA8T3V0bGV0IC8+XG4gICAgICA8L21haW4+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gU2lkZUl0ZW0oeyB0bywgbGFiZWwsIGljb24sIGljb25BY3RpdmUgfTogeyB0bzogc3RyaW5nOyBsYWJlbDogc3RyaW5nOyBpY29uOiBzdHJpbmc7IGljb25BY3RpdmU6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPE5hdkxpbmsgdG89e3RvfSBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+IGBzaWRlLWl0ZW0ke2lzQWN0aXZlID8gJyBhY3RpdmUnIDogJyd9YH0+XG4gICAgICB7KHsgaXNBY3RpdmUgfSkgPT4gKDw+PGltZyBzcmM9e2lzQWN0aXZlID8gaWNvbkFjdGl2ZSA6IGljb259IGFsdD1cIlwiIC8+PHNwYW4+e2xhYmVsfTwvc3Bhbj48Lz4pfVxuICAgIDwvTmF2TGluaz5cbiAgKVxufVxuXG5jb25zdCBNRVRBOiBSZWNvcmQ8c3RyaW5nLCB7IHRpdGxlOiBzdHJpbmc7IGRlc2M6IHN0cmluZzsgcGljaz86IGJvb2xlYW4gfT4gPSB7XG4gICcvc3RhZmYvYm9va2luZyc6IHsgdGl0bGU6ICfEkOG6t3Qgc8OibiB04bqhaSBxdeG6p3kgJiBUaHUgbmfDom4nLCBkZXNjOiAnTOG6rXAgxJHGoW4gbmhhbmggY2hvIGtow6FjaCB2w6NuZyBsYWkgaG/hurdjIGtow6FjaCBjw7MgdMOgaSBraG/huqNuLCDDoXAgZOG7pW5nIGtodXnhur9uIG3Do2kgdsOgIHRodSB0aeG7gW4gdHLhu7FjIHRp4bq/cCcgfSxcbiAgJy9zdGFmZi9vcmRlcnMnOiB7IHRpdGxlOiAnUXXhuqNuIGzDvSDEkcahbiDEkeG6t3QgJiBCw6BuIGdpYW8gc8OibicsIGRlc2M6ICdUcmEgY+G7qXUgbOG7i2NoIMSR4bq3dCBj4bunYSBraMOhY2gsIHRodSBu4buRdCB0aeG7gW4gY8OybiB0aGnhur91IGtoaSBuaOG6rW4gc8OibiB2w6AgY+G6rXAgbmjhuq10IHRy4bqhbmcgdGjDoWkgc8OibicgfSxcbiAgJy9zdGFmZi9zdGF0cyc6IHsgdGl0bGU6ICdU4buVbmcgcXVhbiB24bqtbiBow6BuaCAmIERvYW5oIHRodSB0cm9uZyBuZ8OgeScsIGRlc2M6ICdUaGVvIGTDtWkgbmhhbmggdMOsbmggdHLhuqFuZyBs4bqlcCDEkeG6p3kgc8OibiwgY8OhYyDEkcahbiBz4bqvcCBuaOG6rW4gc8OibiB2w6AgdOG7lW5nIHRp4buBbiB0aOG7sWMgdGh1IHRyb25nIGNhIHRy4buxYycgfSxcbiAgJy9vd25lci9zdGFmZic6IHsgdGl0bGU6ICdRdeG6o24gbMO9IMSR4buZaSBuZ8WpIG5ow6JuIHZpw6puJywgZGVzYzogJ1Bow6JuIGPDtG5nIG5ow6JuIHZpw6puIHRoZW8gdOG7q25nIGNoaSBuaMOhbmgsIGPhuqVwIG3hu5tpIGhv4bq3YyBraMOzYSB0w6BpIGtob+G6o24gbmjDom4gc+G7sSBuZ2jhu4kgdmnhu4djJywgcGljazogdHJ1ZSB9LFxuICAnL293bmVyL2NvdXJ0cyc6IHsgdGl0bGU6ICdRdeG6o24gbMO9IHPDom4gYsOjaSwgQuG6o25nIGdpw6EgJiBM4buLY2ggYuG6o28gdHLDrCcsIGRlc2M6ICdUaMOqbSBzw6JuIG3hu5tpLCDEkWnhu4F1IGNo4buJbmggxJHGoW4gZ2nDoSB0aHXDqiB0aGVvIGtodW5nIGdp4budLCBjw6BpIMSR4bq3dCBnaeG7nSBt4bufIGPhu61hIHbDoCB04bqhbSBraMOzYSBzw6JuIGLhuqNvIHRyw6wnLCBwaWNrOiB0cnVlIH0sXG4gICcvb3duZXIvcmVwb3J0cyc6IHsgdGl0bGU6ICdRdeG6o24gbMO9IEtodXnhur9uIG3Do2kgJiBCw6FvIGPDoW8gZG9hbmggdGh1IGNodXnDqm4gc8OidScsIGRlc2M6ICdUaOG7kW5nIGvDqiBkb2FuaCB0aHUgdGjhu7FjIHRodSB0aGVvIHThu6tuZyBjaGkgbmjDoW5oLCB04bu3IGzhu4cgbOG6pXAgxJHhuqd5IHPDom4gdsOgIHF14bqjbiBsw70gY8OhYyBjaMawxqFuZyB0csOsbmggZ2nhuqNtIGdpw6EnLCBwaWNrOiB0cnVlIH0sXG59XG5leHBvcnQgaW50ZXJmYWNlIFN0YWZmT3V0bGV0IHsgYnJhbmNoRmlsdGVyOiBzdHJpbmc7IHNldEJyYW5jaEZpbHRlcjogKHY6IHN0cmluZykgPT4gdm9pZCB9XG5cbmV4cG9ydCBmdW5jdGlvbiBTdGFmZkxheW91dCgpIHtcbiAgY29uc3QgbG9jID0gdXNlTG9jYXRpb24oKVxuICBjb25zdCBtZXRhID0gTUVUQVtsb2MucGF0aG5hbWVdID8/IE1FVEFbJy9zdGFmZi9ib29raW5nJ11cbiAgY29uc3QgW2JyYW5jaEZpbHRlciwgc2V0QnJhbmNoRmlsdGVyXSA9IHVzZVN0YXRlKCdhbGwnKVxuICBjb25zdCB7IHVzZXIsIGxvZ291dCwgYnJhbmNoZXMgfSA9IHVzZUFwcCgpXG4gIGNvbnN0IG5hdiA9IHVzZU5hdmlnYXRlKClcbiAgaWYgKCF1c2VyKSByZXR1cm4gbnVsbFxuICBjb25zdCBvd25lciA9IHVzZXIucm9sZSA9PT0gJ293bmVyJ1xuICBjb25zdCBicmFuY2ggPSB1c2VyLmJyYW5jaElkID8gYnJhbmNoT2YodXNlci5icmFuY2hJZCkgOiBicmFuY2hlc1swXVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhZmYtc2hlbGxcIj5cbiAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJzaWRlYmFyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZS1sb2dvXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJta1wiPlM8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnNFwiIHN0eWxlPXt7IHBhZGRpbmdCb3R0b206IDEuNSB9fT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxNiB3ODAwIGMtd2hpdGVcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMTZweCcsIGxldHRlclNwYWNpbmc6IC0wLjQgfX0+U3BvcnRIdWIgUE9TPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDExIHc1MDBcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXM0MDApJyB9fT5RdeG6o24gbMO9ICYgVuG6rW4gaMOgbmggc8Oibjwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwic2lkZS1tZW51XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWRlLXNlY1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWRlLXRpdGxlXCI+TmdoaeG7h3AgduG7pSB04bqhaSBxdeG6p3k8L2Rpdj5cbiAgICAgICAgICAgIDxTaWRlSXRlbSB0bz1cIi9zdGFmZi9ib29raW5nXCIgbGFiZWw9XCLEkOG6t3Qgc8OibiB04bqhaSBxdeG6p3lcIiBpY29uPXtpQm9va2luZ30gaWNvbkFjdGl2ZT17aUJvb2tpbmdBfSAvPlxuICAgICAgICAgICAgPFNpZGVJdGVtIHRvPVwiL3N0YWZmL29yZGVyc1wiIGxhYmVsPVwiUXXhuqNuIGzDvSDEkcahbiAmIE5o4bqtbiBzw6JuXCIgaWNvbj17aU9yZGVyc30gaWNvbkFjdGl2ZT17aU9yZGVyc0F9IC8+XG4gICAgICAgICAgICA8U2lkZUl0ZW0gdG89XCIvc3RhZmYvc3RhdHNcIiBsYWJlbD1cIlRo4buRbmcga8OqIHRyb25nIG5nw6B5XCIgaWNvbj17aVN0YXRzfSBpY29uQWN0aXZlPXtpU3RhdHNBfSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtvd25lciAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGUtc2VjXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZS10aXRsZSBnb2xkXCI+UXXhuqNuIHRy4buLIGjhu4cgdGjhu5FuZzwvZGl2PlxuICAgICAgICAgICAgICA8U2lkZUl0ZW0gdG89XCIvb3duZXIvc3RhZmZcIiBsYWJlbD1cIlF14bqjbiBsw70gbmjDom4gdmnDqm5cIiBpY29uPXtpU3RhZmZ9IGljb25BY3RpdmU9e2lTdGFmZkF9IC8+XG4gICAgICAgICAgICAgIDxTaWRlSXRlbSB0bz1cIi9vd25lci9jb3VydHNcIiBsYWJlbD1cIlF14bqjbiBsw70gc8OibiBiw6NpXCIgaWNvbj17aUNvdXJ0c30gaWNvbkFjdGl2ZT17aUNvdXJ0c0F9IC8+XG4gICAgICAgICAgICAgIDxTaWRlSXRlbSB0bz1cIi9vd25lci9yZXBvcnRzXCIgbGFiZWw9XCJLaHV54bq/biBtw6NpICYgQsOhbyBjw6FvXCIgaWNvbj17aVByb21vfSBpY29uQWN0aXZlPXtpUHJvbW9BfSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGUtc2VjXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGUtdGl0bGVcIj5Lw6puaCBraMOhY2ggaMOgbmc8L2Rpdj5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cInNpZGUtaXRlbVwiPlxuICAgICAgICAgICAgICA8aW1nIHNyYz17aUV4dGVybmFsfSBhbHQ9XCJcIiAvPjxzcGFuPntvd25lciA/ICdHaWFvIGRp4buHbiBLaMOhY2ggxJHhurd0IHPDom4nIDogJ1F1YXkgbOG6oWknfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9uYXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZS11c2VyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzEwXCIgc3R5bGU9e3sgbWluV2lkdGg6IDAgfX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF2YXRhciBsZ1wiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1icmFuZC03MDApJyB9fT57aW5pdGlhbHModXNlci5uYW1lKX08L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sXCIgc3R5bGU9e3sgbWluV2lkdGg6IDAgfX0+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NzAwIGMtd2hpdGUgbm93cmFwXCI+e3VzZXIubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMSB3NTAwIG5vd3JhcFwiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tYnJhbmQtNDAwKScgfX0+e3VzZXIudGl0bGV9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJzaWRlLWV4aXRcIiBvbkNsaWNrPXsoKSA9PiB7IGxvZ291dCgpOyBuYXYoJy9sb2dpbicpIH19PlRob8OhdDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXNpZGU+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIndvcmtcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0b3BiYXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbFwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInQxOCB3ODAwIGMtaW5rXCI+e21ldGEudGl0bGV9PC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj57bWV0YS5kZXNjfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTJcIj5cbiAgICAgICAgICAgIHttZXRhLnBpY2sgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGc4XCI+PHNwYW4gY2xhc3NOYW1lPVwidDEyIHc2MDAgYy1zNjAwXCI+Q2hpIG5ow6FuaDo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJzZWxlY3Qgc20gYm9sZCBmaXRcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAndmFyKC0tczEwMCknLCBwYWRkaW5nOiAnOHB4IDMwcHggOHB4IDE4cHgnIH19IHZhbHVlPXticmFuY2hGaWx0ZXJ9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJhbmNoRmlsdGVyKGUudGFyZ2V0LnZhbHVlKX0+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+VOG6pXQgY+G6oyBjaGkgbmjDoW5oICh7YnJhbmNoZXMubGVuZ3RofSBjxqEgc+G7nyk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgIHticmFuY2hlcy5tYXAoKGIpID0+IDxvcHRpb24ga2V5PXtiLmlkfSB2YWx1ZT17Yi5pZH0+e2IubmFtZX08L29wdGlvbj4pfVxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PjwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjaGlwLWJveCByb3cgZzhcIj48aSBzdHlsZT17eyB3aWR0aDogMTAsIGhlaWdodDogMTAsIGJvcmRlclJhZGl1czogOTk5OSwgYmFja2dyb3VuZDogJ3ZhcigtLWJyYW5kLTYwMCknIH19IC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNzAwIH19PkNoaSBuaMOhbmg6IDxiIGNsYXNzTmFtZT1cInc5MDBcIj57YnJhbmNoLm5hbWV9PC9iPjwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNoaXAtYm94XCI+e2RvdyhUT0RBWSl9LCB7dG9WTihUT0RBWSl9PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndvcmstYm9keVwiPjxPdXRsZXQgY29udGV4dD17eyBicmFuY2hGaWx0ZXIsIHNldEJyYW5jaEZpbHRlciB9IHNhdGlzZmllcyBTdGFmZk91dGxldH0gLz48L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=