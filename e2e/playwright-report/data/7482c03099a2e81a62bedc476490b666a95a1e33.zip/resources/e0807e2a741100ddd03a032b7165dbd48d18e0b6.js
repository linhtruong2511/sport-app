import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OwnerStaff.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { fmt } from "/src/data.ts";
import { useApp } from "/src/store.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/OwnerStaff.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
const TONE = {
	green: "b-green",
	sky: "b-sky",
	indigo: "b-indigo"
};
const empty = {
	name: "",
	phone: "",
	email: "",
	branchId: "cs1",
	password: "",
	locked: false
};
export default function OwnerStaff() {
	_s();
	const { staff, setStaff, branches, toast } = useApp();
	const { branchFilter, setBranchFilter } = useOutletContext();
	const [editId, setEditId] = useState(null);
	const [form, setForm] = useState(empty);
	const [err, setErr] = useState("");
	const list = staff.filter((s) => branchFilter === "all" || s.branchId === branchFilter);
	const active = list.filter((s) => !s.locked).length;
	const locked = list.length - active;
	const bOf = (id) => branches.find((b) => b.id === id);
	const edit = (s) => {
		setEditId(s.id);
		setForm({
			name: s.name,
			phone: s.phone,
			email: s.email,
			branchId: s.branchId,
			password: "",
			locked: s.locked
		});
		setErr("");
	};
	const reset = () => {
		setEditId(null);
		setForm({
			...empty,
			branchId: branchFilter === "all" ? "cs1" : branchFilter
		});
		setErr("");
	};
	const toggleLock = (s) => {
		setStaff((ss) => ss.map((x) => x.id === s.id ? {
			...x,
			locked: !x.locked
		} : x));
		toast(s.locked ? `Đã mở khóa tài khoản ${s.name}.` : `Đã khóa tài khoản ${s.name}. Lịch sử giao dịch vẫn được lưu giữ.`, "ok");
	};
	const save = () => {
		if (!form.name.trim()) return setErr("Vui lòng nhập họ và tên nhân viên.");
		if (!/^0\d{9}$/.test(form.phone.trim())) return setErr("Số điện thoại đăng nhập phải gồm 10 chữ số và bắt đầu bằng 0.");
		if (staff.some((s) => s.phone === form.phone.trim() && s.id !== editId)) return setErr("Số điện thoại này đã được cấp cho nhân viên khác.");
		if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) return setErr("Địa chỉ email không hợp lệ.");
		if (!editId && form.password.length < 6) return setErr("Mật khẩu cấp mới phải có tối thiểu 6 ký tự.");
		if (editId && form.password && form.password.length < 6) return setErr("Mật khẩu mới phải có tối thiểu 6 ký tự.");
		if (editId) {
			setStaff((ss) => ss.map((s) => s.id === editId ? {
				...s,
				name: form.name.trim(),
				phone: form.phone.trim(),
				email: form.email.trim(),
				branchId: form.branchId,
				locked: form.locked,
				password: form.password || s.password
			} : s));
			toast(`Đã cập nhật thông tin ${form.name}.`, "ok");
		} else {
			const id = `NV${String(staff.length + 1).padStart(3, "0")}`;
			setStaff((ss) => [...ss, {
				id,
				name: form.name.trim(),
				phone: form.phone.trim(),
				email: form.email.trim(),
				branchId: form.branchId,
				locked: form.locked,
				password: form.password,
				orders: 0,
				revenue: 0
			}]);
			toast(`Đã cấp tài khoản ${id} cho ${form.name}.`, "ok");
		}
		reset();
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
		className: "card row between wrap g16",
		style: { padding: 16 },
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "row g12 wrap",
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					className: "t12 w700 c-s700",
					children: "Lọc theo chi nhánh:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("select", {
					className: "select sm bold fit",
					style: {
						background: "var(--s50)",
						padding: "8px 30px 8px 18px",
						borderRadius: 12
					},
					value: branchFilter,
					onChange: (e) => setBranchFilter(e.target.value),
					children: [/* @__PURE__ */ _jsxDEV("option", {
						value: "all",
						children: [
							"Tất cả chi nhánh (",
							staff.length,
							" nhân sự)"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 13
					}, this), branches.map((b) => /* @__PURE__ */ _jsxDEV("option", {
						value: b.id,
						children: [
							b.name,
							" (",
							staff.filter((s) => s.branchId === b.id).length,
							" nhân sự)"
						]
					}, b.id, true, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 34
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "badge b-green-flat",
					style: {
						borderRadius: 8,
						padding: "6px 12px"
					},
					children: [active, " Đang làm việc"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "badge b-rose-soft",
					style: {
						borderRadius: 8,
						padding: "6px 12px",
						background: "var(--rose-100)",
						color: "var(--rose-900)"
					},
					children: [locked, " Đã khóa tài khoản"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			className: "btn btn-primary btn-md",
			style: { padding: "8px 16px" },
			onClick: reset,
			children: "+ Thêm nhân viên mới"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "grid12",
		children: [/* @__PURE__ */ _jsxDEV("section", {
			className: "span8 card col g16",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "row between",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "t14 w800 c-ink",
						children: "Danh sách nhân viên thu ngân tại các cơ sở"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "t12 c-s600",
						children: "Nhấp \"Sửa\" để thay đổi cơ sở hoặc thông tin liên hệ"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "tbl-wrap",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "tbl",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
							/* @__PURE__ */ _jsxDEV("th", { children: "Mã NV / Họ và tên" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 26
							}, this),
							/* @__PURE__ */ _jsxDEV("th", { children: "Số điện thoại / Email" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 52
							}, this),
							/* @__PURE__ */ _jsxDEV("th", { children: "Chi nhánh làm việc" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 82
							}, this),
							/* @__PURE__ */ _jsxDEV("th", { children: "Giao dịch đã thực hiện" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 109
							}, this),
							/* @__PURE__ */ _jsxDEV("th", { children: "Trạng thái" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 140
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "r",
								children: "Thao tác"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 159
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 22
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [list.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
							colSpan: 6,
							style: {
								textAlign: "center",
								padding: 32,
								color: "var(--s600)"
							},
							children: "Chưa có nhân viên tại chi nhánh này."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 43
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 39
						}, this), list.map((s) => /* @__PURE__ */ _jsxDEV("tr", {
							className: s.locked ? "dim" : editId === s.id ? "hl" : "",
							children: [
								/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "mono w800",
									style: {
										fontSize: 10.5,
										color: s.locked ? "var(--s700)" : "var(--s900)"
									},
									children: s.id
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "w700",
									style: { color: s.locked ? "var(--s700)" : "var(--s800)" },
									children: s.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 140
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "mono w700",
									style: { fontSize: 11 },
									children: s.phone
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "c-s600",
									children: s.email
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 92
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("span", {
									className: `badge ${s.locked ? "b-gray" : TONE[bOf(s.branchId).tone]}`,
									style: {
										borderRadius: 8,
										fontWeight: s.locked ? 600 : 700,
										background: s.locked ? "var(--s200)" : undefined
									},
									children: bOf(s.branchId).name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 25
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w700",
									children: s.locked && s.archived ? `${s.archived} đơn cũ (Đã lưu trữ)` : `${s.orders} đơn tại quầy`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: s.locked ? "c-brand8 w700" : "c-s600",
									children: [
										"Tổng thu: ",
										fmt(s.revenue),
										"đ"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 144
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("span", {
									className: `badge ${s.locked ? "b-rose" : "b-green"}`,
									style: { background: s.locked ? "var(--rose-100)" : undefined },
									children: s.locked ? "Đã khóa" : "Đang làm việc"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 25
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "r",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "row g8",
										style: { justifyContent: "flex-end" },
										children: s.locked ? /* @__PURE__ */ _jsxDEV("button", {
											className: "btn btn-sm",
											style: {
												background: "#fff",
												border: "1px solid var(--brand-400)",
												color: "var(--brand-800)",
												padding: "6px 10px"
											},
											onClick: () => toggleLock(s),
											children: "Mở khóa"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 80,
											columnNumber: 37
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
											className: "btn btn-outline btn-sm",
											style: {
												padding: "6px 10px",
												color: "var(--s800)"
											},
											onClick: () => edit(s),
											children: "Sửa"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 81,
											columnNumber: 29
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											className: "btn btn-danger-o btn-sm",
											style: { padding: "6px 10px" },
											onClick: () => toggleLock(s),
											children: "Khóa"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 82,
											columnNumber: 29
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 81,
											columnNumber: 27
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 79,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 78,
									columnNumber: 21
								}, this)
							]
						}, s.id, true, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 19
						}, this))] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "hint",
					style: { lineHeight: "16px" },
					children: "🔒 Khi khóa tài khoản nhân viên đã nghỉ việc, tài khoản đó sẽ không thể đăng nhập vào hệ thống nhưng toàn bộ lịch sử hóa đơn và giao dịch thu tiền trước đây vẫn được lưu giữ đầy đủ để đối soát doanh thu."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("aside", {
			className: "span4 card card-lg card-raise col g16",
			style: { padding: 20 },
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "col head-rule",
				style: {
					gap: 3.5,
					paddingTop: 5
				},
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "eyebrow",
					children: "Thông tin tài khoản"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("h3", {
					className: "t16 w800 c-ink",
					style: { lineHeight: "24px" },
					children: editId ? `Chỉnh sửa nhân viên ${editId}` : "Thêm nhân viên mới"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				className: "col g14",
				onSubmit: (e) => {
					e.preventDefault();
					save();
				},
				children: [
					/* @__PURE__ */ _jsxDEV(Field, {
						label: "Họ và tên nhân viên",
						req: true,
						children: /* @__PURE__ */ _jsxDEV("input", {
							className: "input sm",
							value: form.name,
							onChange: (e) => setForm({
								...form,
								name: e.target.value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 52
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Field, {
						label: "Số điện thoại đăng nhập",
						req: true,
						children: /* @__PURE__ */ _jsxDEV("input", {
							className: "input sm bold",
							inputMode: "tel",
							value: form.phone,
							onChange: (e) => setForm({
								...form,
								phone: e.target.value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 56
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Field, {
						label: "Địa chỉ Email",
						children: /* @__PURE__ */ _jsxDEV("input", {
							className: "input sm",
							style: { fontWeight: 500 },
							type: "email",
							value: form.email,
							onChange: (e) => setForm({
								...form,
								email: e.target.value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 42
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Field, {
						label: "Chi nhánh phân công",
						req: true,
						children: /* @__PURE__ */ _jsxDEV("select", {
							className: "select sm",
							value: form.branchId,
							onChange: (e) => setForm({
								...form,
								branchId: e.target.value
							}),
							children: branches.map((b) => /* @__PURE__ */ _jsxDEV("option", {
								value: b.id,
								children: b.name
							}, b.id, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 153
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Field, {
						label: editId ? "Mật khẩu mới (bỏ trống nếu giữ nguyên)" : "Mật khẩu cấp mới",
						req: !editId,
						children: /* @__PURE__ */ _jsxDEV("input", {
							className: "input sm",
							style: { fontWeight: 500 },
							type: "text",
							placeholder: "Tối thiểu 6 ký tự",
							value: form.password,
							onChange: (e) => setForm({
								...form,
								password: e.target.value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 113
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Field, {
						label: "Trạng thái làm việc",
						children: /* @__PURE__ */ _jsxDEV("select", {
							className: "select sm",
							value: form.locked ? "locked" : "active",
							onChange: (e) => setForm({
								...form,
								locked: e.target.value === "locked"
							}),
							children: [/* @__PURE__ */ _jsxDEV("option", {
								value: "active",
								children: "Đang làm việc"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 163
							}, this), /* @__PURE__ */ _jsxDEV("option", {
								value: "locked",
								children: "Đã khóa tài khoản"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 208
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 13
					}, this),
					err && /* @__PURE__ */ _jsxDEV("p", {
						className: "field-err",
						children: err
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "row g8",
						style: { paddingTop: 4 },
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "btn btn-primary btn-md f1",
							type: "submit",
							children: "Lưu thông tin"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: "btn btn-outline btn-md",
							type: "button",
							onClick: reset,
							children: "Nhập lại"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 5
	}, this);
}
_s(OwnerStaff, "3AYVyVHMyKkdGVAfL4chdP99I0g=", false, function() {
	return [useApp, useOutletContext];
});
_c = OwnerStaff;
function Field({ label, req, children }) {
	return /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
		className: "label",
		style: { marginBottom: 4 },
		children: [
			label,
			" ",
			req && /* @__PURE__ */ _jsxDEV("span", {
				className: "req",
				children: "*"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 122,
				columnNumber: 84
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 122,
		columnNumber: 15
	}, this), children] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 122,
		columnNumber: 10
	}, this);
}
_c2 = Field;
var _c, _c2;
$RefreshReg$(_c, "OwnerStaff");
$RefreshReg$(_c2, "Field");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/OwnerStaff.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/OwnerStaff.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/OwnerStaff.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/OwnerStaff.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxXQUFXO0FBR3BCLFNBQVMsY0FBYzs7OztBQUV2QixNQUFNLE9BQU87Q0FBRSxPQUFPO0NBQVcsS0FBSztDQUFTLFFBQVE7QUFBVztBQUNsRSxNQUFNLFFBQVE7Q0FBRSxNQUFNO0NBQUksT0FBTztDQUFJLE9BQU87Q0FBSSxVQUFVO0NBQU8sVUFBVTtDQUFJLFFBQVE7QUFBTTtBQUU3RixlQUFlLFNBQVMsYUFBYTs7Q0FDbkMsTUFBTSxFQUFFLE9BQU8sVUFBVSxVQUFVLFVBQVUsT0FBTztDQUNwRCxNQUFNLEVBQUUsY0FBYyxvQkFBb0IsaUJBQThCO0NBQ3hFLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBd0IsSUFBSTtDQUN4RCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQVMsRUFBRTtDQUVqQyxNQUFNLE9BQU8sTUFBTSxRQUFRLE1BQU0saUJBQWlCLFNBQVMsRUFBRSxhQUFhLFlBQVk7Q0FDdEYsTUFBTSxTQUFTLEtBQUssUUFBUSxNQUFNLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztDQUM3QyxNQUFNLFNBQVMsS0FBSyxTQUFTO0NBQzdCLE1BQU0sT0FBTyxPQUFlLFNBQVMsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFO0NBRTVELE1BQU0sUUFBUSxNQUFhO0VBQUUsVUFBVSxFQUFFLEVBQUU7RUFBRyxRQUFRO0dBQUUsTUFBTSxFQUFFO0dBQU0sT0FBTyxFQUFFO0dBQU8sT0FBTyxFQUFFO0dBQU8sVUFBVSxFQUFFO0dBQVUsVUFBVTtHQUFJLFFBQVEsRUFBRTtFQUFPLENBQUM7RUFBRyxPQUFPLEVBQUU7Q0FBRTtDQUMxSyxNQUFNLGNBQWM7RUFBRSxVQUFVLElBQUk7RUFBRyxRQUFRO0dBQUUsR0FBRztHQUFPLFVBQVUsaUJBQWlCLFFBQVEsUUFBUTtFQUFhLENBQUM7RUFBRyxPQUFPLEVBQUU7Q0FBRTtDQUNsSSxNQUFNLGNBQWMsTUFBYTtFQUFFLFVBQVUsT0FBTyxHQUFHLEtBQUssTUFBTyxFQUFFLE9BQU8sRUFBRSxLQUFLO0dBQUUsR0FBRztHQUFHLFFBQVEsQ0FBQyxFQUFFO0VBQU8sSUFBSSxDQUFFLENBQUM7RUFBRyxNQUFNLEVBQUUsU0FBUyx3QkFBd0IsRUFBRSxLQUFLLEtBQUsscUJBQXFCLEVBQUUsS0FBSyx3Q0FBd0MsSUFBSTtDQUFFO0NBRXRQLE1BQU0sYUFBYTtFQUNqQixJQUFJLENBQUMsS0FBSyxLQUFLLEtBQUssR0FBRyxPQUFPLE9BQU8sb0NBQW9DO0VBQ3pFLElBQUksQ0FBQyxXQUFXLEtBQUssS0FBSyxNQUFNLEtBQUssQ0FBQyxHQUFHLE9BQU8sT0FBTywrREFBK0Q7RUFDdEgsSUFBSSxNQUFNLE1BQU0sTUFBTSxFQUFFLFVBQVUsS0FBSyxNQUFNLEtBQUssS0FBSyxFQUFFLE9BQU8sTUFBTSxHQUFHLE9BQU8sT0FBTyxtREFBbUQ7RUFDMUksSUFBSSxLQUFLLFNBQVMsQ0FBQyxpQkFBaUIsS0FBSyxLQUFLLEtBQUssR0FBRyxPQUFPLE9BQU8sNkJBQTZCO0VBQ2pHLElBQUksQ0FBQyxVQUFVLEtBQUssU0FBUyxTQUFTLEdBQUcsT0FBTyxPQUFPLDZDQUE2QztFQUNwRyxJQUFJLFVBQVUsS0FBSyxZQUFZLEtBQUssU0FBUyxTQUFTLEdBQUcsT0FBTyxPQUFPLHlDQUF5QztFQUNoSCxJQUFJLFFBQVE7R0FDVixVQUFVLE9BQU8sR0FBRyxLQUFLLE1BQU8sRUFBRSxPQUFPLFNBQVM7SUFBRSxHQUFHO0lBQUcsTUFBTSxLQUFLLEtBQUssS0FBSztJQUFHLE9BQU8sS0FBSyxNQUFNLEtBQUs7SUFBRyxPQUFPLEtBQUssTUFBTSxLQUFLO0lBQUcsVUFBVSxLQUFLO0lBQVUsUUFBUSxLQUFLO0lBQVEsVUFBVSxLQUFLLFlBQVksRUFBRTtHQUFTLElBQUksQ0FBRSxDQUFDO0dBQ2pPLE1BQU0seUJBQXlCLEtBQUssS0FBSyxJQUFJLElBQUk7RUFDbkQsT0FBTztHQUNMLE1BQU0sS0FBSyxLQUFLLE9BQU8sTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0dBQ3hELFVBQVUsT0FBTyxDQUFDLEdBQUcsSUFBSTtJQUFFO0lBQUksTUFBTSxLQUFLLEtBQUssS0FBSztJQUFHLE9BQU8sS0FBSyxNQUFNLEtBQUs7SUFBRyxPQUFPLEtBQUssTUFBTSxLQUFLO0lBQUcsVUFBVSxLQUFLO0lBQVUsUUFBUSxLQUFLO0lBQVEsVUFBVSxLQUFLO0lBQVUsUUFBUTtJQUFHLFNBQVM7R0FBRSxDQUFDLENBQUM7R0FDMU0sTUFBTSxvQkFBb0IsR0FBRyxPQUFPLEtBQUssS0FBSyxJQUFJLElBQUk7RUFDeEQ7RUFDQSxNQUFNO0NBQ1I7Q0FFQSxPQUNFLGdEQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO0VBQTRCLE9BQU8sRUFBRSxTQUFTLEdBQUc7WUFBcEUsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBa0I7SUFBeUI7Ozs7O0lBQzNELHdCQUFDLFVBQUQ7S0FBUSxXQUFVO0tBQXFCLE9BQU87TUFBRSxZQUFZO01BQWMsU0FBUztNQUFxQixjQUFjO0tBQUc7S0FBRyxPQUFPO0tBQWMsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sS0FBSztlQUFoTSxDQUNFLHdCQUFDLFVBQUQ7TUFBUSxPQUFNO2dCQUFkO09BQW9CO09BQW1CLE1BQU07T0FBTztNQUFpQjs7Ozs7ZUFDcEUsU0FBUyxLQUFLLE1BQU0sd0JBQUMsVUFBRDtNQUFtQixPQUFPLEVBQUU7Z0JBQTVCO09BQWlDLEVBQUU7T0FBSztPQUFHLE1BQU0sUUFBUSxNQUFNLEVBQUUsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDO09BQU87TUFBaUI7UUFBL0YsRUFBRTs7OztZQUE2RixDQUFDLENBQzVIOzs7Ozs7SUFDUix3QkFBQyxRQUFEO0tBQU0sV0FBVTtLQUFxQixPQUFPO01BQUUsY0FBYztNQUFHLFNBQVM7S0FBVztlQUFuRixDQUF1RixRQUFPLGdCQUFvQjs7Ozs7O0lBQ2xILHdCQUFDLFFBQUQ7S0FBTSxXQUFVO0tBQW9CLE9BQU87TUFBRSxjQUFjO01BQUcsU0FBUztNQUFZLFlBQVk7TUFBbUIsT0FBTztLQUFrQjtlQUEzSSxDQUErSSxRQUFPLG9CQUF3Qjs7Ozs7O0dBQzNLOzs7OztZQUNMLHdCQUFDLFVBQUQ7R0FBUSxXQUFVO0dBQXlCLE9BQU8sRUFBRSxTQUFTLFdBQVc7R0FBRyxTQUFTO2FBQU87RUFBNEI7Ozs7VUFDaEg7Ozs7O1dBRVQsd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFpQjtLQUE4Qzs7OztlQUM3RSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBYTtLQUF5RDs7OzthQUNuRjs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQU8sd0JBQUMsTUFBRDtPQUFJLHdCQUFDLE1BQUQsWUFBSSxvQkFBcUI7Ozs7O09BQUMsd0JBQUMsTUFBRCxZQUFJLHdCQUF5Qjs7Ozs7T0FBQyx3QkFBQyxNQUFELFlBQUkscUJBQXNCOzs7OztPQUFDLHdCQUFDLE1BQUQsWUFBSSx5QkFBMEI7Ozs7O09BQUMsd0JBQUMsTUFBRCxZQUFJLGFBQWM7Ozs7O09BQUMsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQUk7T0FBWTs7Ozs7TUFBSzs7OztlQUFROzs7O2dCQUMzTCx3QkFBQyxTQUFELGFBQ0csS0FBSyxXQUFXLEtBQUssd0JBQUMsTUFBRCxZQUFJLHdCQUFDLE1BQUQ7T0FBSSxTQUFTO09BQUcsT0FBTztRQUFFLFdBQVc7UUFBVSxTQUFTO1FBQUksT0FBTztPQUFjO2lCQUFHO01BQXdDOzs7O2VBQUs7Ozs7Z0JBQ3pKLEtBQUssS0FBSyxNQUNULHdCQUFDLE1BQUQ7T0FBZSxXQUFXLEVBQUUsU0FBUyxRQUFRLFdBQVcsRUFBRSxLQUFLLE9BQU87aUJBQXRFO1FBQ0Usd0JBQUMsTUFBRCxhQUFJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQVksT0FBTztVQUFFLFVBQVU7VUFBTSxPQUFPLEVBQUUsU0FBUyxnQkFBZ0I7U0FBYzttQkFBSSxFQUFFO1FBQVE7Ozs7a0JBQUMsd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBTyxPQUFPLEVBQUUsT0FBTyxFQUFFLFNBQVMsZ0JBQWdCLGNBQWM7bUJBQUksRUFBRTtRQUFVOzs7O2dCQUFLOzs7OztRQUMzTix3QkFBQyxNQUFELGFBQUksd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBWSxPQUFPLEVBQUUsVUFBVSxHQUFHO21CQUFJLEVBQUU7UUFBVzs7OztrQkFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBVSxFQUFFO1FBQVc7Ozs7Z0JBQUs7Ozs7O1FBQ2xILHdCQUFDLE1BQUQsWUFBSSx3QkFBQyxRQUFEO1NBQU0sV0FBVyxTQUFTLEVBQUUsU0FBUyxXQUFXLEtBQUssSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQVMsT0FBTztVQUFFLGNBQWM7VUFBRyxZQUFZLEVBQUUsU0FBUyxNQUFNO1VBQUssWUFBWSxFQUFFLFNBQVMsZ0JBQWdCO1NBQVU7bUJBQUksSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQVc7Ozs7aUJBQUs7Ozs7O1FBQ25PLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBUSxFQUFFLFVBQVUsRUFBRSxXQUFXLEdBQUcsRUFBRSxTQUFTLHdCQUF3QixHQUFHLEVBQUUsT0FBTztRQUFvQjs7OztrQkFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVyxFQUFFLFNBQVMsa0JBQWtCO21CQUE3QztVQUF1RDtVQUFXLElBQUksRUFBRSxPQUFPO1VBQUU7U0FBTTs7Ozs7Z0JBQUs7Ozs7O1FBQ3ZOLHdCQUFDLE1BQUQsWUFBSSx3QkFBQyxRQUFEO1NBQU0sV0FBVyxTQUFTLEVBQUUsU0FBUyxXQUFXO1NBQWEsT0FBTyxFQUFFLFlBQVksRUFBRSxTQUFTLG9CQUFvQixVQUFVO21CQUFJLEVBQUUsU0FBUyxZQUFZO1FBQXNCOzs7O2lCQUFLOzs7OztRQUNyTCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWix3QkFBQyxPQUFEO1VBQUssV0FBVTtVQUFTLE9BQU8sRUFBRSxnQkFBZ0IsV0FBVztvQkFDekQsRUFBRSxTQUFTLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO1dBQWEsT0FBTztZQUFFLFlBQVk7WUFBUSxRQUFRO1lBQThCLE9BQU87WUFBb0IsU0FBUztXQUFXO1dBQUcsZUFBZSxXQUFXLENBQUM7cUJBQUc7VUFBZTs7OztxQkFDM00sZ0RBQUUsd0JBQUMsVUFBRDtXQUFRLFdBQVU7V0FBeUIsT0FBTztZQUFFLFNBQVM7WUFBWSxPQUFPO1dBQWM7V0FBRyxlQUFlLEtBQUssQ0FBQztxQkFBRztVQUFXOzs7O29CQUNwSSx3QkFBQyxVQUFEO1dBQVEsV0FBVTtXQUEwQixPQUFPLEVBQUUsU0FBUyxXQUFXO1dBQUcsZUFBZSxXQUFXLENBQUM7cUJBQUc7VUFBWTs7OztrQkFBRzs7Ozs7U0FDMUg7Ozs7O1FBQ0g7Ozs7O09BQ0Y7U0FiSyxFQUFFOzs7O2FBYVAsQ0FDTCxDQUNJOzs7O2NBQ0Y7Ozs7OztJQUNKOzs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQU8sT0FBTyxFQUFFLFlBQVksT0FBTztlQUFHO0lBRWhEOzs7OztHQUNFOzs7OztZQUVULHdCQUFDLFNBQUQ7R0FBTyxXQUFVO0dBQXdDLE9BQU8sRUFBRSxTQUFTLEdBQUc7YUFBOUUsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFnQixPQUFPO0tBQUUsS0FBSztLQUFLLFlBQVk7SUFBRTtjQUFoRSxDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQVU7SUFBeUI7Ozs7Y0FDbkQsd0JBQUMsTUFBRDtLQUFJLFdBQVU7S0FBaUIsT0FBTyxFQUFFLFlBQVksT0FBTztlQUFJLFNBQVMsdUJBQXVCLFdBQVc7SUFBeUI7Ozs7WUFDaEk7Ozs7O2FBQ0wsd0JBQUMsUUFBRDtJQUFNLFdBQVU7SUFBVSxXQUFXLE1BQU07S0FBRSxFQUFFLGVBQWU7S0FBRyxLQUFLO0lBQUU7Y0FBeEU7S0FDRSx3QkFBQyxPQUFEO01BQU8sT0FBTTtNQUFzQjtnQkFBSSx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFXLE9BQU8sS0FBSztPQUFNLFdBQVcsTUFBTSxRQUFRO1FBQUUsR0FBRztRQUFNLE1BQU0sRUFBRSxPQUFPO09BQU0sQ0FBQztNQUFJOzs7OztLQUFROzs7OztLQUMzSix3QkFBQyxPQUFEO01BQU8sT0FBTTtNQUEwQjtnQkFBSSx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFnQixXQUFVO09BQU0sT0FBTyxLQUFLO09BQU8sV0FBVyxNQUFNLFFBQVE7UUFBRSxHQUFHO1FBQU0sT0FBTyxFQUFFLE9BQU87T0FBTSxDQUFDO01BQUk7Ozs7O0tBQVE7Ozs7O0tBQ3RMLHdCQUFDLE9BQUQ7TUFBTyxPQUFNO2dCQUFnQix3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFXLE9BQU8sRUFBRSxZQUFZLElBQUk7T0FBRyxNQUFLO09BQVEsT0FBTyxLQUFLO09BQU8sV0FBVyxNQUFNLFFBQVE7UUFBRSxHQUFHO1FBQU0sT0FBTyxFQUFFLE9BQU87T0FBTSxDQUFDO01BQUk7Ozs7O0tBQVE7Ozs7O0tBQzVMLHdCQUFDLE9BQUQ7TUFBTyxPQUFNO01BQXNCO2dCQUNqQyx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFZLE9BQU8sS0FBSztPQUFVLFdBQVcsTUFBTSxRQUFRO1FBQUUsR0FBRztRQUFNLFVBQVUsRUFBRSxPQUFPO09BQU0sQ0FBQztpQkFBSSxTQUFTLEtBQUssTUFBTSx3QkFBQyxVQUFEO1FBQW1CLE9BQU8sRUFBRTtrQkFBSyxFQUFFO09BQWEsR0FBbkMsRUFBRTs7OztjQUFpQyxDQUFDO01BQVU7Ozs7O0tBQVE7Ozs7O0tBQy9NLHdCQUFDLE9BQUQ7TUFBTyxPQUFPLFNBQVMsMkNBQTJDO01BQW9CLEtBQUssQ0FBQztnQkFBUSx3QkFBQyxTQUFEO09BQU8sV0FBVTtPQUFXLE9BQU8sRUFBRSxZQUFZLElBQUk7T0FBRyxNQUFLO09BQU8sYUFBWTtPQUFvQixPQUFPLEtBQUs7T0FBVSxXQUFXLE1BQU0sUUFBUTtRQUFFLEdBQUc7UUFBTSxVQUFVLEVBQUUsT0FBTztPQUFNLENBQUM7TUFBSTs7Ozs7S0FBUTs7Ozs7S0FDeFMsd0JBQUMsT0FBRDtNQUFPLE9BQU07Z0JBQ1gsd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBWSxPQUFPLEtBQUssU0FBUyxXQUFXO09BQVUsV0FBVyxNQUFNLFFBQVE7UUFBRSxHQUFHO1FBQU0sUUFBUSxFQUFFLE9BQU8sVUFBVTtPQUFTLENBQUM7aUJBQWpKLENBQW9KLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFTO09BQXFCOzs7O2lCQUFDLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFTO09BQXlCOzs7O2VBQVM7Ozs7OztLQUFROzs7OztLQUNuUSxPQUFPLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFhO0tBQU87Ozs7O0tBQ3pDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQVMsT0FBTyxFQUFFLFlBQVksRUFBRTtnQkFBL0MsQ0FDRSx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUE0QixNQUFLO2lCQUFTO01BQXFCOzs7O2dCQUNqRix3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUF5QixNQUFLO09BQVMsU0FBUztpQkFBTztNQUFnQjs7OztjQUN0Rjs7Ozs7O0lBQ0Q7Ozs7O1dBQ0Q7Ozs7O1VBQ0o7Ozs7O1NBQ0w7Ozs7O0FBRU47Ozs7O0FBRUEsU0FBUyxNQUFNLEVBQUUsT0FBTyxLQUFLLFlBQXlFO0NBQ3BHLE9BQU8sd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQ7RUFBTyxXQUFVO0VBQVEsT0FBTyxFQUFFLGNBQWMsRUFBRTtZQUFsRDtHQUFzRDtHQUFNO0dBQUUsT0FBTyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFNO0dBQU87Ozs7O0VBQVM7Ozs7O1dBQUUsUUFBYzs7Ozs7QUFDekkiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiT3duZXJTdGFmZi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU91dGxldENvbnRleHQgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgZm10IH0gZnJvbSAnLi4vZGF0YSdcbmltcG9ydCB0eXBlIHsgU3RhZmYgfSBmcm9tICcuLi9kYXRhJ1xuaW1wb3J0IHR5cGUgeyBTdGFmZk91dGxldCB9IGZyb20gJy4uL2xheW91dHMnXG5pbXBvcnQgeyB1c2VBcHAgfSBmcm9tICcuLi9zdG9yZSdcblxuY29uc3QgVE9ORSA9IHsgZ3JlZW46ICdiLWdyZWVuJywgc2t5OiAnYi1za3knLCBpbmRpZ286ICdiLWluZGlnbycgfSBhcyBjb25zdFxuY29uc3QgZW1wdHkgPSB7IG5hbWU6ICcnLCBwaG9uZTogJycsIGVtYWlsOiAnJywgYnJhbmNoSWQ6ICdjczEnLCBwYXNzd29yZDogJycsIGxvY2tlZDogZmFsc2UgfVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBPd25lclN0YWZmKCkge1xuICBjb25zdCB7IHN0YWZmLCBzZXRTdGFmZiwgYnJhbmNoZXMsIHRvYXN0IH0gPSB1c2VBcHAoKVxuICBjb25zdCB7IGJyYW5jaEZpbHRlciwgc2V0QnJhbmNoRmlsdGVyIH0gPSB1c2VPdXRsZXRDb250ZXh0PFN0YWZmT3V0bGV0PigpXG4gIGNvbnN0IFtlZGl0SWQsIHNldEVkaXRJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxuICBjb25zdCBbZm9ybSwgc2V0Rm9ybV0gPSB1c2VTdGF0ZShlbXB0eSlcbiAgY29uc3QgW2Vyciwgc2V0RXJyXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGNvbnN0IGxpc3QgPSBzdGFmZi5maWx0ZXIoKHMpID0+IGJyYW5jaEZpbHRlciA9PT0gJ2FsbCcgfHwgcy5icmFuY2hJZCA9PT0gYnJhbmNoRmlsdGVyKVxuICBjb25zdCBhY3RpdmUgPSBsaXN0LmZpbHRlcigocykgPT4gIXMubG9ja2VkKS5sZW5ndGhcbiAgY29uc3QgbG9ja2VkID0gbGlzdC5sZW5ndGggLSBhY3RpdmVcbiAgY29uc3QgYk9mID0gKGlkOiBzdHJpbmcpID0+IGJyYW5jaGVzLmZpbmQoKGIpID0+IGIuaWQgPT09IGlkKSFcblxuICBjb25zdCBlZGl0ID0gKHM6IFN0YWZmKSA9PiB7IHNldEVkaXRJZChzLmlkKTsgc2V0Rm9ybSh7IG5hbWU6IHMubmFtZSwgcGhvbmU6IHMucGhvbmUsIGVtYWlsOiBzLmVtYWlsLCBicmFuY2hJZDogcy5icmFuY2hJZCwgcGFzc3dvcmQ6ICcnLCBsb2NrZWQ6IHMubG9ja2VkIH0pOyBzZXRFcnIoJycpIH1cbiAgY29uc3QgcmVzZXQgPSAoKSA9PiB7IHNldEVkaXRJZChudWxsKTsgc2V0Rm9ybSh7IC4uLmVtcHR5LCBicmFuY2hJZDogYnJhbmNoRmlsdGVyID09PSAnYWxsJyA/ICdjczEnIDogYnJhbmNoRmlsdGVyIH0pOyBzZXRFcnIoJycpIH1cbiAgY29uc3QgdG9nZ2xlTG9jayA9IChzOiBTdGFmZikgPT4geyBzZXRTdGFmZigoc3MpID0+IHNzLm1hcCgoeCkgPT4gKHguaWQgPT09IHMuaWQgPyB7IC4uLngsIGxvY2tlZDogIXgubG9ja2VkIH0gOiB4KSkpOyB0b2FzdChzLmxvY2tlZCA/IGDEkMOjIG3hu58ga2jDs2EgdMOgaSBraG/huqNuICR7cy5uYW1lfS5gIDogYMSQw6Mga2jDs2EgdMOgaSBraG/huqNuICR7cy5uYW1lfS4gTOG7i2NoIHPhu60gZ2lhbyBk4buLY2ggduG6q24gxJHGsOG7o2MgbMawdSBnaeG7ry5gLCAnb2snKSB9XG5cbiAgY29uc3Qgc2F2ZSA9ICgpID0+IHtcbiAgICBpZiAoIWZvcm0ubmFtZS50cmltKCkpIHJldHVybiBzZXRFcnIoJ1Z1aSBsw7JuZyBuaOG6rXAgaOG7jSB2w6AgdMOqbiBuaMOibiB2acOqbi4nKVxuICAgIGlmICghL14wXFxkezl9JC8udGVzdChmb3JtLnBob25lLnRyaW0oKSkpIHJldHVybiBzZXRFcnIoJ1Phu5EgxJFp4buHbiB0aG/huqFpIMSRxINuZyBuaOG6rXAgcGjhuqNpIGfhu5NtIDEwIGNo4buvIHPhu5EgdsOgIGLhuq90IMSR4bqndSBi4bqxbmcgMC4nKVxuICAgIGlmIChzdGFmZi5zb21lKChzKSA9PiBzLnBob25lID09PSBmb3JtLnBob25lLnRyaW0oKSAmJiBzLmlkICE9PSBlZGl0SWQpKSByZXR1cm4gc2V0RXJyKCdT4buRIMSRaeG7h24gdGhv4bqhaSBuw6B5IMSRw6MgxJHGsOG7o2MgY+G6pXAgY2hvIG5ow6JuIHZpw6puIGtow6FjLicpXG4gICAgaWYgKGZvcm0uZW1haWwgJiYgIS9eXFxTK0BcXFMrXFwuXFxTKyQvLnRlc3QoZm9ybS5lbWFpbCkpIHJldHVybiBzZXRFcnIoJ8SQ4buLYSBjaOG7iSBlbWFpbCBraMO0bmcgaOG7o3AgbOG7hy4nKVxuICAgIGlmICghZWRpdElkICYmIGZvcm0ucGFzc3dvcmQubGVuZ3RoIDwgNikgcmV0dXJuIHNldEVycignTeG6rXQga2jhuql1IGPhuqVwIG3hu5tpIHBo4bqjaSBjw7MgdOG7kWkgdGhp4buDdSA2IGvDvSB04buxLicpXG4gICAgaWYgKGVkaXRJZCAmJiBmb3JtLnBhc3N3b3JkICYmIGZvcm0ucGFzc3dvcmQubGVuZ3RoIDwgNikgcmV0dXJuIHNldEVycignTeG6rXQga2jhuql1IG3hu5tpIHBo4bqjaSBjw7MgdOG7kWkgdGhp4buDdSA2IGvDvSB04buxLicpXG4gICAgaWYgKGVkaXRJZCkge1xuICAgICAgc2V0U3RhZmYoKHNzKSA9PiBzcy5tYXAoKHMpID0+IChzLmlkID09PSBlZGl0SWQgPyB7IC4uLnMsIG5hbWU6IGZvcm0ubmFtZS50cmltKCksIHBob25lOiBmb3JtLnBob25lLnRyaW0oKSwgZW1haWw6IGZvcm0uZW1haWwudHJpbSgpLCBicmFuY2hJZDogZm9ybS5icmFuY2hJZCwgbG9ja2VkOiBmb3JtLmxvY2tlZCwgcGFzc3dvcmQ6IGZvcm0ucGFzc3dvcmQgfHwgcy5wYXNzd29yZCB9IDogcykpKVxuICAgICAgdG9hc3QoYMSQw6MgY+G6rXAgbmjhuq10IHRow7RuZyB0aW4gJHtmb3JtLm5hbWV9LmAsICdvaycpXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGlkID0gYE5WJHtTdHJpbmcoc3RhZmYubGVuZ3RoICsgMSkucGFkU3RhcnQoMywgJzAnKX1gXG4gICAgICBzZXRTdGFmZigoc3MpID0+IFsuLi5zcywgeyBpZCwgbmFtZTogZm9ybS5uYW1lLnRyaW0oKSwgcGhvbmU6IGZvcm0ucGhvbmUudHJpbSgpLCBlbWFpbDogZm9ybS5lbWFpbC50cmltKCksIGJyYW5jaElkOiBmb3JtLmJyYW5jaElkLCBsb2NrZWQ6IGZvcm0ubG9ja2VkLCBwYXNzd29yZDogZm9ybS5wYXNzd29yZCwgb3JkZXJzOiAwLCByZXZlbnVlOiAwIH1dKVxuICAgICAgdG9hc3QoYMSQw6MgY+G6pXAgdMOgaSBraG/huqNuICR7aWR9IGNobyAke2Zvcm0ubmFtZX0uYCwgJ29rJylcbiAgICB9XG4gICAgcmVzZXQoKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY2FyZCByb3cgYmV0d2VlbiB3cmFwIGcxNlwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2IH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTIgd3JhcFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NzAwIGMtczcwMFwiPkzhu41jIHRoZW8gY2hpIG5ow6FuaDo8L3NwYW4+XG4gICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJzZWxlY3Qgc20gYm9sZCBmaXRcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAndmFyKC0tczUwKScsIHBhZGRpbmc6ICc4cHggMzBweCA4cHggMThweCcsIGJvcmRlclJhZGl1czogMTIgfX0gdmFsdWU9e2JyYW5jaEZpbHRlcn0gb25DaGFuZ2U9eyhlKSA9PiBzZXRCcmFuY2hGaWx0ZXIoZS50YXJnZXQudmFsdWUpfT5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhbGxcIj5U4bqldCBj4bqjIGNoaSBuaMOhbmggKHtzdGFmZi5sZW5ndGh9IG5ow6JuIHPhu7EpPC9vcHRpb24+XG4gICAgICAgICAgICB7YnJhbmNoZXMubWFwKChiKSA9PiA8b3B0aW9uIGtleT17Yi5pZH0gdmFsdWU9e2IuaWR9PntiLm5hbWV9ICh7c3RhZmYuZmlsdGVyKChzKSA9PiBzLmJyYW5jaElkID09PSBiLmlkKS5sZW5ndGh9IG5ow6JuIHPhu7EpPC9vcHRpb24+KX1cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBiLWdyZWVuLWZsYXRcIiBzdHlsZT17eyBib3JkZXJSYWRpdXM6IDgsIHBhZGRpbmc6ICc2cHggMTJweCcgfX0+e2FjdGl2ZX0gxJBhbmcgbMOgbSB2aeG7h2M8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYi1yb3NlLXNvZnRcIiBzdHlsZT17eyBib3JkZXJSYWRpdXM6IDgsIHBhZGRpbmc6ICc2cHggMTJweCcsIGJhY2tncm91bmQ6ICd2YXIoLS1yb3NlLTEwMCknLCBjb2xvcjogJ3ZhcigtLXJvc2UtOTAwKScgfX0+e2xvY2tlZH0gxJDDoyBraMOzYSB0w6BpIGtob+G6o248L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tbWRcIiBzdHlsZT17eyBwYWRkaW5nOiAnOHB4IDE2cHgnIH19IG9uQ2xpY2s9e3Jlc2V0fT4rIFRow6ptIG5ow6JuIHZpw6puIG3hu5tpPC9idXR0b24+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZDEyXCI+XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYW44IGNhcmQgY29sIGcxNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0MTQgdzgwMCBjLWlua1wiPkRhbmggc8OhY2ggbmjDom4gdmnDqm4gdGh1IG5nw6JuIHThuqFpIGPDoWMgY8ahIHPhu588L2gyPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDEyIGMtczYwMFwiPk5o4bqlcCBcIlPhu61hXCIgxJHhu4MgdGhheSDEkeG7lWkgY8ahIHPhu58gaG/hurdjIHRow7RuZyB0aW4gbGnDqm4gaOG7hzwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRibC13cmFwXCI+XG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidGJsXCI+XG4gICAgICAgICAgICAgIDx0aGVhZD48dHI+PHRoPk3DoyBOViAvIEjhu40gdsOgIHTDqm48L3RoPjx0aD5T4buRIMSRaeG7h24gdGhv4bqhaSAvIEVtYWlsPC90aD48dGg+Q2hpIG5ow6FuaCBsw6BtIHZp4buHYzwvdGg+PHRoPkdpYW8gZOG7i2NoIMSRw6MgdGjhu7FjIGhp4buHbjwvdGg+PHRoPlRy4bqhbmcgdGjDoWk8L3RoPjx0aCBjbGFzc05hbWU9XCJyXCI+VGhhbyB0w6FjPC90aD48L3RyPjwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICB7bGlzdC5sZW5ndGggPT09IDAgJiYgPHRyPjx0ZCBjb2xTcGFuPXs2fSBzdHlsZT17eyB0ZXh0QWxpZ246ICdjZW50ZXInLCBwYWRkaW5nOiAzMiwgY29sb3I6ICd2YXIoLS1zNjAwKScgfX0+Q2jGsGEgY8OzIG5ow6JuIHZpw6puIHThuqFpIGNoaSBuaMOhbmggbsOgeS48L3RkPjwvdHI+fVxuICAgICAgICAgICAgICAgIHtsaXN0Lm1hcCgocykgPT4gKFxuICAgICAgICAgICAgICAgICAgPHRyIGtleT17cy5pZH0gY2xhc3NOYW1lPXtzLmxvY2tlZCA/ICdkaW0nIDogZWRpdElkID09PSBzLmlkID8gJ2hsJyA6ICcnfT5cbiAgICAgICAgICAgICAgICAgICAgPHRkPjxkaXYgY2xhc3NOYW1lPVwibW9ubyB3ODAwXCIgc3R5bGU9e3sgZm9udFNpemU6IDEwLjUsIGNvbG9yOiBzLmxvY2tlZCA/ICd2YXIoLS1zNzAwKScgOiAndmFyKC0tczkwMCknIH19PntzLmlkfTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwidzcwMFwiIHN0eWxlPXt7IGNvbG9yOiBzLmxvY2tlZCA/ICd2YXIoLS1zNzAwKScgOiAndmFyKC0tczgwMCknIH19PntzLm5hbWV9PC9kaXY+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkPjxkaXYgY2xhc3NOYW1lPVwibW9ubyB3NzAwXCIgc3R5bGU9e3sgZm9udFNpemU6IDExIH19PntzLnBob25lfTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiYy1zNjAwXCI+e3MuZW1haWx9PC9kaXY+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkPjxzcGFuIGNsYXNzTmFtZT17YGJhZGdlICR7cy5sb2NrZWQgPyAnYi1ncmF5JyA6IFRPTkVbYk9mKHMuYnJhbmNoSWQpLnRvbmVdfWB9IHN0eWxlPXt7IGJvcmRlclJhZGl1czogOCwgZm9udFdlaWdodDogcy5sb2NrZWQgPyA2MDAgOiA3MDAsIGJhY2tncm91bmQ6IHMubG9ja2VkID8gJ3ZhcigtLXMyMDApJyA6IHVuZGVmaW5lZCB9fT57Yk9mKHMuYnJhbmNoSWQpLm5hbWV9PC9zcGFuPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZD48ZGl2IGNsYXNzTmFtZT1cInc3MDBcIj57cy5sb2NrZWQgJiYgcy5hcmNoaXZlZCA/IGAke3MuYXJjaGl2ZWR9IMSRxqFuIGPFqSAoxJDDoyBsxrB1IHRy4buvKWAgOiBgJHtzLm9yZGVyc30gxJHGoW4gdOG6oWkgcXXhuqd5YH08L2Rpdj48ZGl2IGNsYXNzTmFtZT17cy5sb2NrZWQgPyAnYy1icmFuZDggdzcwMCcgOiAnYy1zNjAwJ30+VOG7lW5nIHRodToge2ZtdChzLnJldmVudWUpfcSRPC9kaXY+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkPjxzcGFuIGNsYXNzTmFtZT17YGJhZGdlICR7cy5sb2NrZWQgPyAnYi1yb3NlJyA6ICdiLWdyZWVuJ31gfSBzdHlsZT17eyBiYWNrZ3JvdW5kOiBzLmxvY2tlZCA/ICd2YXIoLS1yb3NlLTEwMCknIDogdW5kZWZpbmVkIH19PntzLmxvY2tlZCA/ICfEkMOjIGtow7NhJyA6ICfEkGFuZyBsw6BtIHZp4buHYyd9PC9zcGFuPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzhcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogJ2ZsZXgtZW5kJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzLmxvY2tlZCA/IDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1zbVwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjZmZmJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWJyYW5kLTQwMCknLCBjb2xvcjogJ3ZhcigtLWJyYW5kLTgwMCknLCBwYWRkaW5nOiAnNnB4IDEwcHgnIH19IG9uQ2xpY2s9eygpID0+IHRvZ2dsZUxvY2socyl9Pk3hu58ga2jDs2E8L2J1dHRvbj4gOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDw+PGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUgYnRuLXNtXCIgc3R5bGU9e3sgcGFkZGluZzogJzZweCAxMHB4JywgY29sb3I6ICd2YXIoLS1zODAwKScgfX0gb25DbGljaz17KCkgPT4gZWRpdChzKX0+U+G7rWE8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tZGFuZ2VyLW8gYnRuLXNtXCIgc3R5bGU9e3sgcGFkZGluZzogJzZweCAxMHB4JyB9fSBvbkNsaWNrPXsoKSA9PiB0b2dnbGVMb2NrKHMpfT5LaMOzYTwvYnV0dG9uPjwvPil9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpbnRcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMTZweCcgfX0+XG4gICAgICAgICAgICDwn5SSIEtoaSBraMOzYSB0w6BpIGtob+G6o24gbmjDom4gdmnDqm4gxJHDoyBuZ2jhu4kgdmnhu4djLCB0w6BpIGtob+G6o24gxJHDsyBz4bq9IGtow7RuZyB0aOG7gyDEkcSDbmcgbmjhuq1wIHbDoG8gaOG7hyB0aOG7kW5nIG5oxrBuZyB0b8OgbiBi4buZIGzhu4tjaCBz4butIGjDs2EgxJHGoW4gdsOgIGdpYW8gZOG7i2NoIHRodSB0aeG7gW4gdHLGsOG7m2MgxJHDonkgduG6q24gxJHGsOG7o2MgbMawdSBnaeG7ryDEkeG6p3kgxJHhu6cgxJHhu4MgxJHhu5FpIHNvw6F0IGRvYW5oIHRodS5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJzcGFuNCBjYXJkIGNhcmQtbGcgY2FyZC1yYWlzZSBjb2wgZzE2XCIgc3R5bGU9e3sgcGFkZGluZzogMjAgfX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgaGVhZC1ydWxlXCIgc3R5bGU9e3sgZ2FwOiAzLjUsIHBhZGRpbmdUb3A6IDUgfX0+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJleWVicm93XCI+VGjDtG5nIHRpbiB0w6BpIGtob+G6o248L3NwYW4+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidDE2IHc4MDAgYy1pbmtcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMjRweCcgfX0+e2VkaXRJZCA/IGBDaOG7iW5oIHPhu61hIG5ow6JuIHZpw6puICR7ZWRpdElkfWAgOiAnVGjDqm0gbmjDom4gdmnDqm4gbeG7m2knfTwvaDM+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiY29sIGcxNFwiIG9uU3VibWl0PXsoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IHNhdmUoKSB9fT5cbiAgICAgICAgICAgIDxGaWVsZCBsYWJlbD1cIkjhu40gdsOgIHTDqm4gbmjDom4gdmnDqm5cIiByZXE+PGlucHV0IGNsYXNzTmFtZT1cImlucHV0IHNtXCIgdmFsdWU9e2Zvcm0ubmFtZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9IC8+PC9GaWVsZD5cbiAgICAgICAgICAgIDxGaWVsZCBsYWJlbD1cIlPhu5EgxJFp4buHbiB0aG/huqFpIMSRxINuZyBuaOG6rXBcIiByZXE+PGlucHV0IGNsYXNzTmFtZT1cImlucHV0IHNtIGJvbGRcIiBpbnB1dE1vZGU9XCJ0ZWxcIiB2YWx1ZT17Zm9ybS5waG9uZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgcGhvbmU6IGUudGFyZ2V0LnZhbHVlIH0pfSAvPjwvRmllbGQ+XG4gICAgICAgICAgICA8RmllbGQgbGFiZWw9XCLEkOG7i2EgY2jhu4kgRW1haWxcIj48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiBzdHlsZT17eyBmb250V2VpZ2h0OiA1MDAgfX0gdHlwZT1cImVtYWlsXCIgdmFsdWU9e2Zvcm0uZW1haWx9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGVtYWlsOiBlLnRhcmdldC52YWx1ZSB9KX0gLz48L0ZpZWxkPlxuICAgICAgICAgICAgPEZpZWxkIGxhYmVsPVwiQ2hpIG5ow6FuaCBwaMOibiBjw7RuZ1wiIHJlcT5cbiAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJzZWxlY3Qgc21cIiB2YWx1ZT17Zm9ybS5icmFuY2hJZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgYnJhbmNoSWQ6IGUudGFyZ2V0LnZhbHVlIH0pfT57YnJhbmNoZXMubWFwKChiKSA9PiA8b3B0aW9uIGtleT17Yi5pZH0gdmFsdWU9e2IuaWR9PntiLm5hbWV9PC9vcHRpb24+KX08L3NlbGVjdD48L0ZpZWxkPlxuICAgICAgICAgICAgPEZpZWxkIGxhYmVsPXtlZGl0SWQgPyAnTeG6rXQga2jhuql1IG3hu5tpIChi4buPIHRy4buRbmcgbuG6v3UgZ2nhu68gbmd1ecOqbiknIDogJ03huq10IGto4bqpdSBj4bqlcCBt4bubaSd9IHJlcT17IWVkaXRJZH0+PGlucHV0IGNsYXNzTmFtZT1cImlucHV0IHNtXCIgc3R5bGU9e3sgZm9udFdlaWdodDogNTAwIH19IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJU4buRaSB0aGnhu4N1IDYga8O9IHThu7FcIiB2YWx1ZT17Zm9ybS5wYXNzd29yZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgcGFzc3dvcmQ6IGUudGFyZ2V0LnZhbHVlIH0pfSAvPjwvRmllbGQ+XG4gICAgICAgICAgICA8RmllbGQgbGFiZWw9XCJUcuG6oW5nIHRow6FpIGzDoG0gdmnhu4djXCI+XG4gICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwic2VsZWN0IHNtXCIgdmFsdWU9e2Zvcm0ubG9ja2VkID8gJ2xvY2tlZCcgOiAnYWN0aXZlJ30gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgbG9ja2VkOiBlLnRhcmdldC52YWx1ZSA9PT0gJ2xvY2tlZCcgfSl9PjxvcHRpb24gdmFsdWU9XCJhY3RpdmVcIj7EkGFuZyBsw6BtIHZp4buHYzwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJsb2NrZWRcIj7EkMOjIGtow7NhIHTDoGkga2hv4bqjbjwvb3B0aW9uPjwvc2VsZWN0PjwvRmllbGQ+XG4gICAgICAgICAgICB7ZXJyICYmIDxwIGNsYXNzTmFtZT1cImZpZWxkLWVyclwiPntlcnJ9PC9wPn1cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGc4XCIgc3R5bGU9e3sgcGFkZGluZ1RvcDogNCB9fT5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLW1kIGYxXCIgdHlwZT1cInN1Ym1pdFwiPkzGsHUgdGjDtG5nIHRpbjwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZSBidG4tbWRcIiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17cmVzZXR9Pk5o4bqtcCBs4bqhaTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2FzaWRlPlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gIClcbn1cblxuZnVuY3Rpb24gRmllbGQoeyBsYWJlbCwgcmVxLCBjaGlsZHJlbiB9OiB7IGxhYmVsOiBzdHJpbmc7IHJlcT86IGJvb2xlYW47IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gPGRpdj48bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDQgfX0+e2xhYmVsfSB7cmVxICYmIDxzcGFuIGNsYXNzTmFtZT1cInJlcVwiPio8L3NwYW4+fTwvbGFiZWw+e2NoaWxkcmVufTwvZGl2PlxufVxuIl19