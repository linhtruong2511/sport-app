import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OwnerReports.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=39aafc4d";
import { fmt, money, toVN } from "/src/data.ts";
import { useApp } from "/src/store.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/OwnerReports.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
// Số liệu tổng hợp tháng 11/2026 theo chi nhánh (dữ liệu mẫu của báo cáo chuyên sâu)
const REPORT = {
	cs1: {
		orders: 310,
		done: 274,
		cancel: 22,
		occ: 84,
		fromDone: 985e5,
		fromCancel: 54e5,
		total: 1112e5
	},
	cs2: {
		orders: 265,
		done: 230,
		cancel: 21,
		occ: 79,
		fromDone: 762e5,
		fromCancel: 43e5,
		total: 864e5
	},
	cs3: {
		orders: 165,
		done: 138,
		cancel: 15,
		occ: 75,
		fromDone: 447e5,
		fromCancel: 27e5,
		total: 51e6
	}
};
const MONTH = {
	from: "2026-11-01",
	to: "2026-11-30"
};
const FRAMES = [
	[
		"Cả ngày (05:00 - 23:00)",
		0,
		24
	],
	[
		"06:00 - 11:00",
		6,
		11
	],
	[
		"11:00 - 15:00",
		11,
		15
	],
	[
		"15:00 - 22:00",
		15,
		22
	]
];
const LEVELS = [
	["5|0", "Giảm 5%"],
	["10|0", "Giảm 10%"],
	["15|0", "Giảm 15%"],
	["20|100000", "Giảm 20% (Tối đa 100k)"],
	["25|150000", "Giảm 25% (Tối đa 150k)"],
	["30|200000", "Giảm 30% (Tối đa 200k)"]
];
const empty = {
	name: "",
	code: "",
	level: "10|0",
	branchId: "all",
	frame: 0,
	start: "2026-11-01",
	end: "2026-11-30",
	limit: 100,
	notify: true
};
const overlap = (a, b) => {
	const s = new Date(Math.max(+new Date(a), +new Date(MONTH.from))), e = new Date(Math.min(+new Date(b), +new Date(MONTH.to)));
	return Math.max(0, Math.round((+e - +s) / 864e5) + 1) / 30;
};
const tr = (n) => `${(n / 1e6).toFixed(2).replace(".", ",").replace(/,?0+$/, "")}Tr`;
export default function OwnerReports() {
	_s();
	const { branches, promos, setPromos, toast } = useApp();
	const { branchFilter } = useOutletContext();
	const [from, setFrom] = useState(MONTH.from);
	const [to, setTo] = useState(MONTH.to);
	const [applied, setApplied] = useState({
		from: MONTH.from,
		to: MONTH.to
	});
	const [editCode, setEditCode] = useState(null);
	const [form, setForm] = useState(empty);
	const [err, setErr] = useState("");
	const factor = overlap(applied.from, applied.to);
	const sel = branches.filter((b) => branchFilter === "all" || b.id === branchFilter);
	const rows = sel.map((b) => ({
		b,
		r: REPORT[b.id] ?? {
			orders: 0,
			done: 0,
			cancel: 0,
			occ: 0,
			fromDone: 0,
			fromCancel: 0,
			total: 0
		}
	}));
	const sc = (n) => Math.round(n * factor);
	const sum = (k) => sc(rows.reduce((s, x) => s + x.r[k], 0));
	const total = sum("total"), done = sum("fromDone"), cancel = sum("fromCancel"), upcoming = total - done - cancel;
	const orders = sum("orders"), ok = sum("done"), bad = sum("cancel"), expired = Math.max(0, orders - ok - bad);
	const pct = (n) => orders ? `${(n / orders * 100).toFixed(1).replace(".", ",")}%` : "0%";
	const used = promos.filter((p) => !p.counterOnly).reduce((s, p) => s + p.used, 0);
	const pub = promos.filter((p) => !p.counterOnly);
	const edit = (p) => {
		setEditCode(p.code);
		setErr("");
		setForm({
			name: p.name,
			code: p.code,
			level: `${p.percent}|${p.maxOff ?? 0}`,
			branchId: p.branchId ?? "all",
			frame: Math.max(0, FRAMES.findIndex(([, a, b]) => a === p.fromHour && b === p.toHour)),
			start: p.start,
			end: p.end,
			limit: p.limit,
			notify: p.notified
		});
	};
	const reset = () => {
		setEditCode(null);
		setForm(empty);
		setErr("");
	};
	const save = () => {
		const code = form.code.trim().toUpperCase();
		if (!form.name.trim()) return setErr("Vui lòng nhập tên chương trình ưu đãi.");
		if (!/^[A-Z0-9]{4,16}$/.test(code)) return setErr("Mã giảm giá gồm 4–16 ký tự chữ hoa hoặc số, không dấu.");
		if (!editCode && promos.some((p) => p.code === code)) return setErr("Mã giảm giá này đã tồn tại.");
		if (!form.start || !form.end || form.end < form.start) return setErr("Khoảng ngày áp dụng không hợp lệ.");
		if (!(form.limit > 0)) return setErr("Số lượt dùng phải lớn hơn 0.");
		const [pc, mx] = form.level.split("|").map(Number);
		const [, fh, th] = FRAMES[form.frame];
		const br = branches.find((b) => b.id === form.branchId);
		const base = {
			code,
			name: form.name.trim(),
			percent: pc,
			maxOff: mx || null,
			fromHour: fh,
			toHour: th,
			scope: br ? br.name : "Tất cả cơ sở",
			start: form.start,
			end: form.end,
			limit: form.limit,
			active: true,
			notified: form.notify,
			branchId: br?.id,
			tag: "Ưu đãi mới",
			tone: "green"
		};
		if (editCode) setPromos((ps) => ps.map((p) => p.code === editCode ? {
			...p,
			...base,
			active: p.active,
			tag: p.tag,
			tone: p.tone
		} : p));
		else setPromos((ps) => [{
			...base,
			used: 0
		}, ...ps]);
		toast(`${editCode ? "Đã cập nhật" : "Đã phát hành"} mã ${code}${form.notify ? " và gửi thông báo cho toàn bộ khách hàng" : ""}.`, "ok");
		reset();
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("section", {
			className: "card row between wrap g16",
			style: { padding: 16 },
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "row g12 wrap",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "t12 w700 c-s700",
						children: "Kỳ báo cáo:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "date",
						className: "input sm",
						style: { width: "auto" },
						value: from,
						onChange: (e) => setFrom(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "t12 w600 c-s600",
						children: "đến"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "date",
						className: "input sm",
						style: { width: "auto" },
						value: to,
						onChange: (e) => setTo(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "chip-box",
						style: {
							borderRadius: 8,
							background: "var(--s50)"
						},
						children: branchFilter === "all" ? `Tất cả chi nhánh (${branches.length} cơ sở)` : branches.find((b) => b.id === branchFilter)?.name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "btn btn-primary btn-md",
						style: { padding: "8px 16px" },
						onClick: () => {
							if (to < from) return toast("Ngày kết thúc phải sau ngày bắt đầu.", "err");
							setApplied({
								from,
								to
							});
							toast("Đã cập nhật báo cáo theo bộ lọc.");
						},
						children: "Lọc dữ liệu"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "t12 c-s600",
				children: "Dữ liệu cập nhật theo thời gian thực"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "row g16",
			style: { alignItems: "stretch" },
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "hero col g8",
					style: {
						padding: 20,
						borderRadius: 16,
						flex: 1.15
					},
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "t12 w700",
							style: { color: "var(--brand-100)" },
							children: [
								"Tổng doanh thu thực thu (",
								applied.from === MONTH.from && applied.to === MONTH.to ? "Tháng 11" : `${toVN(applied.from)} – ${toVN(applied.to)}`,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "t24 w800",
							style: {
								fontSize: 28,
								lineHeight: "36px"
							},
							children: [fmt(total), " VNĐ"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "t12",
							style: { color: "var(--brand-100)" },
							children: [
								"Chuyển khoản QR: ",
								tr(total * .741),
								" • Tiền mặt: ",
								tr(total * .259)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "card col g8 f1",
					style: { borderRadius: 16 },
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "t12 w700 c-s600",
							children: "Chi tiết nguồn doanh thu"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Row, {
							k: "• Đơn đã hoàn thành:",
							v: money(done),
							c: "c-ink"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Row, {
							k: "• Tiền cọc lịch sắp chơi:",
							v: money(upcoming),
							c: "c-brand"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 69
						}, this),
						/* @__PURE__ */ _jsxDEV(Row, {
							k: "• Tiền cọc đơn hủy giữ lại:",
							v: money(cancel),
							c: "c-amber"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 138
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "card col g8 f1",
					style: { borderRadius: 16 },
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "t12 w700 c-s600",
							children: [
								"Tỷ lệ lượt đặt sân (",
								fmt(orders),
								" đơn)"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Row, {
							k: "• Đặt thành công:",
							v: `${fmt(ok)} đơn (${pct(ok)})`,
							c: "c-brand8"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Row, {
							k: "• Khách hủy / Quá giờ:",
							v: `${fmt(bad)} đơn (${pct(bad)})`,
							c: "c-rose"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 87
						}, this),
						/* @__PURE__ */ _jsxDEV(Row, {
							k: "• Hết hạn giữ chỗ:",
							v: `${fmt(expired)} đơn (${pct(expired)})`,
							c: "c-amber"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 168
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "card col g8 f1",
					style: { borderRadius: 16 },
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "t12 w700 c-s600",
							children: "Hiệu quả chương trình ưu đãi"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "t24 w800 c-ink",
							style: { fontSize: 22 },
							children: [used, " đơn dùng mã"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "t11 c-s600",
							children: [
								"Tổng giảm: ",
								/* @__PURE__ */ _jsxDEV("b", {
									className: "c-rose",
									children: tr(used * 76613)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 50
								}, this),
								" • Doanh thu: ",
								/* @__PURE__ */ _jsxDEV("b", {
									className: "c-brand",
									children: tr(used * 367700)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 108
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "card card-lg col g16",
			style: { padding: 20 },
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "row between",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "t14 w800 c-ink",
					children: "Bảng tổng hợp doanh thu & tỷ lệ lấp đầy theo từng chi nhánh"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 38
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "t12 c-s600",
					children: [
						"Kỳ: ",
						toVN(applied.from),
						" – ",
						toVN(applied.to)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 133
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "tbl-wrap",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "tbl",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("th", { children: "Chi nhánh" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 24
					}, this), [
						"Tổng số đơn",
						"Hoàn thành",
						"Đơn hủy (Giữ cọc)",
						"Công suất sân",
						"Thu từ đơn hoàn thành",
						"Thu từ đơn hủy",
						"Tổng thực thu"
					].map((h) => /* @__PURE__ */ _jsxDEV("th", {
						className: "r",
						children: h
					}, h, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 182
					}, this))] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 20
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: rows.map(({ b, r }) => /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("td", {
							className: "w700 c-ink",
							style: { fontSize: 12 },
							children: [
								b.name,
								" (",
								REPORT[b.id] ? {
									cs1: 8,
									cs2: 10,
									cs3: 6
								}[b.id] : 0,
								" sân)"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "r w700",
							children: fmt(sc(r.orders))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "r w700 c-brand8",
							children: fmt(sc(r.done))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 66
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "r w700 c-rose",
							children: fmt(sc(r.cancel))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 120
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "r w800 c-brand8",
							children: factor ? `${r.occ}%` : "—"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "r w700",
							children: money(sc(r.fromDone))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 84
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "r w700",
							children: money(sc(r.fromCancel))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 135
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "r w800 c-ink",
							children: money(sc(r.total))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 188
						}, this)
					] }, b.id, true, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 17
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 107,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "grid12",
			children: [/* @__PURE__ */ _jsxDEV("section", {
				className: "span7 card card-lg col g16",
				style: { padding: 20 },
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "col g2",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "t16 w800 c-ink",
						style: { lineHeight: "24px" },
						children: "Chương trình khuyến mãi & Mã giảm giá đang mở"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 35
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "t12 c-s600",
						children: "Thu hút khách đặt lịch vào khung giờ thấp điểm và tri ân hội viên thân thiết"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 147
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 11
				}, this), pub.map((p) => /* @__PURE__ */ _jsxDEV("div", {
					className: "row between g12",
					style: {
						background: p.active ? "var(--s50)" : "var(--s100)",
						border: "1px solid var(--s300)",
						borderRadius: 12,
						padding: 16,
						opacity: p.active ? 1 : .8
					},
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "col g6 f1",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "row g8 wrap",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "badge sq c-white mono",
										style: {
											background: p.tone === "sky" ? "#0369a1" : "var(--brand-800)",
											fontSize: 11
										},
										children: p.code
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 131,
										columnNumber: 46
									}, this),
									/* @__PURE__ */ _jsxDEV("b", {
										className: "t14 c-ink",
										children: p.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: `badge ${p.active ? "b-green-flat" : "b-gray"}`,
										style: {
											padding: "2px 10px",
											fontSize: 10,
											fontWeight: 700
										},
										children: p.active ? "Đang chạy" : "Tạm dừng"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 56
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "t11 c-s700",
								children: [
									"Giảm: ",
									/* @__PURE__ */ _jsxDEV("b", {
										className: "c-brand8",
										children: [
											p.percent,
											"%",
											p.maxOff ? ` (Tối đa ${money(p.maxOff)})` : ""
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 133,
										columnNumber: 49
									}, this),
									" • ",
									p.scope,
									p.fromHour > 0 ? ` | Khung ${String(p.fromHour).padStart(2, "0")}:00 - ${String(p.toHour).padStart(2, "0")}:00` : " & Mọi khung giờ",
									" • ",
									toVN(p.start),
									" - ",
									toVN(p.end)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "t11 c-s700",
								children: [
									"Lượt sử dụng: ",
									/* @__PURE__ */ _jsxDEV("b", { children: [
										p.used,
										" / ",
										p.limit,
										" lượt"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 134,
										columnNumber: 57
									}, this),
									p.notified ? " • Đã gửi thông báo cho hội viên" : ""
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "row g8",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "btn btn-outline btn-sm",
							style: { color: "var(--s800)" },
							onClick: () => edit(p),
							children: "Chỉnh sửa"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: `btn btn-sm ${p.active ? "btn-warn-o" : "btn-green-o"}`,
							onClick: () => {
								setPromos((ps) => ps.map((x) => x.code === p.code ? {
									...x,
									active: !x.active
								} : x));
								toast(p.active ? `Đã tạm dừng mã ${p.code}.` : `Mã ${p.code} đã chạy lại.`);
							},
							children: p.active ? "Tạm dừng" : "Chạy lại"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 15
					}, this)]
				}, p.code, true, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 13
				}, this))]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 126,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				className: "span5 card card-lg card-raise col g16",
				style: { padding: 20 },
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "col head-rule",
					style: {
						gap: 2,
						paddingTop: 5
					},
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "eyebrow",
						children: editCode ? `Chỉnh sửa chương trình ${editCode}` : "Tạo chương trình mới"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 76
					}, this), /* @__PURE__ */ _jsxDEV("h3", {
						className: "t16 w800 c-ink",
						style: { lineHeight: "24px" },
						children: "Phát hành mã giảm giá & Gửi thông báo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 183
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 145,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("form", {
					className: "col g12",
					onSubmit: (e) => {
						e.preventDefault();
						save();
					},
					children: [
						/* @__PURE__ */ _jsxDEV(F, {
							l: "Tên chương trình ưu đãi *",
							children: /* @__PURE__ */ _jsxDEV("input", {
								className: "input sm",
								value: form.name,
								onChange: (e) => setForm({
									...form,
									name: e.target.value
								}),
								placeholder: "VD: Ưu đãi khung giờ vàng buổi sáng"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 46
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g12",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: /* @__PURE__ */ _jsxDEV(F, {
									l: "Mã giảm giá *",
									children: /* @__PURE__ */ _jsxDEV("input", {
										className: "input sm",
										style: {
											color: "var(--brand-700)",
											fontWeight: 800
										},
										value: form.code,
										disabled: !!editCode,
										placeholder: "SANGVUI20",
										onChange: (e) => setForm({
											...form,
											code: e.target.value.toUpperCase()
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 149,
										columnNumber: 56
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 35
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: /* @__PURE__ */ _jsxDEV(F, {
									l: "Mức giảm giá *",
									children: /* @__PURE__ */ _jsxDEV("select", {
										className: "select sm",
										value: form.level,
										onChange: (e) => setForm({
											...form,
											level: e.target.value
										}),
										children: LEVELS.map(([v, l]) => /* @__PURE__ */ _jsxDEV("option", {
											value: v,
											children: l
										}, v, false, {
											fileName: _jsxFileName,
											lineNumber: 150,
											columnNumber: 192
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 150,
										columnNumber: 57
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 35
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g12",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: /* @__PURE__ */ _jsxDEV(F, {
									l: "Chi nhánh áp dụng *",
									children: /* @__PURE__ */ _jsxDEV("select", {
										className: "select sm",
										value: form.branchId,
										onChange: (e) => setForm({
											...form,
											branchId: e.target.value
										}),
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "all",
											children: "Tất cả chi nhánh"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 153,
											columnNumber: 179
										}, this), branches.map((b) => /* @__PURE__ */ _jsxDEV("option", {
											value: b.id,
											children: b.name
										}, b.id, false, {
											fileName: _jsxFileName,
											lineNumber: 153,
											columnNumber: 245
										}, this))]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 153,
										columnNumber: 62
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 35
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "f1",
								children: /* @__PURE__ */ _jsxDEV(F, {
									l: "Khung giờ áp dụng *",
									children: /* @__PURE__ */ _jsxDEV("select", {
										className: "select sm",
										value: form.frame,
										onChange: (e) => setForm({
											...form,
											frame: Number(e.target.value)
										}),
										children: FRAMES.map(([l], i) => /* @__PURE__ */ _jsxDEV("option", {
											value: i,
											children: l
										}, l, false, {
											fileName: _jsxFileName,
											lineNumber: 154,
											columnNumber: 205
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 154,
										columnNumber: 62
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 35
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 152,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g12",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "f1",
									children: /* @__PURE__ */ _jsxDEV(F, {
										l: "Từ ngày *",
										children: /* @__PURE__ */ _jsxDEV("input", {
											className: "input sm",
											type: "date",
											value: form.start,
											onChange: (e) => setForm({
												...form,
												start: e.target.value
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 157,
											columnNumber: 52
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 157,
										columnNumber: 35
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "f1",
									children: /* @__PURE__ */ _jsxDEV(F, {
										l: "Đến ngày *",
										children: /* @__PURE__ */ _jsxDEV("input", {
											className: "input sm",
											type: "date",
											value: form.end,
											onChange: (e) => setForm({
												...form,
												end: e.target.value
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 158,
											columnNumber: 53
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 158,
										columnNumber: 35
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "f1",
									children: /* @__PURE__ */ _jsxDEV(F, {
										l: "Số lượt dùng *",
										children: /* @__PURE__ */ _jsxDEV("input", {
											className: "input sm",
											type: "number",
											min: 1,
											value: form.limit,
											onChange: (e) => setForm({
												...form,
												limit: Number(e.target.value)
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 159,
											columnNumber: 57
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 159,
										columnNumber: 35
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "row g10 hint hint-green",
							style: {
								padding: 12,
								cursor: "pointer",
								background: "var(--brand-50)"
							},
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								checked: form.notify,
								onChange: (e) => setForm({
									...form,
									notify: e.target.checked
								}),
								style: {
									accentColor: "#0075ff",
									width: 14,
									height: 14
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "w700 c-ink",
								children: "Gửi thông báo chương trình ưu đãi này tới toàn bộ khách hàng"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 13
						}, this),
						err && /* @__PURE__ */ _jsxDEV("p", {
							className: "field-err",
							children: err
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "row g8",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-primary btn-md f1",
								type: "submit",
								children: editCode ? "Lưu thay đổi" : "Lưu & Phát hành ưu đãi"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 37
							}, this), editCode && /* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-outline btn-md",
								type: "button",
								onClick: reset,
								children: "Hủy sửa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 173
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 144,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 125,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 73,
		columnNumber: 5
	}, this);
}
_s(OwnerReports, "FeHlHLBLP39lvDTWQW6TEgHD5l0=", false, function() {
	return [useApp, useOutletContext];
});
_c = OwnerReports;
function Row({ k, v, c }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "row between g8 t11",
		style: { fontSize: 11.5 },
		children: [/* @__PURE__ */ _jsxDEV("b", {
			className: "c-ink",
			style: { fontWeight: 700 },
			children: k
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 175,
			columnNumber: 73
		}, this), /* @__PURE__ */ _jsxDEV("b", {
			className: c,
			children: v
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 175,
			columnNumber: 129
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 175,
		columnNumber: 10
	}, this);
}
_c2 = Row;
function F({ l, children }) {
	return /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
		className: "label",
		style: { marginBottom: 4 },
		children: l
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 178,
		columnNumber: 15
	}, this), children] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 178,
		columnNumber: 10
	}, this);
}
_c3 = F;
var _c, _c2, _c3;
$RefreshReg$(_c, "OwnerReports");
$RefreshReg$(_c2, "Row");
$RefreshReg$(_c3, "F");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/OwnerReports.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/OwnerReports.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/OwnerReports.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/OwnerReports.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxLQUFLLE9BQU8sWUFBWTtBQUdqQyxTQUFTLGNBQWM7Ozs7O0FBR3ZCLE1BQU0sU0FBNkk7Q0FDakosS0FBSztFQUFFLFFBQVE7RUFBSyxNQUFNO0VBQUssUUFBUTtFQUFJLEtBQUs7RUFBSSxVQUFVO0VBQVUsWUFBWTtFQUFTLE9BQU87Q0FBVTtDQUM5RyxLQUFLO0VBQUUsUUFBUTtFQUFLLE1BQU07RUFBSyxRQUFRO0VBQUksS0FBSztFQUFJLFVBQVU7RUFBVSxZQUFZO0VBQVMsT0FBTztDQUFTO0NBQzdHLEtBQUs7RUFBRSxRQUFRO0VBQUssTUFBTTtFQUFLLFFBQVE7RUFBSSxLQUFLO0VBQUksVUFBVTtFQUFVLFlBQVk7RUFBUyxPQUFPO0NBQVM7QUFDL0c7QUFDQSxNQUFNLFFBQVE7Q0FBRSxNQUFNO0NBQWMsSUFBSTtBQUFhO0FBQ3JELE1BQU0sU0FBcUM7Q0FBQztFQUFDO0VBQTJCO0VBQUc7Q0FBRTtDQUFHO0VBQUM7RUFBaUI7RUFBRztDQUFFO0NBQUc7RUFBQztFQUFpQjtFQUFJO0NBQUU7Q0FBRztFQUFDO0VBQWlCO0VBQUk7Q0FBRTtBQUFDO0FBQzlKLE1BQU0sU0FBUztDQUFDLENBQUMsT0FBTyxTQUFTO0NBQUcsQ0FBQyxRQUFRLFVBQVU7Q0FBRyxDQUFDLFFBQVEsVUFBVTtDQUFHLENBQUMsYUFBYSx3QkFBd0I7Q0FBRyxDQUFDLGFBQWEsd0JBQXdCO0NBQUcsQ0FBQyxhQUFhLHdCQUF3QjtBQUFDO0FBQ3pNLE1BQU0sUUFBUTtDQUFFLE1BQU07Q0FBSSxNQUFNO0NBQUksT0FBTztDQUFRLFVBQVU7Q0FBTyxPQUFPO0NBQUcsT0FBTztDQUFjLEtBQUs7Q0FBYyxPQUFPO0NBQUssUUFBUTtBQUFLO0FBRS9JLE1BQU0sV0FBVyxHQUFXLE1BQWM7Q0FDeEMsTUFBTSxJQUFJLElBQUksS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLElBQUksS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDLENBQUM7Q0FDM0gsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFRLElBQUksQ0FBQyxJQUFJO0FBQzdEO0FBQ0EsTUFBTSxNQUFNLE1BQWMsSUFBSSxJQUFJLElBQUcsQ0FBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxHQUFHLENBQUMsQ0FBQyxRQUFRLFNBQVMsRUFBRSxFQUFFO0FBRXpGLGVBQWUsU0FBUyxlQUFlOztDQUNyQyxNQUFNLEVBQUUsVUFBVSxRQUFRLFdBQVcsVUFBVSxPQUFPO0NBQ3RELE1BQU0sRUFBRSxpQkFBaUIsaUJBQThCO0NBQ3ZELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxNQUFNLElBQUk7Q0FDM0MsTUFBTSxDQUFDLElBQUksU0FBUyxTQUFTLE1BQU0sRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVM7RUFBRSxNQUFNLE1BQU07RUFBTSxJQUFJLE1BQU07Q0FBRyxDQUFDO0NBQ3pFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBd0IsSUFBSTtDQUM1RCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQVMsRUFBRTtDQUVqQyxNQUFNLFNBQVMsUUFBUSxRQUFRLE1BQU0sUUFBUSxFQUFFO0NBQy9DLE1BQU0sTUFBTSxTQUFTLFFBQVEsTUFBTSxpQkFBaUIsU0FBUyxFQUFFLE9BQU8sWUFBWTtDQUNsRixNQUFNLE9BQU8sSUFBSSxLQUFLLE9BQU87RUFBRTtFQUFHLEdBQUcsT0FBTyxFQUFFLE9BQU87R0FBRSxRQUFRO0dBQUcsTUFBTTtHQUFHLFFBQVE7R0FBRyxLQUFLO0dBQUcsVUFBVTtHQUFHLFlBQVk7R0FBRyxPQUFPO0VBQUU7Q0FBRSxFQUFFO0NBQ3ZJLE1BQU0sTUFBTSxNQUFjLEtBQUssTUFBTSxJQUFJLE1BQU07Q0FDL0MsTUFBTSxPQUFPLE1BQW9DLEdBQUcsS0FBSyxRQUFRLEdBQUcsTUFBTSxJQUFJLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztDQUN4RixNQUFNLFFBQVEsSUFBSSxPQUFPLEdBQUcsT0FBTyxJQUFJLFVBQVUsR0FBRyxTQUFTLElBQUksWUFBWSxHQUFHLFdBQVcsUUFBUSxPQUFPO0NBQzFHLE1BQU0sU0FBUyxJQUFJLFFBQVEsR0FBRyxLQUFLLElBQUksTUFBTSxHQUFHLE1BQU0sSUFBSSxRQUFRLEdBQUcsVUFBVSxLQUFLLElBQUksR0FBRyxTQUFTLEtBQUssR0FBRztDQUM1RyxNQUFNLE9BQU8sTUFBZSxTQUFTLElBQUssSUFBSSxTQUFVLElBQUcsQ0FBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxHQUFHLEVBQUUsS0FBSztDQUMvRixNQUFNLE9BQU8sT0FBTyxRQUFRLE1BQU0sQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDLFFBQVEsR0FBRyxNQUFNLElBQUksRUFBRSxNQUFNLENBQUM7Q0FDaEYsTUFBTSxNQUFNLE9BQU8sUUFBUSxNQUFNLENBQUMsRUFBRSxXQUFXO0NBRS9DLE1BQU0sUUFBUSxNQUFhO0VBQ3pCLFlBQVksRUFBRSxJQUFJO0VBQUcsT0FBTyxFQUFFO0VBQzlCLFFBQVE7R0FBRSxNQUFNLEVBQUU7R0FBTSxNQUFNLEVBQUU7R0FBTSxPQUFPLEdBQUcsRUFBRSxRQUFRLEdBQUcsRUFBRSxVQUFVO0dBQUssVUFBVSxFQUFFLFlBQVk7R0FBTyxPQUFPLEtBQUssSUFBSSxHQUFHLE9BQU8sV0FBVyxHQUFHLEdBQUcsT0FBTyxNQUFNLEVBQUUsWUFBWSxNQUFNLEVBQUUsTUFBTSxDQUFDO0dBQUcsT0FBTyxFQUFFO0dBQU8sS0FBSyxFQUFFO0dBQUssT0FBTyxFQUFFO0dBQU8sUUFBUSxFQUFFO0VBQVMsQ0FBQztDQUN2UTtDQUNBLE1BQU0sY0FBYztFQUFFLFlBQVksSUFBSTtFQUFHLFFBQVEsS0FBSztFQUFHLE9BQU8sRUFBRTtDQUFFO0NBQ3BFLE1BQU0sYUFBYTtFQUNqQixNQUFNLE9BQU8sS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDMUMsSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLEdBQUcsT0FBTyxPQUFPLHdDQUF3QztFQUM3RSxJQUFJLENBQUMsbUJBQW1CLEtBQUssSUFBSSxHQUFHLE9BQU8sT0FBTyx3REFBd0Q7RUFDMUcsSUFBSSxDQUFDLFlBQVksT0FBTyxNQUFNLE1BQU0sRUFBRSxTQUFTLElBQUksR0FBRyxPQUFPLE9BQU8sNkJBQTZCO0VBQ2pHLElBQUksQ0FBQyxLQUFLLFNBQVMsQ0FBQyxLQUFLLE9BQU8sS0FBSyxNQUFNLEtBQUssT0FBTyxPQUFPLE9BQU8sbUNBQW1DO0VBQ3hHLElBQUksRUFBRSxLQUFLLFFBQVEsSUFBSSxPQUFPLE9BQU8sOEJBQThCO0VBQ25FLE1BQU0sQ0FBQyxJQUFJLE1BQU0sS0FBSyxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNO0VBQ2pELE1BQU0sR0FBRyxJQUFJLE1BQU0sT0FBTyxLQUFLO0VBQy9CLE1BQU0sS0FBSyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sS0FBSyxRQUFRO0VBQ3RELE1BQU0sT0FBNEI7R0FDaEM7R0FBTSxNQUFNLEtBQUssS0FBSyxLQUFLO0dBQUcsU0FBUztHQUFJLFFBQVEsTUFBTTtHQUFNLFVBQVU7R0FBSSxRQUFRO0dBQUksT0FBTyxLQUFLLEdBQUcsT0FBTztHQUMvRyxPQUFPLEtBQUs7R0FBTyxLQUFLLEtBQUs7R0FBSyxPQUFPLEtBQUs7R0FBTyxRQUFRO0dBQU0sVUFBVSxLQUFLO0dBQVEsVUFBVSxJQUFJO0dBQ3hHLEtBQUs7R0FBYyxNQUFNO0VBQzNCO0VBQ0EsSUFBSSxVQUFVLFdBQVcsT0FBTyxHQUFHLEtBQUssTUFBTyxFQUFFLFNBQVMsV0FBVztHQUFFLEdBQUc7R0FBRyxHQUFHO0dBQU0sUUFBUSxFQUFFO0dBQVEsS0FBSyxFQUFFO0dBQUssTUFBTSxFQUFFO0VBQUssSUFBSSxDQUFFLENBQUM7T0FDbkksV0FBVyxPQUFPLENBQUM7R0FBRSxHQUFHO0dBQU0sTUFBTTtFQUFFLEdBQUcsR0FBRyxFQUFFLENBQUM7RUFDcEQsTUFBTSxHQUFHLFdBQVcsZ0JBQWdCLGVBQWUsTUFBTSxPQUFPLEtBQUssU0FBUyw2Q0FBNkMsR0FBRyxJQUFJLElBQUk7RUFDdEksTUFBTTtDQUNSO0NBRUEsT0FDRTtFQUNFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO0dBQTRCLE9BQU8sRUFBRSxTQUFTLEdBQUc7YUFBcEUsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWtCO0tBQWlCOzs7OztLQUNuRCx3QkFBQyxTQUFEO01BQU8sTUFBSztNQUFPLFdBQVU7TUFBVyxPQUFPLEVBQUUsT0FBTyxPQUFPO01BQUcsT0FBTztNQUFNLFdBQVcsTUFBTSxRQUFRLEVBQUUsT0FBTyxLQUFLO0tBQUk7Ozs7O0tBQzFILHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFrQjtLQUFTOzs7OztLQUMzQyx3QkFBQyxTQUFEO01BQU8sTUFBSztNQUFPLFdBQVU7TUFBVyxPQUFPLEVBQUUsT0FBTyxPQUFPO01BQUcsT0FBTztNQUFJLFdBQVcsTUFBTSxNQUFNLEVBQUUsT0FBTyxLQUFLO0tBQUk7Ozs7O0tBQ3RILHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQVcsT0FBTztPQUFFLGNBQWM7T0FBRyxZQUFZO01BQWE7Z0JBQUksaUJBQWlCLFFBQVEscUJBQXFCLFNBQVMsT0FBTyxXQUFXLFNBQVMsTUFBTSxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsRUFBRTtLQUFXOzs7OztLQUNuTix3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUF5QixPQUFPLEVBQUUsU0FBUyxXQUFXO01BQUcsZUFBZTtPQUFFLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSx3Q0FBd0MsS0FBSztPQUFHLFdBQVc7UUFBRTtRQUFNO09BQUcsQ0FBQztPQUFHLE1BQU0sa0NBQWtDO01BQUU7Z0JBQUc7S0FBbUI7Ozs7O0lBQy9QOzs7OzthQUNMLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWE7R0FBMEM7Ozs7V0FDaEU7Ozs7OztFQUVULHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQVUsT0FBTyxFQUFFLFlBQVksVUFBVTthQUF4RDtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWMsT0FBTztNQUFFLFNBQVM7TUFBSSxjQUFjO01BQUksTUFBTTtLQUFLO2VBQWhGO01BQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBVyxPQUFPLEVBQUUsT0FBTyxtQkFBbUI7aUJBQTlEO1FBQWlFO1FBQTBCLFFBQVEsU0FBUyxNQUFNLFFBQVEsUUFBUSxPQUFPLE1BQU0sS0FBSyxhQUFhLEdBQUcsS0FBSyxRQUFRLElBQUksRUFBRSxLQUFLLEtBQUssUUFBUSxFQUFFO1FBQUk7T0FBTzs7Ozs7O01BQ3ROLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVcsT0FBTztRQUFFLFVBQVU7UUFBSSxZQUFZO09BQU87aUJBQXBFLENBQXdFLElBQUksS0FBSyxHQUFFLE1BQVM7Ozs7OztNQUM1Rix3QkFBQyxLQUFEO09BQUcsV0FBVTtPQUFNLE9BQU8sRUFBRSxPQUFPLG1CQUFtQjtpQkFBdEQ7UUFBeUQ7UUFBa0IsR0FBRyxRQUFRLElBQUs7UUFBRTtRQUFjLEdBQUcsUUFBUSxJQUFLO09BQUs7Ozs7OztLQUM3SDs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBaUIsT0FBTyxFQUFFLGNBQWMsR0FBRztlQUExRDtNQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFrQjtNQUE4Qjs7Ozs7TUFDaEUsd0JBQUMsS0FBRDtPQUFLLEdBQUU7T0FBdUIsR0FBRyxNQUFNLElBQUk7T0FBRyxHQUFFO01BQVM7Ozs7O01BQUMsd0JBQUMsS0FBRDtPQUFLLEdBQUU7T0FBNEIsR0FBRyxNQUFNLFFBQVE7T0FBRyxHQUFFO01BQVc7Ozs7O01BQUMsd0JBQUMsS0FBRDtPQUFLLEdBQUU7T0FBOEIsR0FBRyxNQUFNLE1BQU07T0FBRyxHQUFFO01BQVc7Ozs7O0tBQ2hNOzs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFpQixPQUFPLEVBQUUsY0FBYyxHQUFHO2VBQTFEO01BQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCO1FBQWtDO1FBQXFCLElBQUksTUFBTTtRQUFFO09BQVc7Ozs7OztNQUM5RSx3QkFBQyxLQUFEO09BQUssR0FBRTtPQUFvQixHQUFHLEdBQUcsSUFBSSxFQUFFLEVBQUUsUUFBUSxJQUFJLEVBQUUsRUFBRTtPQUFJLEdBQUU7TUFBWTs7Ozs7TUFBQyx3QkFBQyxLQUFEO09BQUssR0FBRTtPQUF5QixHQUFHLEdBQUcsSUFBSSxHQUFHLEVBQUUsUUFBUSxJQUFJLEdBQUcsRUFBRTtPQUFJLEdBQUU7TUFBVTs7Ozs7TUFBQyx3QkFBQyxLQUFEO09BQUssR0FBRTtPQUFxQixHQUFHLEdBQUcsSUFBSSxPQUFPLEVBQUUsUUFBUSxJQUFJLE9BQU8sRUFBRTtPQUFJLEdBQUU7TUFBVzs7Ozs7S0FDL087Ozs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWlCLE9BQU8sRUFBRSxjQUFjLEdBQUc7ZUFBMUQ7TUFDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBa0I7TUFBa0M7Ozs7O01BQ3BFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQWlCLE9BQU8sRUFBRSxVQUFVLEdBQUc7aUJBQXRELENBQTBELE1BQUssY0FBaUI7Ozs7OztNQUNoRix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUE0QjtRQUFXLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFVLEdBQUcsT0FBTyxLQUFLO1FBQUs7Ozs7O1FBQUM7UUFBYyx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBVyxHQUFHLE9BQU8sTUFBTTtRQUFLOzs7OztPQUFNOzs7Ozs7S0FDako7Ozs7OztHQUNGOzs7Ozs7RUFFTCx3QkFBQyxXQUFEO0dBQVMsV0FBVTtHQUF1QixPQUFPLEVBQUUsU0FBUyxHQUFHO2FBQS9ELENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUE2Qix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFpQjtJQUErRDs7OztjQUFDLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCO01BQTZCO01BQUssS0FBSyxRQUFRLElBQUk7TUFBRTtNQUFJLEtBQUssUUFBUSxFQUFFO0tBQVE7Ozs7O1lBQU07Ozs7O2FBQ2xOLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQU8sd0JBQUMsTUFBRCxhQUFJLHdCQUFDLE1BQUQsWUFBSSxZQUFhOzs7O2VBQUU7TUFBQztNQUFlO01BQWM7TUFBcUI7TUFBaUI7TUFBeUI7TUFBa0I7S0FBZSxDQUFDLENBQUMsS0FBSyxNQUFNLHdCQUFDLE1BQUQ7TUFBWSxXQUFVO2dCQUFLO0tBQU0sR0FBeEI7Ozs7WUFBd0IsQ0FBQyxDQUFNOzs7O2NBQVE7Ozs7ZUFDek4sd0JBQUMsU0FBRCxZQUNHLEtBQUssS0FBSyxFQUFFLEdBQUcsUUFDZCx3QkFBQyxNQUFEO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7T0FBYSxPQUFPLEVBQUUsVUFBVSxHQUFHO2lCQUFqRDtRQUFxRCxFQUFFO1FBQUs7UUFBaUIsT0FBTyxFQUFFLE1BQU07U0FBRSxLQUFLO1NBQUcsS0FBSztTQUFJLEtBQUs7UUFBRSxFQUFFLEVBQUUsTUFBTTtRQUFFO09BQVM7Ozs7OztNQUMzSSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBVSxJQUFJLEdBQUcsRUFBRSxNQUFNLENBQUM7TUFBTTs7Ozs7TUFBQyx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBbUIsSUFBSSxHQUFHLEVBQUUsSUFBSSxDQUFDO01BQU07Ozs7O01BQUMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWlCLElBQUksR0FBRyxFQUFFLE1BQU0sQ0FBQztNQUFNOzs7OztNQUMxSix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBbUIsU0FBUyxHQUFHLEVBQUUsSUFBSSxLQUFLO01BQVE7Ozs7O01BQUMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQVUsTUFBTSxHQUFHLEVBQUUsUUFBUSxDQUFDO01BQU07Ozs7O01BQUMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQVUsTUFBTSxHQUFHLEVBQUUsVUFBVSxDQUFDO01BQU07Ozs7O01BQUMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWdCLE1BQU0sR0FBRyxFQUFFLEtBQUssQ0FBQztNQUFNOzs7OztLQUM1TixLQUpLLEVBQUU7Ozs7WUFJUCxDQUNMLEVBQ0k7Ozs7YUFDRjs7Ozs7O0dBQ0o7Ozs7V0FDRTs7Ozs7O0VBRVQsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO0lBQTZCLE9BQU8sRUFBRSxTQUFTLEdBQUc7Y0FBckUsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQXdCLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO01BQWlCLE9BQU8sRUFBRSxZQUFZLE9BQU87Z0JBQUc7S0FBaUQ7Ozs7ZUFBQyx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYTtLQUErRTs7OzthQUFNOzs7OztjQUN0UCxJQUFJLEtBQUssTUFDUix3QkFBQyxPQUFEO0tBQWtCLFdBQVU7S0FBa0IsT0FBTztNQUFFLFlBQVksRUFBRSxTQUFTLGVBQWU7TUFBZSxRQUFRO01BQXlCLGNBQWM7TUFBSSxTQUFTO01BQUksU0FBUyxFQUFFLFNBQVMsSUFBSTtLQUFJO2VBQXhNLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUE2Qix3QkFBQyxRQUFEO1VBQU0sV0FBVTtVQUF3QixPQUFPO1dBQUUsWUFBWSxFQUFFLFNBQVMsUUFBUSxZQUFZO1dBQW9CLFVBQVU7VUFBRztvQkFBSSxFQUFFO1NBQVc7Ozs7O1NBQ3pLLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFhLEVBQUU7U0FBUTs7Ozs7U0FBQyx3QkFBQyxRQUFEO1VBQU0sV0FBVyxTQUFTLEVBQUUsU0FBUyxpQkFBaUI7VUFBWSxPQUFPO1dBQUUsU0FBUztXQUFZLFVBQVU7V0FBSSxZQUFZO1VBQUk7b0JBQUksRUFBRSxTQUFTLGNBQWM7U0FBaUI7Ozs7O1FBQU07Ozs7OztPQUN6Tix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUEwQjtTQUFNLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiO1dBQXlCLEVBQUU7V0FBUTtXQUFFLEVBQUUsU0FBUyxZQUFZLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSztVQUFNOzs7Ozs7U0FBQztTQUFJLEVBQUU7U0FBTyxFQUFFLFdBQVcsSUFBSSxZQUFZLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRyxFQUFFLFFBQVEsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsT0FBTztTQUFtQjtTQUFJLEtBQUssRUFBRSxLQUFLO1NBQUU7U0FBSSxLQUFLLEVBQUUsR0FBRztRQUFLOzs7Ozs7T0FDL1Msd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FBMEI7U0FBYyx3QkFBQyxLQUFEO1VBQUksRUFBRTtVQUFLO1VBQUksRUFBRTtVQUFNO1NBQVE7Ozs7O1NBQUUsRUFBRSxXQUFXLHFDQUFxQztRQUFNOzs7Ozs7TUFDOUg7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUF5QixPQUFPLEVBQUUsT0FBTyxjQUFjO09BQUcsZUFBZSxLQUFLLENBQUM7aUJBQUc7TUFBaUI7Ozs7Z0JBQ3JILHdCQUFDLFVBQUQ7T0FBUSxXQUFXLGNBQWMsRUFBRSxTQUFTLGVBQWU7T0FBaUIsZUFBZTtRQUFFLFdBQVcsT0FBTyxHQUFHLEtBQUssTUFBTyxFQUFFLFNBQVMsRUFBRSxPQUFPO1NBQUUsR0FBRztTQUFHLFFBQVEsQ0FBQyxFQUFFO1FBQU8sSUFBSSxDQUFFLENBQUM7UUFBRyxNQUFNLEVBQUUsU0FBUyxrQkFBa0IsRUFBRSxLQUFLLEtBQUssTUFBTSxFQUFFLEtBQUssY0FBYztPQUFFO2lCQUFJLEVBQUUsU0FBUyxhQUFhO01BQW1COzs7O2NBQzlTOzs7OzthQUNGO09BWEssRUFBRTs7OztXQVdQLENBQ04sQ0FDTTs7Ozs7YUFFVCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtJQUF3QyxPQUFPLEVBQUUsU0FBUyxHQUFHO2NBQTlFLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBZ0IsT0FBTztNQUFFLEtBQUs7TUFBRyxZQUFZO0tBQUU7ZUFBOUQsQ0FBaUUsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQVcsV0FBVywwQkFBMEIsYUFBYTtLQUE2Qjs7OztlQUFDLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO01BQWlCLE9BQU8sRUFBRSxZQUFZLE9BQU87Z0JBQUc7S0FBeUM7Ozs7YUFBTTs7Ozs7Y0FDelIsd0JBQUMsUUFBRDtLQUFNLFdBQVU7S0FBVSxXQUFXLE1BQU07TUFBRSxFQUFFLGVBQWU7TUFBRyxLQUFLO0tBQUU7ZUFBeEU7TUFDRSx3QkFBQyxHQUFEO09BQUcsR0FBRTtpQkFBNEIsd0JBQUMsU0FBRDtRQUFPLFdBQVU7UUFBVyxPQUFPLEtBQUs7UUFBTSxXQUFXLE1BQU0sUUFBUTtTQUFFLEdBQUc7U0FBTSxNQUFNLEVBQUUsT0FBTztRQUFNLENBQUM7UUFBRyxhQUFZO09BQXVDOzs7OztNQUFJOzs7OztNQUNuTSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFLLHdCQUFDLEdBQUQ7U0FBRyxHQUFFO21CQUFnQix3QkFBQyxTQUFEO1VBQU8sV0FBVTtVQUFXLE9BQU87V0FBRSxPQUFPO1dBQW9CLFlBQVk7VUFBSTtVQUFHLE9BQU8sS0FBSztVQUFNLFVBQVUsQ0FBQyxDQUFDO1VBQVUsYUFBWTtVQUFZLFdBQVcsTUFBTSxRQUFRO1dBQUUsR0FBRztXQUFNLE1BQU0sRUFBRSxPQUFPLE1BQU0sWUFBWTtVQUFFLENBQUM7U0FBSTs7Ozs7UUFBSTs7Ozs7T0FBTTs7OztpQkFDbFIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQUssd0JBQUMsR0FBRDtTQUFHLEdBQUU7bUJBQWlCLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO1VBQVksT0FBTyxLQUFLO1VBQU8sV0FBVyxNQUFNLFFBQVE7V0FBRSxHQUFHO1dBQU0sT0FBTyxFQUFFLE9BQU87VUFBTSxDQUFDO29CQUFJLE9BQU8sS0FBSyxDQUFDLEdBQUcsT0FBTyx3QkFBQyxVQUFEO1dBQWdCLE9BQU87cUJBQUk7VUFBVSxHQUF4Qjs7OztpQkFBd0IsQ0FBQztTQUFVOzs7OztRQUFJOzs7OztPQUFNOzs7O2VBQ3hPOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFLLHdCQUFDLEdBQUQ7U0FBRyxHQUFFO21CQUFzQix3QkFBQyxVQUFEO1VBQVEsV0FBVTtVQUFZLE9BQU8sS0FBSztVQUFVLFdBQVcsTUFBTSxRQUFRO1dBQUUsR0FBRztXQUFNLFVBQVUsRUFBRSxPQUFPO1VBQU0sQ0FBQztvQkFBbEgsQ0FBcUgsd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQU07VUFBd0I7Ozs7b0JBQUUsU0FBUyxLQUFLLE1BQU0sd0JBQUMsVUFBRDtXQUFtQixPQUFPLEVBQUU7cUJBQUssRUFBRTtVQUFhLEdBQW5DLEVBQUU7Ozs7aUJBQWlDLENBQUMsQ0FBVTs7Ozs7O1FBQUk7Ozs7O09BQU07Ozs7aUJBQzNTLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFLLHdCQUFDLEdBQUQ7U0FBRyxHQUFFO21CQUFzQix3QkFBQyxVQUFEO1VBQVEsV0FBVTtVQUFZLE9BQU8sS0FBSztVQUFPLFdBQVcsTUFBTSxRQUFRO1dBQUUsR0FBRztXQUFNLE9BQU8sT0FBTyxFQUFFLE9BQU8sS0FBSztVQUFFLENBQUM7b0JBQUksT0FBTyxLQUFLLENBQUMsSUFBSSxNQUFNLHdCQUFDLFVBQUQ7V0FBZ0IsT0FBTztxQkFBSTtVQUFVLEdBQXhCOzs7O2lCQUF3QixDQUFDO1NBQVU7Ozs7O1FBQUk7Ozs7O09BQU07Ozs7ZUFDclA7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQUssd0JBQUMsR0FBRDtVQUFHLEdBQUU7b0JBQVksd0JBQUMsU0FBRDtXQUFPLFdBQVU7V0FBVyxNQUFLO1dBQU8sT0FBTyxLQUFLO1dBQU8sV0FBVyxNQUFNLFFBQVE7WUFBRSxHQUFHO1lBQU0sT0FBTyxFQUFFLE9BQU87V0FBTSxDQUFDO1VBQUk7Ozs7O1NBQUk7Ozs7O1FBQU07Ozs7O1FBQ3pLLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFLLHdCQUFDLEdBQUQ7VUFBRyxHQUFFO29CQUFhLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO1dBQVcsTUFBSztXQUFPLE9BQU8sS0FBSztXQUFLLFdBQVcsTUFBTSxRQUFRO1lBQUUsR0FBRztZQUFNLEtBQUssRUFBRSxPQUFPO1dBQU0sQ0FBQztVQUFJOzs7OztTQUFJOzs7OztRQUFNOzs7OztRQUN0Syx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBSyx3QkFBQyxHQUFEO1VBQUcsR0FBRTtvQkFBaUIsd0JBQUMsU0FBRDtXQUFPLFdBQVU7V0FBVyxNQUFLO1dBQVMsS0FBSztXQUFHLE9BQU8sS0FBSztXQUFPLFdBQVcsTUFBTSxRQUFRO1lBQUUsR0FBRztZQUFNLE9BQU8sT0FBTyxFQUFFLE9BQU8sS0FBSztXQUFFLENBQUM7VUFBSTs7Ozs7U0FBSTs7Ozs7UUFBTTs7Ozs7T0FDN0w7Ozs7OztNQUNMLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO09BQTBCLE9BQU87UUFBRSxTQUFTO1FBQUksUUFBUTtRQUFXLFlBQVk7T0FBa0I7aUJBQWxILENBQ0Usd0JBQUMsU0FBRDtRQUFPLE1BQUs7UUFBVyxTQUFTLEtBQUs7UUFBUSxXQUFXLE1BQU0sUUFBUTtTQUFFLEdBQUc7U0FBTSxRQUFRLEVBQUUsT0FBTztRQUFRLENBQUM7UUFBRyxPQUFPO1NBQUUsYUFBYTtTQUFXLE9BQU87U0FBSSxRQUFRO1FBQUc7T0FBSTs7OztpQkFDekssd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWE7T0FBa0U7Ozs7ZUFDMUY7Ozs7OztNQUNOLE9BQU8sd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWE7TUFBTzs7Ozs7TUFDekMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBd0Isd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBNEIsTUFBSztrQkFBVSxXQUFXLGlCQUFpQjtPQUFpQzs7OztpQkFBRSxZQUFZLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQXlCLE1BQUs7UUFBUyxTQUFTO2tCQUFPO09BQWU7Ozs7ZUFBTzs7Ozs7O0tBQzNQOzs7OztZQUNEOzs7OztXQUNKOzs7Ozs7Q0FDTDs7Ozs7QUFFTjs7Ozs7QUFFQSxTQUFTLElBQUksRUFBRSxHQUFHLEdBQUcsS0FBMEM7Q0FDN0QsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFxQixPQUFPLEVBQUUsVUFBVSxLQUFLO1lBQTVELENBQStELHdCQUFDLEtBQUQ7R0FBRyxXQUFVO0dBQVEsT0FBTyxFQUFFLFlBQVksSUFBSTthQUFJO0VBQUs7Ozs7WUFBQyx3QkFBQyxLQUFEO0dBQUcsV0FBVzthQUFJO0VBQUs7Ozs7VUFBTTs7Ozs7O0FBQzdKOztBQUNBLFNBQVMsRUFBRSxFQUFFLEdBQUcsWUFBc0Q7Q0FDcEUsT0FBTyx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRDtFQUFPLFdBQVU7RUFBUSxPQUFPLEVBQUUsY0FBYyxFQUFFO1lBQUk7Q0FBUzs7OztXQUFFLFFBQWM7Ozs7O0FBQzdGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk93bmVyUmVwb3J0cy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU91dGxldENvbnRleHQgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgZm10LCBtb25leSwgdG9WTiB9IGZyb20gJy4uL2RhdGEnXG5pbXBvcnQgdHlwZSB7IFByb21vIH0gZnJvbSAnLi4vZGF0YSdcbmltcG9ydCB0eXBlIHsgU3RhZmZPdXRsZXQgfSBmcm9tICcuLi9sYXlvdXRzJ1xuaW1wb3J0IHsgdXNlQXBwIH0gZnJvbSAnLi4vc3RvcmUnXG5cbi8vIFPhu5EgbGnhu4d1IHThu5VuZyBo4bujcCB0aMOhbmcgMTEvMjAyNiB0aGVvIGNoaSBuaMOhbmggKGThu68gbGnhu4d1IG3huqt1IGPhu6dhIGLDoW8gY8OhbyBjaHV5w6puIHPDonUpXG5jb25zdCBSRVBPUlQ6IFJlY29yZDxzdHJpbmcsIHsgb3JkZXJzOiBudW1iZXI7IGRvbmU6IG51bWJlcjsgY2FuY2VsOiBudW1iZXI7IG9jYzogbnVtYmVyOyBmcm9tRG9uZTogbnVtYmVyOyBmcm9tQ2FuY2VsOiBudW1iZXI7IHRvdGFsOiBudW1iZXIgfT4gPSB7XG4gIGNzMTogeyBvcmRlcnM6IDMxMCwgZG9uZTogMjc0LCBjYW5jZWw6IDIyLCBvY2M6IDg0LCBmcm9tRG9uZTogOTg1MDAwMDAsIGZyb21DYW5jZWw6IDU0MDAwMDAsIHRvdGFsOiAxMTEyMDAwMDAgfSxcbiAgY3MyOiB7IG9yZGVyczogMjY1LCBkb25lOiAyMzAsIGNhbmNlbDogMjEsIG9jYzogNzksIGZyb21Eb25lOiA3NjIwMDAwMCwgZnJvbUNhbmNlbDogNDMwMDAwMCwgdG90YWw6IDg2NDAwMDAwIH0sXG4gIGNzMzogeyBvcmRlcnM6IDE2NSwgZG9uZTogMTM4LCBjYW5jZWw6IDE1LCBvY2M6IDc1LCBmcm9tRG9uZTogNDQ3MDAwMDAsIGZyb21DYW5jZWw6IDI3MDAwMDAsIHRvdGFsOiA1MTAwMDAwMCB9LFxufVxuY29uc3QgTU9OVEggPSB7IGZyb206ICcyMDI2LTExLTAxJywgdG86ICcyMDI2LTExLTMwJyB9XG5jb25zdCBGUkFNRVM6IFtzdHJpbmcsIG51bWJlciwgbnVtYmVyXVtdID0gW1snQ+G6oyBuZ8OgeSAoMDU6MDAgLSAyMzowMCknLCAwLCAyNF0sIFsnMDY6MDAgLSAxMTowMCcsIDYsIDExXSwgWycxMTowMCAtIDE1OjAwJywgMTEsIDE1XSwgWycxNTowMCAtIDIyOjAwJywgMTUsIDIyXV1cbmNvbnN0IExFVkVMUyA9IFtbJzV8MCcsICdHaeG6o20gNSUnXSwgWycxMHwwJywgJ0dp4bqjbSAxMCUnXSwgWycxNXwwJywgJ0dp4bqjbSAxNSUnXSwgWycyMHwxMDAwMDAnLCAnR2nhuqNtIDIwJSAoVOG7kWkgxJFhIDEwMGspJ10sIFsnMjV8MTUwMDAwJywgJ0dp4bqjbSAyNSUgKFThu5FpIMSRYSAxNTBrKSddLCBbJzMwfDIwMDAwMCcsICdHaeG6o20gMzAlIChU4buRaSDEkWEgMjAwayknXV1cbmNvbnN0IGVtcHR5ID0geyBuYW1lOiAnJywgY29kZTogJycsIGxldmVsOiAnMTB8MCcsIGJyYW5jaElkOiAnYWxsJywgZnJhbWU6IDAsIHN0YXJ0OiAnMjAyNi0xMS0wMScsIGVuZDogJzIwMjYtMTEtMzAnLCBsaW1pdDogMTAwLCBub3RpZnk6IHRydWUgfVxuXG5jb25zdCBvdmVybGFwID0gKGE6IHN0cmluZywgYjogc3RyaW5nKSA9PiB7XG4gIGNvbnN0IHMgPSBuZXcgRGF0ZShNYXRoLm1heCgrbmV3IERhdGUoYSksICtuZXcgRGF0ZShNT05USC5mcm9tKSkpLCBlID0gbmV3IERhdGUoTWF0aC5taW4oK25ldyBEYXRlKGIpLCArbmV3IERhdGUoTU9OVEgudG8pKSlcbiAgcmV0dXJuIE1hdGgubWF4KDAsIE1hdGgucm91bmQoKCtlIC0gK3MpIC8gODY0MDAwMDApICsgMSkgLyAzMFxufVxuY29uc3QgdHIgPSAobjogbnVtYmVyKSA9PiBgJHsobiAvIDFlNikudG9GaXhlZCgyKS5yZXBsYWNlKCcuJywgJywnKS5yZXBsYWNlKC8sPzArJC8sICcnKX1UcmBcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gT3duZXJSZXBvcnRzKCkge1xuICBjb25zdCB7IGJyYW5jaGVzLCBwcm9tb3MsIHNldFByb21vcywgdG9hc3QgfSA9IHVzZUFwcCgpXG4gIGNvbnN0IHsgYnJhbmNoRmlsdGVyIH0gPSB1c2VPdXRsZXRDb250ZXh0PFN0YWZmT3V0bGV0PigpXG4gIGNvbnN0IFtmcm9tLCBzZXRGcm9tXSA9IHVzZVN0YXRlKE1PTlRILmZyb20pXG4gIGNvbnN0IFt0bywgc2V0VG9dID0gdXNlU3RhdGUoTU9OVEgudG8pXG4gIGNvbnN0IFthcHBsaWVkLCBzZXRBcHBsaWVkXSA9IHVzZVN0YXRlKHsgZnJvbTogTU9OVEguZnJvbSwgdG86IE1PTlRILnRvIH0pXG4gIGNvbnN0IFtlZGl0Q29kZSwgc2V0RWRpdENvZGVdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbClcbiAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUoZW1wdHkpXG4gIGNvbnN0IFtlcnIsIHNldEVycl0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCBmYWN0b3IgPSBvdmVybGFwKGFwcGxpZWQuZnJvbSwgYXBwbGllZC50bylcbiAgY29uc3Qgc2VsID0gYnJhbmNoZXMuZmlsdGVyKChiKSA9PiBicmFuY2hGaWx0ZXIgPT09ICdhbGwnIHx8IGIuaWQgPT09IGJyYW5jaEZpbHRlcilcbiAgY29uc3Qgcm93cyA9IHNlbC5tYXAoKGIpID0+ICh7IGIsIHI6IFJFUE9SVFtiLmlkXSA/PyB7IG9yZGVyczogMCwgZG9uZTogMCwgY2FuY2VsOiAwLCBvY2M6IDAsIGZyb21Eb25lOiAwLCBmcm9tQ2FuY2VsOiAwLCB0b3RhbDogMCB9IH0pKVxuICBjb25zdCBzYyA9IChuOiBudW1iZXIpID0+IE1hdGgucm91bmQobiAqIGZhY3RvcilcbiAgY29uc3Qgc3VtID0gKGs6IGtleW9mICh0eXBlb2YgUkVQT1JUKVsnY3MxJ10pID0+IHNjKHJvd3MucmVkdWNlKChzLCB4KSA9PiBzICsgeC5yW2tdLCAwKSlcbiAgY29uc3QgdG90YWwgPSBzdW0oJ3RvdGFsJyksIGRvbmUgPSBzdW0oJ2Zyb21Eb25lJyksIGNhbmNlbCA9IHN1bSgnZnJvbUNhbmNlbCcpLCB1cGNvbWluZyA9IHRvdGFsIC0gZG9uZSAtIGNhbmNlbFxuICBjb25zdCBvcmRlcnMgPSBzdW0oJ29yZGVycycpLCBvayA9IHN1bSgnZG9uZScpLCBiYWQgPSBzdW0oJ2NhbmNlbCcpLCBleHBpcmVkID0gTWF0aC5tYXgoMCwgb3JkZXJzIC0gb2sgLSBiYWQpXG4gIGNvbnN0IHBjdCA9IChuOiBudW1iZXIpID0+IChvcmRlcnMgPyBgJHsoKG4gLyBvcmRlcnMpICogMTAwKS50b0ZpeGVkKDEpLnJlcGxhY2UoJy4nLCAnLCcpfSVgIDogJzAlJylcbiAgY29uc3QgdXNlZCA9IHByb21vcy5maWx0ZXIoKHApID0+ICFwLmNvdW50ZXJPbmx5KS5yZWR1Y2UoKHMsIHApID0+IHMgKyBwLnVzZWQsIDApXG4gIGNvbnN0IHB1YiA9IHByb21vcy5maWx0ZXIoKHApID0+ICFwLmNvdW50ZXJPbmx5KVxuXG4gIGNvbnN0IGVkaXQgPSAocDogUHJvbW8pID0+IHtcbiAgICBzZXRFZGl0Q29kZShwLmNvZGUpOyBzZXRFcnIoJycpXG4gICAgc2V0Rm9ybSh7IG5hbWU6IHAubmFtZSwgY29kZTogcC5jb2RlLCBsZXZlbDogYCR7cC5wZXJjZW50fXwke3AubWF4T2ZmID8/IDB9YCwgYnJhbmNoSWQ6IHAuYnJhbmNoSWQgPz8gJ2FsbCcsIGZyYW1lOiBNYXRoLm1heCgwLCBGUkFNRVMuZmluZEluZGV4KChbLCBhLCBiXSkgPT4gYSA9PT0gcC5mcm9tSG91ciAmJiBiID09PSBwLnRvSG91cikpLCBzdGFydDogcC5zdGFydCwgZW5kOiBwLmVuZCwgbGltaXQ6IHAubGltaXQsIG5vdGlmeTogcC5ub3RpZmllZCB9KVxuICB9XG4gIGNvbnN0IHJlc2V0ID0gKCkgPT4geyBzZXRFZGl0Q29kZShudWxsKTsgc2V0Rm9ybShlbXB0eSk7IHNldEVycignJykgfVxuICBjb25zdCBzYXZlID0gKCkgPT4ge1xuICAgIGNvbnN0IGNvZGUgPSBmb3JtLmNvZGUudHJpbSgpLnRvVXBwZXJDYXNlKClcbiAgICBpZiAoIWZvcm0ubmFtZS50cmltKCkpIHJldHVybiBzZXRFcnIoJ1Z1aSBsw7JuZyBuaOG6rXAgdMOqbiBjaMawxqFuZyB0csOsbmggxrB1IMSRw6NpLicpXG4gICAgaWYgKCEvXltBLVowLTldezQsMTZ9JC8udGVzdChjb2RlKSkgcmV0dXJuIHNldEVycignTcOjIGdp4bqjbSBnacOhIGfhu5NtIDTigJMxNiBrw70gdOG7sSBjaOG7ryBob2EgaG/hurdjIHPhu5EsIGtow7RuZyBk4bqldS4nKVxuICAgIGlmICghZWRpdENvZGUgJiYgcHJvbW9zLnNvbWUoKHApID0+IHAuY29kZSA9PT0gY29kZSkpIHJldHVybiBzZXRFcnIoJ03DoyBnaeG6o20gZ2nDoSBuw6B5IMSRw6MgdOG7k24gdOG6oWkuJylcbiAgICBpZiAoIWZvcm0uc3RhcnQgfHwgIWZvcm0uZW5kIHx8IGZvcm0uZW5kIDwgZm9ybS5zdGFydCkgcmV0dXJuIHNldEVycignS2hv4bqjbmcgbmfDoHkgw6FwIGThu6VuZyBraMO0bmcgaOG7o3AgbOG7hy4nKVxuICAgIGlmICghKGZvcm0ubGltaXQgPiAwKSkgcmV0dXJuIHNldEVycignU+G7kSBsxrDhu6N0IGTDuW5nIHBo4bqjaSBs4bubbiBoxqFuIDAuJylcbiAgICBjb25zdCBbcGMsIG14XSA9IGZvcm0ubGV2ZWwuc3BsaXQoJ3wnKS5tYXAoTnVtYmVyKVxuICAgIGNvbnN0IFssIGZoLCB0aF0gPSBGUkFNRVNbZm9ybS5mcmFtZV1cbiAgICBjb25zdCBiciA9IGJyYW5jaGVzLmZpbmQoKGIpID0+IGIuaWQgPT09IGZvcm0uYnJhbmNoSWQpXG4gICAgY29uc3QgYmFzZTogT21pdDxQcm9tbywgJ3VzZWQnPiA9IHtcbiAgICAgIGNvZGUsIG5hbWU6IGZvcm0ubmFtZS50cmltKCksIHBlcmNlbnQ6IHBjLCBtYXhPZmY6IG14IHx8IG51bGwsIGZyb21Ib3VyOiBmaCwgdG9Ib3VyOiB0aCwgc2NvcGU6IGJyID8gYnIubmFtZSA6ICdU4bqldCBj4bqjIGPGoSBz4bufJyxcbiAgICAgIHN0YXJ0OiBmb3JtLnN0YXJ0LCBlbmQ6IGZvcm0uZW5kLCBsaW1pdDogZm9ybS5saW1pdCwgYWN0aXZlOiB0cnVlLCBub3RpZmllZDogZm9ybS5ub3RpZnksIGJyYW5jaElkOiBicj8uaWQsXG4gICAgICB0YWc6ICfGr3UgxJHDo2kgbeG7m2knLCB0b25lOiAnZ3JlZW4nLFxuICAgIH1cbiAgICBpZiAoZWRpdENvZGUpIHNldFByb21vcygocHMpID0+IHBzLm1hcCgocCkgPT4gKHAuY29kZSA9PT0gZWRpdENvZGUgPyB7IC4uLnAsIC4uLmJhc2UsIGFjdGl2ZTogcC5hY3RpdmUsIHRhZzogcC50YWcsIHRvbmU6IHAudG9uZSB9IDogcCkpKVxuICAgIGVsc2Ugc2V0UHJvbW9zKChwcykgPT4gW3sgLi4uYmFzZSwgdXNlZDogMCB9LCAuLi5wc10pXG4gICAgdG9hc3QoYCR7ZWRpdENvZGUgPyAnxJDDoyBj4bqtcCBuaOG6rXQnIDogJ8SQw6MgcGjDoXQgaMOgbmgnfSBtw6MgJHtjb2RlfSR7Zm9ybS5ub3RpZnkgPyAnIHbDoCBn4butaSB0aMO0bmcgYsOhbyBjaG8gdG/DoG4gYuG7mSBraMOhY2ggaMOgbmcnIDogJyd9LmAsICdvaycpXG4gICAgcmVzZXQoKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY2FyZCByb3cgYmV0d2VlbiB3cmFwIGcxNlwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2IH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTIgd3JhcFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NzAwIGMtczcwMFwiPkvhu7MgYsOhbyBjw6FvOjwvc3Bhbj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cImRhdGVcIiBjbGFzc05hbWU9XCJpbnB1dCBzbVwiIHN0eWxlPXt7IHdpZHRoOiAnYXV0bycgfX0gdmFsdWU9e2Zyb219IG9uQ2hhbmdlPXsoZSkgPT4gc2V0RnJvbShlLnRhcmdldC52YWx1ZSl9IC8+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDEyIHc2MDAgYy1zNjAwXCI+xJHhur9uPC9zcGFuPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZGF0ZVwiIGNsYXNzTmFtZT1cImlucHV0IHNtXCIgc3R5bGU9e3sgd2lkdGg6ICdhdXRvJyB9fSB2YWx1ZT17dG99IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VG8oZS50YXJnZXQudmFsdWUpfSAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNoaXAtYm94XCIgc3R5bGU9e3sgYm9yZGVyUmFkaXVzOiA4LCBiYWNrZ3JvdW5kOiAndmFyKC0tczUwKScgfX0+e2JyYW5jaEZpbHRlciA9PT0gJ2FsbCcgPyBgVOG6pXQgY+G6oyBjaGkgbmjDoW5oICgke2JyYW5jaGVzLmxlbmd0aH0gY8ahIHPhu58pYCA6IGJyYW5jaGVzLmZpbmQoKGIpID0+IGIuaWQgPT09IGJyYW5jaEZpbHRlcik/Lm5hbWV9PC9zcGFuPlxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1tZFwiIHN0eWxlPXt7IHBhZGRpbmc6ICc4cHggMTZweCcgfX0gb25DbGljaz17KCkgPT4geyBpZiAodG8gPCBmcm9tKSByZXR1cm4gdG9hc3QoJ05nw6B5IGvhur90IHRow7pjIHBo4bqjaSBzYXUgbmfDoHkgYuG6r3QgxJHhuqd1LicsICdlcnInKTsgc2V0QXBwbGllZCh7IGZyb20sIHRvIH0pOyB0b2FzdCgnxJDDoyBj4bqtcCBuaOG6rXQgYsOhbyBjw6FvIHRoZW8gYuG7mSBs4buNYy4nKSB9fT5M4buNYyBk4buvIGxp4buHdTwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDEyIGMtczYwMFwiPkThu68gbGnhu4d1IGPhuq1wIG5o4bqtdCB0aGVvIHRo4budaSBnaWFuIHRo4buxYzwvc3Bhbj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzE2XCIgc3R5bGU9e3sgYWxpZ25JdGVtczogJ3N0cmV0Y2gnIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8gY29sIGc4XCIgc3R5bGU9e3sgcGFkZGluZzogMjAsIGJvcmRlclJhZGl1czogMTYsIGZsZXg6IDEuMTUgfX0+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDEyIHc3MDBcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWJyYW5kLTEwMCknIH19PlThu5VuZyBkb2FuaCB0aHUgdGjhu7FjIHRodSAoe2FwcGxpZWQuZnJvbSA9PT0gTU9OVEguZnJvbSAmJiBhcHBsaWVkLnRvID09PSBNT05USC50byA/ICdUaMOhbmcgMTEnIDogYCR7dG9WTihhcHBsaWVkLmZyb20pfSDigJMgJHt0b1ZOKGFwcGxpZWQudG8pfWB9KTwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInQyNCB3ODAwXCIgc3R5bGU9e3sgZm9udFNpemU6IDI4LCBsaW5lSGVpZ2h0OiAnMzZweCcgfX0+e2ZtdCh0b3RhbCl9IFZOxJA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0MTJcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWJyYW5kLTEwMCknIH19PkNodXnhu4NuIGtob+G6o24gUVI6IHt0cih0b3RhbCAqIDAuNzQxKX0g4oCiIFRp4buBbiBt4bq3dDoge3RyKHRvdGFsICogMC4yNTkpfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBjb2wgZzggZjFcIiBzdHlsZT17eyBib3JkZXJSYWRpdXM6IDE2IH19PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NzAwIGMtczYwMFwiPkNoaSB0aeG6v3Qgbmd14buTbiBkb2FuaCB0aHU8L3NwYW4+XG4gICAgICAgICAgPFJvdyBrPVwi4oCiIMSQxqFuIMSRw6MgaG/DoG4gdGjDoG5oOlwiIHY9e21vbmV5KGRvbmUpfSBjPVwiYy1pbmtcIiAvPjxSb3cgaz1cIuKAoiBUaeG7gW4gY+G7jWMgbOG7i2NoIHPhuq9wIGNoxqFpOlwiIHY9e21vbmV5KHVwY29taW5nKX0gYz1cImMtYnJhbmRcIiAvPjxSb3cgaz1cIuKAoiBUaeG7gW4gY+G7jWMgxJHGoW4gaOG7p3kgZ2nhu68gbOG6oWk6XCIgdj17bW9uZXkoY2FuY2VsKX0gYz1cImMtYW1iZXJcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGNvbCBnOCBmMVwiIHN0eWxlPXt7IGJvcmRlclJhZGl1czogMTYgfX0+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDEyIHc3MDAgYy1zNjAwXCI+VOG7tyBs4buHIGzGsOG7o3QgxJHhurd0IHPDom4gKHtmbXQob3JkZXJzKX0gxJHGoW4pPC9zcGFuPlxuICAgICAgICAgIDxSb3cgaz1cIuKAoiDEkOG6t3QgdGjDoG5oIGPDtG5nOlwiIHY9e2Ake2ZtdChvayl9IMSRxqFuICgke3BjdChvayl9KWB9IGM9XCJjLWJyYW5kOFwiIC8+PFJvdyBrPVwi4oCiIEtow6FjaCBo4buneSAvIFF1w6EgZ2nhu506XCIgdj17YCR7Zm10KGJhZCl9IMSRxqFuICgke3BjdChiYWQpfSlgfSBjPVwiYy1yb3NlXCIgLz48Um93IGs9XCLigKIgSOG6v3QgaOG6oW4gZ2nhu68gY2jhu5c6XCIgdj17YCR7Zm10KGV4cGlyZWQpfSDEkcahbiAoJHtwY3QoZXhwaXJlZCl9KWB9IGM9XCJjLWFtYmVyXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBjb2wgZzggZjFcIiBzdHlsZT17eyBib3JkZXJSYWRpdXM6IDE2IH19PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NzAwIGMtczYwMFwiPkhp4buHdSBxdeG6oyBjaMawxqFuZyB0csOsbmggxrB1IMSRw6NpPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidDI0IHc4MDAgYy1pbmtcIiBzdHlsZT17eyBmb250U2l6ZTogMjIgfX0+e3VzZWR9IMSRxqFuIGTDuW5nIG3DozwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidDExIGMtczYwMFwiPlThu5VuZyBnaeG6o206IDxiIGNsYXNzTmFtZT1cImMtcm9zZVwiPnt0cih1c2VkICogNzY2MTMpfTwvYj4g4oCiIERvYW5oIHRodTogPGIgY2xhc3NOYW1lPVwiYy1icmFuZFwiPnt0cih1c2VkICogMzY3NzAwKX08L2I+PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNhcmQgY2FyZC1sZyBjb2wgZzE2XCIgc3R5bGU9e3sgcGFkZGluZzogMjAgfX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW5cIj48aDIgY2xhc3NOYW1lPVwidDE0IHc4MDAgYy1pbmtcIj5C4bqjbmcgdOG7lW5nIGjhu6NwIGRvYW5oIHRodSAmIHThu7cgbOG7hyBs4bqlcCDEkeG6p3kgdGhlbyB04burbmcgY2hpIG5ow6FuaDwvaDI+PHNwYW4gY2xhc3NOYW1lPVwidDEyIGMtczYwMFwiPkvhu7M6IHt0b1ZOKGFwcGxpZWQuZnJvbSl9IOKAkyB7dG9WTihhcHBsaWVkLnRvKX08L3NwYW4+PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGJsLXdyYXBcIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidGJsXCI+XG4gICAgICAgICAgICA8dGhlYWQ+PHRyPjx0aD5DaGkgbmjDoW5oPC90aD57WydU4buVbmcgc+G7kSDEkcahbicsICdIb8OgbiB0aMOgbmgnLCAnxJDGoW4gaOG7p3kgKEdp4buvIGPhu41jKScsICdDw7RuZyBzdeG6pXQgc8OibicsICdUaHUgdOG7qyDEkcahbiBob8OgbiB0aMOgbmgnLCAnVGh1IHThu6sgxJHGoW4gaOG7p3knLCAnVOG7lW5nIHRo4buxYyB0aHUnXS5tYXAoKGgpID0+IDx0aCBrZXk9e2h9IGNsYXNzTmFtZT1cInJcIj57aH08L3RoPil9PC90cj48L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICB7cm93cy5tYXAoKHsgYiwgciB9KSA9PiAoXG4gICAgICAgICAgICAgICAgPHRyIGtleT17Yi5pZH0+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwidzcwMCBjLWlua1wiIHN0eWxlPXt7IGZvbnRTaXplOiAxMiB9fT57Yi5uYW1lfSAoey8qIHPhu5Egc8OibiAqL317UkVQT1JUW2IuaWRdID8geyBjczE6IDgsIGNzMjogMTAsIGNzMzogNiB9W2IuaWRdIDogMH0gc8Oibik8L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInIgdzcwMFwiPntmbXQoc2Moci5vcmRlcnMpKX08L3RkPjx0ZCBjbGFzc05hbWU9XCJyIHc3MDAgYy1icmFuZDhcIj57Zm10KHNjKHIuZG9uZSkpfTwvdGQ+PHRkIGNsYXNzTmFtZT1cInIgdzcwMCBjLXJvc2VcIj57Zm10KHNjKHIuY2FuY2VsKSl9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJyIHc4MDAgYy1icmFuZDhcIj57ZmFjdG9yID8gYCR7ci5vY2N9JWAgOiAn4oCUJ308L3RkPjx0ZCBjbGFzc05hbWU9XCJyIHc3MDBcIj57bW9uZXkoc2Moci5mcm9tRG9uZSkpfTwvdGQ+PHRkIGNsYXNzTmFtZT1cInIgdzcwMFwiPnttb25leShzYyhyLmZyb21DYW5jZWwpKX08L3RkPjx0ZCBjbGFzc05hbWU9XCJyIHc4MDAgYy1pbmtcIj57bW9uZXkoc2Moci50b3RhbCkpfTwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQxMlwiPlxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFuNyBjYXJkIGNhcmQtbGcgY29sIGcxNlwiIHN0eWxlPXt7IHBhZGRpbmc6IDIwIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGcyXCI+PGgyIGNsYXNzTmFtZT1cInQxNiB3ODAwIGMtaW5rXCIgc3R5bGU9e3sgbGluZUhlaWdodDogJzI0cHgnIH19PkNoxrDGoW5nIHRyw6xuaCBraHV54bq/biBtw6NpICYgTcOjIGdp4bqjbSBnacOhIMSRYW5nIG3hu588L2gyPjxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj5UaHUgaMO6dCBraMOhY2ggxJHhurd0IGzhu4tjaCB2w6BvIGtodW5nIGdp4budIHRo4bqlcCDEkWnhu4NtIHbDoCB0cmkgw6JuIGjhu5lpIHZpw6puIHRow6JuIHRoaeG6v3Q8L3A+PC9kaXY+XG4gICAgICAgICAge3B1Yi5tYXAoKHApID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtwLmNvZGV9IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuIGcxMlwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IHAuYWN0aXZlID8gJ3ZhcigtLXM1MCknIDogJ3ZhcigtLXMxMDApJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLXMzMDApJywgYm9yZGVyUmFkaXVzOiAxMiwgcGFkZGluZzogMTYsIG9wYWNpdHk6IHAuYWN0aXZlID8gMSA6IDAuOCB9fT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzYgZjFcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnOCB3cmFwXCI+PHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2Ugc3EgYy13aGl0ZSBtb25vXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogcC50b25lID09PSAnc2t5JyA/ICcjMDM2OWExJyA6ICd2YXIoLS1icmFuZC04MDApJywgZm9udFNpemU6IDExIH19PntwLmNvZGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGIgY2xhc3NOYW1lPVwidDE0IGMtaW5rXCI+e3AubmFtZX08L2I+PHNwYW4gY2xhc3NOYW1lPXtgYmFkZ2UgJHtwLmFjdGl2ZSA/ICdiLWdyZWVuLWZsYXQnIDogJ2ItZ3JheSd9YH0gc3R5bGU9e3sgcGFkZGluZzogJzJweCAxMHB4JywgZm9udFNpemU6IDEwLCBmb250V2VpZ2h0OiA3MDAgfX0+e3AuYWN0aXZlID8gJ8SQYW5nIGNo4bqheScgOiAnVOG6oW0gZOG7q25nJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidDExIGMtczcwMFwiPkdp4bqjbTogPGIgY2xhc3NOYW1lPVwiYy1icmFuZDhcIj57cC5wZXJjZW50fSV7cC5tYXhPZmYgPyBgIChU4buRaSDEkWEgJHttb25leShwLm1heE9mZil9KWAgOiAnJ308L2I+IOKAoiB7cC5zY29wZX17cC5mcm9tSG91ciA+IDAgPyBgIHwgS2h1bmcgJHtTdHJpbmcocC5mcm9tSG91cikucGFkU3RhcnQoMiwgJzAnKX06MDAgLSAke1N0cmluZyhwLnRvSG91cikucGFkU3RhcnQoMiwgJzAnKX06MDBgIDogJyAmIE3hu41pIGtodW5nIGdp4budJ30g4oCiIHt0b1ZOKHAuc3RhcnQpfSAtIHt0b1ZOKHAuZW5kKX08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidDExIGMtczcwMFwiPkzGsOG7o3Qgc+G7rSBk4bulbmc6IDxiPntwLnVzZWR9IC8ge3AubGltaXR9IGzGsOG7o3Q8L2I+e3Aubm90aWZpZWQgPyAnIOKAoiDEkMOjIGfhu61pIHRow7RuZyBiw6FvIGNobyBo4buZaSB2acOqbicgOiAnJ308L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnOFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1zbVwiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tczgwMCknIH19IG9uQ2xpY2s9eygpID0+IGVkaXQocCl9PkNo4buJbmggc+G7rWE8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17YGJ0biBidG4tc20gJHtwLmFjdGl2ZSA/ICdidG4td2Fybi1vJyA6ICdidG4tZ3JlZW4tbyd9YH0gb25DbGljaz17KCkgPT4geyBzZXRQcm9tb3MoKHBzKSA9PiBwcy5tYXAoKHgpID0+ICh4LmNvZGUgPT09IHAuY29kZSA/IHsgLi4ueCwgYWN0aXZlOiAheC5hY3RpdmUgfSA6IHgpKSk7IHRvYXN0KHAuYWN0aXZlID8gYMSQw6MgdOG6oW0gZOG7q25nIG3DoyAke3AuY29kZX0uYCA6IGBNw6MgJHtwLmNvZGV9IMSRw6MgY2jhuqF5IGzhuqFpLmApIH19PntwLmFjdGl2ZSA/ICdU4bqhbSBk4burbmcnIDogJ0No4bqheSBs4bqhaSd9PC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwic3BhbjUgY2FyZCBjYXJkLWxnIGNhcmQtcmFpc2UgY29sIGcxNlwiIHN0eWxlPXt7IHBhZGRpbmc6IDIwIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGhlYWQtcnVsZVwiIHN0eWxlPXt7IGdhcDogMiwgcGFkZGluZ1RvcDogNSB9fT48c3BhbiBjbGFzc05hbWU9XCJleWVicm93XCI+e2VkaXRDb2RlID8gYENo4buJbmggc+G7rWEgY2jGsMahbmcgdHLDrG5oICR7ZWRpdENvZGV9YCA6ICdU4bqhbyBjaMawxqFuZyB0csOsbmggbeG7m2knfTwvc3Bhbj48aDMgY2xhc3NOYW1lPVwidDE2IHc4MDAgYy1pbmtcIiBzdHlsZT17eyBsaW5lSGVpZ2h0OiAnMjRweCcgfX0+UGjDoXQgaMOgbmggbcOjIGdp4bqjbSBnacOhICYgR+G7rWkgdGjDtG5nIGLDoW88L2gzPjwvZGl2PlxuICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImNvbCBnMTJcIiBvblN1Ym1pdD17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBzYXZlKCkgfX0+XG4gICAgICAgICAgICA8RiBsPVwiVMOqbiBjaMawxqFuZyB0csOsbmggxrB1IMSRw6NpICpcIj48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiB2YWx1ZT17Zm9ybS5uYW1lfSBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KX0gcGxhY2Vob2xkZXI9XCJWRDogxq91IMSRw6NpIGtodW5nIGdp4budIHbDoG5nIGJ14buVaSBzw6FuZ1wiIC8+PC9GPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzEyXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjFcIj48RiBsPVwiTcOjIGdp4bqjbSBnacOhICpcIj48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWJyYW5kLTcwMCknLCBmb250V2VpZ2h0OiA4MDAgfX0gdmFsdWU9e2Zvcm0uY29kZX0gZGlzYWJsZWQ9eyEhZWRpdENvZGV9IHBsYWNlaG9sZGVyPVwiU0FOR1ZVSTIwXCIgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgY29kZTogZS50YXJnZXQudmFsdWUudG9VcHBlckNhc2UoKSB9KX0gLz48L0Y+PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjFcIj48RiBsPVwiTeG7qWMgZ2nhuqNtIGdpw6EgKlwiPjxzZWxlY3QgY2xhc3NOYW1lPVwic2VsZWN0IHNtXCIgdmFsdWU9e2Zvcm0ubGV2ZWx9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGxldmVsOiBlLnRhcmdldC52YWx1ZSB9KX0+e0xFVkVMUy5tYXAoKFt2LCBsXSkgPT4gPG9wdGlvbiBrZXk9e3Z9IHZhbHVlPXt2fT57bH08L29wdGlvbj4pfTwvc2VsZWN0PjwvRj48L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzEyXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjFcIj48RiBsPVwiQ2hpIG5ow6FuaCDDoXAgZOG7pW5nICpcIj48c2VsZWN0IGNsYXNzTmFtZT1cInNlbGVjdCBzbVwiIHZhbHVlPXtmb3JtLmJyYW5jaElkfSBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBicmFuY2hJZDogZS50YXJnZXQudmFsdWUgfSl9PjxvcHRpb24gdmFsdWU9XCJhbGxcIj5U4bqldCBj4bqjIGNoaSBuaMOhbmg8L29wdGlvbj57YnJhbmNoZXMubWFwKChiKSA9PiA8b3B0aW9uIGtleT17Yi5pZH0gdmFsdWU9e2IuaWR9PntiLm5hbWV9PC9vcHRpb24+KX08L3NlbGVjdD48L0Y+PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjFcIj48RiBsPVwiS2h1bmcgZ2nhu50gw6FwIGThu6VuZyAqXCI+PHNlbGVjdCBjbGFzc05hbWU9XCJzZWxlY3Qgc21cIiB2YWx1ZT17Zm9ybS5mcmFtZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgZnJhbWU6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSl9PntGUkFNRVMubWFwKChbbF0sIGkpID0+IDxvcHRpb24ga2V5PXtsfSB2YWx1ZT17aX0+e2x9PC9vcHRpb24+KX08L3NlbGVjdD48L0Y+PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGcxMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImYxXCI+PEYgbD1cIlThu6sgbmfDoHkgKlwiPjxpbnB1dCBjbGFzc05hbWU9XCJpbnB1dCBzbVwiIHR5cGU9XCJkYXRlXCIgdmFsdWU9e2Zvcm0uc3RhcnR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHN0YXJ0OiBlLnRhcmdldC52YWx1ZSB9KX0gLz48L0Y+PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjFcIj48RiBsPVwixJDhur9uIG5nw6B5ICpcIj48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiB0eXBlPVwiZGF0ZVwiIHZhbHVlPXtmb3JtLmVuZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgZW5kOiBlLnRhcmdldC52YWx1ZSB9KX0gLz48L0Y+PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZjFcIj48RiBsPVwiU+G7kSBsxrDhu6N0IGTDuW5nICpcIj48aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXQgc21cIiB0eXBlPVwibnVtYmVyXCIgbWluPXsxfSB2YWx1ZT17Zm9ybS5saW1pdH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgbGltaXQ6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSl9IC8+PC9GPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicm93IGcxMCBoaW50IGhpbnQtZ3JlZW5cIiBzdHlsZT17eyBwYWRkaW5nOiAxMiwgY3Vyc29yOiAncG9pbnRlcicsIGJhY2tncm91bmQ6ICd2YXIoLS1icmFuZC01MCknIH19PlxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17Zm9ybS5ub3RpZnl9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIG5vdGlmeTogZS50YXJnZXQuY2hlY2tlZCB9KX0gc3R5bGU9e3sgYWNjZW50Q29sb3I6ICcjMDA3NWZmJywgd2lkdGg6IDE0LCBoZWlnaHQ6IDE0IH19IC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInc3MDAgYy1pbmtcIj5H4butaSB0aMO0bmcgYsOhbyBjaMawxqFuZyB0csOsbmggxrB1IMSRw6NpIG7DoHkgdOG7m2kgdG/DoG4gYuG7mSBraMOhY2ggaMOgbmc8L3NwYW4+XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAge2VyciAmJiA8cCBjbGFzc05hbWU9XCJmaWVsZC1lcnJcIj57ZXJyfTwvcD59XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnOFwiPjxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1tZCBmMVwiIHR5cGU9XCJzdWJtaXRcIj57ZWRpdENvZGUgPyAnTMawdSB0aGF5IMSR4buVaScgOiAnTMawdSAmIFBow6F0IGjDoG5oIMawdSDEkcOjaSd9PC9idXR0b24+e2VkaXRDb2RlICYmIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1tZFwiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtyZXNldH0+SOG7p3kgc+G7rWE8L2J1dHRvbj59PC9kaXY+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2FzaWRlPlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gIClcbn1cblxuZnVuY3Rpb24gUm93KHsgaywgdiwgYyB9OiB7IGs6IHN0cmluZzsgdjogc3RyaW5nOyBjOiBzdHJpbmcgfSkge1xuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJyb3cgYmV0d2VlbiBnOCB0MTFcIiBzdHlsZT17eyBmb250U2l6ZTogMTEuNSB9fT48YiBjbGFzc05hbWU9XCJjLWlua1wiIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDcwMCB9fT57a308L2I+PGIgY2xhc3NOYW1lPXtjfT57dn08L2I+PC9kaXY+XG59XG5mdW5jdGlvbiBGKHsgbCwgY2hpbGRyZW4gfTogeyBsOiBzdHJpbmc7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gPGRpdj48bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDQgfX0+e2x9PC9sYWJlbD57Y2hpbGRyZW59PC9kaXY+XG59XG4iXX0=