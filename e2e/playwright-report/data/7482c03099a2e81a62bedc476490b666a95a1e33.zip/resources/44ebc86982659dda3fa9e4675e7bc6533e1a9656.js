import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/store.tsx");const createContext = __vite__cjsImport0_react["createContext"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { BRANCHES, HOLIDAYS_SEED, LOCKS_SEED, PROMOS_SEED, STAFF_SEED, bookingsSeed, buildCourts, mins } from "/src/data.ts";
var _jsxFileName = "D:/Jobs/Sports/app/src/store.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
const AppCtx = createContext(null);
_c = AppCtx;
export const useApp = () => {
	_s();
	const c = useContext(AppCtx);
	if (!c) throw new Error("useApp must be used inside AppProvider");
	return c;
};
_s(useApp, "rCFJOMMDYLWM7qBzTJAGkiO6eRA=");
export function useNow(interval = 1e3) {
	_s2();
	const [now, setNow] = useState(Date.now());
	useEffect(() => {
		const t = setInterval(() => setNow(Date.now()), interval);
		return () => clearInterval(t);
	}, [interval]);
	return now;
}
_s2(useNow, "D8W74ghnyINHT2ur4C+vDITMVe4=");
const OWNER_PHONE = "0900000001";
const OWNER_PASS = "Chu123456";
export function AppProvider({ children }) {
	_s3();
	const [user, setUser] = useState(() => {
		try {
			return JSON.parse(localStorage.getItem("sporthub.user") || "null");
		} catch {
			return null;
		}
	});
	const [bookings, setBookings] = useState(bookingsSeed);
	const [courts, setCourts] = useState(buildCourts);
	const [staff, setStaff] = useState(STAFF_SEED);
	const [promos, setPromos] = useState(PROMOS_SEED);
	const [locks, setLocks] = useState(LOCKS_SEED);
	const [holidays, setHolidays] = useState(HOLIDAYS_SEED);
	const [branches, setBranches] = useState(BRANCHES);
	const [receipt, setReceipt] = useState({
		code: "PT2026111209",
		order: "#BK2026111015",
		amount: 255e3,
		method: "Tiền mặt",
		cashier: "Lê Văn Hùng"
	});
	const [toasts, setToasts] = useState([]);
	const seq = useRef(1030);
	const tid = useRef(1);
	useEffect(() => {
		if (user) localStorage.setItem("sporthub.user", JSON.stringify(user));
		else localStorage.removeItem("sporthub.user");
	}, [user]);
	const toast = useCallback((msg, kind = "info") => {
		const id = tid.current++;
		setToasts((t) => [...t, {
			id,
			msg,
			kind
		}]);
		setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800);
	}, []);
	// Tự hủy đơn khi hết thời gian giữ chỗ
	useEffect(() => {
		const t = setInterval(() => {
			const now = Date.now();
			setBookings((bs) => {
				if (!bs.some((b) => b.status === "pending" && b.holdUntil && b.holdUntil < now)) return bs;
				return bs.map((b) => b.status === "pending" && b.holdUntil && b.holdUntil < now ? {
					...b,
					status: "cancelled",
					cancelReason: "Hết hạn giữ chỗ",
					holdUntil: undefined
				} : b);
			});
		}, 1500);
		return () => clearInterval(t);
	}, []);
	const login = (identity, password, role) => {
		const id = identity.trim();
		if (!id) return {
			ok: false,
			error: "Vui lòng nhập số điện thoại hoặc email."
		};
		if (password.length < 6) return {
			ok: false,
			error: "Mật khẩu phải có tối thiểu 6 ký tự."
		};
		if (role === "staff") {
			const s = staff.find((x) => x.phone === id || x.email === id);
			if (!s) return {
				ok: false,
				error: "Không tìm thấy tài khoản nhân viên với thông tin này."
			};
			if (s.locked) return {
				ok: false,
				error: "Tài khoản nhân viên đã bị khóa, vui lòng liên hệ chủ hệ thống."
			};
			if (s.password !== password) return {
				ok: false,
				error: "Mật khẩu không chính xác."
			};
			setUser({
				role,
				name: s.name,
				phone: s.phone,
				staffId: s.id,
				branchId: s.branchId,
				title: "Nhân viên thu ngân"
			});
			return { ok: true };
		}
		if (role === "owner") {
			if (id !== OWNER_PHONE && id !== "chu@sporthub.vn") return {
				ok: false,
				error: "Không tìm thấy tài khoản chủ hệ thống."
			};
			if (password !== OWNER_PASS) return {
				ok: false,
				error: "Mật khẩu không chính xác."
			};
			setUser({
				role,
				name: "Đặng Quốc Bảo",
				phone: OWNER_PHONE,
				title: "Chủ hệ thống sân"
			});
			return { ok: true };
		}
		setUser({
			role,
			name: "Nguyễn Văn An",
			phone: "0987654321",
			title: "Hội viên thân thiết"
		});
		return { ok: true };
	};
	const register = (v) => setUser({
		role: "customer",
		name: v.name,
		phone: v.phone,
		title: "Hội viên mới"
	});
	const logout = () => setUser(null);
	const addBooking = (b) => {
		const ym = b.date.slice(0, 7).replace("-", "");
		const nb = {
			...b,
			id: `BK${ym}${seq.current++}`
		};
		setBookings((bs) => [nb, ...bs]);
		return nb;
	};
	const patchBooking = (id, p) => setBookings((bs) => bs.map((b) => b.id === id ? {
		...b,
		...p
	} : b));
	const cancelBooking = (id, reason, keepDeposit) => setBookings((bs) => bs.map((b) => b.id === id ? {
		...b,
		status: "cancelled",
		cancelReason: reason,
		holdUntil: undefined,
		keptDeposit: keepDeposit ? b.paid : 0,
		cancelledAt: new Date().toLocaleString("vi-VN", {
			hour: "2-digit",
			minute: "2-digit",
			day: "2-digit",
			month: "2-digit",
			year: "numeric"
		}).replace(",", " ngày")
	} : b));
	const confirmPayment = (id) => setBookings((bs) => bs.map((b) => b.id === id ? {
		...b,
		status: "confirmed",
		holdUntil: undefined,
		paid: b.payMode === "full" ? b.total : Math.round(b.total * .3)
	} : b));
	const blocker = (courtId, date, start, end) => bookings.find((b) => b.courtId === courtId && b.date === date && b.status !== "cancelled" && b.status !== "completed" && mins(b.start) < mins(end) && mins(b.end) > mins(start));
	const lockAt = (courtId, date, start, end) => {
		const s = `${date}T${start}`, e = `${date}T${end === "24:00" ? "23:59" : end}`;
		return locks.find((l) => l.courtId === courtId && l.from < e && l.to > s);
	};
	const value = useMemo(() => ({
		user,
		login,
		register,
		logout,
		bookings,
		addBooking,
		patchBooking,
		cancelBooking,
		confirmPayment,
		blocker,
		courts,
		setCourts,
		staff,
		setStaff,
		promos,
		setPromos,
		locks,
		setLocks,
		lockAt,
		holidays,
		setHolidays,
		branches,
		setBranches,
		receipt,
		setReceipt,
		toast
	}), [
		user,
		bookings,
		courts,
		staff,
		promos,
		locks,
		holidays,
		branches,
		receipt,
		toast
	]);
	return /* @__PURE__ */ _jsxDEV(AppCtx.Provider, {
		value,
		children: [children, /* @__PURE__ */ _jsxDEV("div", {
			className: "toast-host",
			children: toasts.map((t) => /* @__PURE__ */ _jsxDEV("div", {
				className: `toast ${t.kind}`,
				children: t.msg
			}, t.id, false, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 28
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 159,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 157,
		columnNumber: 5
	}, this);
}
_s3(AppProvider, "gmIdknO+GviNSjWdAcO0Ap3u3mo=");
_c2 = AppProvider;
var _c, _c2;
$RefreshReg$(_c, "AppCtx");
$RefreshReg$(_c2, "AppProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/store.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/store.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/store.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/store.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlLGFBQWEsWUFBWSxXQUFXLFNBQVMsUUFBUSxnQkFBZ0I7QUFFN0YsU0FDRSxVQUFVLGVBQWUsWUFBWSxhQUFhLFlBQVksY0FBYyxhQUFhLFlBQ3BGOzs7O0FBb0NQLE1BQU0sU0FBUyxjQUEwQixJQUFJOztBQUM3QyxPQUFPLE1BQU0sZUFBZTs7Q0FDMUIsTUFBTSxJQUFJLFdBQVcsTUFBTTtDQUMzQixJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksTUFBTSx3Q0FBd0M7Q0FDaEUsT0FBTztBQUNUOztBQUVBLE9BQU8sU0FBUyxPQUFPLFdBQVcsS0FBTTs7Q0FDdEMsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFTLEtBQUssSUFBSSxDQUFDO0NBQ3pDLGdCQUFnQjtFQUNkLE1BQU0sSUFBSSxrQkFBa0IsT0FBTyxLQUFLLElBQUksQ0FBQyxHQUFHLFFBQVE7RUFDeEQsYUFBYSxjQUFjLENBQUM7Q0FDOUIsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUNiLE9BQU87QUFDVDs7QUFFQSxNQUFNLGNBQWM7QUFDcEIsTUFBTSxhQUFhO0FBRW5CLE9BQU8sU0FBUyxZQUFZLEVBQUUsWUFBcUM7O0NBQ2pFLE1BQU0sQ0FBQyxNQUFNLFdBQVcsZUFBZ0M7RUFDdEQsSUFBSTtHQUFFLE9BQU8sS0FBSyxNQUFNLGFBQWEsUUFBUSxlQUFlLEtBQUssTUFBTTtFQUFFLFFBQVE7R0FBRSxPQUFPO0VBQUs7Q0FDakcsQ0FBQztDQUNELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBb0IsWUFBWTtDQUNoRSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQWtCLFdBQVc7Q0FDekQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFrQixVQUFVO0NBQ3RELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBa0IsV0FBVztDQUN6RCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQWlCLFVBQVU7Q0FDckQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFvQixhQUFhO0NBQ2pFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBbUIsUUFBUTtDQUMzRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQXlCO0VBQUUsTUFBTTtFQUFnQixPQUFPO0VBQWlCLFFBQVE7RUFBUSxRQUFRO0VBQVksU0FBUztDQUFjLENBQUM7Q0FDbkssTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFrQixDQUFDLENBQUM7Q0FDaEQsTUFBTSxNQUFNLE9BQU8sSUFBSTtDQUN2QixNQUFNLE1BQU0sT0FBTyxDQUFDO0NBRXBCLGdCQUFnQjtFQUNkLElBQUksTUFBTSxhQUFhLFFBQVEsaUJBQWlCLEtBQUssVUFBVSxJQUFJLENBQUM7T0FDL0QsYUFBYSxXQUFXLGVBQWU7Q0FDOUMsR0FBRyxDQUFDLElBQUksQ0FBQztDQUVULE1BQU0sUUFBUSxhQUFhLEtBQWEsT0FBc0IsV0FBVztFQUN2RSxNQUFNLEtBQUssSUFBSTtFQUNmLFdBQVcsTUFBTSxDQUFDLEdBQUcsR0FBRztHQUFFO0dBQUk7R0FBSztFQUFLLENBQUMsQ0FBQztFQUMxQyxpQkFBaUIsV0FBVyxNQUFNLEVBQUUsUUFBUSxNQUFNLEVBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxJQUFJO0NBQ3ZFLEdBQUcsQ0FBQyxDQUFDOztDQUdMLGdCQUFnQjtFQUNkLE1BQU0sSUFBSSxrQkFBa0I7R0FDMUIsTUFBTSxNQUFNLEtBQUssSUFBSTtHQUNyQixhQUFhLE9BQU87SUFDbEIsSUFBSSxDQUFDLEdBQUcsTUFBTSxNQUFNLEVBQUUsV0FBVyxhQUFhLEVBQUUsYUFBYSxFQUFFLFlBQVksR0FBRyxHQUFHLE9BQU87SUFDeEYsT0FBTyxHQUFHLEtBQUssTUFBTyxFQUFFLFdBQVcsYUFBYSxFQUFFLGFBQWEsRUFBRSxZQUFZLE1BQ3pFO0tBQUUsR0FBRztLQUFHLFFBQVE7S0FBYSxjQUFjO0tBQW1CLFdBQVc7SUFBVSxJQUFJLENBQUU7R0FDL0YsQ0FBQztFQUNILEdBQUcsSUFBSTtFQUNQLGFBQWEsY0FBYyxDQUFDO0NBQzlCLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxTQUF1QixVQUFVLFVBQVUsU0FBUztFQUN4RCxNQUFNLEtBQUssU0FBUyxLQUFLO0VBQ3pCLElBQUksQ0FBQyxJQUFJLE9BQU87R0FBRSxJQUFJO0dBQU8sT0FBTztFQUEwQztFQUM5RSxJQUFJLFNBQVMsU0FBUyxHQUFHLE9BQU87R0FBRSxJQUFJO0dBQU8sT0FBTztFQUFzQztFQUMxRixJQUFJLFNBQVMsU0FBUztHQUNwQixNQUFNLElBQUksTUFBTSxNQUFNLE1BQU0sRUFBRSxVQUFVLE1BQU0sRUFBRSxVQUFVLEVBQUU7R0FDNUQsSUFBSSxDQUFDLEdBQUcsT0FBTztJQUFFLElBQUk7SUFBTyxPQUFPO0dBQXdEO0dBQzNGLElBQUksRUFBRSxRQUFRLE9BQU87SUFBRSxJQUFJO0lBQU8sT0FBTztHQUFpRTtHQUMxRyxJQUFJLEVBQUUsYUFBYSxVQUFVLE9BQU87SUFBRSxJQUFJO0lBQU8sT0FBTztHQUE0QjtHQUNwRixRQUFRO0lBQUU7SUFBTSxNQUFNLEVBQUU7SUFBTSxPQUFPLEVBQUU7SUFBTyxTQUFTLEVBQUU7SUFBSSxVQUFVLEVBQUU7SUFBVSxPQUFPO0dBQXFCLENBQUM7R0FDaEgsT0FBTyxFQUFFLElBQUksS0FBSztFQUNwQjtFQUNBLElBQUksU0FBUyxTQUFTO0dBQ3BCLElBQUksT0FBTyxlQUFlLE9BQU8sbUJBQW1CLE9BQU87SUFBRSxJQUFJO0lBQU8sT0FBTztHQUF5QztHQUN4SCxJQUFJLGFBQWEsWUFBWSxPQUFPO0lBQUUsSUFBSTtJQUFPLE9BQU87R0FBNEI7R0FDcEYsUUFBUTtJQUFFO0lBQU0sTUFBTTtJQUFpQixPQUFPO0lBQWEsT0FBTztHQUFtQixDQUFDO0dBQ3RGLE9BQU8sRUFBRSxJQUFJLEtBQUs7RUFDcEI7RUFDQSxRQUFRO0dBQUU7R0FBTSxNQUFNO0dBQWlCLE9BQU87R0FBYyxPQUFPO0VBQXNCLENBQUM7RUFDMUYsT0FBTyxFQUFFLElBQUksS0FBSztDQUNwQjtDQUNBLE1BQU0sWUFBNkIsTUFBTSxRQUFRO0VBQUUsTUFBTTtFQUFZLE1BQU0sRUFBRTtFQUFNLE9BQU8sRUFBRTtFQUFPLE9BQU87Q0FBZSxDQUFDO0NBQzFILE1BQU0sZUFBZSxRQUFRLElBQUk7Q0FFakMsTUFBTSxjQUFpQyxNQUFNO0VBQzNDLE1BQU0sS0FBSyxFQUFFLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxFQUFFO0VBQzdDLE1BQU0sS0FBYztHQUFFLEdBQUc7R0FBRyxJQUFJLEtBQUssS0FBSyxJQUFJO0VBQVk7RUFDMUQsYUFBYSxPQUFPLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztFQUMvQixPQUFPO0NBQ1Q7Q0FDQSxNQUFNLGdCQUFxQyxJQUFJLE1BQU0sYUFBYSxPQUFPLEdBQUcsS0FBSyxNQUFPLEVBQUUsT0FBTyxLQUFLO0VBQUUsR0FBRztFQUFHLEdBQUc7Q0FBRSxJQUFJLENBQUUsQ0FBQztDQUMxSCxNQUFNLGlCQUF1QyxJQUFJLFFBQVEsZ0JBQ3ZELGFBQWEsT0FBTyxHQUFHLEtBQUssTUFBTyxFQUFFLE9BQU8sS0FDeEM7RUFBRSxHQUFHO0VBQUcsUUFBUTtFQUFhLGNBQWM7RUFBUSxXQUFXO0VBQVcsYUFBYSxjQUFjLEVBQUUsT0FBTztFQUMzRyxhQUFhLElBQUksS0FBSyxDQUFDLENBQUMsZUFBZSxTQUFTO0dBQUUsTUFBTTtHQUFXLFFBQVE7R0FBVyxLQUFLO0dBQVcsT0FBTztHQUFXLE1BQU07RUFBVSxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssT0FBTztDQUFFLElBQ25LLENBQUUsQ0FBQztDQUNULE1BQU0sa0JBQXlDLE9BQzdDLGFBQWEsT0FBTyxHQUFHLEtBQUssTUFBTyxFQUFFLE9BQU8sS0FDeEM7RUFBRSxHQUFHO0VBQUcsUUFBUTtFQUFhLFdBQVc7RUFBVyxNQUFNLEVBQUUsWUFBWSxTQUFTLEVBQUUsUUFBUSxLQUFLLE1BQU0sRUFBRSxRQUFRLEVBQUc7Q0FBRSxJQUFJLENBQUUsQ0FBQztDQUVqSSxNQUFNLFdBQTJCLFNBQVMsTUFBTSxPQUFPLFFBQ3JELFNBQVMsTUFBTSxNQUFNLEVBQUUsWUFBWSxXQUFXLEVBQUUsU0FBUyxRQUFRLEVBQUUsV0FBVyxlQUFlLEVBQUUsV0FBVyxlQUNyRyxLQUFLLEVBQUUsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLEtBQUssRUFBRSxHQUFHLElBQUksS0FBSyxLQUFLLENBQUM7Q0FFN0QsTUFBTSxVQUF5QixTQUFTLE1BQU0sT0FBTyxRQUFRO0VBQzNELE1BQU0sSUFBSSxHQUFHLEtBQUssR0FBRyxTQUFTLElBQUksR0FBRyxLQUFLLEdBQUcsUUFBUSxVQUFVLFVBQVU7RUFDekUsT0FBTyxNQUFNLE1BQU0sTUFBTSxFQUFFLFlBQVksV0FBVyxFQUFFLE9BQU8sS0FBSyxFQUFFLEtBQUssQ0FBQztDQUMxRTtDQUVBLE1BQU0sUUFBUSxlQUFvQjtFQUNoQztFQUFNO0VBQU87RUFBVTtFQUFRO0VBQVU7RUFBWTtFQUFjO0VBQWU7RUFBZ0I7RUFDbEc7RUFBUTtFQUFXO0VBQU87RUFBVTtFQUFRO0VBQVc7RUFBTztFQUFVO0VBQVE7RUFBVTtFQUMxRjtFQUFVO0VBQWE7RUFBUztFQUFZO0NBRTlDLElBQUk7RUFBQztFQUFNO0VBQVU7RUFBUTtFQUFPO0VBQVE7RUFBTztFQUFVO0VBQVU7RUFBUztDQUFLLENBQUM7Q0FFdEYsT0FDRSx3QkFBQyxPQUFPLFVBQVI7RUFBd0I7WUFBeEIsQ0FDRyxVQUNELHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osT0FBTyxLQUFLLE1BQU0sd0JBQUMsT0FBRDtJQUFnQixXQUFXLFNBQVMsRUFBRTtjQUFTLEVBQUU7R0FBUyxHQUFoRCxFQUFFOzs7O1VBQThDLENBQUM7RUFDM0U7Ozs7VUFDVTs7Ozs7O0FBRXJCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInN0b3JlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDYWxsYmFjaywgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtcbiAgQlJBTkNIRVMsIEhPTElEQVlTX1NFRUQsIExPQ0tTX1NFRUQsIFBST01PU19TRUVELCBTVEFGRl9TRUVELCBib29raW5nc1NlZWQsIGJ1aWxkQ291cnRzLCBtaW5zLFxufSBmcm9tICcuL2RhdGEnXG5pbXBvcnQgdHlwZSB7IEJvb2tpbmcsIEJyYW5jaCwgQ291cnQsIEhvbGlkYXksIExvY2ssIFByb21vLCBSb2xlLCBTdGFmZiB9IGZyb20gJy4vZGF0YSdcblxuZXhwb3J0IGludGVyZmFjZSBBdXRoVXNlciB7IHJvbGU6IFJvbGU7IG5hbWU6IHN0cmluZzsgcGhvbmU6IHN0cmluZzsgc3RhZmZJZD86IHN0cmluZzsgYnJhbmNoSWQ/OiBzdHJpbmc7IHRpdGxlOiBzdHJpbmcgfVxuXG5pbnRlcmZhY2UgVG9hc3QgeyBpZDogbnVtYmVyOyBtc2c6IHN0cmluZzsga2luZDogJ29rJyB8ICdlcnInIHwgJ2luZm8nIH1cblxuaW50ZXJmYWNlIEN0eCB7XG4gIHVzZXI6IEF1dGhVc2VyIHwgbnVsbFxuICBsb2dpbjogKGlkZW50aXR5OiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcsIHJvbGU6IFJvbGUpID0+IHsgb2s6IGJvb2xlYW47IGVycm9yPzogc3RyaW5nIH1cbiAgcmVnaXN0ZXI6ICh2OiB7IG5hbWU6IHN0cmluZzsgcGhvbmU6IHN0cmluZzsgZW1haWw6IHN0cmluZzsgcGFzc3dvcmQ6IHN0cmluZyB9KSA9PiB2b2lkXG4gIGxvZ291dDogKCkgPT4gdm9pZFxuICBib29raW5nczogQm9va2luZ1tdXG4gIGFkZEJvb2tpbmc6IChiOiBPbWl0PEJvb2tpbmcsICdpZCc+KSA9PiBCb29raW5nXG4gIHBhdGNoQm9va2luZzogKGlkOiBzdHJpbmcsIHA6IFBhcnRpYWw8Qm9va2luZz4pID0+IHZvaWRcbiAgY2FuY2VsQm9va2luZzogKGlkOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nLCBrZWVwRGVwb3NpdDogYm9vbGVhbikgPT4gdm9pZFxuICBjb25maXJtUGF5bWVudDogKGlkOiBzdHJpbmcpID0+IHZvaWRcbiAgYmxvY2tlcjogKGNvdXJ0SWQ6IHN0cmluZywgZGF0ZTogc3RyaW5nLCBzdGFydDogc3RyaW5nLCBlbmQ6IHN0cmluZykgPT4gQm9va2luZyB8IHVuZGVmaW5lZFxuICBjb3VydHM6IENvdXJ0W11cbiAgc2V0Q291cnRzOiBSZWFjdC5EaXNwYXRjaDxSZWFjdC5TZXRTdGF0ZUFjdGlvbjxDb3VydFtdPj5cbiAgc3RhZmY6IFN0YWZmW11cbiAgc2V0U3RhZmY6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPFN0YWZmW10+PlxuICBwcm9tb3M6IFByb21vW11cbiAgc2V0UHJvbW9zOiBSZWFjdC5EaXNwYXRjaDxSZWFjdC5TZXRTdGF0ZUFjdGlvbjxQcm9tb1tdPj5cbiAgbG9ja3M6IExvY2tbXVxuICBzZXRMb2NrczogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248TG9ja1tdPj5cbiAgbG9ja0F0OiAoY291cnRJZDogc3RyaW5nLCBkYXRlOiBzdHJpbmcsIHN0YXJ0OiBzdHJpbmcsIGVuZDogc3RyaW5nKSA9PiBMb2NrIHwgdW5kZWZpbmVkXG4gIGhvbGlkYXlzOiBIb2xpZGF5W11cbiAgc2V0SG9saWRheXM6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPEhvbGlkYXlbXT4+XG4gIGJyYW5jaGVzOiBCcmFuY2hbXVxuICBzZXRCcmFuY2hlczogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248QnJhbmNoW10+PlxuICByZWNlaXB0OiB7IGNvZGU6IHN0cmluZzsgb3JkZXI6IHN0cmluZzsgYW1vdW50OiBudW1iZXI7IG1ldGhvZDogc3RyaW5nOyBjYXNoaWVyOiBzdHJpbmcgfSB8IG51bGxcbiAgc2V0UmVjZWlwdDogKHI6IEN0eFsncmVjZWlwdCddKSA9PiB2b2lkXG4gIHRvYXN0OiAobXNnOiBzdHJpbmcsIGtpbmQ/OiBUb2FzdFsna2luZCddKSA9PiB2b2lkXG59XG5cbmNvbnN0IEFwcEN0eCA9IGNyZWF0ZUNvbnRleHQ8Q3R4IHwgbnVsbD4obnVsbClcbmV4cG9ydCBjb25zdCB1c2VBcHAgPSAoKSA9PiB7XG4gIGNvbnN0IGMgPSB1c2VDb250ZXh0KEFwcEN0eClcbiAgaWYgKCFjKSB0aHJvdyBuZXcgRXJyb3IoJ3VzZUFwcCBtdXN0IGJlIHVzZWQgaW5zaWRlIEFwcFByb3ZpZGVyJylcbiAgcmV0dXJuIGNcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZU5vdyhpbnRlcnZhbCA9IDEwMDApIHtcbiAgY29uc3QgW25vdywgc2V0Tm93XSA9IHVzZVN0YXRlKERhdGUubm93KCkpXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdCA9IHNldEludGVydmFsKCgpID0+IHNldE5vdyhEYXRlLm5vdygpKSwgaW50ZXJ2YWwpXG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwodClcbiAgfSwgW2ludGVydmFsXSlcbiAgcmV0dXJuIG5vd1xufVxuXG5jb25zdCBPV05FUl9QSE9ORSA9ICcwOTAwMDAwMDAxJ1xuY29uc3QgT1dORVJfUEFTUyA9ICdDaHUxMjM0NTYnXG5cbmV4cG9ydCBmdW5jdGlvbiBBcHBQcm92aWRlcih7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0Tm9kZSB9KSB7XG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlPEF1dGhVc2VyIHwgbnVsbD4oKCkgPT4ge1xuICAgIHRyeSB7IHJldHVybiBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdzcG9ydGh1Yi51c2VyJykgfHwgJ251bGwnKSB9IGNhdGNoIHsgcmV0dXJuIG51bGwgfVxuICB9KVxuICBjb25zdCBbYm9va2luZ3MsIHNldEJvb2tpbmdzXSA9IHVzZVN0YXRlPEJvb2tpbmdbXT4oYm9va2luZ3NTZWVkKVxuICBjb25zdCBbY291cnRzLCBzZXRDb3VydHNdID0gdXNlU3RhdGU8Q291cnRbXT4oYnVpbGRDb3VydHMpXG4gIGNvbnN0IFtzdGFmZiwgc2V0U3RhZmZdID0gdXNlU3RhdGU8U3RhZmZbXT4oU1RBRkZfU0VFRClcbiAgY29uc3QgW3Byb21vcywgc2V0UHJvbW9zXSA9IHVzZVN0YXRlPFByb21vW10+KFBST01PU19TRUVEKVxuICBjb25zdCBbbG9ja3MsIHNldExvY2tzXSA9IHVzZVN0YXRlPExvY2tbXT4oTE9DS1NfU0VFRClcbiAgY29uc3QgW2hvbGlkYXlzLCBzZXRIb2xpZGF5c10gPSB1c2VTdGF0ZTxIb2xpZGF5W10+KEhPTElEQVlTX1NFRUQpXG4gIGNvbnN0IFticmFuY2hlcywgc2V0QnJhbmNoZXNdID0gdXNlU3RhdGU8QnJhbmNoW10+KEJSQU5DSEVTKVxuICBjb25zdCBbcmVjZWlwdCwgc2V0UmVjZWlwdF0gPSB1c2VTdGF0ZTxDdHhbJ3JlY2VpcHQnXT4oeyBjb2RlOiAnUFQyMDI2MTExMjA5Jywgb3JkZXI6ICcjQksyMDI2MTExMDE1JywgYW1vdW50OiAyNTUwMDAsIG1ldGhvZDogJ1Rp4buBbiBt4bq3dCcsIGNhc2hpZXI6ICdMw6ogVsSDbiBIw7luZycgfSlcbiAgY29uc3QgW3RvYXN0cywgc2V0VG9hc3RzXSA9IHVzZVN0YXRlPFRvYXN0W10+KFtdKVxuICBjb25zdCBzZXEgPSB1c2VSZWYoMTAzMClcbiAgY29uc3QgdGlkID0gdXNlUmVmKDEpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodXNlcikgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Nwb3J0aHViLnVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKSlcbiAgICBlbHNlIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdzcG9ydGh1Yi51c2VyJylcbiAgfSwgW3VzZXJdKVxuXG4gIGNvbnN0IHRvYXN0ID0gdXNlQ2FsbGJhY2soKG1zZzogc3RyaW5nLCBraW5kOiBUb2FzdFsna2luZCddID0gJ2luZm8nKSA9PiB7XG4gICAgY29uc3QgaWQgPSB0aWQuY3VycmVudCsrXG4gICAgc2V0VG9hc3RzKCh0KSA9PiBbLi4udCwgeyBpZCwgbXNnLCBraW5kIH1dKVxuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0VG9hc3RzKCh0KSA9PiB0LmZpbHRlcigoeCkgPT4geC5pZCAhPT0gaWQpKSwgMzgwMClcbiAgfSwgW10pXG5cbiAgLy8gVOG7sSBo4buneSDEkcahbiBraGkgaOG6v3QgdGjhu51pIGdpYW4gZ2nhu68gY2jhu5dcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB0ID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKVxuICAgICAgc2V0Qm9va2luZ3MoKGJzKSA9PiB7XG4gICAgICAgIGlmICghYnMuc29tZSgoYikgPT4gYi5zdGF0dXMgPT09ICdwZW5kaW5nJyAmJiBiLmhvbGRVbnRpbCAmJiBiLmhvbGRVbnRpbCA8IG5vdykpIHJldHVybiBic1xuICAgICAgICByZXR1cm4gYnMubWFwKChiKSA9PiAoYi5zdGF0dXMgPT09ICdwZW5kaW5nJyAmJiBiLmhvbGRVbnRpbCAmJiBiLmhvbGRVbnRpbCA8IG5vd1xuICAgICAgICAgID8geyAuLi5iLCBzdGF0dXM6ICdjYW5jZWxsZWQnLCBjYW5jZWxSZWFzb246ICdI4bq/dCBo4bqhbiBnaeG7ryBjaOG7lycsIGhvbGRVbnRpbDogdW5kZWZpbmVkIH0gOiBiKSlcbiAgICAgIH0pXG4gICAgfSwgMTUwMClcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbCh0KVxuICB9LCBbXSlcblxuICBjb25zdCBsb2dpbjogQ3R4Wydsb2dpbiddID0gKGlkZW50aXR5LCBwYXNzd29yZCwgcm9sZSkgPT4ge1xuICAgIGNvbnN0IGlkID0gaWRlbnRpdHkudHJpbSgpXG4gICAgaWYgKCFpZCkgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ1Z1aSBsw7JuZyBuaOG6rXAgc+G7kSDEkWnhu4duIHRob+G6oWkgaG/hurdjIGVtYWlsLicgfVxuICAgIGlmIChwYXNzd29yZC5sZW5ndGggPCA2KSByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAnTeG6rXQga2jhuql1IHBo4bqjaSBjw7MgdOG7kWkgdGhp4buDdSA2IGvDvSB04buxLicgfVxuICAgIGlmIChyb2xlID09PSAnc3RhZmYnKSB7XG4gICAgICBjb25zdCBzID0gc3RhZmYuZmluZCgoeCkgPT4geC5waG9uZSA9PT0gaWQgfHwgeC5lbWFpbCA9PT0gaWQpXG4gICAgICBpZiAoIXMpIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdLaMO0bmcgdMOsbSB0aOG6pXkgdMOgaSBraG/huqNuIG5ow6JuIHZpw6puIHbhu5tpIHRow7RuZyB0aW4gbsOgeS4nIH1cbiAgICAgIGlmIChzLmxvY2tlZCkgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ1TDoGkga2hv4bqjbiBuaMOibiB2acOqbiDEkcOjIGLhu4sga2jDs2EsIHZ1aSBsw7JuZyBsacOqbiBo4buHIGNo4bunIGjhu4cgdGjhu5FuZy4nIH1cbiAgICAgIGlmIChzLnBhc3N3b3JkICE9PSBwYXNzd29yZCkgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ03huq10IGto4bqpdSBraMO0bmcgY2jDrW5oIHjDoWMuJyB9XG4gICAgICBzZXRVc2VyKHsgcm9sZSwgbmFtZTogcy5uYW1lLCBwaG9uZTogcy5waG9uZSwgc3RhZmZJZDogcy5pZCwgYnJhbmNoSWQ6IHMuYnJhbmNoSWQsIHRpdGxlOiAnTmjDom4gdmnDqm4gdGh1IG5nw6JuJyB9KVxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfVxuICAgIH1cbiAgICBpZiAocm9sZSA9PT0gJ293bmVyJykge1xuICAgICAgaWYgKGlkICE9PSBPV05FUl9QSE9ORSAmJiBpZCAhPT0gJ2NodUBzcG9ydGh1Yi52bicpIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdLaMO0bmcgdMOsbSB0aOG6pXkgdMOgaSBraG/huqNuIGNo4bunIGjhu4cgdGjhu5FuZy4nIH1cbiAgICAgIGlmIChwYXNzd29yZCAhPT0gT1dORVJfUEFTUykgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ03huq10IGto4bqpdSBraMO0bmcgY2jDrW5oIHjDoWMuJyB9XG4gICAgICBzZXRVc2VyKHsgcm9sZSwgbmFtZTogJ8SQ4bq3bmcgUXXhu5FjIELhuqNvJywgcGhvbmU6IE9XTkVSX1BIT05FLCB0aXRsZTogJ0No4bunIGjhu4cgdGjhu5FuZyBzw6JuJyB9KVxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfVxuICAgIH1cbiAgICBzZXRVc2VyKHsgcm9sZSwgbmFtZTogJ05ndXnhu4VuIFbEg24gQW4nLCBwaG9uZTogJzA5ODc2NTQzMjEnLCB0aXRsZTogJ0jhu5lpIHZpw6puIHRow6JuIHRoaeG6v3QnIH0pXG4gICAgcmV0dXJuIHsgb2s6IHRydWUgfVxuICB9XG4gIGNvbnN0IHJlZ2lzdGVyOiBDdHhbJ3JlZ2lzdGVyJ10gPSAodikgPT4gc2V0VXNlcih7IHJvbGU6ICdjdXN0b21lcicsIG5hbWU6IHYubmFtZSwgcGhvbmU6IHYucGhvbmUsIHRpdGxlOiAnSOG7mWkgdmnDqm4gbeG7m2knIH0pXG4gIGNvbnN0IGxvZ291dCA9ICgpID0+IHNldFVzZXIobnVsbClcblxuICBjb25zdCBhZGRCb29raW5nOiBDdHhbJ2FkZEJvb2tpbmcnXSA9IChiKSA9PiB7XG4gICAgY29uc3QgeW0gPSBiLmRhdGUuc2xpY2UoMCwgNykucmVwbGFjZSgnLScsICcnKVxuICAgIGNvbnN0IG5iOiBCb29raW5nID0geyAuLi5iLCBpZDogYEJLJHt5bX0ke3NlcS5jdXJyZW50Kyt9YCB9XG4gICAgc2V0Qm9va2luZ3MoKGJzKSA9PiBbbmIsIC4uLmJzXSlcbiAgICByZXR1cm4gbmJcbiAgfVxuICBjb25zdCBwYXRjaEJvb2tpbmc6IEN0eFsncGF0Y2hCb29raW5nJ10gPSAoaWQsIHApID0+IHNldEJvb2tpbmdzKChicykgPT4gYnMubWFwKChiKSA9PiAoYi5pZCA9PT0gaWQgPyB7IC4uLmIsIC4uLnAgfSA6IGIpKSlcbiAgY29uc3QgY2FuY2VsQm9va2luZzogQ3R4WydjYW5jZWxCb29raW5nJ10gPSAoaWQsIHJlYXNvbiwga2VlcERlcG9zaXQpID0+XG4gICAgc2V0Qm9va2luZ3MoKGJzKSA9PiBicy5tYXAoKGIpID0+IChiLmlkID09PSBpZFxuICAgICAgPyB7IC4uLmIsIHN0YXR1czogJ2NhbmNlbGxlZCcsIGNhbmNlbFJlYXNvbjogcmVhc29uLCBob2xkVW50aWw6IHVuZGVmaW5lZCwga2VwdERlcG9zaXQ6IGtlZXBEZXBvc2l0ID8gYi5wYWlkIDogMCxcbiAgICAgICAgICBjYW5jZWxsZWRBdDogbmV3IERhdGUoKS50b0xvY2FsZVN0cmluZygndmktVk4nLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcsIGRheTogJzItZGlnaXQnLCBtb250aDogJzItZGlnaXQnLCB5ZWFyOiAnbnVtZXJpYycgfSkucmVwbGFjZSgnLCcsICcgbmfDoHknKSB9XG4gICAgICA6IGIpKSlcbiAgY29uc3QgY29uZmlybVBheW1lbnQ6IEN0eFsnY29uZmlybVBheW1lbnQnXSA9IChpZCkgPT5cbiAgICBzZXRCb29raW5ncygoYnMpID0+IGJzLm1hcCgoYikgPT4gKGIuaWQgPT09IGlkXG4gICAgICA/IHsgLi4uYiwgc3RhdHVzOiAnY29uZmlybWVkJywgaG9sZFVudGlsOiB1bmRlZmluZWQsIHBhaWQ6IGIucGF5TW9kZSA9PT0gJ2Z1bGwnID8gYi50b3RhbCA6IE1hdGgucm91bmQoYi50b3RhbCAqIDAuMykgfSA6IGIpKSlcblxuICBjb25zdCBibG9ja2VyOiBDdHhbJ2Jsb2NrZXInXSA9IChjb3VydElkLCBkYXRlLCBzdGFydCwgZW5kKSA9PlxuICAgIGJvb2tpbmdzLmZpbmQoKGIpID0+IGIuY291cnRJZCA9PT0gY291cnRJZCAmJiBiLmRhdGUgPT09IGRhdGUgJiYgYi5zdGF0dXMgIT09ICdjYW5jZWxsZWQnICYmIGIuc3RhdHVzICE9PSAnY29tcGxldGVkJ1xuICAgICAgJiYgbWlucyhiLnN0YXJ0KSA8IG1pbnMoZW5kKSAmJiBtaW5zKGIuZW5kKSA+IG1pbnMoc3RhcnQpKVxuXG4gIGNvbnN0IGxvY2tBdDogQ3R4Wydsb2NrQXQnXSA9IChjb3VydElkLCBkYXRlLCBzdGFydCwgZW5kKSA9PiB7XG4gICAgY29uc3QgcyA9IGAke2RhdGV9VCR7c3RhcnR9YCwgZSA9IGAke2RhdGV9VCR7ZW5kID09PSAnMjQ6MDAnID8gJzIzOjU5JyA6IGVuZH1gXG4gICAgcmV0dXJuIGxvY2tzLmZpbmQoKGwpID0+IGwuY291cnRJZCA9PT0gY291cnRJZCAmJiBsLmZyb20gPCBlICYmIGwudG8gPiBzKVxuICB9XG5cbiAgY29uc3QgdmFsdWUgPSB1c2VNZW1vPEN0eD4oKCkgPT4gKHtcbiAgICB1c2VyLCBsb2dpbiwgcmVnaXN0ZXIsIGxvZ291dCwgYm9va2luZ3MsIGFkZEJvb2tpbmcsIHBhdGNoQm9va2luZywgY2FuY2VsQm9va2luZywgY29uZmlybVBheW1lbnQsIGJsb2NrZXIsXG4gICAgY291cnRzLCBzZXRDb3VydHMsIHN0YWZmLCBzZXRTdGFmZiwgcHJvbW9zLCBzZXRQcm9tb3MsIGxvY2tzLCBzZXRMb2NrcywgbG9ja0F0LCBob2xpZGF5cywgc2V0SG9saWRheXMsXG4gICAgYnJhbmNoZXMsIHNldEJyYW5jaGVzLCByZWNlaXB0LCBzZXRSZWNlaXB0LCB0b2FzdCxcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9KSwgW3VzZXIsIGJvb2tpbmdzLCBjb3VydHMsIHN0YWZmLCBwcm9tb3MsIGxvY2tzLCBob2xpZGF5cywgYnJhbmNoZXMsIHJlY2VpcHQsIHRvYXN0XSlcblxuICByZXR1cm4gKFxuICAgIDxBcHBDdHguUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9hc3QtaG9zdFwiPlxuICAgICAgICB7dG9hc3RzLm1hcCgodCkgPT4gPGRpdiBrZXk9e3QuaWR9IGNsYXNzTmFtZT17YHRvYXN0ICR7dC5raW5kfWB9Pnt0Lm1zZ308L2Rpdj4pfVxuICAgICAgPC9kaXY+XG4gICAgPC9BcHBDdHguUHJvdmlkZXI+XG4gIClcbn1cbiJdfQ==