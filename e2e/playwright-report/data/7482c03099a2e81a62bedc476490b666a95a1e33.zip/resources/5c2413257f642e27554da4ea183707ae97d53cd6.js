import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Login.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=39aafc4d";
import { useApp } from "/src/store.tsx";
var _jsxFileName = "D:/Jobs/Sports/app/src/pages/Login.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=39aafc4d";
var _s = $RefreshSig$();
const QUICK = [
	{
		role: "customer",
		label: "Khách hàng",
		id: "0912345678",
		pw: "Matkhau123"
	},
	{
		role: "staff",
		label: "Nhân viên thu ngân",
		id: "0933445566",
		pw: "Nv123456"
	},
	{
		role: "owner",
		label: "Chủ hệ thống sân",
		id: "0900000001",
		pw: "Chu123456"
	}
];
export default function Login() {
	_s();
	const { login, register, toast } = useApp();
	const [tab, setTab] = useState("login");
	const [role, setRole] = useState("customer");
	const [id, setId] = useState(QUICK[0].id);
	const [pw, setPw] = useState(QUICK[0].pw);
	const [show, setShow] = useState(true);
	const [err, setErr] = useState("");
	const [reg, setReg] = useState({
		name: "",
		phone: "",
		email: "",
		password: "",
		confirm: ""
	});
	const pick = (r) => {
		const q = QUICK.find((x) => x.role === r);
		setRole(r);
		setId(q.id);
		setPw(q.pw);
		setErr("");
	};
	const submitLogin = (e) => {
		e.preventDefault();
		const res = login(id, pw, role);
		if (!res.ok) setErr(res.error ?? "Đăng nhập thất bại.");
	};
	const submitReg = (e) => {
		e.preventDefault();
		if (!reg.name.trim()) return setErr("Vui lòng nhập họ và tên.");
		if (!/^0\d{9}$/.test(reg.phone)) return setErr("Số điện thoại phải gồm 10 chữ số và bắt đầu bằng 0.");
		if (reg.email && !/^\S+@\S+\.\S+$/.test(reg.email)) return setErr("Địa chỉ email không hợp lệ.");
		if (reg.password.length < 6) return setErr("Mật khẩu phải có tối thiểu 6 ký tự.");
		if (reg.password !== reg.confirm) return setErr("Mật khẩu nhập lại không khớp.");
		register(reg);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "col",
		style: { minHeight: "100vh" },
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "hdr",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "container hdr-in",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "row g12",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "logo-mark",
						children: "S"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "col g4",
						style: { paddingBottom: 2.5 },
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "logo-name",
							children: "SportHub"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "logo-sub",
							children: "Hệ thống đặt lịch sân thể thao"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: "btn",
					style: {
						background: "var(--brand-50)",
						border: "1px solid var(--gray-200)",
						color: "var(--brand-700)",
						padding: "8px 14px"
					},
					onClick: () => toast("Vui lòng đăng nhập để vào trang chủ đặt sân."),
					children: "← Quay lại Trang chủ"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "container",
			style: {
				flex: 1,
				display: "flex",
				alignItems: "center",
				padding: "48px 16px"
			},
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "grid12",
				style: {
					width: "100%",
					gap: 32,
					alignItems: "center",
					maxWidth: 1152,
					margin: "0 auto"
				},
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "col g24",
					style: { gridColumn: "span 5" },
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "hero col g20",
						style: {
							padding: 28,
							background: "var(--brand-800)"
						},
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "badge",
								style: {
									alignSelf: "flex-start",
									background: "rgba(4,120,87,.8)",
									border: "1px solid rgba(16,185,129,.4)",
									color: "var(--brand-100)"
								},
								children: "⚽ Đặt sân nhanh chóng • Giữ lịch tức thì"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", {
								className: "t24 w800",
								style: {
									lineHeight: "33px",
									paddingTop: 1
								},
								children: "Đặt lịch sân thể thao mọi lúc, mọi nơi cùng SportHub"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "t14",
								style: {
									color: "var(--brand-100)",
									lineHeight: "22.75px"
								},
								children: "Tra cứu khung giờ trống theo thời gian thực tại 3 chi nhánh Hà Nội, thanh toán đặt cọc qua mã QR tiện lợi và nhận tin nhắn nhắc lịch tự động trước giờ bóng lăn 1 tiếng."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "col g12",
								style: {
									borderTop: "1px solid var(--brand-700)",
									paddingTop: 17
								},
								children: [
									"Hiển thị bảng lịch trực quan, báo giá rõ ràng theo từng khung giờ",
									"Hỗ trợ đặt cọc giữ chỗ 30% hoặc thanh toán trọn gói 100%",
									"Nhiều ưu đãi giảm giá khung giờ vàng cho hội viên thân thiết"
								].map((t) => /* @__PURE__ */ _jsxDEV("div", {
									className: "row g12",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "center t12 w700",
										style: {
											width: 24,
											height: 24,
											borderRadius: 8,
											background: "var(--brand-600)",
											flex: "none"
										},
										children: "✓"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 69,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "t12",
										children: t
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 70,
										columnNumber: 21
									}, this)]
								}, t, true, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "card row between g12",
						style: { borderRadius: 16 },
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "col g2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "t12 w700 c-ink",
								children: "Cần hỗ trợ mở khóa tài khoản hoặc đặt sân cố định?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "t12 c-s600",
								children: "Liên hệ trực tiếp quản lý hệ thống sân (05:00 – 23:00 hàng ngày)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "chip-box w800 c-brand",
							style: { fontWeight: 800 },
							children: "1900 6886"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "card card-raise",
					style: {
						gridColumn: "span 7",
						padding: "0 0 32px",
						overflow: "hidden"
					},
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "auth-tabs",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: `auth-tab${tab === "login" ? " on" : ""}`,
							onClick: () => {
								setTab("login");
								setErr("");
							},
							children: "Đăng nhập tài khoản"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: `auth-tab${tab === "register" ? " on" : ""}`,
							onClick: () => {
								setTab("register");
								setErr("");
							},
							children: "Đăng ký hội viên mới"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 13
					}, this), tab === "login" ? /* @__PURE__ */ _jsxDEV("form", {
						className: "col g20",
						style: { padding: "32px 32px 0" },
						onSubmit: submitLogin,
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "col g2",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "t18 w800 c-ink",
									children: "Chào mừng bạn quay trở lại!"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "t12 c-s600",
									children: "Nhập số điện thoại hoặc email của bạn để bắt đầu đặt sân hoặc vào ca làm việc."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "col g16",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "label",
										htmlFor: "login-identity",
										children: ["Số điện thoại hoặc Email ", /* @__PURE__ */ _jsxDEV("span", {
											className: "req",
											children: "*"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 98,
											columnNumber: 96
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										id: "login-identity",
										className: "input",
										value: id,
										onChange: (e) => setId(e.target.value),
										autoComplete: "username"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 99,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 97,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "row between",
										style: { marginBottom: 6 },
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "label",
											style: { margin: 0 },
											htmlFor: "login-password",
											children: ["Mật khẩu ", /* @__PURE__ */ _jsxDEV("span", {
												className: "req",
												children: "*"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 103,
												columnNumber: 104
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 103,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											className: "link-btn",
											onClick: () => setShow((s) => !s),
											children: "Hiện / Ẩn"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 104,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 102,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										id: "login-password",
										className: "input",
										type: show ? "text" : "password",
										value: pw,
										onChange: (e) => setPw(e.target.value),
										autoComplete: "current-password"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 101,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "hint col g8",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "t12 w700 c-s800",
											children: "Tài khoản đăng nhập nhanh:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 109,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "row g8",
											children: QUICK.map((q) => /* @__PURE__ */ _jsxDEV("label", {
												className: "radio-card f1",
												style: { padding: 10 },
												children: [/* @__PURE__ */ _jsxDEV("input", {
													type: "radio",
													name: "quick-role",
													checked: role === q.role,
													onChange: () => pick(q.role)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 113,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: q.label }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 114,
													columnNumber: 27
												}, this)]
											}, q.role, true, {
												fileName: _jsxFileName,
												lineNumber: 112,
												columnNumber: 25
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 110,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 108,
										columnNumber: 19
									}, this),
									err && /* @__PURE__ */ _jsxDEV("p", {
										className: "field-err",
										children: err
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 119,
										columnNumber: 27
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										className: "btn btn-primary btn-lg btn-block",
										type: "submit",
										children: "Đăng nhập ngay"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 120,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "row between top-rule",
								style: { paddingTop: 16 },
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "t12 c-s700",
									children: "Bạn chưa có tài khoản đặt sân?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "link-btn",
									onClick: () => {
										setTab("register");
										setErr("");
									},
									children: "Tạo tài khoản mới miễn phí →"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("form", {
						className: "col g16",
						style: { padding: "32px 32px 0" },
						onSubmit: submitReg,
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "col g2",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "t18 w800 c-ink",
									children: "Trở thành hội viên SportHub"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "t12 c-s600",
									children: "Đăng ký miễn phí để đặt sân nhanh, nhận ưu đãi giờ vàng và theo dõi lịch đặt của bạn."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 17
							}, this),
							[
								[
									"name",
									"Họ và tên",
									"Nguyễn Văn An",
									"text",
									true
								],
								[
									"phone",
									"Số điện thoại",
									"0912345678",
									"tel",
									true
								],
								[
									"email",
									"Địa chỉ email",
									"ban@example.com",
									"email",
									false
								],
								[
									"password",
									"Mật khẩu",
									"Tối thiểu 6 ký tự",
									"password",
									true
								],
								[
									"confirm",
									"Nhập lại mật khẩu",
									"Nhập lại mật khẩu",
									"password",
									true
								]
							].map(([k, l, ph, type, req]) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "label",
								children: [
									l,
									" ",
									req && /* @__PURE__ */ _jsxDEV("span", {
										className: "req",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 135,
										columnNumber: 58
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								className: "input",
								type,
								placeholder: ph,
								value: reg[k],
								onChange: (e) => setReg({
									...reg,
									[k]: e.target.value
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 21
							}, this)] }, k, true, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 19
							}, this)),
							err && /* @__PURE__ */ _jsxDEV("p", {
								className: "field-err",
								children: err
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-primary btn-lg btn-block",
								type: "submit",
								children: "Đăng ký & Bắt đầu đặt sân"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "row between top-rule",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "t12 c-s700",
									children: "Đã có tài khoản?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "link-btn",
									onClick: () => {
										setTab("login");
										setErr("");
									},
									children: "Quay lại đăng nhập →"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 42,
		columnNumber: 5
	}, this);
}
_s(Login, "8AWwR/kiWH19/vN3FnEc6Yy3YZM=", false, function() {
	return [useApp];
});
_c = Login;
var _c;
$RefreshReg$(_c, "Login");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Login.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Jobs/Sports/app/src/pages/Login.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Jobs/Sports/app/src/pages/Login.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Jobs/Sports/app/src/pages/Login.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFHekIsU0FBUyxjQUFjOzs7O0FBRXZCLE1BQU0sUUFBaUU7Q0FDckU7RUFBRSxNQUFNO0VBQVksT0FBTztFQUFjLElBQUk7RUFBYyxJQUFJO0NBQWE7Q0FDNUU7RUFBRSxNQUFNO0VBQVMsT0FBTztFQUFzQixJQUFJO0VBQWMsSUFBSTtDQUFXO0NBQy9FO0VBQUUsTUFBTTtFQUFTLE9BQU87RUFBb0IsSUFBSTtFQUFjLElBQUk7Q0FBWTtBQUNoRjtBQUVBLGVBQWUsU0FBUyxRQUFROztDQUM5QixNQUFNLEVBQUUsT0FBTyxVQUFVLFVBQVUsT0FBTztDQUMxQyxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQStCLE9BQU87Q0FDNUQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFlLFVBQVU7Q0FDakQsTUFBTSxDQUFDLElBQUksU0FBUyxTQUFTLE1BQU0sRUFBRSxDQUFDLEVBQUU7Q0FDeEMsTUFBTSxDQUFDLElBQUksU0FBUyxTQUFTLE1BQU0sRUFBRSxDQUFDLEVBQUU7Q0FDeEMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLElBQUk7Q0FDckMsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFTLEVBQUU7Q0FDakMsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFTO0VBQUUsTUFBTTtFQUFJLE9BQU87RUFBSSxPQUFPO0VBQUksVUFBVTtFQUFJLFNBQVM7Q0FBRyxDQUFDO0NBRTVGLE1BQU0sUUFBUSxNQUFZO0VBQ3hCLE1BQU0sSUFBSSxNQUFNLE1BQU0sTUFBTSxFQUFFLFNBQVMsQ0FBQztFQUN4QyxRQUFRLENBQUM7RUFBRyxNQUFNLEVBQUUsRUFBRTtFQUFHLE1BQU0sRUFBRSxFQUFFO0VBQUcsT0FBTyxFQUFFO0NBQ2pEO0NBQ0EsTUFBTSxlQUFlLE1BQWlCO0VBQ3BDLEVBQUUsZUFBZTtFQUNqQixNQUFNLE1BQU0sTUFBTSxJQUFJLElBQUksSUFBSTtFQUM5QixJQUFJLENBQUMsSUFBSSxJQUFJLE9BQU8sSUFBSSxTQUFTLHFCQUFxQjtDQUN4RDtDQUNBLE1BQU0sYUFBYSxNQUFpQjtFQUNsQyxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLElBQUksS0FBSyxLQUFLLEdBQUcsT0FBTyxPQUFPLDBCQUEwQjtFQUM5RCxJQUFJLENBQUMsV0FBVyxLQUFLLElBQUksS0FBSyxHQUFHLE9BQU8sT0FBTyxxREFBcUQ7RUFDcEcsSUFBSSxJQUFJLFNBQVMsQ0FBQyxpQkFBaUIsS0FBSyxJQUFJLEtBQUssR0FBRyxPQUFPLE9BQU8sNkJBQTZCO0VBQy9GLElBQUksSUFBSSxTQUFTLFNBQVMsR0FBRyxPQUFPLE9BQU8scUNBQXFDO0VBQ2hGLElBQUksSUFBSSxhQUFhLElBQUksU0FBUyxPQUFPLE9BQU8sK0JBQStCO0VBQy9FLFNBQVMsR0FBRztDQUNkO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFNLE9BQU8sRUFBRSxXQUFXLFFBQVE7WUFBakQsQ0FDRSx3QkFBQyxVQUFEO0dBQVEsV0FBVTthQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFZO0tBQU07Ozs7ZUFDakMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBUyxPQUFPLEVBQUUsZUFBZSxJQUFJO2dCQUFwRCxDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFZO01BQWM7Ozs7Z0JBQzFDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFXO01BQW9DOzs7O2NBQzVEOzs7OzthQUNGOzs7OztjQUNMLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO0tBQU0sT0FBTztNQUFFLFlBQVk7TUFBbUIsUUFBUTtNQUE2QixPQUFPO01BQW9CLFNBQVM7S0FBVztLQUNsSixlQUFlLE1BQU0sOENBQThDO2VBQUc7SUFBNEI7Ozs7WUFDakc7Ozs7OztFQUNDOzs7O1lBRVIsd0JBQUMsUUFBRDtHQUFNLFdBQVU7R0FBWSxPQUFPO0lBQUUsTUFBTTtJQUFHLFNBQVM7SUFBUSxZQUFZO0lBQVUsU0FBUztHQUFZO2FBQ3hHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQVMsT0FBTztLQUFFLE9BQU87S0FBUSxLQUFLO0tBQUksWUFBWTtLQUFVLFVBQVU7S0FBTSxRQUFRO0lBQVM7Y0FBaEgsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFVLE9BQU8sRUFBRSxZQUFZLFNBQVM7ZUFBdkQsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFlLE9BQU87T0FBRSxTQUFTO09BQUksWUFBWTtNQUFtQjtnQkFBbkY7T0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUFRLE9BQU87U0FBRSxXQUFXO1NBQWMsWUFBWTtTQUFxQixRQUFRO1NBQWlDLE9BQU87UUFBbUI7a0JBQUc7T0FBOEM7Ozs7O09BQy9NLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO1FBQVcsT0FBTztTQUFFLFlBQVk7U0FBUSxZQUFZO1FBQUU7a0JBQUc7T0FBd0Q7Ozs7O09BQy9ILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO1FBQU0sT0FBTztTQUFFLE9BQU87U0FBb0IsWUFBWTtRQUFVO2tCQUFHO09BRTdFOzs7OztPQUNILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQVUsT0FBTztTQUFFLFdBQVc7U0FBOEIsWUFBWTtRQUFHO2tCQUN2RjtTQUFDO1NBQXFFO1NBQTREO1FBQThELENBQUMsQ0FBQyxLQUFLLE1BQ3RNLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7VUFBa0IsT0FBTztXQUFFLE9BQU87V0FBSSxRQUFRO1dBQUksY0FBYztXQUFHLFlBQVk7V0FBb0IsTUFBTTtVQUFPO29CQUFHO1NBQU87Ozs7bUJBQzFJLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFPO1NBQVE7Ozs7aUJBQzVCO1dBSHlCOzs7O2VBR3pCLENBQ047T0FDRTs7Ozs7TUFDRjs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUF1QixPQUFPLEVBQUUsY0FBYyxHQUFHO2dCQUFoRSxDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWlCO09BQXdEOzs7O2lCQUN6Rix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBYTtPQUFzRTs7OztlQUNoRzs7Ozs7Z0JBQ0wsd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBd0IsT0FBTyxFQUFFLFlBQVksSUFBSTtpQkFBRztNQUFlOzs7O2NBQ2hGOzs7OzthQUNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWtCLE9BQU87TUFBRSxZQUFZO01BQVUsU0FBUztNQUFZLFVBQVU7S0FBUztlQUF4RyxDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUFRLFdBQVcsV0FBVyxRQUFRLFVBQVUsUUFBUTtPQUFNLGVBQWU7UUFBRSxPQUFPLE9BQU87UUFBRyxPQUFPLEVBQUU7T0FBRTtpQkFBRztNQUEyQjs7OztnQkFDekksd0JBQUMsVUFBRDtPQUFRLFdBQVcsV0FBVyxRQUFRLGFBQWEsUUFBUTtPQUFNLGVBQWU7UUFBRSxPQUFPLFVBQVU7UUFBRyxPQUFPLEVBQUU7T0FBRTtpQkFBRztNQUE0Qjs7OztjQUM3STs7Ozs7ZUFFSixRQUFRLFVBQ1Asd0JBQUMsUUFBRDtNQUFNLFdBQVU7TUFBVSxPQUFPLEVBQUUsU0FBUyxjQUFjO01BQUcsVUFBVTtnQkFBdkU7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFpQjtRQUErQjs7OztrQkFDOUQsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWE7UUFBaUY7Ozs7Z0JBQ3hHOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtVQUFRLFNBQVE7b0JBQWpDLENBQWtELDZCQUF5Qix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBTTtVQUFPOzs7O2tCQUFROzs7OzttQkFDaEgsd0JBQUMsU0FBRDtVQUFPLElBQUc7VUFBaUIsV0FBVTtVQUFRLE9BQU87VUFBSSxXQUFXLE1BQU0sTUFBTSxFQUFFLE9BQU8sS0FBSztVQUFHLGNBQWE7U0FBWTs7OztpQkFDdEg7Ozs7O1NBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQWMsT0FBTyxFQUFFLGNBQWMsRUFBRTtvQkFBdEQsQ0FDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtXQUFRLE9BQU8sRUFBRSxRQUFRLEVBQUU7V0FBRyxTQUFRO3FCQUF2RCxDQUF3RSxhQUFTLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFNO1dBQU87Ozs7bUJBQVE7Ozs7O29CQUN0SCx3QkFBQyxVQUFEO1dBQVEsTUFBSztXQUFTLFdBQVU7V0FBVyxlQUFlLFNBQVMsTUFBTSxDQUFDLENBQUM7cUJBQUc7VUFBaUI7Ozs7a0JBQzVGOzs7OzttQkFDTCx3QkFBQyxTQUFEO1VBQU8sSUFBRztVQUFpQixXQUFVO1VBQVEsTUFBTSxPQUFPLFNBQVM7VUFBWSxPQUFPO1VBQUksV0FBVyxNQUFNLE1BQU0sRUFBRSxPQUFPLEtBQUs7VUFBRyxjQUFhO1NBQW9COzs7O2lCQUNoSzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFrQjtVQUFnQzs7OztvQkFDbEUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1osTUFBTSxLQUFLLE1BQ1Ysd0JBQUMsU0FBRDtZQUFvQixXQUFVO1lBQWdCLE9BQU8sRUFBRSxTQUFTLEdBQUc7c0JBQW5FLENBQ0Usd0JBQUMsU0FBRDthQUFPLE1BQUs7YUFBUSxNQUFLO2FBQWEsU0FBUyxTQUFTLEVBQUU7YUFBTSxnQkFBZ0IsS0FBSyxFQUFFLElBQUk7WUFBSTs7OztzQkFDL0Ysd0JBQUMsUUFBRCxZQUFPLEVBQUUsTUFBWTs7OztvQkFDaEI7Y0FISyxFQUFFOzs7O2tCQUdQLENBQ1I7VUFDRTs7OztrQkFDRjs7Ozs7O1NBQ0osT0FBTyx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYTtTQUFPOzs7OztTQUN6Qyx3QkFBQyxVQUFEO1VBQVEsV0FBVTtVQUFtQyxNQUFLO29CQUFTO1NBQXNCOzs7OztRQUN0Rjs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBdUIsT0FBTyxFQUFFLFlBQVksR0FBRztrQkFBOUQsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBYTtRQUFvQzs7OztrQkFDakUsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxXQUFVO1NBQVcsZUFBZTtVQUFFLE9BQU8sVUFBVTtVQUFHLE9BQU8sRUFBRTtTQUFFO21CQUFHO1FBQW9DOzs7O2dCQUMvSDs7Ozs7O01BQ0Q7Ozs7O2dCQUVOLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQVUsT0FBTyxFQUFFLFNBQVMsY0FBYztNQUFHLFVBQVU7Z0JBQXZFO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBaUI7UUFBK0I7Ozs7a0JBQzlELHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFhO1FBQXdGOzs7O2dCQUMvRzs7Ozs7O09BQ0g7UUFBQztTQUFDO1NBQVE7U0FBYTtTQUFpQjtTQUFRO1FBQUk7UUFBRztTQUFDO1NBQVM7U0FBaUI7U0FBYztTQUFPO1FBQUk7UUFBRztTQUFDO1NBQVM7U0FBaUI7U0FBbUI7U0FBUztRQUFLO1FBQUc7U0FBQztTQUFZO1NBQVk7U0FBcUI7U0FBWTtRQUFJO1FBQUc7U0FBQztTQUFXO1NBQXFCO1NBQXFCO1NBQVk7UUFBSTtPQUFDLENBQUMsQ0FBVyxLQUFLLENBQUMsR0FBRyxHQUFHLElBQUksTUFBTSxTQUN2Vix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCO1NBQTBCO1NBQUU7U0FBRSxPQUFPLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFNO1NBQU87Ozs7O1FBQVM7Ozs7O2lCQUMzRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtRQUFjO1FBQU0sYUFBYTtRQUFJLE9BQU8sSUFBSTtRQUFJLFdBQVcsTUFBTSxPQUFPO1NBQUUsR0FBRztVQUFNLElBQUksRUFBRSxPQUFPO1FBQU0sQ0FBQztPQUFJOzs7O2VBQzdILEtBSEs7Ozs7Y0FHTCxDQUNOO09BQ0EsT0FBTyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYTtPQUFPOzs7OztPQUN6Qyx3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUFtQyxNQUFLO2tCQUFTO09BQWlDOzs7OztPQUNwRyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFhO1FBQXNCOzs7O2tCQUNuRCx3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLFdBQVU7U0FBVyxlQUFlO1VBQUUsT0FBTyxPQUFPO1VBQUcsT0FBTyxFQUFFO1NBQUU7bUJBQUc7UUFBNEI7Ozs7Z0JBQ3BIOzs7Ozs7TUFDRDs7Ozs7YUFFTDs7Ozs7WUFDRjs7Ozs7O0VBQ0Q7Ozs7VUFDSDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW4udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgdHlwZSB7IEZvcm1FdmVudCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHR5cGUgeyBSb2xlIH0gZnJvbSAnLi4vZGF0YSdcbmltcG9ydCB7IHVzZUFwcCB9IGZyb20gJy4uL3N0b3JlJ1xuXG5jb25zdCBRVUlDSzogeyByb2xlOiBSb2xlOyBsYWJlbDogc3RyaW5nOyBpZDogc3RyaW5nOyBwdzogc3RyaW5nIH1bXSA9IFtcbiAgeyByb2xlOiAnY3VzdG9tZXInLCBsYWJlbDogJ0tow6FjaCBow6BuZycsIGlkOiAnMDkxMjM0NTY3OCcsIHB3OiAnTWF0a2hhdTEyMycgfSxcbiAgeyByb2xlOiAnc3RhZmYnLCBsYWJlbDogJ05ow6JuIHZpw6puIHRodSBuZ8OibicsIGlkOiAnMDkzMzQ0NTU2NicsIHB3OiAnTnYxMjM0NTYnIH0sXG4gIHsgcm9sZTogJ293bmVyJywgbGFiZWw6ICdDaOG7pyBo4buHIHRo4buRbmcgc8OibicsIGlkOiAnMDkwMDAwMDAwMScsIHB3OiAnQ2h1MTIzNDU2JyB9LFxuXVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMb2dpbigpIHtcbiAgY29uc3QgeyBsb2dpbiwgcmVnaXN0ZXIsIHRvYXN0IH0gPSB1c2VBcHAoKVxuICBjb25zdCBbdGFiLCBzZXRUYWJdID0gdXNlU3RhdGU8J2xvZ2luJyB8ICdyZWdpc3Rlcic+KCdsb2dpbicpXG4gIGNvbnN0IFtyb2xlLCBzZXRSb2xlXSA9IHVzZVN0YXRlPFJvbGU+KCdjdXN0b21lcicpXG4gIGNvbnN0IFtpZCwgc2V0SWRdID0gdXNlU3RhdGUoUVVJQ0tbMF0uaWQpXG4gIGNvbnN0IFtwdywgc2V0UHddID0gdXNlU3RhdGUoUVVJQ0tbMF0ucHcpXG4gIGNvbnN0IFtzaG93LCBzZXRTaG93XSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtlcnIsIHNldEVycl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3JlZywgc2V0UmVnXSA9IHVzZVN0YXRlKHsgbmFtZTogJycsIHBob25lOiAnJywgZW1haWw6ICcnLCBwYXNzd29yZDogJycsIGNvbmZpcm06ICcnIH0pXG5cbiAgY29uc3QgcGljayA9IChyOiBSb2xlKSA9PiB7XG4gICAgY29uc3QgcSA9IFFVSUNLLmZpbmQoKHgpID0+IHgucm9sZSA9PT0gcikhXG4gICAgc2V0Um9sZShyKTsgc2V0SWQocS5pZCk7IHNldFB3KHEucHcpOyBzZXRFcnIoJycpXG4gIH1cbiAgY29uc3Qgc3VibWl0TG9naW4gPSAoZTogRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgY29uc3QgcmVzID0gbG9naW4oaWQsIHB3LCByb2xlKVxuICAgIGlmICghcmVzLm9rKSBzZXRFcnIocmVzLmVycm9yID8/ICfEkMSDbmcgbmjhuq1wIHRo4bqldCBi4bqhaS4nKVxuICB9XG4gIGNvbnN0IHN1Ym1pdFJlZyA9IChlOiBGb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBpZiAoIXJlZy5uYW1lLnRyaW0oKSkgcmV0dXJuIHNldEVycignVnVpIGzDsm5nIG5o4bqtcCBo4buNIHbDoCB0w6puLicpXG4gICAgaWYgKCEvXjBcXGR7OX0kLy50ZXN0KHJlZy5waG9uZSkpIHJldHVybiBzZXRFcnIoJ1Phu5EgxJFp4buHbiB0aG/huqFpIHBo4bqjaSBn4buTbSAxMCBjaOG7ryBz4buRIHbDoCBi4bqvdCDEkeG6p3UgYuG6sW5nIDAuJylcbiAgICBpZiAocmVnLmVtYWlsICYmICEvXlxcUytAXFxTK1xcLlxcUyskLy50ZXN0KHJlZy5lbWFpbCkpIHJldHVybiBzZXRFcnIoJ8SQ4buLYSBjaOG7iSBlbWFpbCBraMO0bmcgaOG7o3AgbOG7hy4nKVxuICAgIGlmIChyZWcucGFzc3dvcmQubGVuZ3RoIDwgNikgcmV0dXJuIHNldEVycignTeG6rXQga2jhuql1IHBo4bqjaSBjw7MgdOG7kWkgdGhp4buDdSA2IGvDvSB04buxLicpXG4gICAgaWYgKHJlZy5wYXNzd29yZCAhPT0gcmVnLmNvbmZpcm0pIHJldHVybiBzZXRFcnIoJ03huq10IGto4bqpdSBuaOG6rXAgbOG6oWkga2jDtG5nIGto4bubcC4nKVxuICAgIHJlZ2lzdGVyKHJlZylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb2xcIiBzdHlsZT17eyBtaW5IZWlnaHQ6ICcxMDB2aCcgfX0+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImhkclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciBoZHItaW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnMTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9nby1tYXJrXCI+UzwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzRcIiBzdHlsZT17eyBwYWRkaW5nQm90dG9tOiAyLjUgfX0+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxvZ28tbmFtZVwiPlNwb3J0SHViPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsb2dvLXN1YlwiPkjhu4cgdGjhu5FuZyDEkeG6t3QgbOG7i2NoIHPDom4gdGjhu4MgdGhhbzwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLWJyYW5kLTUwKScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1ncmF5LTIwMCknLCBjb2xvcjogJ3ZhcigtLWJyYW5kLTcwMCknLCBwYWRkaW5nOiAnOHB4IDE0cHgnIH19XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2FzdCgnVnVpIGzDsm5nIMSRxINuZyBuaOG6rXAgxJHhu4MgdsOgbyB0cmFuZyBjaOG7pyDEkeG6t3Qgc8Oibi4nKX0+4oaQIFF1YXkgbOG6oWkgVHJhbmcgY2jhu6c8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiY29udGFpbmVyXCIgc3R5bGU9e3sgZmxleDogMSwgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgcGFkZGluZzogJzQ4cHggMTZweCcgfX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZDEyXCIgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJywgZ2FwOiAzMiwgYWxpZ25JdGVtczogJ2NlbnRlcicsIG1heFdpZHRoOiAxMTUyLCBtYXJnaW46ICcwIGF1dG8nIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGcyNFwiIHN0eWxlPXt7IGdyaWRDb2x1bW46ICdzcGFuIDUnIH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvIGNvbCBnMjBcIiBzdHlsZT17eyBwYWRkaW5nOiAyOCwgYmFja2dyb3VuZDogJ3ZhcigtLWJyYW5kLTgwMCknIH19PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZVwiIHN0eWxlPXt7IGFsaWduU2VsZjogJ2ZsZXgtc3RhcnQnLCBiYWNrZ3JvdW5kOiAncmdiYSg0LDEyMCw4NywuOCknLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSgxNiwxODUsMTI5LC40KScsIGNvbG9yOiAndmFyKC0tYnJhbmQtMTAwKScgfX0+4pq9IMSQ4bq3dCBzw6JuIG5oYW5oIGNow7NuZyDigKIgR2nhu68gbOG7i2NoIHThu6ljIHRow6w8L3NwYW4+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0MjQgdzgwMFwiIHN0eWxlPXt7IGxpbmVIZWlnaHQ6ICczM3B4JywgcGFkZGluZ1RvcDogMSB9fT7EkOG6t3QgbOG7i2NoIHPDom4gdGjhu4MgdGhhbyBt4buNaSBsw7pjLCBt4buNaSBuxqFpIGPDuW5nIFNwb3J0SHViPC9oMT5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidDE0XCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1icmFuZC0xMDApJywgbGluZUhlaWdodDogJzIyLjc1cHgnIH19PlxuICAgICAgICAgICAgICAgIFRyYSBj4bupdSBraHVuZyBnaeG7nSB0cuG7kW5nIHRoZW8gdGjhu51pIGdpYW4gdGjhu7FjIHThuqFpIDMgY2hpIG5ow6FuaCBIw6AgTuG7mWksIHRoYW5oIHRvw6FuIMSR4bq3dCBj4buNYyBxdWEgbcOjIFFSIHRp4buHbiBs4bujaSB2w6Agbmjhuq1uIHRpbiBuaOG6r24gbmjhuq9jIGzhu4tjaCB04buxIMSR4buZbmcgdHLGsOG7m2MgZ2nhu50gYsOzbmcgbMSDbiAxIHRp4bq/bmcuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzEyXCIgc3R5bGU9e3sgYm9yZGVyVG9wOiAnMXB4IHNvbGlkIHZhcigtLWJyYW5kLTcwMCknLCBwYWRkaW5nVG9wOiAxNyB9fT5cbiAgICAgICAgICAgICAgICB7WydIaeG7g24gdGjhu4sgYuG6o25nIGzhu4tjaCB0cuG7sWMgcXVhbiwgYsOhbyBnacOhIHLDtSByw6BuZyB0aGVvIHThu6tuZyBraHVuZyBnaeG7nScsICdI4buXIHRy4bujIMSR4bq3dCBj4buNYyBnaeG7ryBjaOG7lyAzMCUgaG/hurdjIHRoYW5oIHRvw6FuIHRy4buNbiBnw7NpIDEwMCUnLCAnTmhp4buBdSDGsHUgxJHDo2kgZ2nhuqNtIGdpw6Ega2h1bmcgZ2nhu50gdsOgbmcgY2hvIGjhu5lpIHZpw6puIHRow6JuIHRoaeG6v3QnXS5tYXAoKHQpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGcxMlwiIGtleT17dH0+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNlbnRlciB0MTIgdzcwMFwiIHN0eWxlPXt7IHdpZHRoOiAyNCwgaGVpZ2h0OiAyNCwgYm9yZGVyUmFkaXVzOiA4LCBiYWNrZ3JvdW5kOiAndmFyKC0tYnJhbmQtNjAwKScsIGZsZXg6ICdub25lJyB9fT7inJM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMlwiPnt0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHJvdyBiZXR3ZWVuIGcxMlwiIHN0eWxlPXt7IGJvcmRlclJhZGl1czogMTYgfX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sIGcyXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidDEyIHc3MDAgYy1pbmtcIj5D4bqnbiBo4buXIHRy4bujIG3hu58ga2jDs2EgdMOgaSBraG/huqNuIGhv4bq3YyDEkeG6t3Qgc8OibiBj4buRIMSR4buLbmg/PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj5MacOqbiBo4buHIHRy4buxYyB0aeG6v3AgcXXhuqNuIGzDvSBo4buHIHRo4buRbmcgc8OibiAoMDU6MDAg4oCTIDIzOjAwIGjDoG5nIG5nw6B5KTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNoaXAtYm94IHc4MDAgYy1icmFuZFwiIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDgwMCB9fT4xOTAwIDY4ODY8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBjYXJkLXJhaXNlXCIgc3R5bGU9e3sgZ3JpZENvbHVtbjogJ3NwYW4gNycsIHBhZGRpbmc6ICcwIDAgMzJweCcsIG92ZXJmbG93OiAnaGlkZGVuJyB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC10YWJzXCI+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPXtgYXV0aC10YWIke3RhYiA9PT0gJ2xvZ2luJyA/ICcgb24nIDogJyd9YH0gb25DbGljaz17KCkgPT4geyBzZXRUYWIoJ2xvZ2luJyk7IHNldEVycignJykgfX0+xJDEg25nIG5o4bqtcCB0w6BpIGtob+G6o248L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9e2BhdXRoLXRhYiR7dGFiID09PSAncmVnaXN0ZXInID8gJyBvbicgOiAnJ31gfSBvbkNsaWNrPXsoKSA9PiB7IHNldFRhYigncmVnaXN0ZXInKTsgc2V0RXJyKCcnKSB9fT7EkMSDbmcga8O9IGjhu5lpIHZpw6puIG3hu5tpPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge3RhYiA9PT0gJ2xvZ2luJyA/IChcbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiY29sIGcyMFwiIHN0eWxlPXt7IHBhZGRpbmc6ICczMnB4IDMycHggMCcgfX0gb25TdWJtaXQ9e3N1Ym1pdExvZ2lufT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnMlwiPlxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInQxOCB3ODAwIGMtaW5rXCI+Q2jDoG8gbeG7q25nIGLhuqFuIHF1YXkgdHLhu58gbOG6oWkhPC9oMj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj5OaOG6rXAgc+G7kSDEkWnhu4duIHRob+G6oWkgaG/hurdjIGVtYWlsIGPhu6dhIGLhuqFuIMSR4buDIGLhuq90IMSR4bqndSDEkeG6t3Qgc8OibiBob+G6t2MgdsOgbyBjYSBsw6BtIHZp4buHYy48L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wgZzE2XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibGFiZWxcIiBodG1sRm9yPVwibG9naW4taWRlbnRpdHlcIj5T4buRIMSRaeG7h24gdGhv4bqhaSBob+G6t2MgRW1haWwgPHNwYW4gY2xhc3NOYW1lPVwicmVxXCI+Kjwvc3Bhbj48L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJsb2dpbi1pZGVudGl0eVwiIGNsYXNzTmFtZT1cImlucHV0XCIgdmFsdWU9e2lkfSBvbkNoYW5nZT17KGUpID0+IHNldElkKGUudGFyZ2V0LnZhbHVlKX0gYXV0b0NvbXBsZXRlPVwidXNlcm5hbWVcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiZXR3ZWVuXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiA2IH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJsYWJlbFwiIHN0eWxlPXt7IG1hcmdpbjogMCB9fSBodG1sRm9yPVwibG9naW4tcGFzc3dvcmRcIj5N4bqtdCBraOG6qXUgPHNwYW4gY2xhc3NOYW1lPVwicmVxXCI+Kjwvc3Bhbj48L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImxpbmstYnRuXCIgb25DbGljaz17KCkgPT4gc2V0U2hvdygocykgPT4gIXMpfT5IaeG7h24gLyDhuqhuPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJsb2dpbi1wYXNzd29yZFwiIGNsYXNzTmFtZT1cImlucHV0XCIgdHlwZT17c2hvdyA/ICd0ZXh0JyA6ICdwYXNzd29yZCd9IHZhbHVlPXtwd30gb25DaGFuZ2U9eyhlKSA9PiBzZXRQdyhlLnRhcmdldC52YWx1ZSl9IGF1dG9Db21wbGV0ZT1cImN1cnJlbnQtcGFzc3dvcmRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpbnQgY29sIGc4XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiB3NzAwIGMtczgwMFwiPlTDoGkga2hv4bqjbiDEkcSDbmcgbmjhuq1wIG5oYW5oOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZzhcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7UVVJQ0subWFwKChxKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwga2V5PXtxLnJvbGV9IGNsYXNzTmFtZT1cInJhZGlvLWNhcmQgZjFcIiBzdHlsZT17eyBwYWRkaW5nOiAxMCB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJyYWRpb1wiIG5hbWU9XCJxdWljay1yb2xlXCIgY2hlY2tlZD17cm9sZSA9PT0gcS5yb2xlfSBvbkNoYW5nZT17KCkgPT4gcGljayhxLnJvbGUpfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57cS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAge2VyciAmJiA8cCBjbGFzc05hbWU9XCJmaWVsZC1lcnJcIj57ZXJyfTwvcD59XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tbGcgYnRuLWJsb2NrXCIgdHlwZT1cInN1Ym1pdFwiPsSQxINuZyBuaOG6rXAgbmdheTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gdG9wLXJ1bGVcIiBzdHlsZT17eyBwYWRkaW5nVG9wOiAxNiB9fT5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiBjLXM3MDBcIj5C4bqhbiBjaMawYSBjw7MgdMOgaSBraG/huqNuIMSR4bq3dCBzw6JuPzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImxpbmstYnRuXCIgb25DbGljaz17KCkgPT4geyBzZXRUYWIoJ3JlZ2lzdGVyJyk7IHNldEVycignJykgfX0+VOG6oW8gdMOgaSBraG/huqNuIG3hu5tpIG1p4buFbiBwaMOtIOKGkjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJjb2wgZzE2XCIgc3R5bGU9e3sgcGFkZGluZzogJzMycHggMzJweCAwJyB9fSBvblN1Ym1pdD17c3VibWl0UmVnfT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbCBnMlwiPlxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInQxOCB3ODAwIGMtaW5rXCI+VHLhu58gdGjDoG5oIGjhu5lpIHZpw6puIFNwb3J0SHViPC9oMj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInQxMiBjLXM2MDBcIj7EkMSDbmcga8O9IG1p4buFbiBwaMOtIMSR4buDIMSR4bq3dCBzw6JuIG5oYW5oLCBuaOG6rW4gxrB1IMSRw6NpIGdp4budIHbDoG5nIHbDoCB0aGVvIGTDtWkgbOG7i2NoIMSR4bq3dCBj4bunYSBi4bqhbi48L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgeyhbWyduYW1lJywgJ0jhu40gdsOgIHTDqm4nLCAnTmd1eeG7hW4gVsSDbiBBbicsICd0ZXh0JywgdHJ1ZV0sIFsncGhvbmUnLCAnU+G7kSDEkWnhu4duIHRob+G6oWknLCAnMDkxMjM0NTY3OCcsICd0ZWwnLCB0cnVlXSwgWydlbWFpbCcsICfEkOG7i2EgY2jhu4kgZW1haWwnLCAnYmFuQGV4YW1wbGUuY29tJywgJ2VtYWlsJywgZmFsc2VdLCBbJ3Bhc3N3b3JkJywgJ03huq10IGto4bqpdScsICdU4buRaSB0aGnhu4N1IDYga8O9IHThu7EnLCAncGFzc3dvcmQnLCB0cnVlXSwgWydjb25maXJtJywgJ05o4bqtcCBs4bqhaSBt4bqtdCBraOG6qXUnLCAnTmjhuq1wIGzhuqFpIG3huq10IGto4bqpdScsICdwYXNzd29yZCcsIHRydWVdXSBhcyBjb25zdCkubWFwKChbaywgbCwgcGgsIHR5cGUsIHJlcV0pID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtrfT5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImxhYmVsXCI+e2x9IHtyZXEgJiYgPHNwYW4gY2xhc3NOYW1lPVwicmVxXCI+Kjwvc3Bhbj59PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IGNsYXNzTmFtZT1cImlucHV0XCIgdHlwZT17dHlwZX0gcGxhY2Vob2xkZXI9e3BofSB2YWx1ZT17cmVnW2tdfSBvbkNoYW5nZT17KGUpID0+IHNldFJlZyh7IC4uLnJlZywgW2tdOiBlLnRhcmdldC52YWx1ZSB9KX0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIHtlcnIgJiYgPHAgY2xhc3NOYW1lPVwiZmllbGQtZXJyXCI+e2Vycn08L3A+fVxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1sZyBidG4tYmxvY2tcIiB0eXBlPVwic3VibWl0XCI+xJDEg25nIGvDvSAmIELhuq90IMSR4bqndSDEkeG6t3Qgc8OibjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGJldHdlZW4gdG9wLXJ1bGVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInQxMiBjLXM3MDBcIj7EkMOjIGPDsyB0w6BpIGtob+G6o24/PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwibGluay1idG5cIiBvbkNsaWNrPXsoKSA9PiB7IHNldFRhYignbG9naW4nKTsgc2V0RXJyKCcnKSB9fT5RdWF5IGzhuqFpIMSRxINuZyBuaOG6rXAg4oaSPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9tYWluPlxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=